// ===----------------------------------------------------------------------=== //
//
// This source file is part of the DeviceKit open source project
//
// Copyright © 2014 - 2018 Dennis Weissmann and the DeviceKit project authors
//
// License: https://github.com/dennisweissmann/DeviceKit/blob/master/LICENSE
// Contributors: https://github.com/dennisweissmann/DeviceKit#contributors
//
// ===----------------------------------------------------------------------=== //

@testable import DeviceKit
import XCTest

class DeviceKitTests: XCTestCase {

  let device = Device.current

  #if os(iOS) || os(watchOS)
  func testSeptember2026Devices() {
    struct ExpectedDevice {
      let model: Device
      let identifiers: [String]
      let diagonal: Double
      let ratio: (Double, Double)
      let ppi: Int
    }
    #if os(iOS)
    let models: [ExpectedDevice] = [
      ExpectedDevice(model: .iPhone18Pro, identifiers: ["iPhone19,2"], diagonal: 6.3, ratio: (9, 19.5), ppi: 460),
      ExpectedDevice(model: .iPhone18ProMax, identifiers: ["iPhone19,3", "iPhone19,7"], diagonal: 6.9, ratio: (9, 19.5), ppi: 460)
    ]
    let chip = Device.CPU.a20Pro
    XCTAssertEqual(chip.description, "A20 Pro")
    // The deferred model and unverified identifiers must remain unknown.
    for identifier in ["iPhone19,1", "iPhone19,4", "iPhone19,5", "iPhone19,6", "placeholder:iPhone18Pro", "placeholder:iPhone18ProMax"] {
      XCTAssertEqual(Device.mapToDevice(identifier: identifier), .unknown(identifier))
    }
    #else
    let models: [ExpectedDevice] = [
      ExpectedDevice(model: .appleWatchSeries12_42mm, identifiers: ["Watch8,2", "Watch8,4"], diagonal: 1.79, ratio: (374, 446), ppi: 326),
      ExpectedDevice(model: .appleWatchSeries12_46mm, identifiers: ["Watch8,3", "Watch8,5"], diagonal: 1.99, ratio: (416, 496), ppi: 326),
      ExpectedDevice(model: .appleWatchUltra4, identifiers: ["Watch8,1"], diagonal: 2.04, ratio: (422, 514), ppi: 326)
    ]
    let chip = Device.CPU.s11
    XCTAssertEqual(chip.description, "S11")
    for identifier in ["Watch8,6", "Watch8,7", "Watch8,8", "Watch8,9", "placeholder:appleWatchSeries12_42mm", "placeholder:appleWatchSeries12_46mm", "placeholder:appleWatchUltra4"] {
      XCTAssertEqual(Device.mapToDevice(identifier: identifier), .unknown(identifier))
    }
    #endif
    for expected in models {
      let model = expected.model
      for identifier in expected.identifiers {
        XCTAssertEqual(Device.mapToDevice(identifier: identifier), model, identifier)
      }
      #if os(iOS)
      XCTAssertTrue(model.isPhone)
      XCTAssertFalse(model.isPad)
      #endif
      XCTAssertTrue(Device.allRealDevices.contains(model))
      XCTAssertTrue(Device.allSimulators.contains(.simulator(model)))
      for variant in [model, .simulator(model)] {
        XCTAssertEqual(variant.cpu, chip)
        XCTAssertEqual(variant.diagonal, expected.diagonal)
        XCTAssertEqual(variant.screenRatio.width, expected.ratio.0)
        XCTAssertEqual(variant.screenRatio.height, expected.ratio.1)
        XCTAssertEqual(variant.ppi, expected.ppi)
        #if os(iOS)
        XCTAssertTrue(variant.supportsWirelessCharging)
        XCTAssertTrue(variant.hasEsimSupport)
        XCTAssertTrue(variant.hasDualEsimSupport)
        #endif
      }
    }
  }
  #endif

  func testDeviceSimulator() {
    #if os(macOS)
    XCTAssertFalse(device.isOneOf(Device.allSimulators))
    #else
    XCTAssertTrue(device.isOneOf(Device.allSimulators))
    #endif
  }

  func testIsSimulator() {
    #if os(macOS)
    XCTAssertFalse(device.isSimulator)
    #else
    XCTAssertTrue(device.isSimulator)
    #endif
  }

  func testDeviceDescription() {
    #if os(macOS)
    #else
    XCTAssertTrue(device.description.hasPrefix("Simulator"))
    XCTAssertTrue(device.description.contains("iPhone")
      || device.description.contains("iPad")
      || device.description.contains("iPod")
      || device.description.contains("TV")
      || device.description.contains("Apple Watch"))
    #endif
  }

  func testIsCanvas() {
    #if os(iOS)
    let otherDevice: Device = device == .iPhone14Pro ? .iPhone14ProMax : .iPhone14Pro
    #elseif os(tvOS)
    let otherDevice: Device = device == .appleTVHD ? .appleTV4K : .appleTVHD
    #elseif os(watchOS)
    let otherDevice: Device = device == .appleWatchUltra ? .appleWatchSeries8_41mm : .appleWatchUltra
    #else
    let otherDevice: Device = .unknown("mac")
    #endif
    XCTAssertEqual(otherDevice.isCanvas, nil)
    XCTAssertEqual(device.isCanvas, false)
  }

  #if os(iOS) || os(tvOS)
  func testDeviceCPU() {
  #if os(iOS)
    XCTAssertEqual(Device.iPhone12Mini.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPhone12.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPhone12Pro.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPhone12ProMax.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPhone13Mini.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone13.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone13Pro.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone13ProMax.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone14.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone14Plus.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPhone14Pro.cpu, Device.CPU.a16Bionic)
    XCTAssertEqual(Device.iPhone14ProMax.cpu, Device.CPU.a16Bionic)

    XCTAssertEqual(Device.iPad8.cpu, Device.CPU.a12Bionic)
    XCTAssertEqual(Device.iPad9.cpu, Device.CPU.a13Bionic)
    XCTAssertEqual(Device.iPad10.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPadAir3.cpu, Device.CPU.a12Bionic)
    XCTAssertEqual(Device.iPadAir4.cpu, Device.CPU.a14Bionic)
    XCTAssertEqual(Device.iPadAir5.cpu, Device.CPU.m1)
    XCTAssertEqual(Device.iPadMini4.cpu, Device.CPU.a8)
    XCTAssertEqual(Device.iPadMini5.cpu, Device.CPU.a12Bionic)
    XCTAssertEqual(Device.iPadMini6.cpu, Device.CPU.a15Bionic)
    XCTAssertEqual(Device.iPadMiniA17Pro.cpu, Device.CPU.a17Pro)
    XCTAssertEqual(Device.iPadPro11Inch.cpu, Device.CPU.a12XBionic)
    XCTAssertEqual(Device.iPadPro11Inch2.cpu, Device.CPU.a12ZBionic)
    XCTAssertEqual(Device.iPadPro11Inch3.cpu, Device.CPU.m1)
    XCTAssertEqual(Device.iPadPro11Inch4.cpu, Device.CPU.m2)
    XCTAssertEqual(Device.iPadPro11M4.cpu, Device.CPU.m4)
    XCTAssertEqual(Device.iPadPro13M4.cpu, Device.CPU.m4)
    XCTAssertEqual(Device.iPadPro11M5.cpu, Device.CPU.m5)
    XCTAssertEqual(Device.iPadPro13M5.cpu, Device.CPU.m5)
    XCTAssertEqual(Device.iPhone17e.cpu, Device.CPU.a19)
    XCTAssertEqual(Device.iPadAir11M4.cpu, Device.CPU.m4)
    XCTAssertEqual(Device.iPadAir13M4.cpu, Device.CPU.m4)
  #elseif os(tvOS)
    XCTAssertEqual(Device.appleTVHD.cpu, Device.CPU.a8)
    XCTAssertEqual(Device.appleTV4K.cpu, Device.CPU.a10XFusion)
    XCTAssertEqual(Device.appleTV4K2.cpu, Device.CPU.a12Bionic)
    XCTAssertEqual(Device.appleTV4K3.cpu, Device.CPU.a15Bionic)
  #endif
  }

  func testCPUDescription() {
    XCTAssertEqual(Device.CPU.a15Bionic.description, "A15 Bionic")
    XCTAssertEqual(Device.CPU.a16Bionic.description, "A16 Bionic")
    XCTAssertEqual(Device.CPU.m1.description, "M1")
    XCTAssertEqual(Device.CPU.m2.description, "M2")
    XCTAssertEqual(Device.CPU.m4.description, "M4")
    XCTAssertEqual(Device.CPU.m5.description, "M5")
  }
  #endif

  // MARK: - iOS
  #if os(iOS)

  func testIsPhoneIsPadIsPod() {
    // Test for https://github.com/devicekit/DeviceKit/issues/165 to prevent it from happening in the future.

    if UIDevice.current.userInterfaceIdiom == .pad {
      XCTAssertTrue(device.isPad)
      XCTAssertFalse(device.isPhone)
      XCTAssertFalse(device.isPod)
    } else if UIDevice.current.userInterfaceIdiom == .phone {
      XCTAssertFalse(device.isPad)
      if device.description.contains("iPod") {
        XCTAssertFalse(device.isPhone)
        XCTAssertTrue(device.isPod)
      } else {
        XCTAssertTrue(device.isPhone)
        XCTAssertFalse(device.isPod)
      }
    }

    for pad in Device.allPads {
      XCTAssertTrue(pad.isPad)
      XCTAssertFalse(pad.isPhone)
      XCTAssertFalse(pad.isPod)
    }
    for phone in Device.allPhones {
      XCTAssertFalse(phone.isPad)
      XCTAssertTrue(phone.isPhone)
      XCTAssertFalse(phone.isPod)
    }
    for pod in Device.allPods {
      XCTAssertFalse(pod.isPad)
      XCTAssertFalse(pod.isPhone)
      XCTAssertTrue(pod.isPod)
    }
  }

  func testSystemName() {
    if UIDevice.current.userInterfaceIdiom == .pad {
      XCTAssertEqual(device.systemName, "iPadOS")
    } else if UIDevice.current.userInterfaceIdiom == .phone {
      XCTAssertEqual(device.systemName, "iOS")
    }
  }

  func testBattery() {
    XCTAssertTrue(Device.BatteryState.full > Device.BatteryState.charging(100))
    XCTAssertTrue(Device.BatteryState.charging(75) != Device.BatteryState.unplugged(75))
    XCTAssertTrue(Device.BatteryState.unplugged(2) > Device.BatteryState.charging(1))
  }

  func testMapFromIdentifier() {
    XCTAssertEqual(Device.mapToDevice(identifier: "iPod5,1"), .iPodTouch5)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPod7,1"), .iPodTouch6)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone3,1"), .iPhone4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone3,2"), .iPhone4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone3,3"), .iPhone4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone4,1"), .iPhone4s)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone5,1"), .iPhone5)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone5,2"), .iPhone5)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone5,3"), .iPhone5c)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone5,4"), .iPhone5c)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone6,1"), .iPhone5s)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone6,2"), .iPhone5s)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone7,2"), .iPhone6)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone7,1"), .iPhone6Plus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone8,1"), .iPhone6s)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone8,2"), .iPhone6sPlus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone9,1"), .iPhone7)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone9,3"), .iPhone7)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone9,2"), .iPhone7Plus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone9,4"), .iPhone7Plus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone8,4"), .iPhoneSE)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,1"), .iPhone8)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,4"), .iPhone8)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,2"), .iPhone8Plus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,5"), .iPhone8Plus)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,3"), .iPhoneX)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone10,6"), .iPhoneX)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone11,2"), .iPhoneXS)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone11,4"), .iPhoneXSMax)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone11,6"), .iPhoneXSMax)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone11,8"), .iPhoneXR)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,1"), .iPad2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,2"), .iPad2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,3"), .iPad2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,4"), .iPad2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,1"), .iPad3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,2"), .iPad3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,3"), .iPad3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,4"), .iPad4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,5"), .iPad4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad3,6"), .iPad4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,1"), .iPadAir)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,2"), .iPadAir)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,3"), .iPadAir)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad5,3"), .iPadAir2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad5,4"), .iPadAir2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,11"), .iPad5)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,12"), .iPad5)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,5"), .iPadMini)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,6"), .iPadMini)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad2,7"), .iPadMini)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,4"), .iPadMini2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,5"), .iPadMini2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,6"), .iPadMini2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,7"), .iPadMini3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,8"), .iPadMini3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad4,9"), .iPadMini3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad5,1"), .iPadMini4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad5,2"), .iPadMini4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,3"), .iPadPro9Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,4"), .iPadPro9Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,7"), .iPadPro12Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad6,8"), .iPadPro12Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad7,1"), .iPadPro12Inch2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad7,2"), .iPadPro12Inch2)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad7,3"), .iPadPro10Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad7,4"), .iPadPro10Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,1"), .iPadPro11Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,2"), .iPadPro11Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,3"), .iPadPro11Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,4"), .iPadPro11Inch)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,5"), .iPadPro12Inch3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,6"), .iPadPro12Inch3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,7"), .iPadPro12Inch3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad8,8"), .iPadPro12Inch3)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPhone18,5"), .iPhone17e)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad16,8"), .iPadAir11M4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad16,9"), .iPadAir11M4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad16,10"), .iPadAir13M4)
    XCTAssertEqual(Device.mapToDevice(identifier: "iPad16,11"), .iPadAir13M4)
  }

  func testScreenRatio() {
    XCTAssertTrue(Device.iPodTouch5.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPodTouch6.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone4.screenRatio == (width: 2, height: 3))
    XCTAssertTrue(Device.iPhone4s.screenRatio == (width: 2, height: 3))
    XCTAssertTrue(Device.iPhone5.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone5c.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone5s.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone6.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone6Plus.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone6s.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone6sPlus.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone7.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone7Plus.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhoneSE.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhoneSE2.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone8.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhone8Plus.screenRatio == (width: 9, height: 16))
    XCTAssertTrue(Device.iPhoneX.screenRatio == (width: 9, height: 19.5))
    XCTAssertTrue(Device.iPhoneXS.screenRatio == (width: 9, height: 19.5))
    XCTAssertTrue(Device.iPhoneXSMax.screenRatio == (width: 9, height: 19.5))
    XCTAssertTrue(Device.iPhoneXR.screenRatio == (width: 9, height: 19.5))
    XCTAssertTrue(Device.iPad2.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPad3.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPad4.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadAir.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadAir2.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPad5.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadMini.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadMini2.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadMini3.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadMini4.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadPro9Inch.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadPro12Inch.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadPro12Inch2.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadPro10Inch.screenRatio == (width: 3, height: 4))
    XCTAssertTrue(Device.iPadPro11Inch.screenRatio == (width: 139, height: 199))
    XCTAssertTrue(Device.iPadPro12Inch3.screenRatio == (width: 512, height: 683))

    XCTAssertTrue(Device.simulator(device).screenRatio == device.screenRatio)
    XCTAssertTrue(Device.unknown(UUID().uuidString).screenRatio == (width: -1, height: -1))
  }

  func testDiagonal() {
    XCTAssertEqual(Device.iPhone4.diagonal, 3.5)
    XCTAssertEqual(Device.iPhone4s.diagonal, 3.5)

    XCTAssertEqual(Device.iPodTouch5.diagonal, 4)
    XCTAssertEqual(Device.iPodTouch6.diagonal, 4)
    XCTAssertEqual(Device.iPhone5.diagonal, 4)
    XCTAssertEqual(Device.iPhone5c.diagonal, 4)
    XCTAssertEqual(Device.iPhone5s.diagonal, 4)
    XCTAssertEqual(Device.iPhoneSE.diagonal, 4)

    XCTAssertEqual(Device.iPhone6.diagonal, 4.7)
    XCTAssertEqual(Device.iPhone6s.diagonal, 4.7)
    XCTAssertEqual(Device.iPhone7.diagonal, 4.7)
    XCTAssertEqual(Device.iPhone8.diagonal, 4.7)

    XCTAssertEqual(Device.iPhone6Plus.diagonal, 5.5)
    XCTAssertEqual(Device.iPhone6sPlus.diagonal, 5.5)
    XCTAssertEqual(Device.iPhone7Plus.diagonal, 5.5)
    XCTAssertEqual(Device.iPhone8Plus.diagonal, 5.5)
    XCTAssertEqual(Device.iPhoneX.diagonal, 5.8)
    XCTAssertEqual(Device.iPhoneXS.diagonal, 5.8)
    XCTAssertEqual(Device.iPhoneXSMax.diagonal, 6.5)
    XCTAssertEqual(Device.iPhoneXR.diagonal, 6.1)

    XCTAssertEqual(Device.iPad2.diagonal, 9.7)
    XCTAssertEqual(Device.iPad3.diagonal, 9.7)
    XCTAssertEqual(Device.iPad4.diagonal, 9.7)
    XCTAssertEqual(Device.iPadAir.diagonal, 9.7)
    XCTAssertEqual(Device.iPadAir2.diagonal, 9.7)
    XCTAssertEqual(Device.iPad5.diagonal, 9.7)

    XCTAssertEqual(Device.iPadMini.diagonal, 7.9)
    XCTAssertEqual(Device.iPadMini2.diagonal, 7.9)
    XCTAssertEqual(Device.iPadMini3.diagonal, 7.9)
    XCTAssertEqual(Device.iPadMini4.diagonal, 7.9)

    XCTAssertEqual(Device.iPadPro9Inch.diagonal, 9.7)
    XCTAssertEqual(Device.iPadPro12Inch.diagonal, 12.9)
    XCTAssertEqual(Device.iPadPro12Inch2.diagonal, 12.9)
    XCTAssertEqual(Device.iPadPro10Inch.diagonal, 10.5)
    XCTAssertEqual(Device.iPadPro11Inch.diagonal, 11.0)
    XCTAssertEqual(Device.iPadPro12Inch3.diagonal, 12.9)

    XCTAssertEqual(Device.simulator(.iPadPro10Inch).diagonal, 10.5)
    XCTAssertEqual(Device.unknown(UUID().uuidString).diagonal, -1)
  }

  func testDescription() {
    XCTAssertEqual(Device.iPodTouch5.description, "iPod touch (5th generation)")
    XCTAssertEqual(Device.iPodTouch6.description, "iPod touch (6th generation)")
    XCTAssertEqual(Device.iPodTouch7.description, "iPod touch (7th generation)")
    XCTAssertEqual(Device.iPhone4.description, "iPhone 4")
    XCTAssertEqual(Device.iPhone4s.description, "iPhone 4s")
    XCTAssertEqual(Device.iPhone5.description, "iPhone 5")
    XCTAssertEqual(Device.iPhone5c.description, "iPhone 5c")
    XCTAssertEqual(Device.iPhone5s.description, "iPhone 5s")
    XCTAssertEqual(Device.iPhone6.description, "iPhone 6")
    XCTAssertEqual(Device.iPhone6Plus.description, "iPhone 6 Plus")
    XCTAssertEqual(Device.iPhone6s.description, "iPhone 6s")
    XCTAssertEqual(Device.iPhone6sPlus.description, "iPhone 6s Plus")
    XCTAssertEqual(Device.iPhone7.description, "iPhone 7")
    XCTAssertEqual(Device.iPhone7Plus.description, "iPhone 7 Plus")
    XCTAssertEqual(Device.iPhoneSE.description, "iPhone SE")
    XCTAssertEqual(Device.iPhone8.description, "iPhone 8")
    XCTAssertEqual(Device.iPhone8Plus.description, "iPhone 8 Plus")
    XCTAssertEqual(Device.iPhoneX.description, "iPhone X")
    XCTAssertEqual(Device.iPhoneXS.description, "iPhone Xs")
    XCTAssertEqual(Device.iPhoneXSMax.description, "iPhone Xs Max")
    XCTAssertEqual(Device.iPhoneXR.description, "iPhone Xʀ")
    XCTAssertEqual(Device.iPad2.description, "iPad 2")
    XCTAssertEqual(Device.iPad3.description, "iPad (3rd generation)")
    XCTAssertEqual(Device.iPad4.description, "iPad (4th generation)")
    XCTAssertEqual(Device.iPadAir.description, "iPad Air")
    XCTAssertEqual(Device.iPadAir2.description, "iPad Air 2")
    XCTAssertEqual(Device.iPad5.description, "iPad (5th generation)")
    XCTAssertEqual(Device.iPad6.description, "iPad (6th generation)")
    XCTAssertEqual(Device.iPadAir3.description, "iPad Air (3rd generation)")
    XCTAssertEqual(Device.iPadMini.description, "iPad mini")
    XCTAssertEqual(Device.iPadMini2.description, "iPad mini 2")
    XCTAssertEqual(Device.iPadMini3.description, "iPad mini 3")
    XCTAssertEqual(Device.iPadMini4.description, "iPad mini 4")
    XCTAssertEqual(Device.iPadMini5.description, "iPad mini (5th generation)")
    XCTAssertEqual(Device.iPadPro9Inch.description, "iPad Pro (9.7-inch)")
    XCTAssertEqual(Device.iPadPro12Inch.description, "iPad Pro (12.9-inch)")
    XCTAssertEqual(Device.iPadPro12Inch2.description, "iPad Pro (12.9-inch) (2nd generation)")
    XCTAssertEqual(Device.iPadPro10Inch.description, "iPad Pro (10.5-inch)")
    XCTAssertEqual(Device.iPadPro11Inch.description, "iPad Pro (11-inch)")
    XCTAssertEqual(Device.iPadPro12Inch3.description, "iPad Pro (12.9-inch) (3rd generation)")
    XCTAssertEqual(Device.simulator(Device.iPadPro10Inch).description, "Simulator (\(Device.iPadPro10Inch))")
    let uuid = UUID().uuidString
    XCTAssertEqual(Device.unknown(uuid).description, uuid)
  }

  func testSafeDescription() {
    for device in Device.allRealDevices {
      switch device {
      case .iPhoneXR, .iPhoneXS, .iPhoneXSMax:
        XCTAssertNotEqual(device.description, device.safeDescription)
      default:
        XCTAssertEqual(device.description, device.safeDescription)
      }
    }
  }

  func testIsPad() {
    Device.allPads.forEach { XCTAssertTrue($0.isPad) }
  }

  // Test that all the ppi values for applicable devices match the public information available at wikipedia.
  // Non-applicable devices return nil.
  func testPPI() {
    // swiftlint:disable comma
    assertEqualDeviceAndSimulator(device: Device.iPodTouch5,      property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPodTouch6,      property: \Device.ppi, value: 326)

    assertEqualDeviceAndSimulator(device: Device.iPhone4,         property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone4s,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone5,         property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone5c,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone5s,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone6,         property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone6Plus,     property: \Device.ppi, value: 401)
    assertEqualDeviceAndSimulator(device: Device.iPhone6s,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone6sPlus,    property: \Device.ppi, value: 401)
    assertEqualDeviceAndSimulator(device: Device.iPhone7,         property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone7Plus,     property: \Device.ppi, value: 401)
    assertEqualDeviceAndSimulator(device: Device.iPhoneSE,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhoneSE2,       property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone8,         property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhone8Plus,     property: \Device.ppi, value: 401)
    assertEqualDeviceAndSimulator(device: Device.iPhoneX,         property: \Device.ppi, value: 458)
    assertEqualDeviceAndSimulator(device: Device.iPhoneXR,        property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPhoneXS,        property: \Device.ppi, value: 458)
    assertEqualDeviceAndSimulator(device: Device.iPhoneXSMax,     property: \Device.ppi, value: 458)

    assertEqualDeviceAndSimulator(device: Device.iPad2,           property: \Device.ppi, value: 132)
    assertEqualDeviceAndSimulator(device: Device.iPad3,           property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPad4,           property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadAir,         property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadAir2,        property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPad5,           property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPad6,           property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadMini,        property: \Device.ppi, value: 163)
    assertEqualDeviceAndSimulator(device: Device.iPadMini2,       property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPadMini3,       property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPadMini4,       property: \Device.ppi, value: 326)
    assertEqualDeviceAndSimulator(device: Device.iPadPro9Inch,    property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadPro12Inch,   property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadPro12Inch2,  property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadPro10Inch,   property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadPro11Inch,   property: \Device.ppi, value: 264)
    assertEqualDeviceAndSimulator(device: Device.iPadPro12Inch3,  property: \Device.ppi, value: 264)
    // swiftlint:enable comma
  }

  func assertEqualDeviceAndSimulator<Value>(device: Device,
                                            property: KeyPath<Device, Value>,
                                            value: Value,
                                            file: StaticString = #file,
                                            line: UInt = #line) where Value: Equatable {
    let simulator = Device.simulator(device)
    XCTAssertTrue(device[keyPath: property] == value, file: file, line: line)
    XCTAssertTrue(simulator[keyPath: property] == value, file: file, line: line)
  }

  func testIsPlusSized() {
    XCTAssertEqual(Device.allPlusSizedDevices, [
      .iPhone6Plus,
      .iPhone6sPlus,
      .iPhone7Plus,
      .iPhone8Plus,
      .iPhoneXSMax,
      .iPhone11ProMax,
      .iPhone12ProMax,
      .iPhone13ProMax,
      .iPhone14Plus,
      .iPhone14ProMax,
      .iPhone15Plus,
      .iPhone15ProMax,
      .iPhone16Plus,
      .iPhone16ProMax,
      .iPhone17ProMax,
      .iPhoneAir,
      .iPhone18ProMax,
    ])
  }

  func testIsPro() {
    XCTAssertEqual(Device.allProDevices, [
      .iPhone11Pro,
      .iPhone11ProMax,
      .iPhone12Pro,
      .iPhone12ProMax,
      .iPhone13Pro,
      .iPhone13ProMax,
      .iPhone14Pro,
      .iPhone14ProMax,
      .iPhone15Pro,
      .iPhone15ProMax,
      .iPhone16Pro,
      .iPhone16ProMax,
      .iPhone17Pro,
      .iPhone17ProMax,
      .iPhone18Pro,
      .iPhone18ProMax,
      .iPadPro9Inch,
      .iPadPro12Inch,
      .iPadPro12Inch2,
      .iPadPro10Inch,
      .iPadPro11Inch,
      .iPadPro12Inch3,
      .iPadPro11Inch2,
      .iPadPro12Inch4,
      .iPadPro11Inch3,
      .iPadPro12Inch5,
      .iPadPro11Inch4,
      .iPadPro12Inch6,
      .iPadPro11M4,
      .iPadPro13M4,
      .iPadPro11M5,
      .iPadPro13M5,
    ])
  }

  func testGuidedAccessSession() {
    XCTAssertFalse(Device.current.isGuidedAccessSessionActive)
  }

  // enable once unit tests can be run on device
  func testKeepsBatteryMonitoringState() {
    UIDevice.current.isBatteryMonitoringEnabled = true
    XCTAssertTrue(UIDevice.current.isBatteryMonitoringEnabled)
    _ = Device.current.batteryState
    XCTAssertTrue(UIDevice.current.isBatteryMonitoringEnabled)

    UIDevice.current.isBatteryMonitoringEnabled = false
    _ = Device.current.batteryState
    XCTAssertFalse(UIDevice.current.isBatteryMonitoringEnabled)
  }

  func testHasDynamicIsland() {
    let dynamicIslandDevices: [Device] = [
      .iPhone14Pro,
      .iPhone14ProMax,
      .iPhone15,
      .iPhone15Plus,
      .iPhone15Pro,
      .iPhone15ProMax,
      .iPhone16,
      .iPhone16Plus,
      .iPhone16Pro,
      .iPhone16ProMax,
      .iPhone17,
      .iPhone17Pro,
      .iPhone17ProMax,
      .iPhone18Pro,
      .iPhone18ProMax,
      .iPhoneAir,
    ]
    for device in Device.allRealDevices {
      XCTAssertTrue(device.hasDynamicIsland == device.isOneOf(dynamicIslandDevices), "testHasDynamicIsland failed for \(device.description)")
    }
  }

  func testHas5gSupport() {
    let has5gDevices: [Device] = [
      .iPhone12,
      .iPhone12Mini,
      .iPhone12Pro,
      .iPhone12ProMax,
      .iPhone13,
      .iPhone13Mini,
      .iPhone13Pro,
      .iPhone13ProMax,
      .iPhoneSE3,
      .iPhone14,
      .iPhone14Plus,
      .iPhone14Pro,
      .iPhone14ProMax,
      .iPhone15,
      .iPhone15Plus,
      .iPhone15Pro,
      .iPhone15ProMax,
      .iPhone16,
      .iPhone16Plus,
      .iPhone16Pro,
      .iPhone16ProMax,
      .iPhone16e,
      .iPhone17,
      .iPhone17Pro,
      .iPhone17ProMax,
      .iPhone18Pro,
      .iPhone18ProMax,
      .iPhoneAir,
      .iPhone17e,
      .iPad10,
      .iPadA16,
      .iPadAir5,
      .iPadAir11M2,
      .iPadAir13M2,
      .iPadAir11M3,
      .iPadAir13M3,
      .iPadAir11M4,
      .iPadAir13M4,
      .iPadMini6,
      .iPadMiniA17Pro,
      .iPadPro11Inch3,
      .iPadPro12Inch5,
      .iPadPro11Inch4,
      .iPadPro12Inch6,
      .iPadPro11M4,
      .iPadPro13M4,
      .iPadPro11M5,
      .iPadPro13M5,
    ]
    for device in Device.allRealDevices {
      XCTAssertTrue(device.has5gSupport == device.isOneOf(has5gDevices), "testHas5gSupport failed for \(device.description)")
    }
  }

  func testEsimSupportBoundaries() {
    // eSIM starts with XS/XR; dual eSIM starts with iPhone 13 and SE (3rd generation).
    let unsupported: [Device] = [.iPhoneX, .iPhone8, .iPhoneSE, .iPad6, .iPadAir2,
                                 .iPadMini4, .iPadPro10Inch, .iPadPro12Inch2, .iPodTouch7,
                                 .unknown("future device")]
    let esimOnly: [Device] = [.iPhoneXS, .iPhoneXSMax, .iPhoneXR, .iPhone11, .iPhoneSE2,
                              .iPhone12, .iPhone12Mini, .iPhone12Pro, .iPhone12ProMax,
                              .iPad7, .iPadAir3, .iPadMini5, .iPadPro11Inch, .iPadPro12Inch3]
    let dualEsim: [Device] = [.iPhone13, .iPhone13Mini, .iPhone13Pro, .iPhone13ProMax, .iPhoneSE3]
    for model in unsupported + esimOnly + dualEsim {
      for variant in [model, .simulator(model)] {
        XCTAssertEqual(variant.hasEsimSupport, !unsupported.contains(model), "\(variant)")
        XCTAssertEqual(variant.hasDualEsimSupport, dualEsim.contains(model), "\(variant)")
      }
    }
  }

  func testRecentDevicesEsimSupport() {
    let phones: [Device] = [.iPhone16, .iPhone16Plus, .iPhone16Pro, .iPhone16ProMax, .iPhone16e,
                            .iPhone17, .iPhone17Pro, .iPhone17ProMax, .iPhoneAir, .iPhone17e]
    let pads: [Device] = [.iPadAir11M2, .iPadAir13M2, .iPadPro11M4, .iPadPro13M4,
                          .iPadMiniA17Pro, .iPadA16, .iPadAir11M3, .iPadAir13M3,
                          .iPadPro11M5, .iPadPro13M5, .iPadAir11M4, .iPadAir13M4]
    for model in phones + pads {
      for variant in [model, .simulator(model)] {
        XCTAssertTrue(variant.hasEsimSupport, "\(variant)")
        XCTAssertEqual(variant.hasDualEsimSupport, phones.contains(model), "\(variant)")
      }
    }
  }

  func testEsimDeviceLists() {
    for model in Device.allDevicesWithDualEsimSupport {
      XCTAssertTrue(Device.allDevicesWithEsimSupport.contains(model), "\(model)")
      XCTAssertTrue(model.isPhone)
    }
    for model in Device.allRealDevices {
      XCTAssertEqual(Device.allDevicesWithEsimSupport.contains(model), model.hasEsimSupport)
      XCTAssertEqual(Device.allDevicesWithDualEsimSupport.contains(model), model.hasDualEsimSupport)
    }
    XCTAssertFalse(Device.allDevicesWithEsimSupport.contains(.iPhoneX))
    XCTAssertFalse(Device.allDevicesWithDualEsimSupport.contains(.iPhone12))
  }

  // MARK: - volumes
  @available(iOS 11.0, *)
  func testVolumeTotalCapacity() {
    XCTAssertNotNil(Device.volumeTotalCapacity)
  }

  @available(iOS 11.0, *)
  func testVolumeAvailableCapacity() {
    XCTAssertNotNil(Device.volumeAvailableCapacity)
  }

  @available(iOS 11.0, *)
  func testVolumeAvailableCapacityForImportantUsage() {
    XCTAssertNotNil(Device.volumeAvailableCapacityForImportantUsage)
  }

  @available(iOS 11.0, *)
  func testVolumeAvailableCapacityForOpportunisticUsage() {
    XCTAssertNotNil(Device.volumeAvailableCapacityForOpportunisticUsage)
  }

  @available(iOS 11.0, *)
  func testVolumes() {
    XCTAssertNotNil(Device.volumes)
  }

  func testCameras() {
    for device in Device.allDevicesWithCamera {
      XCTAssertTrue(device.cameras.contains(.wide) || device.cameras.contains(.telephoto) || device.cameras.contains(.ultraWide))
      XCTAssertTrue(device.hasCamera)
      XCTAssertTrue(device.hasWideCamera || device.hasTelephotoCamera || device.hasUltraWideCamera)
    }
    let devices = Device.allPhones + Device.allPads + Device.allPods
    for device in devices where !Device.allDevicesWithCamera.contains(device) {
      XCTAssertFalse(device.cameras.contains(.wide))
      XCTAssertFalse(device.cameras.contains(.telephoto))
      XCTAssertFalse(device.cameras.contains(.ultraWide))
      XCTAssertFalse(device.hasCamera)
      XCTAssertFalse(device.hasWideCamera)
      XCTAssertFalse(device.hasTelephotoCamera)
      XCTAssertFalse(device.hasUltraWideCamera)
    }
    for device in Device.allDevicesWithWideCamera {
      XCTAssertTrue(device.cameras.contains(.wide))
      XCTAssertTrue(device.hasCamera)
      XCTAssertTrue(device.hasWideCamera)
    }
    for device in Device.allDevicesWithTelephotoCamera {
      XCTAssertTrue(device.cameras.contains(.telephoto))
      XCTAssertTrue(device.hasCamera)
      XCTAssertTrue(device.hasTelephotoCamera)
    }
    for device in Device.allDevicesWithUltraWideCamera {
      XCTAssertTrue(device.cameras.contains(.ultraWide))
      XCTAssertTrue(device.hasCamera)
      XCTAssertTrue(device.hasUltraWideCamera)
    }
  }

  func testLidarValues() {
    let lidarDevices: [Device] = [
      .iPhone12Pro,
      .iPhone12ProMax,
      .iPhone13Pro,
      .iPhone13ProMax,
      .iPhone14Pro,
      .iPhone14ProMax,
      .iPhone15Pro,
      .iPhone15ProMax,
      .iPhone16Pro,
      .iPhone16ProMax,
      .iPhone17Pro,
      .iPhone17ProMax,
      .iPhone18Pro,
      .iPhone18ProMax,
      .iPadPro11Inch2,
      .iPadPro12Inch4,
      .iPadPro11Inch3,
      .iPadPro12Inch5,
      .iPadPro11Inch4,
      .iPadPro12Inch6,
      .iPadPro11M4,
      .iPadPro13M4,
      .iPadPro11M5,
      .iPadPro13M5,
    ]
    for device in Device.allRealDevices {
      XCTAssertTrue(device.hasLidarSensor == device.isOneOf(lidarDevices), "testLidarValues failed for \(device.description)")
    }
  }

  func testHasUSBCConnectivity() {
    let usbCDevices: [Device] = [
      .iPhone15,
      .iPhone15Plus,
      .iPhone15Pro,
      .iPhone15ProMax,
      .iPhone16,
      .iPhone16Plus,
      .iPhone16Pro,
      .iPhone16ProMax,
      .iPhone16e,
      .iPhone17,
      .iPhone17Pro,
      .iPhone17ProMax,
      .iPhone18Pro,
      .iPhone18ProMax,
      .iPhoneAir,
      .iPhone17e,
      .iPad10,
      .iPadA16,
      .iPadAir4,
      .iPadAir5,
      .iPadAir11M2,
      .iPadAir13M2,
      .iPadAir11M3,
      .iPadAir13M3,
      .iPadAir11M4,
      .iPadAir13M4,
      .iPadMini6,
      .iPadMiniA17Pro,
      .iPadPro11Inch,
      .iPadPro12Inch3,
      .iPadPro11Inch2,
      .iPadPro12Inch4,
      .iPadPro11Inch3,
      .iPadPro12Inch5,
      .iPadPro11Inch4,
      .iPadPro12Inch6,
      .iPadPro11M4,
      .iPadPro13M4,
      .iPadPro11M5,
      .iPadPro13M5,
    ]
    for device in Device.allRealDevices {
      XCTAssertTrue(device.hasUSBCConnectivity == device.isOneOf(usbCDevices), "testHasUSBCConnectivity failed for \(device.description)")
    }
  }

  func testApplePencilSupport() {
    // Test iPad (10th gen) - Supports Apple Pencil (1st gen) and Apple Pencil (USB-C)
    XCTAssertTrue(Device.iPad10.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPad10.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPad10.applePencilSupport.contains(.secondGeneration))
    XCTAssertFalse(Device.iPad10.applePencilSupport.contains(.pro))

    // Test iPad (A16) - Supports Apple Pencil (1st gen) and Apple Pencil (USB-C)
    XCTAssertTrue(Device.iPadA16.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadA16.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadA16.applePencilSupport.contains(.secondGeneration))
    XCTAssertFalse(Device.iPadA16.applePencilSupport.contains(.pro))

    // Test iPad Air 11" (M2) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadAir11M2.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadAir11M2.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadAir11M2.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadAir11M2.applePencilSupport.contains(.pro))

    // Test iPad Air 13" (M2) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadAir13M2.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadAir13M2.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadAir13M2.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadAir13M2.applePencilSupport.contains(.pro))

    // Test iPad Air 11" (M3) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadAir11M3.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadAir11M3.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadAir11M3.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadAir11M3.applePencilSupport.contains(.pro))

    // Test iPad Air 13" (M3) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadAir13M3.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadAir13M3.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadAir13M3.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadAir13M3.applePencilSupport.contains(.pro))

    // Test iPad Pro 11" (M4) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadPro11M4.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadPro11M4.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadPro11M4.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadPro11M4.applePencilSupport.contains(.pro))

    // Test iPad Pro 13" (M4) - Supports Apple Pencil Pro and Apple Pencil (USB-C)
    XCTAssertFalse(Device.iPadPro13M4.applePencilSupport.contains(.firstGeneration))
    XCTAssertTrue(Device.iPadPro13M4.applePencilSupport.contains(.firstGenerationUsbC))
    XCTAssertFalse(Device.iPadPro13M4.applePencilSupport.contains(.secondGeneration))
    XCTAssertTrue(Device.iPadPro13M4.applePencilSupport.contains(.pro))
  }

  #endif

  // MARK: - tvOS
  #if os(tvOS)

  func testDescriptionFromIdentifier() {
    XCTAssertEqual(Device.mapToDevice(identifier: "AppleTV5,3").description, "Apple TV HD")
    XCTAssertEqual(Device.mapToDevice(identifier: "AppleTV6,2").description, "Apple TV 4K")
  }

  func testSafeDescription() {
    for device in Device.allRealDevices {
      XCTAssertEqual(device.description, device.safeDescription)
    }
  }

  /// Test that all the ppi values for applicable devices match the public information available at wikipedia. Test non-applicable devices return nil.
  func testPPI() {
    // Non-applicable devices:
    // Apple TV
    XCTAssertEqual(Device.appleTVHD.ppi, nil)
    XCTAssertEqual(Device.appleTV4K.ppi, nil)
    // Simulators
    XCTAssertEqual(Device.simulator(Device.appleTVHD).ppi, nil)
    XCTAssertEqual(Device.simulator(Device.appleTV4K).ppi, nil)
  }

  #endif

}
