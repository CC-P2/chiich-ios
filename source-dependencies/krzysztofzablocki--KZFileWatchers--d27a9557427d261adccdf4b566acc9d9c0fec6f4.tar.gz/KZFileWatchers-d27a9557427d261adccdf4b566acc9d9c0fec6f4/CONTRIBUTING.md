# Contributing to KZFileWatchers

KZFileWatcher is an open source project started by Krzysztof Zabłocki and open to the entire Cocoa community.

I really appreciate your help!

## Filing issues

When filing an issue, make sure to answer these five questions:

1. What version of Swift are you using (`swift --version`)?
2. What did you do?
3. What did you expect to see?
4. What did you see instead?

## Contributing code

Before submitting changes, please follow these guidelines:

1. Check the open issues and pull requests for existing discussions.
2. Open an issue to discuss a new feature.
3. Write tests.
4. Make sure the entire test suite passes locally and on Travis CI.
5. Open a Pull Request.

Unless otherwise noted, the KZFileWatchers source files are distributed under
the MIT license found in the LICENSE.md file.

[Please review our Code of Conduct](https://github.com/krzysztofzablocki/KZFileWatchers/blob/master/CODE_OF_CONDUCT.md)
