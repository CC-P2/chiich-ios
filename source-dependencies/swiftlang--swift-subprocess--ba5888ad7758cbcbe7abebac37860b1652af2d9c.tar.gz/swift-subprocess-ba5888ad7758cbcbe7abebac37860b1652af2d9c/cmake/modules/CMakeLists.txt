##===----------------------------------------------------------------------===##
##
## This source file is part of the Swift.org open source project
##
## Copyright (c) 2025 Apple Inc. and the Swift project authors
## Licensed under Apache License v2.0 with Runtime Library Exception
##
## See https://swift.org/LICENSE.txt for license information
##
##===----------------------------------------------------------------------===##

configure_file(SwiftSubprocessConfig.cmake.in
  ${CMAKE_CURRENT_BINARY_DIR}/SwiftSubprocessConfig.cmake)

