//
//  KFImageRenderer.swift
//  Kingfisher
//
//  Created by onevcat on 2021/05/08.
//
//  Copyright (c) 2021 Wei Wang <onevcat@gmail.com>
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.

#if canImport(SwiftUI) && canImport(Combine)
import SwiftUI
import Combine

/// A Kingfisher compatible SwiftUI `View` to load an image from a `Source`.
/// Declaring a `KFImage` in a `View`'s body to trigger loading from the given `Source`.
struct KFImageRenderer<HoldingView> : View where HoldingView: KFImageHoldingView & Sendable {
    
    @StateObject var binder: KFImage.ImageBinder = .init()
    let context: KFImage.Context<HoldingView>
    
    init(context: KFImage.Context<HoldingView>) {
        self.init(context: context, binder: .init())
    }

    init(context: KFImage.Context<HoldingView>, binder: KFImage.ImageBinder) {
        _binder = StateObject(wrappedValue: binder)
        self.context = context
    }

    var body: some View {
        if context.startLoadingBeforeViewAppear && !binder.loadingOrSucceeded && !binder.animating {
            binder.markLoading()
            DispatchQueue.main.async { binder.start(context: context) }
        }
        
        return ZStack {
            if context.swiftUITransition == nil {
                // Fade transition or no transition: use opacity control
                // Keep the image branch for external transitions without affecting layout while no
                // image is loaded. The zero frame is intentionally tied to `loadedImage` instead of
                // `isImageRenderable`: it is released in the render pass that sets `loadedImage`,
                // one pass before the animated `markLoaded`, so the layout change never falls into
                // the fade transaction and gets interpolated into a scaling effect.
                renderedImage()
                    .opacity(isImageRenderable ? 1.0 : 0.0)
                    .frame(
                        width: binder.loadedImage == nil ? 0 : nil,
                        height: binder.loadedImage == nil ? 0 : nil
                    )
            } else if isImageRenderable {
                // SwiftUI loadTransition: insert/remove view for proper transition behavior
                renderedImage()
            }

            if !isImageRenderable {
                ZStack {
                    // Priority: failureView > placeholder > Color.clear
                    // failureView is only set when image loading fails
                    if let failureView = binder.failureView {
                        failureView()
                    } else if let placeholder = context.placeholder {
                        placeholder(binder.progress)
                    } else {
                        Color.clear
                    }
                }
                .onAppear { [weak binder = self.binder] in
                    guard let binder = binder else {
                        return
                    }
                    if !binder.loadingOrSucceeded {
                        binder.start(context: context)
                    } else {
                        if context.reducePriorityOnDisappear {
                            binder.restorePriorityOnAppear()
                        }
                    }
                }
                .onDisappear { [weak binder = self.binder] in
                    guard let binder = binder else {
                        return
                    }
                    if context.cancelOnDisappear {
                        binder.cancel()
                    } else if context.reducePriorityOnDisappear {
                        binder.reducePriorityOnDisappear()
                    }
                }
            }
        }
        // Workaround for https://github.com/onevcat/Kingfisher/issues/1988
        // on iOS 16 there seems to be a bug that when in a List, the `onAppear` of the `ZStack` above in the
        // `binder.loadedImage == nil` not get called. Adding this empty `onAppear` fixes it and the life cycle can
        // work again.
        //
        // There is another "fix": adding an `else` clause and put a `Color.clear` there. But I believe this `onAppear`
        // should work better.
        //
        // It should be a bug in iOS 16, I guess it is some kinds of over-optimization in list cell loading caused it.
        .onAppear()
    }
    
    /// Whether the image branch takes part in rendering and layout.
    ///
    /// The fallback set by the deprecated `onFailureImage` also has to be rendered, so this stays independent of
    /// `isImageLoaded`.
    private var isImageRenderable: Bool {
        binder.loadedImage != nil && binder.loaded
    }

    /// Whether the rendered image was retrieved from the cache or the network, as opposed to the fallback set by the
    /// deprecated `onFailureImage`.
    private var isImageLoaded: Bool {
        isImageRenderable && !binder.usesFailureImage
    }

    @ViewBuilder
    private func renderedImage() -> some View {
        if let swiftUITransition = context.swiftUITransition {
            // Apply SwiftUI loadTransition as the last step for correct rendering order
            configuredImage.transition(swiftUITransition)
        } else {
            configuredImage
        }
    }
    
    @ViewBuilder
    private var configuredImage: some View {
        let configuredImage = context.configurations
            .reduce(HoldingView.created(from: binder.loadedImage, context: context)) {
                current, config in config(current)
            }
        
        // Apply contentConfiguration first, then loadTransition as the final step
        if let contentConfiguration = context.contentConfiguration {
            contentConfiguration(configuredImage, isImageLoaded)
        } else {
            configuredImage
        }
    }
}

extension Image {
    // Creates an Image with either UIImage or NSImage.
    init(crossPlatformImage: KFCrossPlatformImage?) {
        #if canImport(UIKit)
        self.init(uiImage: crossPlatformImage ?? KFCrossPlatformImage())
        #elseif canImport(AppKit)
        self.init(nsImage: crossPlatformImage ?? KFCrossPlatformImage())
        #endif
    }
}

#if canImport(UIKit)
extension UIImage.Orientation {
    func toSwiftUI() -> Image.Orientation {
        switch self {
        case .down: return .down
        case .up: return .up
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}
#endif
#endif
