# Changelog

Notable changes to matrix-rust-rtc. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

Entries begin with the Android integration work — earlier history is in the git
log only.

## Unreleased

## v0.5.0-rc.5 - 2026-10-15

### Breaking

- `CallJoinOptions::kind` (FFI `FfiJoinSessionParams::kind`, required) replaces `notify`: `Group { notify }` for a group call's notification, `Direct { ring }` for a DM call the library rings, follows and ends; web `joinCall` refuses `notification_type: "ring"`.
- An MSC4075 ring now lasts 90 s by default, as Element Call's does.
- `notify_session_started` takes the `DialectBackend`, so a notification always goes out in the room's membership format.
- `CallEvent::Ended`, `CallEvent::MediaConnectionState` and `EndedReason` (FFI `FfiEndedReason`, web `ended` and `media_connection_state`) are removed: the call's status says both.

### Added

- `RtcCall::status`/`subscribe_status` (FFI `status`/`subscribe_status`, web `status` and `onStatus`, `LiveKitCall::status`) report the call as connecting, calling (a DM's ring, with the callee's user ID and our media's progress), connected since the pickup or our media, or ended with a reason, including a DM's decline, no answer and everyone else leaving.
- `ApplicationIntake::sticky_event_types`/`on_sticky_events` hand an application the sticky events of its types, and `BaseRtcRoom::room_members` the room's joined users.

## v0.5.0-rc.4 - 2026-10-13

### Breaking

- `HandRaised` and `HandLowered` now announce only hands raised or lowered while we are in the call, never the hands we arrive to or a member arrives with, and `Reaction` is sent only while we are in the call and for reactions newer than `ReactionsConfig::max_age_ms` (10 s by default).

### Added

- Participants and tiles carry `hand_raised_position`, their 1-based place in the raised-hand queue.

## v0.5.0-rc.3 - 2026-10-12

### Breaking

- `ParticipantJoined` and `ParticipantLeft` now report only arrivals and departures while we are in the call, never the roster we join, lapse or return to, and carry `participant_count`, the memberships after the change.

### Added

- A local video publication reports send statistics per simulcast layer (size, frame rate, bytes, whether dynacast paused it), as `LocalTrackHandle::send_stats` and `FfiLocalTrack::send_stats`.

## v0.5.0-rc.2 - 2026-10-08

### Added

- `sdk_version()` (web `sdkVersion()`) returns the SDK release version, for hosts to display or attach to log reports, and logging setup logs it.
- `set_ranking_threshold(tiles)` keeps tiles in join order, screen shares first, while a call has no more than that many remote tiles, so small calls stop shuffling on speaking, video or a raised hand; sticky and MSC4143 memberships take their join time from the first member event's `origin_server_ts`.

## v0.5.0-rc.1 - 2026-10-06

### Breaking

- `matrix-rtc-media` is renamed `matrix-rtc-call-sdk`, and `LiveKitCall`, `open_slot`, `attach_livekit` and the examples and e2e test move there from `matrix-rtc-livekit` (features `livekit` and `matrix-sdk`), leaving `matrix-rtc-livekit` the transport alone, without a `matrix-sdk` feature.
- The transport contract, frames, constraints and media key handler move from `matrix-rtc-media` to the new `matrix-rtc-transport`, and `matrix-rtc-livekit-proto` becomes its `livekit` module; `matrix-rtc-media` keeps the call's roster, tiles, events and `attach_media`.
- `LiveKitMediaTransport::connect_livekit` becomes `OwnFocusTransport::connect_own`, and `LiveKitTransportConnection::set_local_key_index` moves onto `TransportConnection`.
- `connect_media_session`/`connectMedia` take the own focus from the call and the account from the backend: `MediaSessionConfig` loses `livekit_service_url`, `user_id` and `device_id`, and a receive-only call connects only to its peers' foci.
- `MembershipSnapshotSubscription::next_snapshot()`, which polled, becomes an async `next()` that waits for the next roster and returns `None` once the room is gone.
- FFI and web `joinCall` take an optional `application_slot_id` (`m.call#{application_slot_id}`, `room` when omitted) instead of `slot_id` and `application`.
- The room-wide slot is `{application}#room`, as MSC4143 spells it, instead of `{application}#ROOM` (the 2025 Element Call format still respells it `#ROOM` on the wire); `ROOM_SLOT_NAME` becomes `ROOM_APPLICATION_SLOT_ID`.
- `CallEvent::KeyImported` (web `key_imported`) carries the `identity` the key was installed under.
- A join refused because its slot is not open fails with `MatrixRtcFfiError::SlotClosed` instead of `InvalidInput`.
- A join's transport is one choice, `Advertised`, `Publish` on a LiveKit focus, or `ReceiveOnly`, replacing `transport`, `receive_only` and `can_subscribe` in the FFI and web join params.
- The library keeps a joined session alive and performs its key rotations at their deadline itself; `heartbeat()`, `flushDueKeyRotation()`/`flush_due_key_rotation`, `keyRotationDueAtMs()`/`key_rotation_due_at_ms` and `HEARTBEAT_INTERVAL_MS` are gone, and `LiveKitCallOptions::heartbeat_interval` becomes `keep_alive_interval_ms` (default 10 s).
- `RtcClient::room` spawns the room's feeds on `matrix_rtc_core::executor` and returns the room alone (`RoomRuns` is gone); natively it must be called within a tokio runtime, and `LiveKitCall::join` no longer needs a `LocalSet`.
- The session managers are replaced by client → room → session (`RtcClient` → `RtcRoom` → `RtcSession`/`RtcCall`, likewise on the FFI and wasm), and the core's manager by the per-room `BaseRtcRoom`.
- `matrix_rtc_livekit::Call`, `CallOptions` and `CallError` are renamed `LiveKitCall`, `LiveKitCallOptions` and `LiveKitCallError`, so they no longer read as the call crate's `RtcCall`.
- `compat`, `feeder` and `transports` move from `matrix-rtc-bridge` to `matrix-rtc-call`, and what remains is renamed `matrix-rtc-matrix-sdk`, with no `matrix-sdk` feature; its `SdkBackend` becomes `SdkMatrixBackend`.
- One `MatrixBackend` trait (`matrix-rtc-core`) replaces `RtcCommandSender` and every inbound method on the managers and bindings (`set_current_sticky_state`/`set_current_membership`, `on_room_slots_received`, `on_room_members_received`, `on_room_encryption_received`, `receive_encryption_key`/`receive_legacy_encryption_key`, `on_room_timeline_events`, `on_event_redacted`, `on_relations_received`). A host implements the trait — the sends, a per-room subscription delivering the room's complete current sets, a to-device subscription, `/relations`, the OpenID token and `GET /rtc/transports` — and opens rooms through `RtcClient::room`; the feeder (`matrix_rtc_call::feeder`) does the feeding, including the pre-2026 compatibility funnels, for every host. Gone with it: `CommandSenderCallback`, `OpenIdTokenProvider`, `OpenIdTokenSource`, `SdkCommandSender`, `run_membership_bridge`, `discover_livekit_transport`, and the typed inbound records (`StickyEvent`, `SlotEvent`, `FfiTimelineEvent`, `FfiReceivedEncryptionKey`, `RawMemberEvent`, …).
- `send_delayed_event` takes an optional state key; `send_delayed_state_event` is folded into it.
- The compatibility mode is given when a room is opened, not on `join`; the FFI and wasm join params no longer take `user_id`/`device_id` (the backend knows them) and their `transport` is optional — the library picks from `rtc_transports()` when it is absent.
- `LiveKitCall::join` takes `LiveKitCallOptions::livekit_transport` as an override instead of `livekit_service_url_fallback`; `connect_media_session` no longer takes a token provider.
- Joining a slot the room's state says is closed (or that is absent) fails with `JoinError::SlotClosed`; nothing opens a slot implicitly — `open_slot` is the room admin's, or the room's initial state.
- Call features (reactions, raised hand, MSC4075 notify) moved from `matrix-rtc-core` to the new `matrix-rtc-call` crate, joined with `RtcRoom::join_call` and `CallJoinOptions`.
- `CallMembershipEvent` is renamed `RtcMembershipEvent`, and `try_into_call_membership_event` is renamed `try_into_membership_event`.
- `JoinSessionParams.application` and `JoinedMembership.application` are the whole MSC4143 `ApplicationInfo`, and the wasm roster serializes it as an object.
- `BaseRtcRoom::join` returns the event id of the membership it sent, and `RtcSession::membership_event_id` reads the current one.
- The feeder feeds any `ApplicationIntake`, subscribing to the event types it names.
- The feeder moves from `matrix_rtc_call::feeder` to `matrix_rtc_core::feeder`, reading a room through an `IngestDialect`.
- `JoinSessionParams` no longer takes the user and device, which are the backend's: `JoinSessionParams::application("org.example.board").slot("planning")` composes the slot id (`{application}#room` without `.slot`), and every other field is a named setter (`.transport(..)`, required, `.member_id(..)`, `.keep_alive_interval_ms(..)`, …); `JoinSessionParams::new` and `with_transport_intent` are gone. The call layer's options read the same way: `CallJoinOptions::new()` joins `m.call#room` and `.slot("standup")` names another, `JoinOptions::application(..).slot(..)` for any application; `JoinOptions::new` and `CallJoinOptions::new(slot_id)` are gone.
- The pre-2026 membership formats move from `matrix_rtc_call::compat` to `matrix_rtc_core::compat`, and `ElementCallCompat { Off, StickyEvents, StateEvents }` becomes `MembershipFormat { Current, Sticky2025, RoomState }` on every host (`FfiMembershipFormat`, the wasm `format: "current" | "sticky_2025" | "room_state"` room option, `LiveKitCallOptions::format`, `RoomOptions::format`, the load test's `--format`).
- `WasmRtcSession`, the bare single-session wasm API, is removed; `WasmRtcClient` over a `MatrixBackendHost` is the one entry point, and `joinCall` rings like every other host.

### Added

- A call leaves on its own when its slot closes (`leave_reason` `slot_closed`), and every ending — leave, slot close, room close — ends its media and closes its SFU connections on one path — at once on a leave, even one that fails to send — reported by `RtcSession::subscribe_ended` / FFI `RtcCall.waitForEnd()`.
- `matrix_rtc_transport::pool::MediaPool`, the MSC4195 multi-SFU connection pool extracted from the call engine, reports a session's media per `member_id` for any application on the core.
- `matrix_rtc_call_sdk::attach_media` and `attach_livekit` attach media to a joined call, now the one wiring behind the FFI and web media sessions and `LiveKitCall`.
- A room still waiting on its first deliveries logs which `RoomSink` calls are missing every 5 s, so a host that never delivers one sees why `room()` has not returned.
- `BaseRtcClient` opens a core room that subscribes through the backend and feeds itself, so a host of the core alone feeds and ticks nothing.
- A core room opens in a `MembershipFormat` (`BaseRtcClient::room(room_id, RoomOptions)`) and renders its joins in it, so a host of the core alone can join in the 2025 sticky or the pre-sticky room-state format.
- `BaseRtcRoom::join` starts the slot's upkeep (keep-alive, sticky refresh, key rotations at their deadline) until the leave, so a host on the core alone ticks nothing either; `upkeep_abort_handle` stops it for an owner that drops the join without leaving.
- `BaseRtcRoom::add_membership_listener`: synchronous notice of every change to a slot's joined memberships, for applications built on the core.
- `ApplicationIntake` and `RelationsRequest`, how a host feeds an application beyond membership.
- `BaseRtcRoom::backend()`, and a core `testing` feature exposing `MockBackend`, whose sinks a test delivers sets into.
- Reactions, the raised hand and the `/relations` backfill on every host (FFI, wasm, `LiveKitCall`), since the feeder does the work once.
- `matrix_rtc_call::transports::choose`: the library's transport choice from the homeserver's `GET /rtc/transports`.
- `SdkMatrixBackend` discovers transports through matrix-sdk's cached `discover_rtc_transports`, falling back to the well-known `rtc_foci`; a failed request is an error rather than "none advertised".
- A member event carrying both `msc4354_sticky_key` and `sticky_key` (as seen on the wire) now parses; it was dropped as a duplicate field.

### Fixed

- The web `onEvent` callback now receives `key_imported` for keys that arrived before `connectMedia`, and `LiveKitCall::join` leaves the slot on any media attach failure, not only a refused SFU.
- In the 2025 Element Call format the room-wide slot is sent and read as `m.call#ROOM`, including in the token request, so we share a session and an SFU room with Element Call again.
- The media engine's first event subscriber now receives events emitted before it subscribed, so `KeyImported` for keys replayed during connect is no longer lost.

## v0.4.0-rc.1 - 2026-09-25

### Added

- The call tile roster: `MediaSession::next_roster()` / `next_local_state()`
  publish one ranked, damped `CallTile` per renderable stream, with thresholds
  configurable via `stability`.
- A tile's kind is a `TileKind` — `Person` or `ScreenShare` — rather than a stream
  kind: `TileId.kind`, `CallTile.kind` and their `FfiTileKind` mirrors. The stream a
  tile draws is `TileKind::video_stream()`; a microphone is never a tile.
- `MediaSession::receive_stats_for(streams)` (and `CallEngine::receive_stats_for`)
  reads receive counters for a set of `(member_id, kind)` in one call, awaiting
  the transports concurrently: one round trip per sample for a host that polls
  the tiles it draws, instead of one per stream.

### Breaking

- MSC4354 sticky events now come from upstream matrix-rust-sdk and are always on with the `matrix-sdk` feature; the `experimental-sticky` feature, `STICKY_EVENTS_SUPPORTED` and `CallError::StickyEventsUnsupported` are gone.

### Removed

- `FfiCallEvent::ActiveSpeakers`. Who is speaking is `FfiCallTile::speaking`, damped
  into the roster's order; the event was the noisiest thing on the stream and no
  host drew from it. The event stream now carries one-shots and diagnostics only —
  see `MediaSession::next_event`'s docs. wasm keeps its own `active_speakers`.
  Drive audio playback from the tile roster's `order`, not from `StreamStarted`;
  `participants()` is a diagnostics pull, not something to re-read per event.

## v0.3.0-rc.2 - 2026-09-22

### Added

- `PublishOptions::muted` publishes a track already muted, for a lobby that
  joins muted; also on `FfiPublishOptions`.

### Fixed

- Our own publications now land on the roster when they are made before our
  membership does, mute state included (#50).

## v0.3.0-rc.1 - 2026-09-21

### Project

- The project is now dual licensed by Element Creations Ltd: AGPL-3.0-only
  **OR** the Element Commercial License (`AGPL-3.0-only OR LicenseRef-Element-Commercial`).

### Breaking

Hosts implementing the FFI/WASM command sender must update. All of these are
compile errors, not silent behaviour changes.

- **The generated bindings have their release names.** Kotlin moves from
  package `uniffi.matrix_rtc_ffi` to `org.matrix.rtc` (the package of the
  hand-written `MatrixRtc` / `RtcLogging` helpers, so one import prefix covers
  the whole API); the Swift module is `MatrixRtc` and the C module inside the
  xcframework `MatrixRtcFFI` (was `matrix_rtc_ffiFFI`). The Android module now
  declares JNA as an `api` dependency (`net.java.dev.jna:jna:5.19.1@aar`), so a
  consumer gets it from the POM, and drops the `appcompat` and `jna-platform`
  dependencies nothing used. The Swift package moves to the repository root
  (`Package.swift` + `Sources/MatrixRtc`) and is consumed as a remote package
  at a `v*` tag; `mobile/ios/Package.swift` is gone.

- **The Rust-driven path now depends on upstream `matrix-org/matrix-rust-sdk`
  by default; MSC4354 sticky events are behind a new `experimental-sticky`
  feature.** `matrix-rtc-bridge` and `matrix-rtc-livekit` (feature `matrix-sdk`)
  no longer pin the `BillCarsonFr/matrix-rust-sdk` fork. Against the stock SDK
  they carry membership as `org.matrix.msc3401.call.member` room state only, so
  `Call::join` accepts `ElementCallCompat::StateEvents` and returns the new
  `CallError::StickyEventsUnsupported` for `Off` and `StickyEvents`; a sticky
  send reaching `SdkCommandSender` directly fails with
  `CommandError::ClientRejected`. `experimental-sticky` compiles the sticky
  paths and needs the fork, selected with the `.cargo/experimental-sticky.toml`
  overlay (`scripts/cargo-sticky.sh`, `make check-sticky` / `clippy-sticky` /
  `test-e2e-sticky`), plus `matrix-sdk/unstable-msc4354` and
  `matrix-sdk-ui/unstable-msc4354` on the command line — a cargo feature cannot
  forward to an SDK feature upstream lacks without breaking resolution for
  everyone. `matrix_rtc_bridge::STICKY_EVENTS_SUPPORTED` says which build a
  caller has. `run_sticky_bridge` is renamed `run_membership_bridge`. Consumers
  must replicate the SDK's `[patch]` blocks as before; the set is now
  upstream's (the `tracing` pins are gone, a `ruma` patch is added). The FFI and
  WASM bindings are unaffected: they never had matrix-sdk in their graph.

- **In `StateEvents` mode the MSC4075 notification goes out through
  `send_room_event` / `sendRoomEvent`, not the sticky send.** The pre-sticky
  wire has no sticky map, so that generation's ring is an ordinary room event.
  `MemberEventRoute` gains a `Room` variant for it (exhaustive matches break).
  A host whose SDK has no MSC4354 support can now run a `StateEvents` call end
  to end, notification included, without ever implementing `sendStickyEvent`.

- **The command sender gains `sendRoomEvent(roomId, eventType, content)` and
  `redactEvent(roomId, eventId, reason?)`.** Kotlin/Swift: two new methods on
  `CommandSenderCallback`; JS: two new methods on the client object handed to
  `setupCommandSender`, resolving like `sendStickyEvent` does (`{event_id}`)
  and to anything at all, respectively. They carry Element Call's reactions
  (`io.element.call.reaction`) and the raised hand (an `m.reaction`
  annotation, lowered by redacting it) — plain message-like sends, encrypted
  in an encrypted room by the client SDK's ordinary send. The `matrix-js-sdk`
  host module implements both.

- **Sticky events fed in should now carry their `event_id`.** `StickyEvent`
  (FFI), `StickyEventIn` / `RawMemberEventIn` / `LegacyStateMemberEventIn`
  (JS) and the FFI `RawMemberEvent` / `LegacyStateMemberEvent` records gain an
  optional `event_id`. Optional so existing hosts compile, but a member fed
  without one cannot be reacted for and none of their reactions validate:
  Element Call relates every reaction to the reacting member's membership
  event. `JoinedMembership` / `MembershipSnapshot` grow the matching
  `membership_event_id`, which moves on every sticky refresh.

**v0.3.0 sweep** — deliberately batched into one release while there is still a
single integrator, rather than dripped out over several:

- **`CallOptions::legacy_element_call: bool` is now
  `CallOptions::element_call_compat: ElementCallCompat`** (`Off` / `StickyEvents`
  / `StateEvents`). There are two pre-2026 Element Call generations to render for
  now, and they disagree about the *carrier* of a membership rather than just its
  fields, so they are mutually exclusive by construction — an enum makes the
  impossible fourth state unrepresentable. `LiveKitTransportConfig` likewise
  gains a `token_endpoint: TokenEndpoint` field. The load generator's
  `--legacy-element-call` flag becomes `--element-call-compat <off|sticky|state>`,
  and `join_and_record`'s `LEGACY_ELEMENT_CALL` now takes `sticky` or `state`
  (any other value still means `sticky`).

- **`sendStickyEvent` and `sendStateEvent` now return the event id.**
  Kotlin/Swift: `String`; JS: resolve to matrix-js-sdk's `{event_id}` (a bare
  string and `{eventId}` are accepted too), and resolving to anything else is
  now a failed send rather than a silent success.

  The id is what MSC4075 needs: a call notification must carry an `m.reference`
  relation to the membership event that justifies it. It is not optional because
  every Matrix send responds with one — `PUT /rooms/{id}/send/{type}/{txn}` and
  `PUT /rooms/{id}/state/{type}/{key}` both do — so an implementation that
  cannot produce it is broken, and failing loudly beats a call that joins fine
  and quietly never rings. `sendStateEvent` is included because in `StateEvents`
  compat mode the *membership* goes out through it; nothing reads the id of a
  slot event.

  The alternative, recovering the id from our own membership echoing back
  through sync (what matrix-js-sdk does), puts a full sync round trip in front
  of the ring.
- **`sendToDeviceMessage` now takes a recipient *list* and returns a result per
  recipient**, replacing the per-device call whose only failure channel was an
  exception. That exception landed inside the core's loop over members, so one
  undeliverable recipient silenced every member after it; and because the core
  had no way to learn who was actually served, it recorded everyone as holding
  the key and never retried. Now: return `FfiToDeviceDelivery { userId,
  deviceId, error }` per recipient — a recipient you report as delivered is
  never re-sent to, one you mark failed or omit is retried on the next rollout.
  Reserve `Err` for "the batch could not be attempted at all". This also removes
  a loop and several FFI crossings, and maps onto matrix-rust-sdk's own
  recipient-list `sendToDeviceMessage`.
- **`restartDelayedEvent` / `cancelDelayedEvent` take `delayId`, not
  `eventId`.** The value was always the MSC4140 delay id; the parameter name
  said otherwise, and transposing the two fails silently, surfacing minutes
  later as the dead man's switch retiring a live membership. Renamed everywhere,
  including `sendDelayedEvent`'s documented return.
- **`CommandSenderCallback` is async, and so is every manager-handle method
  that touches the core.** In Kotlin they are `suspend fun`s; in Swift, `async`.
  A synchronous callback forced hosts to bridge to their async Matrix client
  themselves — `runBlocking` on a dedicated dispatcher on Android — while every
  corresponding matrix-rust-sdk call is already async.

  `setCommandSender` now takes the interface directly rather than a boxed one
  (uniffi `with_foreign`), and `CommandSenderError` gained a `Display` impl,
  which uniffi requires of a foreign-trait error type.

  This was blocked until now by a subtlety worth recording: uniffi's async
  exports must be `Send`, while `matrix-rtc-core`'s command traits were
  `?Send` on every target to accommodate WASM's JS-backed futures. They are now
  `Send` everywhere except `wasm32`, via a `cfg_attr` pair that **every
  implementation of those traits must carry**. A consequence is that
  `matrix-rtc-wasm` no longer compiles for a host target — its crate body is
  gated to `wasm32` and a `Clippy (wasm32)` CI job type-checks it instead.

  Internally this removed the blocking bridge entirely: no `block_on`, and the
  keep-alive is a spawned task rather than a thread per session (it needed a
  thread only because its future held a `std::sync::MutexGuard` and so was not
  `Send`).
- **One way in for membership: `setCurrentStickyState(roomId, events)`.** It
  carries the room's *complete* current sticky state and **replaces** what the
  core held — a member absent from it is gone, and an empty list clears the
  room. `initialStickyForRoom`, `onStickyEventsSnapshotReceived`,
  `stickyUpdateForRoom` and `onStickyEventsUpdateReceived` are all gone, along
  with the `StickyEventUpdate` record.

  A delta bought nothing: the core discarded the `previous` half of an update,
  flattened every removal to a plain leave, and an explicit leave arrives inside
  the current state anyway as a leave-shaped sticky replacing the join under the
  same key. Meanwhile `matrix-sdk-ffi` hands hosts a full snapshot on every
  change (it collapses the SDK's delta before it crosses the boundary), so the
  current state is the shape hosts already have — and the core now does the
  diffing once instead of each host doing it. Feeding a shrunken set is how an
  expired membership departs.
- **`RtcSessionHandle` is gone.** Its `leave()` could only ever return an error,
  and a session created through it was invisible to `RtcSessionManagerHandle`,
  so nothing else could act on it. Its one unique capability — observing the
  roster — is now on the manager. Drive sessions through the manager handle.
- **`FfiAudioFrame.data` is a `ByteArray` of little-endian `int16`**, not a
  `List<Short>`. uniffi renders a sample list boxed — roughly 48 000 objects a
  second at 48 kHz mono, the single biggest cost this API imposed on a host.
  Read it with
  `ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()`;
  `AudioTrack`/`AudioRecord` take the byte form directly.
- **`FfiCallEvent.ActiveSpeakers` carries `speakers: List<FfiSpeakingMember>`**
  (`memberId` + `level`) rather than bare member ids. The level arrives in the
  same transport event, and dropping it forced hosts to meter the PCM
  themselves to answer "how loud".
- **`EncryptionManager::get_encryption_keys()` is gone.** It derived participant
  identities itself, ignoring the installed identity mapper, so anything
  importing from it addressed keys under identities the transport never sees —
  indistinguishable from the keys never arriving. Use
  `replayKeysToHandler`/`replay_encryption_keys`, which derive identities the
  same way the live signal path does.

- **`CommandSenderCallback.sendStickyEvent` takes a new `durationMs`
  argument.** Pass it through verbatim — with matrix-rust-sdk that is
  `.with_sticky_duration_ms(durationMs)`. Substituting a value of your own
  breaks the membership refresh: shorter and the membership disappears mid-call,
  longer and a ghost membership outlives a crash.
- **`CommandSenderCallback.restartDelayedEvent(roomId, eventId)` is new.**
  Implement it as `update_delayed_event` with `UpdateAction.Restart` (MSC4140's
  "heartbeat ping"). Do *not* implement it as cancel-then-reschedule; see
  Fixed below for why.
- **`CommandSenderCallback.sendDelayedStateEvent(roomId, eventType, stateKey,
  contentJson, delayMs)` is new.** It is only ever called in
  `ElementCallCompat.STATE_EVENTS`, where the membership is room state and so its
  dead man's switch has to be too — the message-like `sendDelayedEvent` has no
  state key to send it under. Hosts not doing Element Call interop can implement
  it as a thrown `SendError`; the SDK will not reach it. See Added below.
- **The SDK now owns the `member.id`.** `FfiJoinSessionParams.membershipId` and
  `MediaSessionConfig.memberId` are gone; `join` returns the id it generated, and
  `connect_media_session` reads it from the join. Drop both fields and use the
  return value (or `ownMemberId(roomId, slotId)`, which cannot go stale).
  A host-chosen id was silently destructive when reused across joins: the
  MSC4195 participant identity is derived from it, so a rejoin kept the identity
  peers already held a key for while our key index restarted at 0 — every peer
  then decrypted our media with the previous call's key and never recovered.
  MSC4143 requires a fresh id per join, and nothing validated that.
- **`FfiCallEvent` gained a `FrameEncryptionState` variant.** uniffi generates
  the enum as a sealed class, so exhaustive `when` blocks without an `else` need
  a new arm.
- `FfiJoinSessionParams` gained `stickyDurationMs: Long?` — pass `null` for the
  default.
- WASM hosts: the JS client must implement `restartDelayedEvent(roomId,
  eventId)` and accept the new `durationMs` argument on `sendStickyEvent`.
  `join` no longer accepts `membership_id` and now resolves to the generated
  `member.id`; `ownMemberId(...)` reads it back.
- Android media builds must call `MatrixRtc.initialize()` before touching any
  FFI object. Required only for the media AAR (the slim signalling-only build
  loads fine through JNA); harmless to call either way.

### Added

- **Releases.** `.github/workflows/release.yml` (dispatched by hand, see
  [RELEASING.md](RELEASING.md)) builds the media variant for both platforms
  with the new `mobile-release` cargo profile, publishes the AAR to GitHub
  Packages (and Maven Central once its secrets are configured) as
  `io.element.android:matrix-rtc-android`, rewrites the root
  `Package.swift` with the xcframework zip's checksum, and tags `v<version>`
  with the AAR, the zip, split Android debug symbols and `SHA256SUMS` attached
  to the GitHub Release. The xcframework now ships its header and module map,
  so `import MatrixRtcFFI` resolves for SwiftPM consumers, the package declares
  the system frameworks and `libc++` that libwebrtc needs, and the archives are
  built for an iOS 16 deployment target rather than the host SDK's. The build scripts
  grew `--target`, `--profile`, `--split-debug`, `--skip-build`,
  `--skip-codegen`, `--version` (Android) and `--profile`, `--swift-out`,
  `--zip` (iOS) for the workflow; `make release-android` / `make release-ios`
  run the same locally. The Android consumer ProGuard rules are now valid
  (`consumer-rules.pro` carried a C-style comment) and keep JNA, the bindings
  and libwebrtc's Java classes.

- **Element Call reactions and the raised hand**, interoperable with Element
  Call and shared by every host through the core's new `reactions` module.
  An emoji reaction is an `io.element.call.reaction` relating to the sender's
  membership event, shown for three seconds and de-duplicated per member
  inside that window (Element Call's rules, unspecced); a raised hand is an
  `m.reaction` annotation of the membership event with key `🖐️`, lowered by
  redaction. Sending: `Call::send_reaction` / `raise_hand` / `lower_hand`
  (Rust), the same on `RtcSessionManagerHandle` (FFI) and
  `WasmRtcSessionManager` / `MatrixRtcCall` (JS), with a send cooldown that
  refuses what peers would drop anyway. Receiving: `CallEvent::Reaction`
  (with a sound *hint* — the SDK plays no audio; hosts bundle the assets the
  `reactionCatalog()` names), `CallEvent::HandRaised` / `HandLowered`, and
  `Participant.hand_raised_at_ms` on the roster so tiles can be ordered by
  who asked first. Our own hand is re-annotated onto the new membership
  event after every sticky refresh, because Element Call drops a hand whose
  membership event moved on; as a receiver we are lenient and keep a peer's
  hand for as long as they are in the call. Hands raised before we joined are
  recovered from the membership events' `/relations`: the Rust and JS hosts
  do this themselves, FFI hosts answer `pendingRelationLookups` (see the
  host obligations on `RtcSessionManagerHandle`). Configured per join with
  `JoinSessionParams::reactions` / `CallOptions::reactions`; on by default.

- **`MediaSession.unpublish(kind)`, so a stopped screen share can be retracted
  rather than left muted.** Muting keeps the publication up on purpose — that
  is right for a camera, where peers should tell a deliberate off from a
  wedged sender — but a screen has no "off" state, and peers kept rendering
  an empty tile for a muted share. Unpublishing removes the publication at
  the SFU (peers drop the stream), removes it from our own roster entry, and
  emits `StreamStopped`; underneath it are the new `CallEngine::unpublish`
  and `LocalTrackHandle::unpublish`. The `FfiLocalTrack` from `publish` is
  dead afterwards: `captureAudio`/`captureVideo` fail with a transport error
  instead of silently succeeding (and never crash, so a capture thread still
  mid-call during the unpublish is safe). Clarified in the docs what
  integrators had to find out by trying: dropping/`close()`-ing the
  `FfiLocalTrack` wrapper never retracts the publication.

- **MSC4075 call notifications, so a call can ring.** A membership says who is
  *in* a session; it never said who should be *summoned* to one, which is why a
  mobile client had nothing to raise an incoming call from. Passing `notify` on a
  join now sends an `m.rtc.notification` (wire:
  `org.matrix.msc4075.rtc.notification`) as a sticky event, with an `m.reference`
  relation to our own `m.rtc.member` event.

  - `NotifyConfig { notification_type: Ring | Notification, intent, lifetime_ms,
    mentions }` on `JoinSessionParams::notify`, `CallOptions::notify`,
    `FfiJoinSessionParams.notify` and the WASM join params' `notify`. Unset —
    the default — joins quietly.
  - **Only the member who *starts* the session notifies.** MSC4075 leaves the
    question open, but every joiner sending one would ring the room once per
    participant, so the core suppresses it when anybody *else* is already in the
    session — our own memberships are excluded from that count, both the current
    one (the host feeds the whole sticky map, which contains our echo) and a
    previous one still held as a candidate across a `leave()` in the same
    process. This matches matrix-js-sdk's `oldMemberships.length === 0`, and the
    captured Element Call exchange in
    `skills/e2e-testing/references/Alice-Bob-Call-Events.md`, where Bob starts
    and Alice, joining second, sends nothing. The application still decides
    whether to ask at all — Element Call passes the notification type only when
    the app *starts* a call, never when it joins one.
  - **The content carries the call fields twice, on purpose.** MSC4075 as
    written nests them under `application`; nothing deployed reads them there.
    Element Call puts `notification_type`, `sender_ts`, `lifetime` and
    `m.call.intent` at the top level, and so does ruma's
    `RtcNotificationEventContent` — which is what matrix-rust-sdk hands a mobile
    client, and which *requires* all three at the top level, so a purely nested
    event fails to deserialize there and rings nobody. Both shapes are written;
    a reader of either ignores the other as unknown fields. `element_call_compat`
    additionally strips `application` and `m.text`, for the byte-exact legacy
    shape.
  - Not implemented, and a separate change: the receiving rules (push rules,
    `m.mentions` match, an open slot, not already joined), lifetime expiry
    against `origin_server_ts`, optimistic ringing, `m.call.ring.ack`
    acknowledgements, and the sender-side "still ringing" indication. On mobile
    the first signal is a push notification, which arrives outside this
    workspace entirely.
  - `skills/msc/references/msc4075.md` vendors the proposal.

- **An automated Element Call interop test.** Both compat dialects were
  validated against real Element Call by hand, once; nothing re-checked them, so
  a regression in a dialect, an identity derivation or a key binding stayed
  invisible until somebody repeated a manual call. Now a Rust client and a real
  Element Call join the same call in CI, and each side asserts it can see,
  key-exchange with and decrypt media from the other:

  - `demo/backend/docker-compose.interop.yml` — a TLS overlay on the existing
    backend stack (nginx fronting `*.m.localhost` with a CA minted at up time,
    plus Element Web). Element Call is a widget in an iframe and needs a secure
    context, which `http://localhost` cannot give it. Element Web **ships
    Element Call embedded**, so there is no Element Call service to run — the
    version under test is the one users get. The base compose file is untouched
    and `make test-e2e` is unaffected. See `demo/backend/INTEROP.md`.
  - `crates/matrix-rtc-livekit/examples/interop_peer.rs` — the Rust half, driven
    over stdin, reporting JSON lines on stdout.
  - `interop/` — the Playwright suite that owns the browser and drives that
    peer, parametrised over Element Call's `Compatibility: state events`
    (`ElementCallCompat::StateEvents`) and `Matrix 2.0` (`StickyEvents`).
    `ElementCallCompat::Off` has no Element Call counterpart yet and stays
    `e2e_call`'s job.
  - `.github/workflows/interop-element-call.yml` — nightly against Element Web
    `develop` (the drift signal), on demand, and on PRs labelled `interop`
    against a pinned image.

- **`openSlot(roomId, slotId, applicationType, encryption)` and
  `closeSlot(roomId, slotId)` on the manager handle**, wrapping the core calls the
  native path has always had. A room has no slot until somebody opens one, and a
  host that reports slot state projects every member out of a room that has none —
  so in a room where no other client opens slots, this is what makes a call
  possible at all. That includes every room whose other participant is Element
  Call: no generation of it publishes `m.rtc.slot`. `encryption` is the new
  `FfiSlotEncryption` (`PerMember`, or `Other { encryptionType }`), required in an
  encrypted room and forbidden elsewhere. A `slotId` that does not start with
  `{applicationType}#` is refused here rather than by the homeserver, which would
  accept a slot every client then treats as closed.

- **Element Call interop over the FFI**, so an Android or iOS host can be tested
  against Element Call rather than only against another Rust client. Both
  generations, selected per join with
  `FfiJoinSessionParams.elementCallCompat: FfiElementCallCompat?`
  (`OFF` / `STICKY_EVENTS` / `STATE_EVENTS`, `null` meaning `OFF`).

  Chosen once and remembered for the room, because it is one decision rather
  than a wire-format flag: it also fixes the `member.id` the session joins with,
  how an inbound media key is bound to a membership, the SFU participant
  identity, and which authorisation-service endpoint mints the token. The media
  session reads it back from the join rather than taking it again — those two
  disagreeing is not an error but a silence, a fully connected call in which
  nothing decrypts.

  The outbound half needs no host change: memberships, the delayed leave and
  media keys are rewritten (or re-routed to room state) inside the binding. The
  inbound half does, because reading a legacy membership means parsing a content
  that states its transports somewhere else, its membership nowhere at all, and —
  a generation earlier — is not a sticky event:

  - `setCurrentMembership(roomId, memberEvents, legacyStateEvents)` takes raw
    event content and does the parsing in Rust. Both sources in one call, because
    it replaces the room's whole membership: fed separately, each call would wipe
    the other's members and the roster would flicker between the two halves of
    the call. Spec-current hosts keep using `setCurrentStickyState`.
  - `receiveLegacyEncryptionKey(sender, contentJson, wasEncrypted,
    senderDeviceId, senderIsCrossSigned)` ingests
    `io.element.call.encryption_keys`. Easily forgotten, and expensive to forget:
    the roster fills in, everything looks joined, and every remote tile stays
    black.
  - In `STATE_EVENTS` only: implement `sendDelayedStateEvent` (see Breaking).

  Slots need no host handling. Element Call publishes no `m.rtc.slot` in either
  generation, so the truthful "no slots" a host feeds would resolve the session
  closed and project out every member, itself included. In `STATE_EVENTS` the
  mode absorbs it: the join calls the new
  `RtcSessionManager::forget_room_slots(room_id)` — the way back from
  `on_room_slots_received`, which was otherwise irreversible, since an empty slot
  list means "no open slots" rather than "I have nothing to say" — and later slot
  updates for that room are ignored. The condition returns to unenforced, which
  is the honest answer for a generation that predates the concept. `STICKY_EVENTS`
  keeps it enforced, because those rooms are otherwise spec-shaped and a slot in
  one is meaningful; a host feeding slot state there needs the slot opened, as
  the native tools do with `--open-slot`.

  The translation itself is `matrix-rtc-bridge`'s `compat`, unchanged and shared
  with the native path; `matrix-rtc-ffi` gained a dependency on that crate
  (without its `matrix-sdk` feature — pure JSON, no git dependencies, so the slim
  mobile artifact is unaffected).

- **Interop with *pre-sticky* Element Call — membership as room state
  (`matrix-rtc-livekit`'s `compat::element_call_state`).** One generation older
  than the dialect below: before MSC4354 existed, Element Call carried MatrixRTC
  membership as `org.matrix.msc3401.call.member` **room state events**, using the
  state key for per-device keying and room state for the delivery guarantee
  stickiness now provides.

  Four things change at once, so unlike its sibling this cannot be an additive
  rewrite — a call joined this way is visible to that generation and to nobody
  else:

  - **Carrier.** The membership is a state event keyed
    `_{user}_{device}_{application}{call_id}`, sent with
    `PUT /rooms/{id}/state/...`, and the dead man's switch becomes a *delayed
    state* event. That last one is an improvement the spec path still lacks: a
    delayed state event with `{}` content genuinely empties our membership,
    whereas a delayed sticky leave clears nothing from the sticky map, so crash
    cleanup there still rides on the sticky TTL.
  - **SFU identity.** The plain `{user}:{device}` string the legacy
    authorisation service mints, not the MSC4195 hash of
    `[user, device, member_id]`. All four derivation sites — our own identity,
    the core's `RtcIdentityMapper`, `remote_identity`, and the local frame
    cryptor's compare — now share one `Arc`, because a divergence there is not an
    error but a silence: peers sit in the roster with no media and their keys land
    under an identity the SFU never assigned.
  - **Token.** `POST /sfu/get` with `{room, openid_token, device_id}`, not
    MSC4195's `/get_token`. Deliberately *not* a 404-driven fallback: the endpoint
    is bundled with the identity derivation and the membership carrier, both
    decided before any HTTP happens, so a 404 cannot retroactively change what we
    already published — and succeeding with the wrong derivation yields a fully
    connected session in which nothing decrypts and nobody appears.
  - **Content.** `application` as a string plus `call_id`/`scope` instead of a
    `slot_id`, `membershipID` instead of `member.id`, an in-content
    `created_ts + expires` lifetime, and `foci_preferred` +
    `focus_active.focus_selection` instead of `transports`.

  The core still speaks only MSC4143. Inbound, state events are read from the SDK
  store (`m.call.member` *is* in sliding sync's `required_state`, unlike the
  MSC4143 slot type) and translated into synthetic sticky memberships with
  `EventOrigin::Claimed`, with two things resolved in the translation because
  nothing downstream can: expiry, since the core has no membership deadline and no
  timer, and `focus_selection: "oldest_membership"`, which makes a peer's SFU a
  property of the room's whole membership rather than of that peer's event.

  Two consequences worth knowing. The bridge grows a room-state wake source and a
  30 s poll in this mode, because a state-carried call produces **no sticky
  traffic at all** and a bridge waiting only on sticky events would seed once and
  sleep through the whole call. And the slot condition is left *unenforced*
  (`SlotKnowledge::Unsupplied`) rather than reported empty: that generation has no
  slot concept, so saying "no slots" would resolve every session closed and drop
  every member, us included.

  Opt-in in both directions, unlike the sticky dialect's always-on reader — this
  one reads a different event type in a different part of the room, so left on
  everywhere any room that ever hosted an old Element Call would show a call that
  ended months ago.

- **Interop with pre-2026 Element Call (`matrix-rtc-livekit`'s `compat`
  module).** Element Call on the JS SDK is the only other MatrixRTC
  implementation available to test against, and it still speaks the wire format
  from before the 2026 MSC4143 rewrite: `member: {user_id, device_id, id}` with
  no `membership`, a flat `rtc_transports` array, a leave whose content is a
  bare sticky key, and media keys as `io.element.call.encryption_keys`.

  All of it is confined to two JSON funnels at the crate's edge — the core never
  sees a dialect parameter or a legacy field. **Reading** the old format needs no
  flag and is always on: every rule fires only where the modern field is absent
  and its legacy counterpart is present, so a spec-shaped event is passed through
  untouched. **Writing** it is opt-in per call via
  `CallOptions::element_call_compat = StickyEvents`, since it is the half that changes what
  peers see. A join stays MSC4143-valid, the legacy fields riding alongside; a
  leave and a media key cannot be both at once, so a leave becomes the legacy
  bare-sticky-key content (Element Call has no `membership` field, and a spec
  leave padded to satisfy its validator would read to it as still *joined*) and
  keys go out under the legacy type *instead of* the spec one, a to-device
  message having only one type. Delete the module and the flag once Element Call
  catches up.

- **`EventOrigin::Claimed`** — a sending device a member event asserts rather
  than one decryption proved. Element Call runs as a widget and the widget API
  gives it no decryption metadata, so a self-asserted device is the only one it
  can state or read; without somewhere to put it, no media key can travel in
  either direction with such a peer. Ranked below `Encrypted` throughout:
  `was_encrypted()` stays `None`, so it never satisfies the "member events MUST
  be encrypted in an encrypted room" rule, and an inbound key must still arrive
  Olm-encrypted from the very device named. Produced only by the compatibility
  path, and only where no authenticated device was available.

- **Publishing raises `StreamStarted` against our own `member_id`, and
  `MediaSession.setLocalMuted(kind, muted)` mutes it.** Our own publications
  never arrive as transport events — nothing subscribes us to ourselves — so a
  host's own roster entry lacked the microphone it was actively capturing, and
  alone in a call nothing later prompted a re-read to correct it. Hosts were
  shadowing their own mute state to render themselves truthfully.

  Muting goes to the transport as well as the roster, so peers are told: a muted
  sender and one that has merely stopped pushing frames look the same to a peer
  otherwise, and the second is what a wedged client looks like.
  `StreamMuted`/`StreamUnmuted` are emitted against our `member_id` exactly as
  for anyone else, so a host can render itself from the same source.
- **`subscribeMembershipSnapshots(roomId, slotId)` on
  `RtcSessionManagerHandle`.** The roster previously existed only on
  `RtcSessionHandle`, while media requires the manager — so a host driving the
  manager could read `memberCount` but never learn *who* was in the call, and
  polling a count once a second was the only way to notice a change. Returns
  `null` when no session exists for that slot yet. This is also what a host
  watches to be told a call has started.
- `MediaSession.receiveStats(memberId, kind)` reports cumulative receive-side
  RTP counters — packets, bytes, loss, jitter, `framesDecoded`, and the audio
  concealment counters. The receive path emits frames at a fixed cadence whether
  or not RTP arrives, so this is the only way a host can distinguish "nothing is
  arriving" from "arriving but not decoding".
- `FfiCallEvent.FrameEncryptionState` surfaces the frame cryptor's verdict
  (`Ok` / `MissingKey` / `DecryptionFailed` / `EncryptionFailed` /
  `InternalError`). Reported per participant, not per stream.
- The keep-alive now runs by itself: `join()` starts a driver and `leave()`
  stops it. `RtcSessionManagerHandle.heartbeat(roomId, slotId)` is exported for
  hosts that would rather drive it from their own scheduler.
- The membership's sticky-map entry is re-sent once it is halfway to expiring,
  configurable per join via `stickyDurationMs` (default 1 h, the maximum
  MSC4354 allows).
- `MatrixRtc.initialize()` on Android owns native library loading, so
  libwebrtc's `JNI_OnLoad` runs.
- `Call::receive_stats` for parity on the native Rust facade.
- `ownMemberId` on the manager and session handles (FFI and WASM), and
  `RtcSession::own_member_id` / `RtcSessionManager::own_member_id` in the core.
- `scripts/build-android-aar.sh` now fails the build if a produced `.so`
  exports no `Java_livekit_org_webrtc*` symbols.
- **`FfiCallEvent.FrameEncryptionState` now carries a `diagnostic`.** The frame
  cryptor reports *that* it cannot decrypt, never why; this adds whether any key
  was installed for that participant (`NoKeyInstalled` / `KeysInstalled(indices)`),
  which splits a `MissingKey` into the two cases needing different
  investigations — nothing ever arrived, versus frames carrying an index we have
  not been given yet.
- **`FfiCallEvent.KeyDiscarded` reports a key that arrived and was *refused*,
  with the reason** (`FfiKeyRejection`: cleartext, not cross-signed, room /
  sender / device mismatch, unverifiable device) and the device that sent it.
  Previously these reasons were warn-logged inside the core and never crossed the
  FFI, so a refused key was indistinguishable from one that never arrived — a
  trust problem looking exactly like a delivery problem. `NotCrossSigned` in
  particular is a "verify this device" prompt, which is why the reason is typed
  rather than a message.
  Corresponding core API: `EncryptionKeySignalHandler::on_key_discarded`
  (defaulted, so existing handlers need no change) and `DiscardedKey`.
- Core-side log lines that an Android integration had to add by hand to make
  failures distinguishable: recipient *and* index on every key send (flagging a
  send addressed to ourselves), a per-rollout delivery summary naming members the
  key could not be delivered to, the provenance of each received key
  (`from user/device cross_signed=…`) before it is judged, and frame-encryption
  changes as a transition (`Ok -> MissingKey`) rather than a bare state.

### Fixed

- **A homeserver without MSC4140 delayed events could not join a call at all.**
  `matrix.org` answers `403 M_FORBIDDEN "Sending delayed events has been
  disallowed"`, and the dead man's switch was armed as step 1 of the join, so
  that 403 failed the whole join — no call, on a homeserver where the call works
  perfectly well.

  The delayed leave is a cleanup *optimisation*: both dialects already expire a
  membership on their own, so losing it costs the speed of the cleanup, not the
  call. The join now degrades instead of failing, and publishes the membership on
  `degraded_lifetime_ms` (new; default 5 min, on `JoinSessionParams`,
  `CallOptions`, `FfiJoinSessionParams` and the WASM join params) so a client that
  dies is forgotten in minutes rather than in an hour. Hosts can throw the new
  `CommandSenderError::NotSupported` from the delayed-event callbacks to say the
  homeserver means it — optional, since a plain `SendError` degrades the same way,
  with a re-probe every five minutes in case it was a blip.
  `RtcSession::delayed_leave_supported()` reports which mode a session ended up
  in.

  Five minutes and not less because MSC4354 says a sticky duration "SHOULD NOT be
  set to below 5 minutes" — a server whose `origin_server_ts` runs behind expires
  sticky events early, and a short duration has no room to absorb that. The
  lifetime is also chosen *before the first membership is published* and never
  moved: MSC4354 keeps whichever event with a given `sticky_key` expires last, so
  an hour-long join entry would out-live every shorter refresh after it and the
  degradation would buy nothing.

  In `StateEvents` compat mode this is the *only* thing bounding a ghost — room
  state has no TTL and there is no delayed `{}` to empty it — so `expires` is now
  derived from that lifetime and moved forward on every refresh, instead of being
  pinned at the JS SDK's four hours. `created_ts` still never moves: peers read it
  as the join instant for `oldest_membership` focus selection.
- **Key rotation never took effect: we advertised a new key and kept encrypting
  with the old one.** `KeyProvider::set_key` only fills the key *ring*; the index
  a sender stamps lives on its frame cryptor, which is created at index 0 and
  moves only via `set_key_index` — something nothing called. Two consequences:
  any peer joining after a rotation held only the new index and could decrypt
  nothing from us, and **rotate-on-departure did not deliver the forward secrecy
  it exists for** — we reported the rotation and carried on using the key the
  departed member holds.

  The key bridge now moves our sender onto each of our own keys as it activates
  (at activation, so MSC4143's `delayBeforeUse` still gates it), and the
  connection re-asserts the current index after every publish, because a track
  published after a rotation gets a fresh cryptor at index 0. A key the ring
  refused never moves the sender — that would make our media undecryptable for
  everyone rather than for one peer.

  No test had ever rotated a key: in both existing e2e scenarios the second peer
  joins inside the 10 s grace period, so the rollout reuses the current key. The
  new `e2e_call_rejoin_in_the_same_process` scenario is what exposed it.
- **The second call in a process distributed no media key at all.** A session is
  keyed by `(room_id, slot_id)` and outlives `leave()` on purpose, so a rejoin
  started with the previous call's roster already in place. Key distribution was
  only ever driven by a roster *change*, and there is none when the incumbent's
  membership is unchanged across our leave and rejoin — so the first call in a
  process distributed its key and every later one silently distributed nothing,
  leaving peers at `MISSING_KEY` for the whole call. `join()` now drives the first
  distribution itself, unconditionally.
- **A previous participation of our own device counted as a peer.** MSC4143 mints
  a fresh `member.id` per join, so the superseded one lingered in the roster as a
  phantom member: the media layer opened a receive stream for it and waited for a
  key that could never arrive, and it forced a key rotation whose only recipient
  was a device that cannot receive its own to-device messages. It is now excluded
  from the joined set (matched on user *and* device, so other devices of our own
  user stay ordinary peers), and `leave()` republishes the roster immediately
  rather than waiting for the host's next sticky delta.
- **The same key index was imported repeatedly.** The eager first-key signal was
  gated on `shared_with` being empty, which is also the state a rollout with no
  recipients leaves behind — so in a solo call every membership update re-signalled
  the same index, and each reached the transport as a fresh key import. Gated on
  the index last signalled instead.
- **A peer's rekey at an index we already held was discarded.** `OutdatedKeyFilter`
  stamps receive time (MSC4143 puts no creation timestamp on the wire) and treated
  an equal timestamp as stale, so a rekey arriving in the same millisecond was
  dropped and that peer's media never decrypted. Equal timestamps now pass, one
  entry is kept per index holding the newest material, and identical
  re-deliveries are recognised on the key material itself.
- **A rotation nobody could decrypt still waited out its `delayBeforeUse`.** The
  delay exists to keep members who hold the *outgoing* key decrypting while its
  replacement propagates. After the call had sat empty the key we held had gone to
  nobody, so waiting protected no one and left the arriving member — holding
  nothing — undecryptable for the full delay instead of just for its own key's
  delivery. It is now skipped when no member present holds the outgoing key.
- **The coalesced follow-up key distribution was always dropped.**
  `ensure_key_distribution` recursed *before* clearing its in-progress flag, so
  the follow-up took the "already in progress" branch and returned without rolling
  out anything. Replaced with a loop.
- **Keys imported before a membership arrived could be lost.** The engine held one
  pending index per identity, so a second import before the sticky membership
  landed overwrote the first; identity-keyed buffers also survived a departure and
  could resurface against a later member. Both fixed.
- **A peer using the stable `sticky_key` spelling vanished from the call.** The
  core accepted only `msc4354_sticky_key`, while matrix-rust-sdk reads both, so
  such a member event failed to deserialize and was dropped whole — silently.
  Both spellings are now accepted, and an unparseable member event is logged
  instead of ignored.
- **Keys held at `Call::join` time surfaced no `KeyImported`.** The native facade
  never replayed them, and installed the identity mapper *after* the signal
  handler, so a key signalled in between was imported under a fallback identity
  the SFU never uses. Both corrected.
- **Android aborted on session start.** `libmatrix_rtc_ffi.so` exported none of
  libwebrtc's `Java_*` JNI symbols, so its Java classes had no native
  implementation and constructing `PeerConnectionFactory` killed the process.
  The link arguments have to be emitted from the crate that owns the cdylib —
  `cargo:rustc-link-arg` from an rlib dependency is silently dropped.
- **TLS handshake failure on the LiveKit signal socket.** `rustls-native-certs`
  finds no certificates on Android; the connection now also carries the bundled
  webpki root store.
- **Panic and permanently wedged manager.** The MSC4143 `delayBeforeUse` wait
  armed a tokio timer with no reactor in context, and the resulting panic
  poisoned the manager's mutex — after which every call failed, including
  `leave()`. The core no longer arms timers at all (the delay travels to the
  consumer as `KeyMaterialSignal::use_after_ms`), and poisoned locks are
  recovered rather than propagated.
- **Media keys received before the media session attached were dropped.**
  Key signals with no handler installed were discarded, and nothing re-signalled
  them until a rotation — which needs a membership change. They are now replayed
  on attach, under identities derived through the installed identity mapper, and
  after the key-import listener is wired — so replayed keys surface as
  `KeyImported` events instead of being applied invisibly.
- **The keep-alive never ran on the FFI path.** `heartbeat()` existed and was
  driven by the native Rust facade, but nothing called it through the FFI and it
  was not exported, so a host could not even opt in.
- **The heartbeat no longer cancels and reschedules the delayed leave.** It uses
  MSC4140's `restart`: one request instead of two, and never a moment with
  nothing armed. The old approach could leak a delay whose leave then fires —
  and because MSC4354 resolves sticky conflicts by *last to expire*, that leave
  out-expires the live membership and shows the user as having left a call they
  are still in.
- **We could try to send our own media key to our own device.** The recipient
  filter excluded us by `member.id`, which is fresh per join — so a stale
  membership of our own device (crash without leaving, rejoin inside its sticky
  lifetime) read as a peer. Olm has no session with the sending device, so that
  send failed; and since our own user+device under a new `member.id` also forces
  a key rotation, the ghost forced rotations and broke them for as long as it
  stayed visible. The filter now matches on user + device. Other devices of our
  own user remain ordinary recipients.
- **Media keys are no longer broadcast to every device of a user.** A membership
  that named no sending device fell back to `"*"`, which hands the key to devices
  that are not in the call — and, for our own user, to this device. Such a
  membership is now logged and skipped, and the matrix-rust-sdk bridge no longer
  implements a `"*"` fan-out at all: `sendToDeviceMessage` always names exactly
  one device, and a host implementation must not widen it.
- **One unreachable recipient no longer abandons a key rotation.** Distribution
  stopped at the first failing send, so later recipients got nothing *and* the
  new key was never stored or signalled: we kept encrypting with the old key and
  the rotation vanished silently. Failures are now logged per recipient and the
  rollout continues. (Recipients are still recorded as shared with regardless of
  outcome, so a failed send is not retried — see the `TODO` in
  `encryption/mod.rs`.)
- **`leave()` failed when the delayed leave had already fired.** The 404 from
  cancelling an expired delay aborted the leave after the leave event had
  already been sent, leaving the state machine stuck in `Leaving`. Cancellation
  failure is now logged, not propagated — an already-fired delay is the outcome
  a leave wanted anyway.
- **`MediaSession.disconnect()` threw on a normal hangup.** LiveKit answers
  `AlreadyClosed` both for a second disconnect and for a room the SFU already
  tore down; closing an already-closed connection now succeeds.

### Known limitations

- The delayed leave is a plain, non-sticky delayed event, so it clears nothing
  from the sticky map when it fires. Crash cleanup therefore relies on the
  membership's own sticky TTL, and a client that dies without leaving lingers as
  a ghost for up to `stickyDurationMs` rather than `keepAliveTimeoutMs`. This is
  a ruma limitation rather than a protocol one — both `delay` and
  `sticky_duration_ms` are query parameters on the same send endpoint, but no
  ruma request type carries both. See the note in
  `crates/matrix-rtc-livekit/src/matrix_bridge.rs`.
- Frame encryption state is reported per participant, not per stream: the frame
  cryptor is keyed by participant identity, so a failure does not say which of
  their tracks it came from.
- Android honours only the bundled root certificate store for the SFU
  connection, so a deployment fronted by an enterprise or internal CA will still
  fail the TLS handshake. Fixing that needs `rustls-platform-verifier` support
  in `livekit-api`.
