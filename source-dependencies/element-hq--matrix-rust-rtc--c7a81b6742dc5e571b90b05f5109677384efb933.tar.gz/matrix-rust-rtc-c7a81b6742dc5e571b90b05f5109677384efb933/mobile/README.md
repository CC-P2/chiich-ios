# Mobile Build Setup

This directory contains build scripts and configuration for packaging the Matrix RTC FFI library for mobile platforms.

## Quick Start

### Install Build Tools

```bash
# Install Rust toolchain additions and build tools (the bindings generator is
# the in-repo `uniffi-bindgen` crate; nothing else to install)
cargo install cargo-ndk

# Add iOS targets
rustup target add aarch64-apple-ios aarch64-apple-ios-sim x86_64-apple-ios

# Add Android targets
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
```

### Build Android AAR

```bash
./scripts/build-android-aar.sh
```

Output: `mobile/android/matrixrtc/build/outputs/aar/matrixrtc-release.aar`

### Build iOS XCFramework

```bash
./scripts/build-ios-xcframework.sh
```

Output: `mobile/ios/build/MatrixRtcFFI.xcframework` (headers included) and the
generated Swift in `mobile/ios/generated/MatrixRtc.swift`.

Published releases (Maven artifact and Swift Package) are described in
[PACKAGING.md](./PACKAGING.md#consuming-a-release); cutting one is
[../RELEASING.md](../RELEASING.md).

## Load the native library first (Android)

```kotlin
import org.matrix.rtc.MatrixRtc

MatrixRtc.initialize()
```

This must run before any other SDK call. The generated bindings reach the native
library through JNA, which `dlopen`s it — and `dlopen` does not run `JNI_OnLoad`,
only `System.loadLibrary` does. In the media build `JNI_OnLoad` is what gives
libwebrtc its `JavaVM` and class loader, so without this call the first attempt to
open a session aborts the process from inside libwebrtc rather than throwing.

It is idempotent, and the `RtcLogging` helpers below call it themselves, so setting
logging up as your first SDK call covers it too.

## The objects: client → room → call

```kotlin
val client = RtcClient(backend)                    // one per Matrix session; does no I/O
val room = client.room(roomId, FfiRoomOptions()) // subscribes, resolves once the room's state is in
room.memberCount("m.call#room")                    // observe a slot without joining it
val call = room.joinCall(FfiJoinSessionParams(slotId = "m.call#room", application = "m.call"))
val media = connectMediaSession(call, MediaSessionConfig(/* … */))
// …
call.leave(FfiLeaveSessionParams(leaveReason = null))  // the call object is over afterwards
room.shutdown()                                    // leaves what is still joined, ends the subscription
```

- **Open a room only while you need it.** A room costs its subscriptions for as
  long as its object lives; the client holds nothing about a room until you ask
  for one, and its to-device key subscription runs only while a room is open.
- **One live room object per room, one live call per slot.** Opening an open
  room, or joining a joined slot, is refused.
- **Dropping is not leaving.** A dropped room or call ends its subscriptions and
  keep-alive but sends nothing; the membership expires through its delayed leave.
  `leave()` and `shutdown()` are the clean paths; Kotlin's `close()` (or
  `use {}`) frees the object, which is dropping it. Joining a slot whose call was
  dropped leaves that participation first.
- **The library does not detect incoming calls.** Ringing reaches the app
  through its own SDK or push path; open the room when the user answers or
  starts a call.

## When the call ends

Every ending takes one path: `call.leave()`, the slot closing mid-call (the
library sends your leave with `leave_reason.code = "slot_closed"` on its own) or
`room.close()`. The call is over (`isLive()` is false) as soon as `leave()` is
called, even if the leave then fails to send, and a `MediaSession`
ends itself — `Ended(Left)` or `Ended(SlotClosed)`, every SFU connection closed —
so there is no separate `disconnect()` to call. Stop camera and microphone
capture on that `Ended`. A host running its own media waits on
`call.waitForEnd()` and tears it down there.

## Turn on logging first

The SDK is silent until the host installs a logger. Do this before creating an
`RtcClient`, or you will see nothing at all — not even errors.

**Android**

```kotlin
import org.matrix.rtc.RtcLogging
import org.matrix.rtc.RtcLogLevel

RtcLogging.initLogcat(RtcLogLevel.DEBUG)
// noisier, for one subsystem:
RtcLogging.initLogcat(RtcLogLevel.INFO, "matrix_rtc_core=debug,matrix_rtc_livekit=trace")
```

```bash
adb logcat -s matrix-rtc
```

To route into Timber, a rageshake file, or any host pipeline, use
`RtcLogging.init(...) { record -> ... }` instead. The callback runs on a dedicated Rust
thread and may block; records are dropped rather than queued without bound if it falls
behind (`droppedLogRecordCount()` reports how many).

**iOS**

```swift
try setupLogging(config: RtcLogConfig(level: .debug, filter: "", writeToSystem: true),
                 sink: nil)
```

Output goes to stderr, which appears in the Xcode console.

**Filter syntax** is `RUST_LOG`'s. Targets are Rust module paths matched by prefix; the
roots are `matrix_rtc_core`, `matrix_rtc_call_sdk`, `matrix_rtc_transport`, `matrix_rtc_livekit`,
`matrix_rtc_ffi`, plus third-party `livekit` and `webrtc_sys`.

**Useful extras**

- `RtcLogging.log(level, message)` (or `logEvent(...)`) puts your own lines in the same
  timeline as the SDK's, which is usually how you tell an SDK bug from an integration one.
- `room.debugSnapshot()` returns JSON of the room's state, every slot, and each
  candidate member with the reason it is or is not joined — attach it to bug reports.
- Key material, LiveKit JWTs and OpenID tokens are never logged at any level.

See the "Logging" section of [../ARCHITECTURE.md](../ARCHITECTURE.md) for the level
conventions the SDK follows.

## Staying in the call (keep-alive)

Two independent clocks expire your membership, and the SDK tends both for you.
`joinCall()` starts the call's upkeep and `leave()` (or dropping the call)
stops it — **there is nothing to call.**

| Clock | Default | Kept alive by |
| --- | --- | --- |
| Delayed leave (dead man's switch) | 30 s | Restarting its timer every 10 s |
| Sticky-map entry for your membership | 1 h | Re-sending the membership once it is halfway to expiry |

Both are configurable per join via `keepAliveTimeoutMs` and `stickyDurationMs`.
Shortening `stickyDurationMs` buys nothing but extra traffic — the refresh
interval is derived from it. Values above one hour are clamped, because servers
clamp them too and the refresh has to stay ahead of the real expiry.

Two `MatrixBackend` methods are load-bearing here, and both are easy to
implement in a way that looks right and silently breaks the call:

- **`sendStickyEvent(..., durationMs)`** — pass `durationMs` through verbatim;
  with matrix-sdk-ffi that is
  `Room.sendStickyRaw(eventType, content, durationMs)`.
  Substituting a value of your own breaks the refresh: shorter and the
  membership disappears mid-call, longer and a ghost membership outlives a
  crash.
- **`restartDelayedEvent(roomId, eventId)`** — implement as
  `update_delayed_event` with `UpdateAction.Restart` (MSC4140's "heartbeat
  ping"). Do **not** implement it as cancel-then-reschedule: that leaves the
  call unprotected in between, burns the server's `max_scheduled` quota, and a
  failed cancel leaks a delay that later fires — and because the sticky map
  resolves conflicts by *last to expire*, that leave out-expires your live
  membership and shows you as having left a call you are still in.

A client that dies without leaving stays visible to peers for up to
`stickyDurationMs`, not `keepAliveTimeoutMs` — see Known limitations in
[../CHANGELOG.md](../CHANGELOG.md).

## Diagnosing "the call connects but I see/hear nothing"

Frames are produced at a fixed cadence whether or not RTP is arriving — an audio
stream with no incoming packets still yields 10 ms buffers of jitter-buffer
concealment (silence), and a video stream holds its last picture. So a silent call
and a silent-because-nothing-is-arriving call look identical at the frame level.
Two APIs separate them, without reading logcat.

**`MediaSession.receiveStats(memberId, kind)`** returns cumulative RTP counters, or
`null` if that stream isn't subscribed or no RTCP report has landed yet. Every field
is a running total, so sample twice and compare:

| Between two samples | Diagnosis |
| --- | --- |
| `packetsReceived` flat | Nothing is arriving: network, subscription, or SFU |
| `packetsReceived` up, `framesDecoded` flat | Arriving but not decoding (video) |
| `concealedSamples` up in step with `totalSamplesReceived` | The "audio" is entirely fabricated |
| both up, `packetsLost`/`jitter` rising | Arriving and decoding, but lossy |

For a per-tile health readout, ask for the whole window at once rather than one stream
at a time. **`MediaSession.receiveStatsFor(streams)`** takes a list of
`FfiStreamRef(memberId, kind)` and answers every entry in one round trip, in request
order, with `stats == null` exactly where `receiveStats` would return `null`. Bound the
list to the tiles you compose — the detail window you gave `setDetailWindow`, plus each
member's microphone — and call it once per second; at two hundred participants that is
one call per sample instead of hundreds.

Whose audio to play follows the tile roster too: every remote person tile in
`nextRoster().order` is a candidate, so on each roster open `audioStream(memberId,
MICROPHONE)` for candidates you have no player for — it returns `null` at once for a
member with no microphone track, so the retries cost nothing — and stop the player of
anyone who left the order. Do not rebuild that from `StreamStarted`/`StreamStopped`:
the event stream is for one-shots (joins and leaves, key reports, the call ending), and
a consumer that lags more than 256 events loses some, which must never cost anyone
their voice. `participants()` is a diagnostics pull, the whole call every time; read it
once for your own row and on demand, never per event. Who is speaking is
`FfiCallTile.speaking`; there is no event for it.

**`FfiCallEvent.FrameEncryptionState`** on the event stream names the cause when it is
a key problem. `MissingKey` means frames carry a key index we hold nothing for (their
key never reached us, or arrived under a different identity); `DecryptionFailed` means
we have a key for that index and it doesn't work. It is reported per participant, not
per stream — the frame cryptor is keyed by participant identity.

```kotlin
when (val event = session.nextEvent()) {
    is FfiCallEvent.FrameEncryptionState ->
        if (event.state != FfiFrameEncryptionState.OK) {
            val stats = session.receiveStats(event.memberId, FfiStreamKind.MICROPHONE)
            // packetsReceived > 0 here means the media path is fine and the key is not
            Timber.w("no media from ${event.memberId}: ${event.state}, stats=$stats")
        }
    else -> { /* ... */ }
}
```

## Testing against Element Call

Element Call is the only other MatrixRTC implementation there is to test against,
and it still speaks a pre-2026 wire format — two of them, in fact, which disagree
about where a membership lives rather than merely what it says. Pass
`format` when you open the room to speak one of them:

| Mode | Element Call generation | Membership lives in |
| --- | --- | --- |
| `null` / `CURRENT` | none — current MSC4143 + MSC4354 | sticky events |
| `STICKY2025` | 2025 | sticky events, legacy fields alongside the spec ones |
| `ROOM_STATE` | before MSC4354 | `org.matrix.msc3401.call.member` room state |

It is one decision, not a wire-format flag: it also fixes the `member.id` you
join with, how an inbound media key is bound to a membership, your SFU
participant identity, and which token endpoint mints your JWT. Choose it once,
when opening the room — the join and the media session read it back from
there. Getting a mode wrong
produces no error: the call connects, the roster may even fill in, and nothing
decrypts.

Reading the 2025 sticky dialect needs no mode and is always on. What your host
must do differently:

```kotlin
val room = client.room(roomId, FfiRoomOptions(
    format = FfiMembershipFormat.ROOM_STATE,
))
```

- **Nothing changes on the inbound side.** Your `MatrixBackend` delivers the
  same raw events in every mode; the library subscribes to the room state the
  mode needs (`org.matrix.msc3401.call.member` in `ROOM_STATE`), translates
  it, and reads that generation's `io.element.call.encryption_keys` to-device
  messages through the same to-device subscription. Do set `originServerTs` on
  every event: it is the deadline base for a membership that states no
  `created_ts`, and `0` reads as long expired.
- **In `ROOM_STATE` only:** honour the `stateKey` of `sendDelayedEvent` — the
  dead man's switch has to be a state event too.

Slots need nothing from you. Both generations of Element Call publish no
`m.rtc.slot`, so the truthful "no slots" your backend reports would resolve the
session closed and drop every member, you included. In `ROOM_STATE` the SDK
absorbs that: it does not subscribe to slot state for the room at all, leaving
the condition unenforced — that generation predates the concept entirely, so
"unknowable" is the honest answer rather than "closed".

In `STICKY2025` the condition stays enforced, because those rooms are
otherwise spec-shaped and a slot in one is meaningful. Someone has to open the
slot — otherwise the room reads as all-closed, and `join` refuses with
`SlotClosed`. Element Call will not, so open it yourself (it needs the power
level for `m.rtc.slot` state; the room creator by default, or set it in the
room's initial state):

```kotlin
room.openSlot("m.call#room", "m.call", FfiSlotEncryption.PerMember)
```

`encryption` must be `PerMember` in an encrypted room and `null` elsewhere — the
mismatch resolves the slot closed for everyone. It needs the power level for
`m.rtc.slot` state (by default the room creator), and `closeSlot(slotId)`
ends the call for every member, which is not the same as leaving it.

Two traps that cost whole debugging sessions on the native path, and are not
specific to it:

- Element Call must join **after** your device has logged in and been seen by the
  homeserver. A fresh device cannot decrypt a member event sent before it
  existed, so the roster stays empty and every key is buffered.
- Use an **encrypted** room. The core discards a media key that arrived in the
  clear, as MSC4143 requires.

## Full Documentation

See [PACKAGING.md](./PACKAGING.md) for complete documentation including:
- Detailed build workflows
- Integration instructions for iOS and Android apps
- CI/CD examples
- Troubleshooting guides

