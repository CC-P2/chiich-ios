#!/usr/bin/env bash
# Copyright 2026 Element Creations Ltd.
#
# SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
# Please see LICENSE in the repository root for full details.

# Host-side readiness probe for the MatrixRTC backend stack. `docker compose up
# --wait` already gates on the synapse, livekit and lk-jwt healthchecks; this exists
# for what healthchecks cannot see from inside a container: that the
# endpoints answer from the host, where the tests run.
# With --interop it additionally probes the TLS overlay
# (docker-compose.interop.yml): the proxied homeserver, the MatrixRTC origin,
# Element Web, and the Element Call widget Element Web bundles.

set -euo pipefail

INTEROP=0
if [ "${1:-}" = "--interop" ]; then
  INTEROP=1
fi

probe() {
  local name="$1" url="$2"
  shift 2
  for _ in $(seq 1 60); do
    if curl -fsS -o /dev/null "$@" "$url"; then
      echo "[wait-ready] $name is up ($url)"
      return 0
    fi
    sleep 2
  done
  echo "[wait-ready] ERROR: $name never became ready at $url" >&2
  return 1
}

probe "synapse" "http://localhost:8008/health"
# MSC4195's C-S endpoints are proxied by Synapse to lk-jwt-service (as an
# application service). Unauthenticated, a served endpoint answers 401 and a
# missing one 404 — the check Element Call makes.
for _ in $(seq 1 60); do
  status=$(curl -s -o /dev/null -w '%{http_code}' -X POST \
    http://localhost:8008/_matrix/client/unstable/io.element.msc4195/rtc/livekit/delegate_delayed_leave || true)
  [ "$status" = "401" ] && break
  sleep 2
done
if [ "$status" != "401" ]; then
  echo "[wait-ready] ERROR: synapse has no /rtc/livekit route for lk-jwt-service (HTTP $status)" >&2
  exit 1
fi
# A 401 shows the route is registered; Synapse answers it before contacting
# the app service, so lk-jwt-service itself is probed below.
echo "[wait-ready] rtc/livekit C-S route registered (HTTP 401 unauthenticated)"
probe "lk-jwt-service" "http://localhost:6080/healthz"
probe "livekit" "http://localhost:7880/"
probe "lk-jwt-service-2" "http://localhost:6081/healthz"
probe "livekit-2" "http://localhost:7890/"

if [ "$INTEROP" = "1" ]; then
  # -k: the stack's CA is minted at up time, and whether the *host* trusts it
  # is a separate concern from whether the services are answering. The Rust
  # client does need that trust — see INTEROP.md.
  if ! curl -fsS -o /dev/null -k --max-time 5 https://synapse.m.localhost/_matrix/client/versions; then
    if ! grep -qE '^\s*[^#].*\bsynapse\.m\.localhost\b' /etc/hosts 2>/dev/null; then
      echo "[wait-ready] ERROR: synapse.m.localhost does not resolve. Add to /etc/hosts:" >&2
      echo "  127.0.0.1 synapse.m.localhost matrix-rtc.m.localhost app.m.localhost" >&2
      exit 1
    fi
  fi

  probe "synapse (via nginx)" "https://synapse.m.localhost/_matrix/client/versions" -k
  probe "rtc focus well-known" "https://synapse.m.localhost/.well-known/matrix/client" -k
  probe "lk-jwt-service (via nginx)" "https://matrix-rtc.m.localhost/livekit/jwt/healthz" -k
  probe "element-web" "https://app.m.localhost/" -k
  # The interop test drives the Element Call *bundled into Element Web*. If
  # that path 404s, every selector downstream fails in a way that reads like a
  # test bug — catch it here instead.
  probe "element-call (bundled)" "https://app.m.localhost/widgets/element-call/index.html" -k

  echo "[wait-ready] interop stack is ready"
  exit 0
fi

echo "[wait-ready] backend stack is ready"
