/*
Copyright 2026 Element Creations Ltd.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
Please see LICENSE in the repository root for full details.
*/

/**
 * The web stack and a real Element Call in the same call — EC's 2025 sticky
 * generation ("Matrix 2.0" in its Developer tab), our `sticky_2025` mode.
 * The web sibling of `element-call.spec.ts`'s second scenario, proving the
 * wasm compat seam end-to-end from a browser host: our membership goes out
 * with the legacy mirror fields (or EC shows no tile), EC's membership-less
 * member content normalises into our roster, and media keys cross as
 * `io.element.call.encryption_keys` in both directions (or nothing decrypts —
 * asserted by the video pattern EC reads back and the audio energy we meter).
 */

import { expect, test } from "@playwright/test";

import {
  acceptRoomInvite,
  callFrame,
  joinCall,
  loginToElementWeb,
  setRtcModeBeforeJoining,
  type RtcMode,
} from "../helpers/element-web";
import { registerUser } from "../helpers/register";
import { expectPeerVideoPattern } from "../helpers/video";
import { WebPeer } from "../helpers/web-peer";

const HOMESERVER_URL = process.env.HOMESERVER_URL ?? "https://synapse.m.localhost";

interface Scenario {
  /** Element Call's Developer-tab dialect. */
  ec: RtcMode;
  /** The matching web-peer mode string. */
  web: "room_state" | "sticky_2025";
  title: string;
}

const SCENARIOS: Scenario[] = [
  // Same order and rationale as element-call.spec.ts: the state dialect is
  // what deployed Element Call speaks today. It swaps the membership carrier
  // (msc3401 room state), the identity ({user}:{device}), the token endpoint
  // (/sfu/get), and the delayed leave (a delayed STATE event).
  { ec: "compat", web: "room_state", title: "ec-2024 state events" },
  { ec: "2_0", web: "sticky_2025", title: "ec-2025 sticky events" },
];

for (const scenario of SCENARIOS) {
test(`Web client and Element Call share a call — ${scenario.title}`, async ({
  browser,
}, testInfo) => {
  // Two logins with crypto bootstrap, a room, a real call and media.
  test.slow();

  const bob = await registerUser("ec");
  const page = await loginToElementWeb(browser, bob);

  // The web peer creates the room (and, outside the pre-sticky mode, opens
  // the slot): it puts our device in the room before Element Call ever joins —
  // a device that arrives later cannot decrypt a membership Element Call has
  // already sent.
  const web = await WebPeer.open(browser);
  await web.send({ cmd: "login", homeserver: HOMESERVER_URL });
  await web.waitFor("ready");

  try {
    const roomName = `Web interop ${scenario.ec} ${Date.now().toString(16)}`;
    await web.send({
      cmd: "create_room",
      name: roomName,
      invite: bob.userId,
      mode: scenario.web,
    });
    const created = await web.waitFor("room_created");
    const roomId = created.room_id as string;

    await acceptRoomInvite(page, roomName);

    // Before joining: the dialect decides the membership carrier, the SFU
    // identity and the token endpoint together, so it cannot change mid-call.
    await setRtcModeBeforeJoining(page, scenario.ec);

    // The web peer joins the slot first, publishing the interop pattern+tone
    // in the scenario's compat dialect.
    await web.send({
      cmd: "join",
      roomId,
      compat: scenario.web,
      publish: { pattern: true, tone: true },
    });
    await web.waitFor("joined", { timeout: 120_000 });

    // Both publications signalled frame-encrypted — Element Call decodes
    // cleartext frames too, flagging them only with a "not encrypted" badge
    // no other assertion here would catch.
    for (const kind of ["video", "audio"]) {
      const published = await web.waitFor("published", {
        predicate: (event) => event.kind === kind,
      });
      expect(published.encrypted, `the ${kind} publication must be encrypted`).toBe(true);
    }

    await joinCall(page);

    // ---- Element Call sees the web client ----------------------------------
    const frame = callFrame(page);
    await expect(frame.getByTestId("videoTile")).toHaveCount(2, { timeout: 90_000 });
    await expect(frame.getByText("Web Peer")).toBeVisible({ timeout: 30_000 });
    // Our frames decrypt and decode on EC's side: the published luma split
    // survives the whole legacy key path.
    await expectPeerVideoPattern(frame);

    // ---- the web client sees Element Call ----------------------------------
    await web.waitFor("members", {
      timeout: 90_000,
      predicate: (event) => (event.count as number) >= 2,
    });
    const subscribed = await web.waitFor("track_subscribed", {
      timeout: 90_000,
      predicate: (event) => event.kind === "audio",
    });
    // EC's legacy key installed under the identity the SFU assigned it.
    await web.waitFor("key_imported", {
      timeout: 90_000,
      predicate: (event) => event.identity === subscribed.identity,
    });
    // EC publishes Chrome's pulsed fake microphone; a peak reading above the
    // floor proves its audio decrypts with real energy in it.
    await web.waitFor("audio_rms", {
      timeout: 120_000,
      predicate: (event) =>
        event.identity === subscribed.identity &&
        (event.value as number) > (event.floor as number),
    });

    await web.send({ cmd: "leave" });
    await web.waitFor("left", { timeout: 60_000 });
  } finally {
    await web.dispose().catch(() => {});
    await testInfo.attach("web-peer.log", { body: web.log });
  }
});
}
