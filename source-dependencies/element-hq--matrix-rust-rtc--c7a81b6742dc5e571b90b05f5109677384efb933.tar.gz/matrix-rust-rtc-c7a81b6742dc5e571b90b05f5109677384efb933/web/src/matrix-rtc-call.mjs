/*
Copyright 2026 Element Creations Ltd.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
Please see LICENSE in the repository root for full details.
*/

/**
 * The call model for web apps: a joined wasm call's roster and connection
 * lifecycle, joined with livekit-js participants.
 * This is the thin JS half of the web media session. Rust owns the protocol
 * (membership reconciliation, the multi-focus pool, MSC4195 identities, token
 * request shapes, key bookkeeping); this wrapper owns what only JS can:
 * `fetch`, the livekit-js `Room`, and the RoomEvent-to-sink translation. Every
 * roster entry is a plain object from Rust plus `livekitParticipant` — the
 * live livekit-js participant, when the room knows the entry's `rtc_identity`.
 * `livekit-client` is not imported here: the app passes its module (or a
 * compatible mock) to the constructor, keeping it a peer dependency and this
 * file testable without it.
 */

/** livekit-js `Track.Source` values that map onto roster stream kinds. */
const KNOWN_KINDS = new Set([
  'microphone',
  'camera',
  'screen_share',
  'screen_share_audio',
]);

export class MatrixRtcCall {
  /**
   * @param {object} options
   * @param {object} options.call - the `WasmRtcCall` that `room.joinCall`
   *   returned.
   * @param {object} options.livekit - the `livekit-client` module (peer
   *   dependency): `Room`, `RoomEvent`, `ExternalE2EEKeyProvider` are used.
   * @param {(url: string, body: object) => Promise<{status: number, body: string}>}
   *   [options.fetchJson] - the token POST; defaults to global `fetch`.
   * @param {object} [options.roomOptions] - extra livekit-js `Room` options,
   *   merged under the E2EE ones (pass `e2ee.worker` here to enable frame
   *   encryption).
   */
  constructor({ call, livekit, fetchJson, roomOptions }) {
    this.call = call;
    this.livekit = livekit;
    this.fetchJson = fetchJson ?? defaultFetchJson;
    this.roomOptions = roomOptions ?? {};
    /** connectionKey -> Room */
    this.rooms = new Map();
    this.keyProvider = null;
    this.session = null;
    /** @type {(participants: object[]) => void} */
    this.onParticipants = () => {};
    /** @type {(event: object) => void} */
    this.onEvent = () => {};
    /**
     * Invoked with each livekit-js `Room` when it is created, BEFORE it
     * connects: `TrackSubscribed` and friends can fire while `connect()` is
     * still awaiting, so a listener added any later misses them.
     * @type {(room: object, connectionKey: string) => void}
     */
    this.onRoomCreated = () => {};
  }

  /**
   * Attach media to the joined call. Resolves once the own-focus room is
   * connected; roster changes then arrive via `onParticipants` and call
   * events via `onEvent`.
   *
   * The own focus is the one the join publishes on (none for a receive-only
   * call) and the account is the backend's.
   *
   * @param {object} [config] - `{ keyRingSize?, format? }`
   */
  async connect(config = {}) {
    if (this.session) throw new Error('already connected');
    this.config = config;
    this.keyProvider = makePerParticipantKeyProvider(this.livekit);

    this.session = await this.call.connectMedia(
      {
        key_ring_size: config.keyRingSize,
        format: config.format,
      },
      this.delegate(),
    );

    return this.participants();
  }

  /**
   * Send an Element Call emoji reaction. `name` is what peers pick a sound by
   * (`reactionCatalog()` in the bindings); only the first grapheme of `emoji`
   * is sent. Resolves with the event id; rejects inside the send cooldown.
   */
  sendReaction(emoji, name) {
    return this.call.sendReaction(emoji, name);
  }

  /** Raise our hand (idempotent while it is up). Shows on our roster entry at once. */
  raiseHand() {
    return this.call.raiseHand();
  }

  /** Lower our hand (a no-op when it is down). */
  lowerHand() {
    return this.call.lowerHand();
  }

  /** The raised hands right now, oldest first (`RaisedHand[]`). */
  raisedHands() {
    return this.call.raisedHands();
  }

  /** The current roster, each entry with its `livekitParticipant` when live. */
  participants() {
    return this.withLivekitParticipants(this.session.participants());
  }

  /**
   * Close every room and shut the media session down.
   * Leaving the slot is the call's (`call.leave`).
   */
  async disconnect() {
    if (this.session) {
      // Closes peer-focus rooms via the engine and the own focus through the
      // delegate's handle.
      await this.session.disconnect();
      this.session = null;
    }
    this.rooms.clear();
  }

  /** The delegate the wasm transport drives (see the transport module docs). */
  delegate() {
    const wrapper = this;
    return {
      fetchJson: (url, body) => wrapper.fetchJson(url, body),
      connect: (request, sink) => wrapper.connectRoom(request, sink),
      setKey: (identity, index, key) =>
        // livekit-js's provider: material, participant identity, key index.
        Promise.resolve(wrapper.keyProvider.setKey(key, identity, index)).then(
          (accepted) => accepted ?? true,
        ),
      // livekit-js moves the local sender with `setKey` for the local
      // participant; nothing further to do. Kept as a seam for versions (or
      // providers) where the sender index is a separate call.
      setLocalKeyIndex: () => {},
      // The push half: roster changes and call events.
      onParticipants: (roster) =>
        wrapper.onParticipants(wrapper.withLivekitParticipants(roster)),
      onEvent: (event) => wrapper.onEvent(event),
    };
  }

  /**
   * One livekit-js room per focus: connect it, register the RoomEvent
   * translation onto the sink, and hand back the close handle.
   */
  async connectRoom(request, sink) {
    const e2ee = this.roomOptions.e2ee
      ? { keyProvider: this.keyProvider, ...this.roomOptions.e2ee }
      : undefined;
    const room = new this.livekit.Room({ ...this.roomOptions, e2ee });
    if (e2ee) {
      // Constructing the room with `e2ee` only arms *decryption*; without
      // this, everything we publish goes out (and is signalled) in the clear —
      // peers show it with a "not encrypted" warning while it decodes fine.
      await room.setE2EEEnabled(true);
    }
    this.registerSink(room, sink, request.connectionKey);
    this.onRoomCreated(room, request.connectionKey);
    await room.connect(request.sfuUrl, request.jwt);
    this.rooms.set(request.connectionKey, room);
    return {
      close: async () => {
        this.rooms.delete(request.connectionKey);
        await room.disconnect();
      },
    };
  }

  /** The RoomEvent → sink translation table. */
  registerSink(room, sink, connectionKey) {
    const { RoomEvent } = this.livekit;
    const kindOf = (publication) =>
      KNOWN_KINDS.has(publication?.source) ? publication.source : null;

    room.on(RoomEvent.ParticipantConnected, (participant) =>
      sink.remoteJoined(participant.identity),
    );
    room.on(RoomEvent.ParticipantDisconnected, (participant) =>
      sink.remoteLeft(participant.identity),
    );
    room.on(RoomEvent.TrackSubscribed, (_track, publication, participant) => {
      const kind = kindOf(publication);
      if (kind) sink.trackAdded(participant.identity, kind);
    });
    room.on(RoomEvent.TrackUnsubscribed, (_track, publication, participant) => {
      const kind = kindOf(publication);
      if (kind) sink.trackRemoved(participant.identity, kind);
    });
    // Local publications too, so our own roster entry carries our streams.
    room.on(RoomEvent.LocalTrackPublished, (publication) => {
      const kind = kindOf(publication);
      if (kind) sink.trackAdded(room.localParticipant.identity, kind);
    });
    room.on(RoomEvent.LocalTrackUnpublished, (publication) => {
      const kind = kindOf(publication);
      if (kind) sink.trackRemoved(room.localParticipant.identity, kind);
    });
    room.on(RoomEvent.TrackMuted, (publication, participant) => {
      const kind = kindOf(publication);
      if (kind) sink.trackMuted(participant.identity, kind, true);
    });
    room.on(RoomEvent.TrackUnmuted, (publication, participant) => {
      const kind = kindOf(publication);
      if (kind) sink.trackMuted(participant.identity, kind, false);
    });
    room.on(RoomEvent.ActiveSpeakersChanged, (speakers) =>
      sink.activeSpeakers(
        speakers.map((speaker) => ({
          identity: speaker.identity,
          level: speaker.audioLevel ?? 0,
        })),
      ),
    );
    room.on(RoomEvent.Reconnecting, () => sink.reconnecting());
    room.on(RoomEvent.Reconnected, () => sink.reconnected());
    room.on(RoomEvent.Disconnected, (reason) => {
      this.rooms.delete(connectionKey);
      sink.closed(String(reason ?? 'disconnected'));
      sink.free?.();
    });
  }

  /** Join roster entries to live livekit-js participants by rtc_identity. */
  withLivekitParticipants(roster) {
    return roster.map((entry) => ({
      ...entry,
      livekitParticipant: entry.rtc_identity
        ? this.findParticipant(entry.rtc_identity)
        : undefined,
    }));
  }

  findParticipant(identity) {
    for (const room of this.rooms.values()) {
      if (room.localParticipant?.identity === identity) {
        return room.localParticipant;
      }
      const participant = room.getParticipantByIdentity?.(identity);
      if (participant) return participant;
    }
    return undefined;
  }
}

/**
 * A per-participant key provider over the injected livekit-client module.
 *
 * NOT `ExternalE2EEKeyProvider`: that one is "a single shared passphrase
 * between all participants" — with it, the local sender encrypts with
 * whichever key was set *last* (usually a peer's), and nobody decrypts us.
 * MSC4195 keys are per participant identity, so this subclasses
 * `BaseKeyProvider` with `sharedKey: false` and hands each raw key to the
 * E2EE worker as HKDF material under its identity and index — the exact
 * mirror of the native `KeyProvider::set_key`.
 */
function makePerParticipantKeyProvider(livekit) {
  class PerParticipantKeyProvider extends livekit.BaseKeyProvider {
    constructor() {
      // No ratcheting: MSC4143 rotates by distributing whole new keys at new
      // indices. failureTolerance -1 keeps the cryptor trying (a key may
      // simply not have arrived yet).
      super({ sharedKey: false, ratchetWindowSize: 0, failureTolerance: -1 });
    }

    /** The `FrameKeyRing` shape: raw bytes, participant identity, key index. */
    async setKey(material, participantIdentity, keyIndex) {
      const cryptoKey = await livekit.createKeyMaterialFromBuffer(material.buffer);
      this.onSetEncryptionKey(cryptoKey, participantIdentity, keyIndex);
      return true;
    }
  }
  return new PerParticipantKeyProvider();
}

async function defaultFetchJson(url, body) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: response.status, body: await response.text() };
}
