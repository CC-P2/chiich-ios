/*
Copyright 2026 Element Creations Ltd.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
Please see LICENSE in the repository root for full details.
*/

/**
 * The call: one wasm client, room and call + one MatrixRtcCall over it, with
 * tiles for humans and events for the test driver.
 * Everything protocol-shaped lives below this file (the wasm engine, the
 * MatrixHost); this is the app glue — join sequencing, publishing, tile
 * rendering, and the observable events the Playwright driver asserts on.
 */

import * as livekit from 'livekit-client';
import E2EEWorker from 'livekit-client/e2ee-worker?worker';
import * as sdk from 'matrix-js-sdk';
import init, * as bindings from 'matrix-rtc-wasm';
import { MatrixRtcCall } from 'matrix-rtc-wasm/call';
import { MatrixHost, createMatrixSession } from 'matrix-rtc-wasm/matrix-js-sdk-host';
import {
  AUDIO_RMS_FLOOR,
  patternVideoTrack,
  rmsMeter,
  sampleVideoHalves,
  toneAudioTrack,
} from './tracks.mjs';

const DEFAULT_SLOT_ID = 'm.call#room';

export class WebPeerApp {
  /**
   * @param {object} options
   * @param {(event: object) => void} options.emit - observable events (the
   *   test protocol; the page log in human mode).
   * @param {(line: string) => void} options.log
   * @param {HTMLElement} [options.tilesElement]
   */
  constructor({ emit, log, tilesElement }) {
    this.emit = emit;
    this.log = log;
    this.tilesElement = tilesElement;
    this.tiles = new Map();
    this.meters = [];
    this.ready = init().then(() => {
      bindings.initLogging('info', '');
    });
  }

  /** Log in (or register a throwaway user) and start syncing. */
  async login({ homeserver, user, password, displayName = 'Web Peer' }) {
    await this.ready;
    const session = await createMatrixSession({
      sdk,
      homeserverUrl: homeserver,
      user,
      password,
      displayName,
      log: this.log,
    });
    this.client = session.client;
    this.userId = session.userId;
    this.deviceId = session.deviceId;

    this.host = new MatrixHost({ sdk, client: this.client, log: this.log });
    this.rtc = new bindings.WasmRtcClient(this.host);

    this.emit({ event: 'ready', user_id: this.userId, device_id: this.deviceId });
    return { userId: this.userId, deviceId: this.deviceId };
  }

  /** Join a Matrix room we were invited to. */
  async joinRoom(roomId) {
    await this.client.joinRoom(roomId);
    // The room object needs a sync round-trip to be fully populated.
    await this.waitForRoom(roomId);
    this.emit({ event: 'room_joined', room_id: roomId });
  }

  /**
   * Create an encrypted room for the call and invite a peer; the shape
   * mirrors the native interop peer's `create_encrypted_room`.
   */
  async createRoom({ name, invite, mode }) {
    const response = await this.client.createRoom({
      name,
      invite: invite ? [invite] : [],
      initial_state: [
        {
          type: 'm.room.encryption',
          state_key: '',
          content: { algorithm: 'm.megolm.v1.aes-sha2' },
        },
      ],
      // The pre-sticky dialect writes membership as room state; PL 0 lets
      // every member do that (state_default is 50).
      power_level_content_override: {
        events: { 'org.matrix.msc3401.call.member': 0 },
      },
    });
    await this.waitForRoom(response.room_id);
    // We created the room, so opening the slot is ours to do: our own sync
    // feed reports the room's complete slot state, and "no slots" resolves the
    // session closed. Encrypted room ⇒ MSC4143 requires `m.per_member`. Not in
    // the pre-sticky mode: that generation predates slots (a join in it leaves
    // the condition unenforced), and its Element Call ignores them anyway.
    if (mode !== 'room_state') {
      // Opened only for the slot: `join` opens it again in its own mode.
      const rtcRoom = await this.rtc.room(response.room_id, undefined);
      try {
        await rtcRoom.openSlot(DEFAULT_SLOT_ID, 'm.call', { type: 'm.per_member' });
      } finally {
        await rtcRoom.close();
      }
    }
    this.emit({ event: 'room_created', room_id: response.room_id, room_name: name });
    return response.room_id;
  }

  async waitForRoom(roomId, timeoutMs = 30_000) {
    const deadline = Date.now() + timeoutMs;
    while (this.client.getRoom(roomId)?.getMyMembership() !== 'join') {
      if (Date.now() > deadline) throw new Error(`room ${roomId} never appeared in sync`);
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
  }

  /**
   * Join the RTC slot and attach media: feed the room, publish the
   * membership, connect the SFU through the engine, publish tracks.
   */
  async join({ roomId, compat, publish = {} }) {
    const focusUrl = await this.host.discoverFocus();
    this.roomId = roomId;
    this.slotId = DEFAULT_SLOT_ID;
    this.compat = compat;
    this.log(`joining ${roomId} / ${this.slotId} on focus ${focusUrl}`);

    // Open before joining: the room subscribes through the host and applies
    // its current state (encryption, slots, members, membership) before
    // publishing ours.
    this.rtcRoom = await this.rtc.room(roomId, {
      format: compat === 'current' ? undefined : compat,
    });

    this.rtcCall = await this.rtcRoom.joinCall({
      // The demo pins the focus it discovered; omit to take the homeserver's.
      transport: { kind: 'publish', livekit_service_url: focusUrl },
    });
    const memberId = this.rtcCall.memberId;
    this.memberId = memberId;

    this.call = new MatrixRtcCall({
      call: this.rtcCall,
      livekit,
      roomOptions: { e2ee: { worker: new E2EEWorker() } },
    });
    this.call.onParticipants = (roster) => this.onRoster(roster);
    this.call.onEvent = (event) => this.onCallEvent(event);
    this.call.onRoomCreated = (room, key) => this.onRoomCreated(room, key);

    await this.call.connect({
      format: compat === 'current' ? undefined : compat,
    });

    await this.publishMedia(focusUrl, publish);
    this.emit({ event: 'joined', member_id: memberId, identity: this.call.session.ownRtcIdentity() });
  }

  /** Publish into the own-focus room: synthetic tracks, or the real devices. */
  async publishMedia(focusUrl, { pattern, tone, devices } = {}) {
    const room = this.call.rooms.get(focusUrl);
    if (!room) throw new Error('own-focus room missing after connect');
    // Every publication reports whether it went out frame-encrypted — the
    // signalled truth peers act on, and exactly what silently regressing to
    // cleartext would flip. The test driver asserts on it.
    const report = (publication) =>
      this.emit({
        event: 'published',
        kind: publication.kind,
        encrypted: publication.isEncrypted,
      });
    if (devices) {
      await room.localParticipant.enableCameraAndMicrophone();
      for (const publication of room.localParticipant.trackPublications.values()) {
        report(publication);
      }
      return;
    }
    if (pattern) {
      report(
        await room.localParticipant.publishTrack(patternVideoTrack(), {
          source: livekit.Track.Source.Camera,
        }),
      );
    }
    if (tone) {
      report(
        await room.localParticipant.publishTrack(toneAudioTrack(), {
          source: livekit.Track.Source.Microphone,
        }),
      );
    }
  }

  /** Leave the slot and tear the media session down. */
  async leave() {
    for (const meter of this.meters.splice(0)) meter.stop();
    if (this.call) {
      await this.call.disconnect();
      this.call = null;
    }
    if (this.rtcCall) {
      await this.rtcCall.leave({});
      this.rtcCall = null;
    }
    if (this.rtcRoom) {
      await this.rtcRoom.close();
      this.rtcRoom = null;
    }
    this.emit({ event: 'left' });
  }

  // --- observation ---------------------------------------------------------

  onRoster(roster) {
    this.emit({ event: 'members', count: roster.length });
    this.renderTiles(roster);
  }

  onCallEvent(event) {
    if (event.type === 'unknown_participant') {
      // The classic dialect mismatch reads as exactly this silence: the modes
      // derive SFU identities differently, so the peer maps to no membership,
      // its key binds to nothing, and its tile stays black. Name it.
      const looksHashed = !event.identity.includes(':');
      const stateMode = this.compat === 'room_state';
      if (stateMode && looksHashed) {
        this.log(
          `HINT: ${event.identity} is a hashed identity but this call speaks state events — ` +
            `the peer is likely in Element Call's "Matrix 2.0" mode; both sides must use the same mode`,
        );
      } else if (!stateMode && !looksHashed) {
        this.log(
          `HINT: ${event.identity} is a {user}:{device} identity but this call speaks ` +
            `${this.compat ?? 'the spec-current dialect'} — the peer is likely in Element Call's ` +
            `"state events" mode; both sides must use the same mode`,
        );
      }
    }
    if (event.type === 'key_imported') {
      // The identity comes with the event: keys held before media connects
      // arrive while `connect()` is pending, before there is a roster to read.
      this.emit({
        event: 'key_imported',
        member_id: event.member_id,
        identity: event.identity,
        key_index: event.key_index,
      });
      return;
    }
    this.emit({ event: 'call_event', ...event });
  }

  /** Per-room media observation: attach, then meter what arrives. */
  onRoomCreated(room) {
    // Own tile: TrackSubscribed only fires for remote tracks, so the local
    // camera is attached from its publication (video only — attaching our own
    // microphone would echo).
    room.on(livekit.RoomEvent.LocalTrackPublished, (publication) => {
      const track = publication.track;
      if (track?.kind === 'video') {
        this.attachTrack(track, room.localParticipant.identity);
      }
    });
    room.on(livekit.RoomEvent.TrackSubscribed, (track, publication, participant) => {
      this.emit({
        event: 'track_subscribed',
        identity: participant.identity,
        kind: track.kind,
      });
      const element = this.attachTrack(track, participant.identity);
      if (track.kind === 'audio') this.startAudioMeter(track, participant.identity);
      if (track.kind === 'video' && element) this.startVideoMeter(element, participant.identity);
    });
  }

  startAudioMeter(track, identity) {
    const meter = rmsMeter(track.mediaStreamTrack);
    const timer = setInterval(() => {
      const value = meter.read();
      if (value > 0) {
        this.emit({ event: 'audio_rms', identity, value, floor: AUDIO_RMS_FLOOR });
      }
    }, 1000);
    this.meters.push({ stop: () => (clearInterval(timer), meter.stop()) });
  }

  startVideoMeter(video, identity) {
    const timer = setInterval(() => {
      const halves = sampleVideoHalves(video);
      if (halves) {
        this.emit({ event: 'video_pattern', identity, ...halves });
      }
    }, 1000);
    this.meters.push({ stop: () => clearInterval(timer) });
  }

  // --- tiles (the human half; harmless under test) --------------------------

  renderTiles(roster) {
    if (!this.tilesElement) return;
    const seen = new Set();
    for (const participant of roster) {
      seen.add(participant.member_id);
      let tile = this.tiles.get(participant.member_id);
      if (!tile) {
        tile = document.createElement('div');
        tile.className = 'tile';
        tile.innerHTML =
          '<video autoplay playsinline muted></video><div class="who"></div><div class="meta"></div>';
        this.tilesElement.append(tile);
        this.tiles.set(participant.member_id, tile);
      }
      tile.querySelector('.who').textContent =
        `${participant.user_id}${participant.is_local ? ' (you)' : ''}`;
      tile.querySelector('.meta').textContent =
        `${participant.member_id} · ${participant.streams
          .map((stream) => `${stream.kind}${stream.muted ? ' (muted)' : ''}`)
          .join(', ') || 'no streams'}`;
      tile.dataset.identity = participant.rtc_identity ?? '';
      // The local publication may predate this tile; backfill the video.
      if (participant.is_local && this.call) {
        const video = tile.querySelector('video');
        if (!video.srcObject) {
          for (const room of this.call.rooms.values()) {
            for (const publication of room.localParticipant?.trackPublications?.values() ?? []) {
              if (publication.track?.kind === 'video') publication.track.attach(video);
            }
          }
        }
      }
    }
    for (const [memberId, tile] of this.tiles) {
      if (!seen.has(memberId)) {
        tile.remove();
        this.tiles.delete(memberId);
      }
    }
  }

  /** Attach a subscribed track to its member's tile (by identity). */
  attachTrack(track, identity) {
    if (!this.tilesElement) return null;
    for (const tile of this.tiles.values()) {
      if (tile.dataset.identity === identity) {
        const video = tile.querySelector('video');
        if (track.kind === 'video') {
          track.attach(video);
          return video;
        }
        // Audio: attach to a detached element so it plays (muted <video> won't).
        const audio = track.attach();
        tile.append(audio);
        return audio;
      }
    }
    // No tile yet (membership still propagating): attach off-DOM so meters work.
    const element = track.attach();
    element.muted = track.kind === 'video';
    return element;
  }
}
