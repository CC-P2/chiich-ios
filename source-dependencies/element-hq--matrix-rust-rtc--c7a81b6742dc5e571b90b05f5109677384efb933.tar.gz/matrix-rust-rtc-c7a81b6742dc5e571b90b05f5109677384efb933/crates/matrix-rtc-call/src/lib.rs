// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
// Please see LICENSE in the repository root for full details.

//! The call application over `matrix-rtc-core`, which is application-agnostic:
//! Element Call's reactions and raised hand ([`reactions`]), MSC4075
//! notifications ([`notification`]), a DM call's ringing and lifecycle
//! ([`direct_call`]), and the host-facing [`RtcClient`] → [`RtcRoom`] →
//! [`RtcSession`] / [`RtcCall`].
//!
//! It also holds [`transports`], which transport a join publishes on: the
//! homeserver's first advertised LiveKit one, a named one, or none.
//! Opening a room, its feeds and the pre-2026 membership formats
//! (`matrix_rtc_core::compat`) are the core's.

mod client;
pub mod direct_call;
#[cfg(test)]
mod feeder_tests;
pub mod notification;
pub mod reactions;
mod status;
pub use status::{CallEnd, CallStatus, MediaPhase, MediaStatusReporter, RingPhase};
mod room_state;
pub mod transports;

pub use client::{CallJoinOptions, JoinOptions, RtcCall, RtcClient, RtcError, RtcRoom, RtcSession};
pub use direct_call::{CallKind, DECLINE_EVENT_TYPES, GroupNotify, RING_SEND_DEADLINE, RingConfig};
pub use notification::{
    DEFAULT_RING_LIFETIME_MS, MAX_RING_LIFETIME_MS, Mentions, NOTIFICATION_EVENT_TYPE,
    NotificationType, NotifyConfig, build_notification_content, notification_sticky_duration_ms,
    notify_session_started,
};
pub use reactions::{
    ANNOTATION_EVENT_TYPE, ANNOTATION_RELATION_TYPE, DEFAULT_REACTION_ACTIVE_MS,
    DEFAULT_REACTION_MAX_AGE_MS, GENERIC_SOUND, KNOWN_REACTIONS, RAISED_HAND_KEY,
    REACTION_EVENT_TYPE, RaisedHand, ReactionError, ReactionKind, ReactionSound, ReactionsConfig,
    ReceivedReaction, RelationLookup, build_raised_hand_content, build_reaction_content,
    first_grapheme, reaction_kind, sound_for,
};
pub use transports::JoinTransport;

#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
use std::time::{SystemTime, UNIX_EPOCH};
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
use web_time::{SystemTime, UNIX_EPOCH};

/// Milliseconds since the Unix epoch: a clock read, never a timer.
pub(crate) fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}
