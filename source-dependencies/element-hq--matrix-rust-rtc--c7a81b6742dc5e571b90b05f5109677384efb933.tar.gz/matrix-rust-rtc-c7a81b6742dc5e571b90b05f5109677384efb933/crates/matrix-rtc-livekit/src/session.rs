// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
// Please see LICENSE in the repository root for full details.

//! LiveKit SFU media session.
//!
//! Wraps a connected LiveKit [`Room`] and surfaces its [`RoomEvent`] stream so
//! the host can react to participants and subscribed tracks. The session itself
//! publishes nothing: local media is published through the room handle by the
//! layer above ([`crate::transport_impl`]), and remote tracks are subscribed
//! automatically unless the caller passes [`RoomOptions`] with `auto_subscribe`
//! off (see [`crate::connect_e2ee`]).

use livekit::{Room, RoomEvent, RoomOptions};
use tokio::sync::mpsc::UnboundedReceiver;

use crate::{Error, SfuToken};

/// A connected LiveKit session plus its event stream.
///
/// The [`UnboundedReceiver`] yields [`RoomEvent`]s (e.g.
/// [`RoomEvent::TrackSubscribed`]) for the lifetime of the connection.
pub struct LiveKitConnection {
    /// The connected session.
    pub session: LiveKitSession,
    /// Stream of room events (participants joining, tracks subscribed, ...).
    pub events: UnboundedReceiver<RoomEvent>,
}

/// A connected LiveKit SFU session.
pub struct LiveKitSession {
    room: Room,
}

impl LiveKitSession {
    /// Connect to the SFU using a previously obtained [`SfuToken`], with
    /// default [`RoomOptions`] (auto-subscribe, no local publication).
    pub async fn connect(token: &SfuToken) -> Result<LiveKitConnection, Error> {
        Self::connect_with_options(token, RoomOptions::default()).await
    }

    /// Connect to the SFU with caller-provided [`RoomOptions`].
    pub async fn connect_with_options(
        token: &SfuToken,
        options: RoomOptions,
    ) -> Result<LiveKitConnection, Error> {
        let (room, events) = Room::connect(&token.url, &token.jwt, options).await?;
        Ok(LiveKitConnection {
            session: LiveKitSession { room },
            events,
        })
    }

    /// Access the underlying LiveKit [`Room`] (participants, publications, ...).
    pub fn room(&self) -> &Room {
        &self.room
    }

    /// Disconnect from the SFU.
    pub async fn close(self) -> Result<(), Error> {
        self.room.close().await?;
        Ok(())
    }
}
