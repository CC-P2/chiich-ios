// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
// Please see LICENSE in the repository root for full details.

//! The TypeScript declarations for everything that crosses the boundary as a
//! `JsValue`.
//!
//! wasm-bindgen types a `JsValue` parameter or return as `any`; this custom
//! section supplies the real shapes, and the `unchecked_param_type` /
//! `unchecked_return_type` attributes at each call site bind them. The
//! declarations are hand-written and MUST track the serde shapes they
//! describe (the structs are all in this crate — `WasmJoinSessionParams`,
//! `WasmParticipant`, `WasmCallEvent`, the compat carriers, ...); the
//! `web/` package's type-check test catches declarations that stop parsing,
//! but a field rename only a human reads here.
//!
//! Conventions, mirroring the wire: input objects mark serde-defaulted fields
//! `?:`; output objects type `Option` fields `| null` (serde serializes
//! `None` as `null`, not absence).

use wasm_bindgen::prelude::*;

#[wasm_bindgen(typescript_custom_section)]
const TS_TYPES: &'static str = r#"
/** What the client reports about how an event or to-device message arrived. */
export type EventEncryptionIn =
    | { kind: "cleartext" }
    /** `sender_cross_signed` stays absent when the client cannot say; never infer it. */
    | { kind: "encrypted"; sender_device_id?: string; sender_cross_signed?: boolean };

/** A room event as the client handed it over, content verbatim; the library parses it. */
export interface EventIn {
    event_id: string;
    sender: string;
    event_type: string;
    /** Set for state events. */
    state_key?: string;
    origin_server_ts?: number;
    content: Record<string, unknown>;
    encryption: EventEncryptionIn;
}

/** A decrypted to-device message as the client handed it over. */
export interface ToDeviceMessageIn {
    sender: string;
    event_type: string;
    content: Record<string, unknown>;
    encryption: EventEncryptionIn;
}

/** What the library wants delivered for one room (`subscribeRoom`). */
export interface RoomSubjects {
    /** Stable and unstable spellings both listed; deliver each under its own type. */
    state_event_types: string[];
    /** Message-like types to forward as they arrive, redactions included. */
    timeline_event_types: string[];
}

/** What a `subscribeRoom` / `subscribeToDevice` call returns. */
export interface BackendSubscription {
    cancel(): void;
}

/** `WasmRtcClient.room`'s options. */
export interface RoomOptionsIn {
    format?: MembershipFormatMode;
}

/**
 * The page's Matrix backend: the one object `WasmRtcClient` takes.
 * Sends take the event type already in its wire spelling. The read half
 * delivers into the sink classes (`WasmRoomSink`, `WasmToDeviceSink`): for
 * sticky events, state events and joined members every call carries the
 * room's complete current set, the first one on subscribe; an empty set
 * means none.
 */
export interface MatrixBackendHost {
    ownUserId(): string;
    ownDeviceId(): string;
    /** MSC4354 sticky send; pass `durationMs` through verbatim. Never called for a room opened in `room_state` mode, so a host without sticky support may reject it there. */
    sendStickyEvent(roomId: string, eventType: string, content: Record<string, unknown>, durationMs: number): Promise<{ event_id: string } | { eventId: string } | string>;
    sendStateEvent(roomId: string, eventType: string, stateKey: string, content: Record<string, unknown>): Promise<{ event_id: string } | { eventId: string } | string>;
    /** MSC4140 delayed send — a delayed STATE event when `stateKey` is set; resolves with the bare delay id. A rejection carrying `errcode` lets the library tell a homeserver without delayed events apart. */
    sendDelayedEvent(roomId: string, eventType: string, stateKey: string | null, content: Record<string, unknown>, delayMs: number): Promise<string>;
    /** MSC4140 `restart` — never cancel+resend. */
    restartDelayedEvent(roomId: string, delayId: string): Promise<unknown>;
    cancelDelayedEvent(roomId: string, delayId: string): Promise<unknown>;
    /** Olm-encrypted, per specific device. Resolving with nothing reports every recipient served. */
    sendToDeviceMessage(recipients: { userId: string; deviceId: string }[], messageType: string, content: Record<string, unknown>): Promise<{ userId: string; deviceId: string; error?: string }[] | void>;
    /** Plain message-like send (reactions, raised hand); encrypted in an encrypted room. */
    sendRoomEvent(roomId: string, eventType: string, content: Record<string, unknown>): Promise<{ event_id: string } | { eventId: string } | string>;
    /** Redact one of our own events (lowering a raised hand). */
    redactEvent(roomId: string, eventId: string, reason?: string): Promise<unknown>;
    /** Synchronous: register listeners, deliver the current sets (now or soon), return the handle. */
    subscribeRoom(roomId: string, subjects: RoomSubjects, sink: WasmRoomSink): BackendSubscription;
    subscribeToDevice(eventTypes: string[], sink: WasmToDeviceSink): BackendSubscription;
    /** `GET /rooms/{room}/relations/{event}/{relType}/{eventType}`, decrypted. */
    relations(roomId: string, eventId: string, relType: string, eventType: string): Promise<EventIn[]>;
    getOpenIdToken(): Promise<{ access_token: string; token_type: string; matrix_server_name: string; expires_in: number }>;
    /** The `rtc_transports` array of `GET /_matrix/client/v1/rtc/transports`; `[]` when the endpoint is missing. */
    rtcTransports(): Promise<unknown[]>;
}

export type RtcStreamKind = "microphone" | "camera" | "screen_share" | "screen_share_audio" | "data";
export type MembershipFormatMode = "current" | "sticky_2025" | "room_state";

/** One roster entry, as `participants()` returns it. */
export interface RtcParticipant {
    member_id: string;
    user_id: string;
    device_id: string | null;
    is_local: boolean;
    reachable: boolean;
    /** The livekit-js participant identity — the join key for `room.getParticipantByIdentity()`. */
    rtc_identity: string | null;
    streams: { kind: RtcStreamKind; muted: boolean }[];
    /** When the participant raised their hand (ms since the epoch); `null` while it is down. */
    hand_raised_at_ms: number | null;
    /** Place in the raised-hand queue, 1 for the earliest; `null` while it is down. Read this rather than sorting. */
    hand_raised_position: number | null;
}

/** An event on the unified call stream (`onEvent`). */
export type RtcCallEvent =
    | { type: "participant_joined"; member_id: string; user_id: string; participant_count: number }
    | { type: "participant_left"; member_id: string; participant_count: number }
    | { type: "stream_started"; member_id: string; kind: RtcStreamKind }
    | { type: "stream_stopped"; member_id: string; kind: RtcStreamKind }
    | { type: "stream_muted"; member_id: string; kind: RtcStreamKind }
    | { type: "stream_unmuted"; member_id: string; kind: RtcStreamKind }
    | { type: "active_speakers"; speakers: { member_id: string; level: number }[] }
    | { type: "key_imported"; member_id: string; identity: string; key_index: number }
    | { type: "frame_encryption_state"; member_id: string;
        state: "ok" | "missing_key" | "decryption_failed" | "encryption_failed" | "internal_error";
        installed_key_indices: number[] | null }
    | { type: "key_discarded"; member_id: string; key_index: number | null;
        sender_user_id: string | null; sender_device_id: string | null;
        reason_code: "cleartext" | "not_cross_signed" | "room_mismatch" | "sender_mismatch" | "unverifiable_device" | "device_mismatch";
        reason: string }
    /** Only for a hand raised while we are in the call; the state is `hand_raised_at_ms` / `hand_raised_position`. */
    | { type: "hand_raised"; member_id: string; raised_at_ms: number }
    | { type: "hand_lowered"; member_id: string }
    /** Transient: show `emoji` for ~3 s; `sound` is the asset base name to play (`null` = silent).
     *  Only while we are in the call, and only for a recent reaction (`reactions.max_age_ms`). */
    | { type: "reaction"; member_id: string; emoji: string; name: string; sound: string | null }
    | { type: "unknown_participant"; identity: string };

/** How far our own media has got. */
export type RtcMediaPhase =
    | { type: "connecting" }
    /** `degraded` while a transport reconnects. */
    | { type: "connected"; degraded: boolean };

/** Where a joined call is (`WasmRtcCall.status`, `onStatus`). Only `ended` is final. */
export type RtcCallStatus =
    /** Our media is not up yet, and there is somebody to talk to. */
    | { type: "connecting" }
    /** A DM call waiting for `callee`, the user ID it rings; `media` is how far our side has got. */
    | { type: "calling";
        callee: string;
        ring: { type: "sending" } | { type: "ringing"; sent_at_ms: number; lifetime_ms: number };
        media: RtcMediaPhase }
    /** Media up and somebody to talk to; `since_ms` holds through `degraded`. */
    | { type: "connected"; since_ms: number; degraded: boolean }
    /** `message` is the transport's, for `connection_closed` only. */
    | { type: "ended";
        reason: "left" | "declined" | "unanswered" | "ring_not_sent" | "others_left" | "empty" | "slot_closed" | "connection_closed";
        message: string | null };

/** `connectMedia`'s tuning. The room, slot, own focus and account are the call's. */
export interface MediaSessionConfigIn {
    /** livekit-js key-provider ring size when configured away from its default of 16. */
    key_ring_size?: number;
    /** Cross-check only: the mode comes from the room. */
    format?: MembershipFormatMode;
    /** How much the tile order is damped; omitted fields take the defaults. */
    stability?: StabilityConfigIn;
}

/**
 * Tile-order damping. A product decision rather than a protocol one, so a
 * page can tune it. A `demote_ms` above `promote_ms` leaves a tile at the top
 * of the order after the speaker stopped, which reads as a stuck UI.
 */
export interface StabilityConfigIn {
    /** Sustained voice before a member ranks as speaking; the tile flag is not delayed. Default 1500. */
    promote_ms?: number;
    /** Silence before a speaking member stops ranking as one. Default 1500. */
    demote_ms?: number;
    /** Reorders inside this window are delivered as one. Default 300. */
    coalesce_ms?: number;
}

/** The object driving livekit-js for `connectMedia`. */
export interface MediaDelegate {
    /** POST `body` as JSON to `url`; resolve with the HTTP status and raw response text. */
    fetchJson(url: string, body: Record<string, unknown>): Promise<{ status: number; body: string }>;
    /** Connect a livekit-js Room and register the RoomEvent translation onto `sink`. */
    connect(request: { connectionKey: string; sfuUrl: string; jwt: string }, sink: WasmConnectionEventSink): Promise<{ close(): Promise<unknown> }>;
    /** Install a media key in livekit-js's key provider (per participant, HKDF material). */
    setKey(identity: string, index: number, key: Uint8Array): Promise<boolean | void>;
    /** Move the local sender onto a rotated key index. */
    setLocalKeyIndex?(index: number): void;
    /** The push half: the roster after each change. */
    onParticipants?(roster: RtcParticipant[]): void;
    /** The push half: the unified call event stream. */
    onEvent?(event: RtcCallEvent): void;
    /** The call's status: as it is first, then each change, last the end. */
    onStatus?(status: RtcCallStatus): void;
}

/** What a join publishes on: the homeserver's advertised LiveKit transport, a given LiveKit focus, or nothing. */
export type JoinTransportIn =
    | { kind: 'advertised' }
    | { kind: 'publish'; livekit_service_url: string }
    | { kind: 'receive_only' };

/** `joinCall`'s parameters. */
export interface JoinParamsIn {
    /** The call slot to join, `m.call#{application_slot_id}`; omitted is the room-wide call, `room`. */
    application_slot_id?: string;
    /** What the join publishes on; omitted is `advertised`, the first LiveKit transport the homeserver advertises (`rtcTransports`). */
    transport?: JoinTransportIn;
    keep_alive_timeout_ms?: number;
    sticky_duration_ms?: number;
    degraded_lifetime_ms?: number;
    encryption_config?: {
        delay_before_use_ms?: number;
        key_rotation_grace_period_ms?: number;
        max_key_lifetime_ms?: number;
        manage_media_keys?: boolean;
        require_cross_signed_sender?: boolean;
    };
    notify?: { notification_type?: string; mentions?: Record<string, unknown>; lifetime_ms?: number };
    /** Element Call reactions and raised hand; omitted is enabled with the 3 s window. */
    reactions?: {
        enabled?: boolean;
        active_window_ms?: number;
        send_cooldown_ms?: number;
        /** Older received reactions (by our clock) are dropped as stale; default 10 s. */
        max_age_ms?: number;
    };
}

/** `leave`'s parameters (`{}` is a plain hang-up). */
export interface LeaveParamsIn {
    leave_reason?: { code: string; reason?: string };
}

/** A member whose hand is up (`raisedHands`). */
export interface RaisedHand {
    member_id: string;
    sender: string;
    reaction_event_id: string;
    /** ms since the epoch, by the server's clock; sort ascending to order speakers. */
    raised_at_ms: number;
}

/** One entry of Element Call's reaction catalogue (`reactionCatalog()`). */
export interface ReactionKind {
    name: string;
    emoji: string;
    /** Base name of the sound asset Element Call plays for it, or `null` for a silent reaction. */
    sound: string | null;
}

/** MSC4143 `content.encryption` of an `m.rtc.slot` (`openSlot`). */
export interface SlotEncryptionIn {
    type: string;
    [key: string]: unknown;
}

/** One entry of the sink's `activeSpeakers` payload. */
export interface SpeakerIn {
    identity: string;
    /** 0.0 (silent) to 1.0; omit for transports that report no level. */
    level?: number;
}

"#;
