//
//  PostHogStorageTest.swift
//  PostHogTests
//
//  Created by Ben White on 08.02.23.
//

import Foundation
@testable import PostHog
import Testing

@Suite("PostHogStorage Tests", .serialized)
class PostHogStorageTest {
    func getSut(config: PostHogConfig = PostHogConfig(projectToken: "test_project_token")) -> PostHogStorage {
        PostHogStorage(config)
    }

    @Test("returns the application support dir URL")
    func returnsTheApplicationSupportDirURL() {
        let url = applicationSupportDirectoryURL()
        let expectedSuffix = ["Library", "Application Support", testBundleIdentifier]
        let actualSuffix = Array(url.pathComponents.suffix(expectedSuffix.count))
        #expect(actualSuffix == expectedSuffix)
    }

    @Test("returns the app group container dir URL")
    func returnsTheAppGroupContainerDirURL() {
        let config = PostHogConfig(projectToken: "test_project_token")
        config.appGroupIdentifier = testAppGroupIdentifier
        let url = appGroupContainerUrl(config: config)!

        let expectedSuffix = ["Library", "Application Support", testAppGroupIdentifier]
        let actualSuffix = Array(url.pathComponents.suffix(expectedSuffix.count))

        // positive check: must return the same url across the whole app group
        #expect(actualSuffix == expectedSuffix)

        // negative check: guard against using bundleIdentifier, prevents spawning
        // separate folders per bundle identifer within the app group folder
        #expect(!actualSuffix.contains(testBundleIdentifier))

        let groupContainerComponent = url.pathComponents[url.pathComponents.count - 5]
        #expect(["Group Containers", "AppGroup"].contains(groupContainerComponent))
    }

    @Test("creates a folder if none exists")
    func createsFolderIfNoneExists() throws {
        let fileManager = FileManager.default

        let config = PostHogConfig(projectToken: UUID().uuidString)
        let expectedURL = applicationSupportDirectoryURL().appendingPathComponent(config.projectToken)
        try #require(!fileManager.fileExists(atPath: expectedURL.path))
        defer { deleteSafely(expectedURL) }

        let sut = getSut(config: config)
        #expect(sut.appFolderUrl == expectedURL)
        #expect(fileManager.fileExists(atPath: expectedURL.path))
    }

    @Test("Persists and loads string")
    func persistsAndLoadsString() {
        let sut = getSut()

        let str = "san francisco"
        sut.setString(forKey: .distinctId, contents: str)

        #expect(sut.getString(forKey: .distinctId) == str)

        sut.remove(key: .distinctId)
        #expect(sut.getString(forKey: .distinctId) == nil)

        sut.reset()
    }

    @Test("Persists and loads bool")
    func persistsAndLoadsBool() {
        let sut = getSut()

        sut.setBool(forKey: .optOut, contents: true)

        #expect(sut.getBool(forKey: .optOut) == true)

        sut.remove(key: .optOut)
        #expect(sut.getBool(forKey: .optOut) == nil)

        sut.reset()
    }

    @Test("Persists and loads dictionary")
    func persistsAndLoadsDictionary() {
        let sut = getSut()

        let dict = [
            "san francisco": "tech",
            "new york": "finance",
            "paris": "fashion",
        ]
        sut.setDictionary(forKey: .distinctId, contents: dict)
        #expect(sut.getDictionary(forKey: .distinctId) as? [String: String] == dict)

        sut.remove(key: .distinctId)
        #expect(sut.getDictionary(forKey: .distinctId) == nil)

        sut.reset()
    }

    @Test("Saves file to disk and removes from disk")
    func savesFileToDiskAndRemovesFromDisk() throws {
        let sut = getSut()

        let url = sut.url(forKey: .distinctId)
        let isUrlReachable: () -> Bool = {
            (try? url.checkResourceIsReachable()) ?? false
        }

        #expect(isUrlReachable() == false)

        sut.setString(forKey: .distinctId, contents: "sloth")
        #expect(isUrlReachable() == true)

        sut.remove(key: .distinctId)
        #expect(isUrlReachable() == false)

        sut.reset()
    }

    @Test("writes to disk in a project token folder under application support directory")
    func writesToDiskInAProjectTokenFolderUnderApplicationSupportDirectory() {
        let config = PostHogConfig(projectToken: "test_project_token")
        let sut = PostHogStorage(config)
        let url = sut.appFolderUrl

        sut.setString(forKey: .distinctId, contents: "distinct_id_value")

        let expectedSuffix = ["Library", "Application Support", testBundleIdentifier, "test_project_token"]
        let actualSuffix = Array(url.pathComponents.suffix(expectedSuffix.count))
        #expect(expectedSuffix == actualSuffix)

        let fileManager = FileManager.default
        let fileUrl = url.appendingPathComponent(PostHogStorage.StorageKey.distinctId.rawValue)
        #expect(fileManager.fileExists(atPath: fileUrl.path))

        sut.remove(key: .distinctId)
        #expect(fileManager.fileExists(atPath: fileUrl.path) == false)

        sut.reset()
    }

    @Test("writes to disk in a project token folder under a group container directory")
    func writesToDiskInAProjectTokenFolderUnderGroupContainerDirectory() {
        let config = PostHogConfig(projectToken: "test_project_token")
        config.appGroupIdentifier = testAppGroupIdentifier
        let sut = PostHogStorage(config)
        let url = sut.appFolderUrl

        sut.setString(forKey: .distinctId, contents: "distinct_id_value")

        let expectedSuffix = ["Library", "Application Support", testAppGroupIdentifier, "test_project_token"]
        let actualSuffix = Array(url.pathComponents.suffix(expectedSuffix.count))
        #expect(expectedSuffix == actualSuffix)

        let groupContainerComponent = url.pathComponents[url.pathComponents.count - 6]
        #expect(["Group Containers", "AppGroup"].contains(groupContainerComponent))

        let fileManager = FileManager.default
        let fileUrl = url.appendingPathComponent(PostHogStorage.StorageKey.distinctId.rawValue)
        #expect(fileManager.fileExists(atPath: fileUrl.path))

        sut.remove(key: .distinctId)
        #expect(fileManager.fileExists(atPath: fileUrl.path) == false)

        sut.reset()
    }

    @Test("falls back to application support directory when app group identifier is not provided")
    func fallsBackToApplicationSupportDirectoryWhenAppGroupIdentifierIsNotProvided() {
        let config = PostHogConfig(projectToken: "test_project_token")
        config.appGroupIdentifier = nil
        let sut = PostHogStorage(config)
        let url = sut.appFolderUrl

        let expectedSuffix = ["Library", "Application Support", testBundleIdentifier, "test_project_token"]
        let actualSuffix = Array(url.pathComponents.suffix(expectedSuffix.count))
        #expect(expectedSuffix == actualSuffix)

        let groupContainerComponent = url.pathComponents[url.pathComponents.count - 6]
        #expect(!["Group Containers", "AppGroup"].contains(groupContainerComponent))

        sut.reset()
    }
}

@Suite("PostHogStorage backup exclusion", .serialized)
struct PostHogStorageBackupTest {
    @Test("excludes new and existing project folders from backup", arguments: [false, true], [false, true])
    func excludesProjectFolderFromBackup(existingFolder: Bool, appGroup: Bool) throws {
        let config = PostHogConfig(projectToken: "backup-test-\(UUID().uuidString)")
        if appGroup {
            config.appGroupIdentifier = testAppGroupIdentifier
        }
        // Allow local test runs to prove filesystem isolation before creating storage.
        if let isolatedHome = ProcessInfo.processInfo.environment["CFFIXED_USER_HOME"] {
            try #require(applicationSupportDirectoryURL().path.hasPrefix(isolatedHome + "/"))
            print("Backup test Application Support: \(applicationSupportDirectoryURL().path)")
        }
        let baseURL = try appGroup ? #require(appGroupContainerUrl(config: config)) : applicationSupportDirectoryURL()
        let projectURL = baseURL.appendingPathComponent(config.projectToken, isDirectory: true)
        defer { deleteSafely(projectURL) }
        let queueKeys: [PostHogStorage.StorageKey] = [.queue, .replayQeueue, .replayBufferQueue, .logsQueue]
        let payload = Data("queued telemetry".utf8)
        let filename = UUID.v7String()
        try FileManager.default.createDirectory(at: baseURL, withIntermediateDirectories: true)
        let baseExcluded = try baseURL.resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup

        if existingFolder {
            for key in queueKeys {
                let queueURL = projectURL.appendingPathComponent(key.rawValue)
                try FileManager.default.createDirectory(at: queueURL, withIntermediateDirectories: true)
                try payload.write(to: queueURL.appendingPathComponent(filename))
            }
            var url = projectURL
            var values = URLResourceValues()
            values.isExcludedFromBackup = false
            try url.setResourceValues(values)
        }

        let storage = PostHogStorage(config)
        #expect(storage.appFolderUrl.path == projectURL.path)
        #expect(try projectURL.resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup == true)
        // The bundle/app-group folder may also hold unrelated application data.
        #expect(try baseURL.resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup == baseExcluded)

        for key in queueKeys {
            let queueURL = storage.url(forKey: key)
            #expect(queueURL.deletingLastPathComponent() == projectURL)
            if existingFolder {
                #expect(try Data(contentsOf: queueURL.appendingPathComponent(filename)) == payload)
            }
            if key == .replayBufferQueue {
                let buffer = PostHogReplayBufferQueue(queue: queueURL)
                buffer.add(payload)
                #expect(buffer.depth == 1)
                buffer.clear()
                buffer.add(payload)
                #expect(buffer.depth == 1)
            } else {
                let queue = PostHogFileBackedQueue(queue: queueURL)
                if existingFolder {
                    #expect(queue.peek(1) == [payload])
                }
                queue.clear()
                queue.add(payload)
                #expect(queue.peek(1) == [payload])
            }
            // Recreating a child queue must not remove the ancestor's exclusion.
            #expect(try projectURL.resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup == true)
        }

        let reopenedStorage = PostHogStorage(config)
        #expect(try reopenedStorage.appFolderUrl.resourceValues(forKeys: [.isExcludedFromBackupKey]).isExcludedFromBackup == true)
    }
}
