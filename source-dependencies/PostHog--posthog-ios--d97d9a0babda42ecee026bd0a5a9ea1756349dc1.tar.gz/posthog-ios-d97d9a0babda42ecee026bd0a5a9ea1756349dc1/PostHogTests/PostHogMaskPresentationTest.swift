//
//  Regression tests for masks left behind by a screen that is covered but still attached
//  to the window. UIKit keeps the presenter's view in the hierarchy for an over-full-screen
//  presentation, and newer OS versions do the same for SwiftUI's `fullScreenCover`, so a
//  `postHogMask()` reporter on the covered screen kept reporting its rect and the capture
//  path painted it over the cover.
//

#if os(iOS) && canImport(SwiftUI) && TEST_PRESENTATION_MASKS
    import Combine
    import Foundation
    @testable import PostHog
    import SwiftUI
    import Testing
    import UIKit

    @Suite("Replay masking behind a cover", .serialized)
    @MainActor
    struct PostHogMaskPresentationTest {
        private static let secret = "SSN 123-45-6789"

        // MARK: - Harness

        private final class CoverModel: ObservableObject {
            @Published var isPresented = false
        }

        @available(iOS 14.0, *)
        private struct MaskedScreen: View {
            @ObservedObject var model: CoverModel

            var body: some View {
                VStack {
                    Text("Visible label")
                    Text(PostHogMaskPresentationTest.secret).postHogMask()
                }
                .fullScreenCover(isPresented: $model.isPresented) {
                    ZStack {
                        Color.white.ignoresSafeArea()
                        Text("Cover")
                    }
                }
            }
        }

        private func host(_ view: some View) -> Host {
            let controller = UIHostingController(rootView: AnyView(view))
            let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first!
            let window = UIWindow(windowScene: scene)
            window.frame = scene.coordinateSpace.bounds
            window.rootViewController = controller
            window.makeKeyAndVisible()
            controller.view.frame = window.bounds
            settle(window)
            return Host(window: window, controller: controller)
        }

        private func maskRects(_ screen: Host) -> [CGRect] {
            let rects = PostHogReplayIntegration().collectMaskableRects(in: screen.window)
            #expect(rects != nil)
            return rects ?? []
        }

        /// Presentation completes over several run loop turns, so poll instead of assuming
        /// one settle pass is enough.
        private func waitUntil(_ window: UIWindow, _ condition: () -> Bool) async -> Bool {
            for _ in 0 ..< 100 {
                window.layoutIfNeeded()
                try? await Task.sleep(nanoseconds: 50_000_000)
                if condition() { return true }
            }
            return condition()
        }

        /// A view controller whose view fills the window, kept over the presenter so the
        /// covered screen stays attached — the shape the defect needs.
        private func presentCover(over screen: Host, background: UIColor) async -> UIViewController {
            let cover = UIViewController()
            cover.modalPresentationStyle = .overFullScreen
            cover.view.backgroundColor = background
            screen.controller.present(cover, animated: false)
            #expect(await waitUntil(screen.window) { cover.view.window === screen.window && !cover.isBeingPresented })
            return cover
        }

        // MARK: - Tests

        @available(iOS 14.0, *)
        @Test("a SwiftUI fullScreenCover drops the masks of the screen it covers")
        func fullScreenCoverDropsMasksBehindIt() async {
            let model = CoverModel()
            let screen = host(MaskedScreen(model: model))
            #expect(!maskRects(screen).isEmpty)

            model.isPresented = true
            #expect(await waitUntil(screen.window) {
                guard let cover = screen.controller.presentedViewController else { return false }
                return cover.viewIfLoaded?.window === screen.window && !cover.isBeingPresented
            })
            #expect(maskRects(screen).isEmpty)

            model.isPresented = false
            #expect(await waitUntil(screen.window) { screen.controller.presentedViewController == nil })
            // The screen is on top again, so its mask has to come back.
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("an opaque cover that keeps the presenter attached drops its masks")
        func opaqueCoverDropsMasksBehindIt() async {
            let screen = host(Text(Self.secret).postHogMask())
            #expect(!maskRects(screen).isEmpty)

            let cover = await presentCover(over: screen, background: .white)
            // The covered screen is still in the window: this is the state the fix reads.
            #expect(screen.controller.view.window === screen.window)
            #expect(maskRects(screen).isEmpty)

            cover.dismiss(animated: false)
            #expect(await waitUntil(screen.window) { screen.controller.presentedViewController == nil })
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("a see-through cover keeps the masks behind it")
        func transparentCoverKeepsMasks() async {
            let screen = host(Text(Self.secret).postHogMask())
            _ = await presentCover(over: screen, background: .clear)
            // The masked content still shows through, so redacting it is the only safe answer.
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("a rounded cover keeps the masks behind it")
        func roundedCoverKeepsMasks() async {
            let screen = host(Text(Self.secret).postHogMask())
            let cover = await presentCover(over: screen, background: .white)
            #expect(maskRects(screen).isEmpty)

            // Same cover, one shape change: the corner arcs go see-through and the presenter
            // shows through them. The full-window test cannot notice, because the presentation
            // rect is the plain bounds either way.
            cover.view.layer.cornerRadius = 24
            cover.view.layer.masksToBounds = true
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("a sibling raised over the cover by zPosition keeps the masks behind it")
        func siblingAboveCoverByZPositionKeepsMasks() async {
            let screen = host(Text(Self.secret).postHogMask())
            _ = await presentCover(over: screen, background: .white)

            // An app's own banner, added to the window before the presentation. Behind the
            // cover in subview order, so the cover still holds the screen.
            let banner = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 60))
            banner.backgroundColor = .red
            screen.window.insertSubview(banner, at: 0)
            #expect(maskRects(screen).isEmpty)

            // One property change, and the banner draws over the cover while its index still
            // says otherwise — the way an app keeps a banner above later presentations. Its
            // own content shows, so nothing behind may be treated as hidden any more.
            banner.layer.zPosition = (screen.window.subviews.map(\.layer.zPosition).max() ?? 0) + 1
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("a sibling that paints nothing over the cover does not keep the masks behind it",
              arguments: [true, false])
        func invisibleSiblingAboveCoverDropsMasks(hidden: Bool) async {
            let screen = host(Text(Self.secret).postHogMask())
            _ = await presentCover(over: screen, background: .white)

            // An overlay host parked in the window and raised over later presentations, the way
            // a toast or HUD container is kept between uses. It paints nothing, so the cover
            // still holds the whole window.
            let overlay = UIView(frame: screen.window.bounds)
            overlay.backgroundColor = .red
            overlay.layer.zPosition = (screen.window.subviews.map(\.layer.zPosition).max() ?? 0) + 1
            if hidden { overlay.isHidden = true } else { overlay.alpha = 0 }
            screen.window.addSubview(overlay)
            settle(screen.window)
            #expect(maskRects(screen).isEmpty)

            // Once it shows, its own pixels are on screen and nothing behind it may be dropped.
            if hidden { overlay.isHidden = false } else { overlay.alpha = 1 }
            #expect(!maskRects(screen).isEmpty)
        }

        @Test("a hidden ancestor drops a reporter's mask")
        func hiddenAncestorDropsMask() {
            let screen = host(Text(Self.secret).postHogMask())
            #expect(!maskRects(screen).isEmpty)

            // Nothing under a hidden view is drawn, so nothing under it can need redacting.
            screen.controller.view.isHidden = true
            #expect(maskRects(screen).isEmpty)

            screen.controller.view.isHidden = false
            #expect(!maskRects(screen).isEmpty)
        }
    }
#endif
