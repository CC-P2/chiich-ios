//
//  ContentView.swift
//  PostHogExample
//
//  Created by Ben White on 10.01.23.
//

import AuthenticationServices
import PostHog
import SwiftUI

class SignInViewModel: NSObject, ObservableObject, ASWebAuthenticationPresentationContextProviding {
    // MARK: - ASWebAuthenticationPresentationContextProviding

    func presentationAnchor(for _: ASWebAuthenticationSession) -> ASPresentationAnchor {
        ASPresentationAnchor()
    }

    func triggerAuthentication() {
        guard let authURL = URL(string: "https://example.com/auth") else { return }
        let scheme = "exampleauth"

        // Initialize the session.
        let session = ASWebAuthenticationSession(url: authURL, callbackURLScheme: scheme) { callbackURL, error in
            if callbackURL != nil {
                print("URL", callbackURL!.absoluteString)
            }
            if error != nil {
                print("Error", error!.localizedDescription)
            }
        }
        session.presentationContextProvider = self
        session.prefersEphemeralWebBrowserSession = true

        session.start()
    }
}

class FeatureFlagsModel: ObservableObject {
    @Published var boolValue: Bool?
    @Published var stringValue: String?
    @Published var payloadValue: [String: String]?
    @Published var isReloading: Bool = false

    init() {
        NotificationCenter.default.addObserver(self, selector: #selector(reloaded), name: PostHogSDK.didReceiveFeatureFlags, object: nil)
    }

    @objc func reloaded() {
        boolValue = PostHogSDK.shared.isFeatureEnabled("4535-funnel-bar-viz")
        stringValue = PostHogSDK.shared.getFeatureFlag("multivariant") as? String
        payloadValue = PostHogSDK.shared.getFeatureFlagResult("multivariant")?.payload as? [String: String]
    }

    func reload() {
        isReloading = true

        PostHogSDK.shared.reloadFeatureFlags {
            self.isReloading = false
        }
    }
}

struct ContentView: View {
    @State var counter: Int = 0
    @State private var name: String = "Max"
    @State private var showingSheet = false
    @State private var showingRedactedSheet = false
    @StateObject var api = Api()

    @StateObject var signInViewModel = SignInViewModel()
    @StateObject var featureFlagsModel = FeatureFlagsModel()

    func incCounter() {
        counter += 1
    }

    func triggerIdentify() {
        PostHogSDK.shared.identify(name, userProperties: [
            "name": name,
        ])
    }

    func testPersonPropertiesForFlags() {
        print("🧪 Testing person properties for flags...")

        // Note: PostHog iOS SDK automatically sets default person properties like:
        // $app_version, $app_build, $os_name, $os_version, $device_type, $locale
        // This ensures feature flags work immediately without waiting for identify() calls.

        // Set some additional test person properties
        PostHogSDK.shared.setPersonPropertiesForFlags([
            "test_property": "manual_test_value",
            "plan": "premium_test",
            "$app_version": "custom_override_version", // This will override the automatic value
        ])

        print("✅ Set person properties for flags")

        // Set some test group properties
        PostHogSDK.shared.setGroupPropertiesForFlags("organization", properties: [
            "plan": "enterprise",
            "seats": 50,
            "industry": "technology",
        ])

        print("✅ Set group properties for flags (organization)")

        // Trigger flag evaluation to send the request
        let flagValue = PostHogSDK.shared.isFeatureEnabled("test_flag")
        print("🏁 Flag value: \(flagValue)")

        // Check what's in getFeatureFlag too
        if let strFlag = PostHogSDK.shared.getFeatureFlag("multivariant") as? String {
            print("📄 Multivariant flag: \(strFlag)")
        }
    }

    /// Creates a multi-level async call chain to test stack trace capture
    func captureAsyncError() async {
        do {
            try await asyncLevel1()
        } catch {
            PostHogSDK.shared.captureException(error, properties: [
                "is_test": true,
                "error_type": "async_await_chain",
                "capture_point": "top_level_catch",
            ])
        }
    }

    private func asyncLevel1() async throws {
        // Simulate some async work
        try await Task.sleep(nanoseconds: 10_000_000) // 0.01 seconds
        try await asyncLevel2()
    }

    private func asyncLevel2() async throws {
        // Simulate more async work
        try await Task.sleep(nanoseconds: 20_000_000) // 0.02 seconds
        try await asyncLevel3()
    }

    private func asyncLevel3() async throws {
        // Simulate final async work before error
        try await Task.sleep(nanoseconds: 30_000_000) // 0.03 seconds

        // Throw an error from deep in the async chain
        throw AsyncTestError.deepAsyncError(
            message: "Error occurred in async level 3",
            context: ["level": 3, "operation": "data_processing"]
        )
    }

    func triggerAuthentication() {
        signInViewModel.triggerAuthentication()
    }

    func triggerFlagReload() {
        featureFlagsModel.reload()
    }

    var body: some View {
        NavigationView {
            List {
                Section("General") {
                    #if os(iOS)
                        NavigationLink {
                            SessionRecordingView()
                        } label: {
                            Text("Session Recording Tests")
                        }
                        NavigationLink {
                            LogsView()
                        } label: {
                            Text("Logs")
                        }
                        NavigationLink {
                            RageClickControlsView()
                        } label: {
                            Text("Rage Click Control (UIKit)")
                        }
                        NavigationLink {
                            RageClickControlsSwiftUIView()
                        } label: {
                            Text("Rage Click Control (SwiftUI)")
                        }
                    #endif
                    NavigationLink {
                        ContentView()
                    } label: {
                        Text("Infinite navigation")
                    }
                    #if os(iOS)
                    .postHogMask()
                    #endif

                    HStack {
                        Spacer()
                        VStack {
                            Text("Remote Image")
                            AsyncImage(
                                url: URL(string: "https://res.cloudinary.com/dmukukwp6/image/upload/v1710055416/posthog.com/contents/images/media/social-media-headers/hogs/professor_hog.png"),
                                content: { image in
                                    image
                                        .renderingMode(.original)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                },
                                placeholder: {
                                    Color.gray
                                }
                            )
                            .frame(width: 60, height: 60)
                        }
                        Spacer()
                        VStack {
                            Text("Static Image")
                            Image(.maxStatic)
                                .resizable()
                                .frame(width: 60, height: 60)
                        }
                        Spacer()
                    }

                    Button("Show Sheet") {
                        showingSheet.toggle()
                    }
                    .sheet(isPresented: $showingSheet) {
                        ContentView()
                            .postHogScreenView("ContentViewSheet")
                    }
                    Button("Show redacted view") {
                        showingRedactedSheet.toggle()
                    }
                    .sheet(isPresented: $showingRedactedSheet) {
                        RepresentedExampleUIView()
                    }

                    #if os(iOS)
                        Text("Sensitive text!!").postHogMask()
                        Button(action: incCounter) {
                            Text(String(counter))
                        }
                        .postHogMask()
                    #endif

                    TextField("Enter your name", text: $name)
                    #if os(iOS)
                        .postHogMask()
                    #endif

                    Text("Hello, \(name)!")
                    Button(action: triggerAuthentication) {
                        Text("Trigger fake authentication!")
                    }
                    Button(action: triggerIdentify) {
                        Text("Trigger identify!")
                    }.postHogViewSeen("Trigger identify")

                    Button(action: testPersonPropertiesForFlags) {
                        Text("🧪 Test Person & Group Properties")
                    }

                    #if DEBUG
                        Button("Test preload+identify race") {
                            PostHogSDK.shared.reloadFeatureFlags()
                            PostHogSDK.shared.identify("test-race-\(UUID().uuidString)")
                        }
                    #endif
                }

                Section("Feature flags") {
                    HStack {
                        Text("Boolean:")
                        Spacer()
                        Text("\(featureFlagsModel.boolValue?.description ?? "unknown")")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("String:")
                        Spacer()
                        Text("\(featureFlagsModel.stringValue ?? "unknown")")
                            .foregroundColor(.secondary)
                    }

                    HStack {
                        Text("Payload:")
                        Spacer()
                        Text("\(featureFlagsModel.payloadValue?.description ?? "unknown")")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Button(action: triggerFlagReload) {
                            Text("Reload flags")
                        }
                        Spacer()
                        if featureFlagsModel.isReloading {
                            ProgressView()
                        }
                    }
                }

                // Manual testing of exception steps.
                Section("Exception steps") {
                    Button("Add 3 exception steps") {
                        PostHogSDK.shared.addExceptionStep("App launched test flow")
                        PostHogSDK.shared.addExceptionStep("User tapped Checkout", properties: [
                            "screen": "cart",
                            "item_count": 3,
                            "at": Date(),
                        ])
                        PostHogSDK.shared.addExceptionStep("Network request started", properties: [
                            "url": "https://example.com/pay",
                            "method": "POST",
                        ])
                    }

                    Button("Add single exception step") {
                        PostHogSDK.shared.addExceptionStep("Manual breadcrumb at \(Date())")
                    }

                    Button("Add exception steps via ObjC") {
                        PHGExceptionHandler.recordExceptionStepsFromObjC()
                    }

                    // High-frequency stress test; crash mid-run to check recent steps survive.
                    Button("Flood steps in background (high-frequency)") {
                        DispatchQueue.global(qos: .background).async {
                            let total = 200
                            for i in 0 ..< total {
                                PostHogSDK.shared.addExceptionStep("Background step \(i)", properties: [
                                    "iteration": i,
                                    "thread": "background",
                                    "payload": String(repeating: "x", count: 64),
                                ])
                                // Spread the work out so it behaves like a long-running task.
                                Thread.sleep(forTimeInterval: 0.002)
                            }
                            PostHogSDK.shared.addExceptionStep("Background flood finished (\(total) steps)")
                            print("Exception-step flood complete: \(total) steps")
                        }
                    }
                }

                Section("Crash Triggers") {
                    // NSException - richest info with name + reason
                    Button("Uncaught NSException") {
                        PHGExceptionHandler.triggerUncaughtNSException()
                    }
                    // SIGTRAP - Swift runtime trap with message from __crash_info
                    Button("fatalError()") {
                        SwiftCrashTriggers.triggerFatalError()
                    }
                    // SIGTRAP - Swift runtime trap with message from __crash_info
                    Button("preconditionFailure()") {
                        SwiftCrashTriggers.triggerPreconditionFailure()
                    }
                    // SIGTRAP - debug-only Swift assertion trap with message from __crash_info
                    Button("assertionFailure() (Debug)") {
                        SwiftCrashTriggers.triggerAssertionFailure()
                    }
                    // SIGTRAP - Swift runtime trap on nil unwrap
                    Button("Force unwrap nil") {
                        SwiftCrashTriggers.triggerForceUnwrapNil()
                    }
                    // EXC_BAD_ACCESS - null pointer dereference
                    Button("Null Pointer") {
                        PHGExceptionHandler.triggerNullPointerCrash()
                    }
                    // SIGABRT - explicit abort() call
                    Button("Abort") {
                        PHGExceptionHandler.triggerAbortCrash()
                    }
                }

                Section("Error tracking") {
                    Button("Capture Swift Enum Error (with associated value)") {
                        do {
                            throw SampleAppError.generalAppError(ErrorDetails(code: 10, reason: "some reason"))
                        } catch {
                            PostHogSDK.shared.captureException(error, properties: [
                                "is_test": true,
                            ])
                        }
                    }

                    Button("Capture NSException (Constructed)") {
                        let exception = NSException(
                            name: NSExceptionName("PostHogTestException"),
                            reason: "Manual test exception for error tracking validation",
                            userInfo: [
                                "test_scenario": "manual_button_press",
                                "app_version": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "unknown",
                            ]
                        )

                        PostHogSDK.shared.captureException(exception, properties: [
                            "is_test": true,
                            "user_initiated": true,
                            "exception_type": "safe_nsexception",
                        ])
                    }

                    Button("Trigger Real NSRangeException") {
                        PHGExceptionHandler.try {
                            PHGExceptionHandler.triggerSampleRangeException()
                        } catch: { exception in
                            PostHogSDK.shared.captureException(exception, properties: [
                                "is_test": true,
                                "exception_type": "real_nsrange_exception",
                                "caught_by": "objective_c_wrapper",
                            ])
                        }
                    }

                    Button("Trigger Real NSInvalidArgumentException") {
                        PHGExceptionHandler.try {
                            PHGExceptionHandler.triggerSampleInvalidArgumentException()
                        } catch: { exception in
                            PostHogSDK.shared.captureException(exception, properties: [
                                "is_test": true,
                                "exception_type": "real_invalid_argument_exception",
                                "caught_by": "objective_c_wrapper",
                            ])
                        }
                    }

                    Button("Trigger Custom NSException") {
                        PHGExceptionHandler.try {
                            PHGExceptionHandler.triggerSampleGenericException()
                        } catch: { exception in
                            PostHogSDK.shared.captureException(exception, properties: [
                                "is_test": true,
                                "exception_type": "real_custom_exception",
                                "caught_by": "objective_c_wrapper",
                            ])
                        }
                    }

                    Button("Trigger Chained NSException") {
                        PHGExceptionHandler.try {
                            PHGExceptionHandler.triggerChainedException()
                        } catch: { exception in
                            PostHogSDK.shared.captureException(exception, properties: [
                                "is_test": true,
                                "exception_type": "chained_exception",
                                "caught_by": "objective_c_wrapper",
                                "scenario": "network_database_business_chain",
                            ])
                        }
                    }

                    Button("Capture Async/Await Error") {
                        Task {
                            await captureAsyncError()
                        }
                    }
                }

                Section("PostHog beers") {
                    if !api.beers.isEmpty {
                        ForEach(api.beers) { beer in
                            HStack(alignment: .center) {
                                Text(beer.name)
                                Spacer()
                                Text("First brewed")
                                Text(beer.first_brewed).foregroundColor(Color.gray)
                            }
                        }
                    } else {
                        HStack {
                            Text("Loading beers...")
                            Spacer()
                            ProgressView()
                        }
                    }
                }
            }
            .navigationTitle("PostHog")
        }
        .onAppear {
            api.listBeers(completion: { beers in
                api.beers = beers
            })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

enum SampleAppError: LocalizedError {
    case generalAppError(ErrorDetails)

    var errorDescription: String? {
        switch self {
        case let .generalAppError(details):
            return "Custom error description for SampleAppError.generalAppError with details: \(details)"
        }
    }
}

struct ErrorDetails {
    let code: Int
    let reason: String
}

enum AsyncTestError: LocalizedError {
    case deepAsyncError(message: String, context: [String: Any])

    var errorDescription: String? {
        switch self {
        case let .deepAsyncError(message, context):
            return "Async Error: \(message) | Context: \(context)"
        }
    }
}
