//
//  PostHogQueue.swift
//  PostHog
//
//  Created by Ben White on 06.02.23.
//

import Foundation

private func clamped(_ value: Int) -> Int {
    max(1, value)
}

/// Adaptive limits stored privately on the queue rather than mutating
/// `config.maxBatchSize` / `config.flushAt` so user-supplied config fields
/// aren't silently changed. Both `cap` and `flushAt` are halved together on
/// HTTP 413.
private struct BatchLimits {
    var cap: Int
    var flushAt: Int

    static func initial(cap: Int, flushAt: Int) -> BatchLimits {
        BatchLimits(cap: clamped(cap), flushAt: clamped(flushAt))
    }

    /// Halves both `cap` and `flushAt`, returning the new cap. The cap is
    /// bounded by the actual batch size that triggered the halving — partial
    /// batches (queue depth below cap) shouldn't waste a halving step since
    /// the server only saw `actualBatchSize` records anyway. `flushAt` is
    /// clamped to the new `cap` so we never buffer more events than a single
    /// batch can drain.
    @discardableResult
    mutating func halve(actualBatchSize: Int) -> Int {
        cap = clamped(min(cap, actualBatchSize) / 2)
        flushAt = clamped(min(flushAt / 2, cap))
        return cap
    }
}

/**
 # Queue

 The queue uses File persistence. This allows us to
 1. Only send events when we have a network connection
 2. Ensure that we can survive app closing or offline situations
 3. Not hold too much in memory

 Generic over `Record` so the same infrastructure can ship analytics events,
 replay snapshots, and OTLP log records — see `QueueEndpoint<Record>` for the
 per-wire codec, send, and retry/cap policy that varies between them.
 */

class PostHogQueue<Record> {
    private let config: PostHogConfig
    private let endpoint: QueueEndpoint<Record>
    private let configuredMaxQueueSize: Int
    private let timerInterval: TimeInterval

    /// Guards `paused`, `pausedUntil`, and `retryCount`. These are touched from
    /// the URLSession completion queue (handleResult), the timer's main-thread
    /// callback (canFlush), and the reachability callbacks (onReachable /
    /// onUnreachable) — all without coordination — so a single state lock keeps
    /// the trio consistent against ThreadSanitizer.
    private let stateLock = NSLock()
    private var paused: Bool = false
    private var pausedUntil: Date?
    private var retryCount: Int = 0
    #if !os(watchOS)
        private let reachability: Reachability?
        private var reachableToken: RegistrationToken?
        private var unreachableToken: RegistrationToken?
    #endif

    private var isFlushing = false
    private let isFlushingLock = NSLock()
    /// Guards `timer` and `stopped`. The flag is set by `stop()` so a `start()`
    /// whose main-thread block hasn't fired yet can short-circuit instead of
    /// scheduling a timer that escapes invalidation.
    private let timerLock = NSLock()
    private var timer: Timer?
    private var stopped: Bool = false
    private let dispatchQueue: DispatchQueue

    private var batchLimits: BatchLimits
    private let batchLimitsLock = NSLock()

    /// Records accepted per `rateCapWindowSeconds`. `0` disables the cap and
    /// is the default for endpoints that don't opt in.
    private let rateCapMax: Int
    private let rateCapWindowSeconds: TimeInterval

    /// Guards the tumbling-window state below. Separate from `stateLock` so a
    /// hot-path `add(_:)` doesn't contend with reachability / retry traffic.
    private let rateCapLock = NSLock()
    private var rateCapWindowStart: Date?
    private var rateCapCount: Int = 0
    /// Flips to `true` the first time we drop a record in the current window;
    /// reset when the window rolls. Used to emit one warning per window
    /// instead of one per dropped record.
    private var rateCapDropWarned = false

    var depth: Int {
        fileQueue.depth
    }

    let fileQueue: PostHogFileBackedQueue

    #if !os(watchOS)
        init(_ config: PostHogConfig, _ storage: PostHogStorage, _ endpoint: QueueEndpoint<Record>, _ reachability: Reachability?) {
            self.config = config
            self.endpoint = endpoint
            self.reachability = reachability
            configuredMaxQueueSize = endpoint.maxQueueSize(config)
            timerInterval = endpoint.flushIntervalSeconds(config)
            batchLimits = .initial(cap: endpoint.initialCap(config), flushAt: endpoint.initialFlushAt(config))
            rateCapMax = endpoint.rateCapMax(config)
            rateCapWindowSeconds = endpoint.rateCapWindowSeconds(config)
            fileQueue = PostHogFileBackedQueue(
                queue: storage.url(forKey: endpoint.storageKey),
                oldQueues: endpoint.oldStorageKeys.map { storage.url(forKey: $0) },
                maxSize: configuredMaxQueueSize
            )
            dispatchQueue = DispatchQueue(label: endpoint.dispatchQueueLabel, target: .global(qos: .utility))
        }
    #else
        init(_ config: PostHogConfig, _ storage: PostHogStorage, _ endpoint: QueueEndpoint<Record>) {
            self.config = config
            self.endpoint = endpoint
            configuredMaxQueueSize = endpoint.maxQueueSize(config)
            timerInterval = endpoint.flushIntervalSeconds(config)
            batchLimits = .initial(cap: endpoint.initialCap(config), flushAt: endpoint.initialFlushAt(config))
            rateCapMax = endpoint.rateCapMax(config)
            rateCapWindowSeconds = endpoint.rateCapWindowSeconds(config)
            fileQueue = PostHogFileBackedQueue(
                queue: storage.url(forKey: endpoint.storageKey),
                oldQueues: endpoint.oldStorageKeys.map { storage.url(forKey: $0) },
                maxSize: configuredMaxQueueSize
            )
            dispatchQueue = DispatchQueue(label: endpoint.dispatchQueueLabel, target: .global(qos: .utility))
        }
    #endif

    private func sendBatch(_ payload: PostHogConsumerPayload<Record>) {
        hedgeLog("Sending batch of \(payload.records.count) records to PostHog")
        endpoint.send(payload.records) { [weak self] result in
            self?.handleResult(result, payload)
        }
    }

    private func handleResult(_ result: PostHogUploadInfo, _ payload: PostHogConsumerPayload<Record>) {
        // A missing response means no terminal delivery outcome is known, so
        // the exact durable entries must remain eligible for a later flush.
        let statusCode = result.statusCode ?? -1
        let isRetriable = statusCode == -1 || endpoint.isRetriableStatusCode(statusCode)

        if isRetriable {
            let newCount = nextRetryCount()
            let backoffDelay = min(TimeInterval(newCount) * retryDelay, maxRetryDelay)
            let delay = max(backoffDelay, result.retryAfter ?? 0)
            pauseFor(seconds: delay)
            hedgeLog("Pausing queue consumption for \(delay) seconds due to \(newCount) API failure(s).")
            payload.completion(false)
            return
        }

        // A multi-record 413 is resolved by progressively shrinking the batch.
        // Once a singleton still receives 413, only that poison entry is
        // acknowledged for removal. Neither path clears unrelated records.
        if statusCode == 413 {
            let canHalve = batchLimitsLock.withLock { batchLimits.cap > 1 && payload.records.count > 1 }

            if canHalve {
                let actualBatchSize = payload.records.count
                let halvedCap = batchLimitsLock.withLock {
                    batchLimits.halve(actualBatchSize: actualBatchSize)
                }
                hedgeLog("Queue: HTTP 413, halved batch cap to \(halvedCap)")
                payload.completion(false)
                return
            }

            hedgeLog("Queue: dropping singleton batch after HTTP 413")
            resetRetryState()
            payload.completion(true)
            return
        }

        // 2xx success or a terminal response removes the exact snapshotted
        // entries. The adaptive cap stays where it is.
        resetRetryState()
        payload.completion(true)
    }

    private func nextRetryCount() -> Int {
        stateLock.withLock {
            let maximumBackoffStep = max(1, Int(maxRetryDelay / retryDelay))
            if retryCount < maximumBackoffStep {
                retryCount += 1
            }
            return retryCount
        }
    }

    private func resetRetryState() {
        stateLock.withLock {
            retryCount = 0
            pausedUntil = nil
        }
    }

    func start(disableReachabilityForTesting: Bool,
               disableQueueTimerForTesting: Bool)
    {
        if !disableReachabilityForTesting {
            #if !os(watchOS)
                // Subscribe via the multicast so events, replay, and logs queues
                // can all receive notifications without overwriting each other.
                reachableToken = reachability?.onReachable.subscribe { [weak self] reachability in
                    guard let self else { return }
                    if self.updatePauseState(for: reachability) {
                        self.flush()
                    }
                }

                unreachableToken = reachability?.onUnreachable.subscribe { [weak self] _ in
                    guard let self else { return }
                    self.stateLock.withLock {
                        hedgeLog("Queue is paused because network is unreachable")
                        self.paused = true
                    }
                }

                if let reachability {
                    // A shared notifier may already be running, so late queue
                    // subscribers must synchronously adopt its current state
                    // rather than waiting for a transition that may never come.
                    _ = updatePauseState(for: reachability)
                }

                do {
                    try reachability?.startNotifier()
                } catch {
                    // Without a running notifier no callback can ever clear a
                    // reachability pause, so it must not outlive the failure.
                    // URLSession errors and the retry backoff cover connectivity.
                    hedgeLog("Error: Unable to monitor network reachability: \(error)")
                    stateLock.withLock { paused = false }
                }
            #endif
        }

        if !disableQueueTimerForTesting {
            // Schedule on the main runloop so the Timer fires in a default
            // mode. The lock is re-acquired *inside* the dispatched block so a
            // concurrent `stop()` (which sets `stopped = true`) can short-
            // circuit and prevent a leaked timer.
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.timerLock.withLock {
                    guard !self.stopped else { return }
                    self.timer = Timer.scheduledTimer(withTimeInterval: self.timerInterval, repeats: true, block: { [weak self] _ in
                        self?.timerFired()
                    })
                }
            }
        }
    }

    private func timerFired() {
        flush()
    }

    /// Internal, used for testing
    func clear() {
        fileQueue.clear()
        rateCapLock.withLock {
            rateCapWindowStart = nil
            rateCapCount = 0
            rateCapDropWarned = false
        }
    }

    func stop() {
        // Snapshot the timer under the lock, then invalidate on the main
        // thread (Timer requires invalidation on the runloop it was scheduled
        // on). Setting `stopped = true` blocks any in-flight `start()` whose
        // main-thread block has not yet fired from creating a new timer.
        let timerToInvalidate: Timer? = timerLock.withLock {
            stopped = true
            let snapshot = timer
            timer = nil
            return snapshot
        }
        if let timerToInvalidate {
            if Thread.isMainThread {
                timerToInvalidate.invalidate()
            } else {
                DispatchQueue.main.async {
                    timerToInvalidate.invalidate()
                }
            }
        }

        #if !os(watchOS)
            // Releases the multicast tokens; new subscriber callbacks won't be
            // dispatched after this. Callbacks already past the multicast
            // snapshot can still complete — the `[weak self]` capture on each
            // subscription neutralises them once the queue is also nilled.
            reachableToken = nil
            unreachableToken = nil
        #endif
    }

    func flush() {
        if !canFlush() {
            return
        }

        let cap = batchLimitsLock.withLock { batchLimits.cap }
        take(cap) { payload in
            if !payload.records.isEmpty {
                self.sendBatch(payload)
            } else {
                // there's nothing to be sent
                payload.completion(true)
            }
        }
    }

    func flushIfOverThreshold() {
        let threshold = batchLimitsLock.withLock { batchLimits.flushAt }
        if fileQueue.depth >= threshold {
            flush()
        }
    }

    /// Enqueues a record on the caller's thread. Encoding plus the
    /// `fileQueue.add` disk write are synchronous — sized in microseconds for
    /// a healthy filesystem but technically blocking. We keep it sync to
    /// preserve crash durability: a process kill between `add()` returning and
    /// a deferred write would lose the record. Callers on hot paths (main
    /// thread, frame loops) should be aware.
    ///
    /// Rate cap drops happen *before* the FIFO eviction check so a new record
    /// over the cap doesn't displace an older queued one — the rate cap is a
    /// caller-side throttle, not a buffer policy.
    @discardableResult
    func add(_ record: Record) -> Bool {
        if !consumeRateCap() {
            noteRateCapDropped()
            return false
        }

        guard let data = endpoint.encode(record) else {
            hedgeLog("Tried to queue unserialisable record")
            return false
        }

        let result = fileQueue.add(data, maxSize: configuredMaxQueueSize)
        guard result.success else { return false }
        if result.evicted != nil {
            hedgeLog("Queue is full, dropping oldest record")
        }
        hedgeLog("Queued \(endpoint.describe(record)). Depth: \(fileQueue.depth)")
        flushIfOverThreshold()
        return true
    }

    /// Returns `true` if the record can be enqueued, `false` if the per-window
    /// cap has been reached. Re-anchors the window on negative elapsed so
    /// wall-clock jumps don't strand the counter.
    private func consumeRateCap() -> Bool {
        if rateCapMax <= 0 {
            return true
        }
        return rateCapLock.withLock {
            rollRateCapWindowIfNeeded()
            if rateCapCount >= rateCapMax {
                return false
            }
            rateCapCount += 1
            return true
        }
    }

    /// Caller must hold `rateCapLock`.
    private func rollRateCapWindowIfNeeded() {
        let current = now()
        guard let start = rateCapWindowStart else {
            rateCapWindowStart = current
            rateCapCount = 0
            rateCapDropWarned = false
            return
        }
        let elapsed = current.timeIntervalSince(start)
        if elapsed < 0 || elapsed >= rateCapWindowSeconds {
            rateCapWindowStart = current
            rateCapCount = 0
            rateCapDropWarned = false
        }
    }

    /// Logs the first rate-cap drop in each window and silences subsequent
    /// ones, to avoid spamming console at high record rates.
    private func noteRateCapDropped() {
        rateCapLock.withLock {
            guard !rateCapDropWarned else { return }
            rateCapDropWarned = true
            hedgeLog("Queue rate cap exceeded (\(rateCapMax) per \(rateCapWindowSeconds)s), dropping records this window")
        }
    }

    private func take(_ count: Int, completion: @escaping (PostHogConsumerPayload<Record>) -> Void) {
        dispatchQueue.async { [weak self] in
            guard let self else { return }

            // Re-check pause state on the dispatch queue: the synchronous
            // `canFlush()` snapshot can lie if reachability flipped or
            // `pausedUntil` was set between the caller's check and now.
            if self.pauseReason() != nil { return }

            // Atomically test-and-set the flushing flag. `withLock` returns
            // the closure value, so a `false` here means another flush is
            // already in flight and we bail out of the function — not just
            // the closure.
            let acquired: Bool = self.isFlushingLock.withLock {
                if self.isFlushing { return false }
                self.isFlushing = true
                return true
            }
            if !acquired {
                hedgeLog("Already flushing")
                return
            }

            let entries = self.fileQueue.peekEntries(count)

            var processing: [Record] = []

            for entry in entries {
                guard let record = self.endpoint.decode(entry.data) else {
                    continue
                }
                processing.append(record)
            }

            completion(PostHogConsumerPayload(records: processing) { [weak self] success in
                guard let self else { return }
                if success, !entries.isEmpty {
                    self.fileQueue.remove(ids: entries.map(\.id))
                    hedgeLog("Completed!")
                }

                self.isFlushingLock.withLock {
                    self.isFlushing = false
                }
            })
        }
    }

    #if !os(watchOS)
        /// Applies the latest shared reachability snapshot and returns whether
        /// this queue may send under its configured data mode.
        private func updatePauseState(for reachability: Reachability) -> Bool {
            let connection = reachability.connection
            return stateLock.withLock {
                if connection == .unavailable {
                    hedgeLog("Queue is paused because network is unreachable")
                    paused = true
                } else if config.dataMode == .wifi, connection != .wifi {
                    hedgeLog("Queue is paused because its not in WiFi mode")
                    paused = true
                } else {
                    paused = false
                }
                return !paused
            }
        }
    #endif

    private func pauseFor(seconds: TimeInterval) {
        let until = now().addingTimeInterval(seconds)
        stateLock.withLock { pausedUntil = until }
    }

    /// Returns a human-readable pause reason if the queue is currently
    /// paused, or `nil` if it can flush. Used by both the synchronous
    /// pre-check in `flush()` and the re-check inside `take()`.
    private func pauseReason() -> String? {
        let (isPaused, until) = stateLock.withLock { (paused, pausedUntil) }
        if isPaused { return "paused due to the reachability check" }
        if let until, until > now() { return "paused until `\(until)`" }
        return nil
    }

    private func canFlush() -> Bool {
        if let reason = pauseReason() {
            hedgeLog("The queue is \(reason)")
            return false
        }
        return true
    }
}

#if TESTING
    extension PostHogQueue {
        var currentBatchCapForTesting: Int {
            batchLimitsLock.withLock { batchLimits.cap }
        }

        var currentFlushAtForTesting: Int {
            batchLimitsLock.withLock { batchLimits.flushAt }
        }

        var currentRetryCountForTesting: Int {
            stateLock.withLock { retryCount }
        }
    }
#endif
