//
//  PostHogStorage.swift
//  PostHog
//
//  Created by Ben White on 08.02.23.
//

import Darwin
import Foundation

/**
 # Storage

 Note for tvOS:
 As tvOS restricts access to persisted Application Support directory, we use Library/Caches instead for storage

 If needed, we can use UserDefaults for lightweight data - according to Apple, you can use UserDefaults to persist up to 500KB of data on tvOS
 see: https://developer.apple.com/forums/thread/16967?answerId=50696022#50696022
 */
func applicationSupportDirectoryURL() -> URL {
    #if os(tvOS)
        // tvOS restricts access to Application Support directory on physical devices
        // Use Library/Caches directory which may have less frequent eviction behavior than temp (which is purged when the app quits)
        let searchPath: FileManager.SearchPathDirectory = .cachesDirectory
    #else
        let searchPath: FileManager.SearchPathDirectory = .applicationSupportDirectory
    #endif

    let url = FileManager.default.urls(for: searchPath, in: .userDomainMask).first!
    let bundleIdentifier = getBundleIdentifier()

    return url.appendingPathComponent(bundleIdentifier)
}

/**

 From Apple Docs:
 In iOS, the value is nil when the group identifier is invalid. In macOS, a URL of the expected form is always
 returned, even if the app group is invalid, so be sure to test that you can access the underlying directory
 before attempting to use it.

 MacOS: The system also creates the Library/Application Support, Library/Caches, and Library/Preferences
 subdirectories inside the group directory the first time you use it
 iOS: The system creates only the Library/Caches subdirectory automatically

  see: https://developer.apple.com/documentation/foundation/filemanager/1412643-containerurl/
  */
func appGroupContainerUrl(config: PostHogConfig) -> URL? {
    guard let appGroupIdentifier = config.appGroupIdentifier else { return nil }

    #if os(tvOS)
        // tvOS: Due to stricter sandbox rules, creating "Application Support" directory is not possible on tvOS
        let librarySubPath = "Library/Caches/"
    #else
        let librarySubPath = "Library/Application Support/"
    #endif

    let libraryUrl = FileManager.default
        .containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier)?
        .appendingPathComponent(librarySubPath)

    guard let url = libraryUrl?.appendingPathComponent(appGroupIdentifier) else { return nil }

    createDirectoryAtURLIfNeeded(url: url)

    // Merges a legacy container (using bundleIdentifier) into the new container using appGroupIdentifier
    mergeLegacyContainerIfNeeded(within: libraryUrl, to: url)

    return directoryExists(url) ? url : nil
}

func getBundleIdentifier() -> String {
    #if TESTING // only visible to test targets
        return bundleIdentifier(fallback: "com.posthog.test")
    #else
        return bundleIdentifier(fallback: "com.posthog.unknown")
    #endif
}

/**
 Determines if the current process is an extension target.

 App extensions have bundle paths ending in ".appex"
 */
func isExtension() -> Bool {
    Bundle.main.bundlePath.hasSuffix(".appex")
}

/**
 Merges content from a legacy container directory into the current app group container.

 This function handles the migration of PostHog data from the old storage location (using `bundleIdentifier`)
 to the new app group shared container location (using `appGroupIdentifier`).

 Migration rules:
 - Files that already exist at the destination are skipped (no overwrite)
 - Identity-related keys (distinctId, anonymousId, etc.) are only migrated from the main app target
 - Successfully migrated files are deleted from the source
 - Empty directories are cleaned up after migration
 - The entire folder structure is preserved during migration

 - Parameters:
   - libraryUrl: The base library URL where both legacy and new containers might exist
   - destinationUrl: The target app group container URL where files should be migrated
 */
func mergeLegacyContainerIfNeeded(within libraryUrl: URL?, to destinationUrl: URL) {
    let bundleIdentifier = getBundleIdentifier()
    guard let sourceUrl = libraryUrl?.appendingPathComponent(bundleIdentifier), directoryExists(sourceUrl) else {
        return
    }

    let skipKeys: [PostHogStorage.StorageKey]
    if isExtension() {
        // Extensions should skip migrating identity-related keys to ensure consistent user identity with main app target
        skipKeys = [
            .distinctId,
            .anonymousId,
            .isIdentified,
            .groups,
            .registerProperties,
            .personPropertiesForFlags,
            .groupPropertiesForFlags,
            .personPropertiesHash,
        ]
        hedgeLog("Legacy folder found at \(sourceUrl), merging from extension... (skipping \(skipKeys.count) identity keys)")
    } else {
        skipKeys = []
        hedgeLog("Legacy folder found at \(sourceUrl), merging from main app... (migrating all keys)")
    }

    // Migrate contents from the legacy container
    migrateDirectoryContents(from: sourceUrl, to: destinationUrl, skipKeys: skipKeys)

    // Try to remove the source directory if it's empty
    if removeIfEmpty(sourceUrl) {
        hedgeLog("Successfully migrated and removed legacy folder at \(sourceUrl)")
    }
}

/**
 Removes a directory if it's empty.

 - Parameters:
   - url: The directory URL to potentially remove
 - Returns: `true` if the directory was removed, `false` otherwise
 */
@discardableResult
func removeIfEmpty(_ url: URL) -> Bool {
    let remainingItems = try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil, options: [])
    if remainingItems?.isEmpty == true {
        do {
            try FileManager.default.removeItem(at: url)
            return true
        } catch {
            hedgeLog("Failed to remove empty directory at \(url.path): \(error)")
        }
    }
    return false
}

/**
 Migrates a single file from source to destination.

 Migration rules:
 - If the file doesn't exist at destination, it's copied and then deleted from source
 - If the file already exists at destination, only the source file is deleted

 - Parameters:
   - sourceFile: The source file URL
   - destinationFile: The destination file URL
   - skipCopy: Wether to skip copying file to desitnation
 - Throws: Any errors that occur during file operations
 */
func migrateFile(from sourceFile: URL, to destinationFile: URL, skipCopy: Bool) throws {
    if !skipCopy, !FileManager.default.fileExists(atPath: destinationFile.path) {
        try FileManager.default.copyItem(at: sourceFile, to: destinationFile)
    }
    // Always delete source file after processing (whether copied or skipped)
    try FileManager.default.removeItem(at: sourceFile)
}

/**
 Recursively migrates all contents from a source directory to a destination directory.

 - Parameters:
   - sourceDir: The source directory URL
   - destinationDir: The destination directory URL
   - skipKeys: Array of storage keys that should be skipped during migration
 */
func migrateDirectoryContents(from sourceDir: URL, to destinationDir: URL, skipKeys: [PostHogStorage.StorageKey] = []) {
    do {
        // Create destination directory if it doesn't exist (we need to call this here again as the function is recursive)
        createDirectoryAtURLIfNeeded(url: destinationDir)

        // Get all items in source directory
        let items = try FileManager.default.contentsOfDirectory(at: sourceDir, includingPropertiesForKeys: nil, options: [])

        for item in items {
            let destinationItem = destinationDir.appendingPathComponent(item.lastPathComponent)

            // Check if it's a directory
            var isDirectory: ObjCBool = false
            if FileManager.default.fileExists(atPath: item.path, isDirectory: &isDirectory) {
                if isDirectory.boolValue {
                    // Recursively migrate subdirectory (preserving the folder structure)
                    migrateDirectoryContents(from: item, to: destinationItem, skipKeys: skipKeys)
                    // Remove empty directory after migration
                    removeIfEmpty(item)
                } else {
                    let fileName = item.lastPathComponent
                    let shouldSkip = skipKeys.contains(where: { $0.rawValue == fileName })

                    // Migrate file
                    do {
                        try migrateFile(from: item, to: destinationItem, skipCopy: shouldSkip)
                    } catch {
                        hedgeLog("Failed to migrate file from \(item.path) to \(destinationItem.path): \(error)")
                    }
                }
            }
        }
    } catch {
        hedgeLog("Error reading directory contents at \(sourceDir.path): \(error)")
    }
}

class PostHogStorage {
    // when adding or removing items here, make sure to update the reset method
    enum StorageKey: String, CaseIterable {
        case distinctId = "posthog.distinctId"
        case anonymousId = "posthog.anonymousId"
        case queue = "posthog.queueFolder.uuid" // queue from > 3.48.1
        case oldQueueFolder = "posthog.queueFolder" // queue from 3.0.0 - 3.48.1
        case oldQueuePlist = "posthog.queue.plist" // queue from pre-3.0.0
        case replayQeueue = "posthog.replayFolder.uuid" // replay queue with UUID filenames
        case oldReplayQueue = "posthog.replayFolder" // replay queue with legacy timestamp filenames
        case replayBufferQueue = "posthog.replayBufferFolder"
        case logsQueue = "posthog.logsFolder"
        case enabledFeatureFlags = "posthog.enabledFeatureFlags"
        case enabledFeatureFlagPayloads = "posthog.enabledFeatureFlagPayloads"
        case flags = "posthog.flags"
        case groups = "posthog.groups"
        case registerProperties = "posthog.registerProperties"
        case optOut = "posthog.optOut"
        case sessionReplay = "posthog.sessionReplay"
        case isIdentified = "posthog.isIdentified"
        case personProcessingEnabled = "posthog.enabledPersonProcessing"
        case remoteConfig = "posthog.remoteConfig"
        case surveyProgress = "posthog.surveyProgress"
        case surveyResetEpoch = "posthog.surveyResetEpoch"
        case surveySeen = "posthog.surveySeen"
        case lastSeenSurveyDate = "posthog.lastSeenSurveyDate"
        case requestId = "posthog.requestId"
        case evaluatedAt = "posthog.evaluatedAt"
        case minimalFlagCalledEvents = "posthog.minimalFlagCalledEvents"
        case personPropertiesForFlags = "posthog.personPropertiesForFlags"
        case groupPropertiesForFlags = "posthog.groupPropertiesForFlags"
        case errorTracking = "posthog.errorTracking"
        case capturePerformance = "posthog.capturePerformance"
        case deviceId = "posthog.deviceId"
        case pushSubscription = "posthog.pushSubscription"
        case pushPendingUnregister = "posthog.pushPendingUnregister"
        case pushAppIdsMigrated = "posthog.pushAppIdsMigrated"
        case personPropertiesHash = "posthog.personPropertiesHash"
    }

    private let surveyStateLock = NSRecursiveLock()
    private var surveyStateDepth = 0
    private var surveyStateCoordinated = false
    private var surveyEpochUnavailable = false
    #if TESTING
        var testOnSurveyProgressRead: (() -> Void)?
    #endif

    /// The lock file survives reset so other app-group processes keep locking the same inode.
    func withSurveyState<T>(_ operation: (String) -> T) -> T {
        surveyStateLock.withLock {
            if surveyStateDepth > 0 { return operation(currentSurveyEpoch()) }
            let descriptor = open(appFolderUrl.appendingPathComponent("posthog.surveyState.lock").path, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR)
            if descriptor >= 0 {
                var result: Int32
                repeat {
                    result = flock(descriptor, LOCK_EX)
                } while result != 0 && errno == EINTR
                surveyStateCoordinated = result == 0
            }
            if !surveyStateCoordinated { hedgeLog("Unable to coordinate shared survey storage; survey progress is disabled") }
            surveyStateDepth += 1
            defer {
                surveyStateDepth -= 1
                if surveyStateCoordinated { flock(descriptor, LOCK_UN) }
                if descriptor >= 0 { close(descriptor) }
                surveyStateCoordinated = false
            }
            return operation(currentSurveyEpoch())
        }
    }

    private func currentSurveyEpoch() -> String {
        // A different token on every failed read makes all validation fail closed.
        guard surveyStateCoordinated, !surveyEpochUnavailable,
              !FileManager.default.fileExists(atPath: surveyRevocationUrl.path) else { return UUID().uuidString }
        if let epoch = getString(forKey: .surveyResetEpoch), UUID(uuidString: epoch) != nil { return epoch }
        let epoch = UUID().uuidString
        return persistSurveyEpoch(epoch) ? epoch : UUID().uuidString
    }

    private func persistSurveyEpoch(_ epoch: String) -> Bool {
        do {
            let data = try JSONSerialization.data(withJSONObject: [StorageKey.surveyResetEpoch.rawValue: epoch])
            try data.write(to: url(forKey: .surveyResetEpoch), options: .atomic)
            return getString(forKey: .surveyResetEpoch) == epoch
        } catch {
            hedgeLog("Failed to persist survey reset epoch: \(error)")
            return false
        }
    }

    private var surveyRevocationUrl: URL { appFolderUrl.appendingPathComponent("posthog.surveyResetRevoked") }

    private func rotateSurveyEpoch() {
        surveyEpochUnavailable = true
        if persistSurveyEpoch(UUID().uuidString) {
            do {
                if FileManager.default.fileExists(atPath: surveyRevocationUrl.path) { try FileManager.default.removeItem(at: surveyRevocationUrl) }
                surveyEpochUnavailable = false
            } catch { hedgeLog("Unable to clear survey epoch revocation: \(error)") }
            return
        }
        do {
            // Revoke the previous token when a recoverable write error prevents replacement.
            let epochUrl = url(forKey: .surveyResetEpoch)
            if FileManager.default.fileExists(atPath: epochUrl.path) { try FileManager.default.removeItem(at: epochUrl) }
            surveyEpochUnavailable = false
        } catch {
            // An immutable epoch can coexist with writable identity files in the same directory.
            do {
                try Data().write(to: surveyRevocationUrl, options: .atomic)
                surveyEpochUnavailable = false
            } catch { hedgeLog("Unable to revoke survey reset epoch; shared reset could not be persisted: \(error)") }
        }
    }

    func isSurveyGenerationCurrent(_ generation: String) -> Bool {
        withSurveyState { $0 == generation }
    }

    // The location for storing data that we always want to keep
    let appFolderUrl: URL

    init(_ config: PostHogConfig) {
        appFolderUrl = Self.getAppFolderUrl(from: config)

        // migrate legacy storage if needed
        Self.migrateLegacyStorage(from: config, to: appFolderUrl)
    }

    func url(forKey key: StorageKey) -> URL {
        appFolderUrl.appendingPathComponent(key.rawValue)
    }

    // The "data" methods are the core for storing data and differ between Modes
    // All other typed storage methods call these
    private func getData(forKey: StorageKey) -> Data? {
        let url = url(forKey: forKey)

        do {
            if FileManager.default.fileExists(atPath: url.path) {
                return try Data(contentsOf: url)
            }
        } catch {
            hedgeLog("Error reading data from key \(forKey): \(error)")
        }
        return nil
    }

    private func setData(forKey: StorageKey, contents: Data?) {
        var url = url(forKey: forKey)

        do {
            if contents == nil {
                deleteSafely(url)
                return
            }

            try contents?.write(to: url)

            var resourceValues = URLResourceValues()
            resourceValues.isExcludedFromBackup = true
            try url.setResourceValues(resourceValues)
        } catch {
            hedgeLog("Failed to write data for key '\(forKey)' error: \(error)")
        }
    }

    private func getJson(forKey key: StorageKey) -> Any? {
        guard let data = getData(forKey: key) else { return nil }

        do {
            return try JSONSerialization.jsonObject(with: data)
        } catch {
            hedgeLog("Failed to serialize key '\(key)' error: \(error)")
        }
        return nil
    }

    private func setJson(forKey key: StorageKey, json: Any) {
        var jsonObject: Any?

        if let dictionary = json as? [AnyHashable: Any] {
            jsonObject = dictionary
        } else if let array = json as? [Any] {
            jsonObject = array
        } else {
            // TRICKY: This is weird legacy behaviour storing the data as a dictionary
            jsonObject = [key.rawValue: json]
        }

        var data: Data?
        do {
            data = try JSONSerialization.data(withJSONObject: jsonObject!)
        } catch {
            hedgeLog("Failed to serialize key '\(key)' error: \(error)")
        }
        setData(forKey: key, contents: data)
    }

    /**
     There are cases where applications using posthog-ios want to share analytics data between host app and
     an app extension, Widget or App Clip. If there's a defined `appGroupIdentifier` in configuration,
     we want to use a shared container for storing data so that extensions correctly identify a user (and batch process events)
     */
    private static func getBaseAppFolderUrl(from configuration: PostHogConfig) -> URL {
        appGroupContainerUrl(config: configuration) ?? applicationSupportDirectoryURL()
    }

    private static func migrateItem(at sourceUrl: URL, to destinationUrl: URL, fileManager: FileManager) throws {
        guard fileManager.fileExists(atPath: sourceUrl.path) else { return }
        // Copy file or directory over (if it doesn't exist)
        if !fileManager.fileExists(atPath: destinationUrl.path) {
            try fileManager.copyItem(at: sourceUrl, to: destinationUrl)
        }
    }

    private static func migrateLegacyStorage(from configuration: PostHogConfig, to apiDir: URL) {
        let legacyUrl = getBaseAppFolderUrl(from: configuration)
        if directoryExists(legacyUrl) {
            let fileManager = FileManager.default

            // Migrate old files that correspond to StorageKey values
            for storageKey in StorageKey.allCases {
                let legacyFileUrl = legacyUrl.appendingPathComponent(storageKey.rawValue)
                let newFileUrl = apiDir.appendingPathComponent(storageKey.rawValue)

                do {
                    // Migrate the item and its contents if it exists
                    try migrateItem(at: legacyFileUrl, to: newFileUrl, fileManager: fileManager)
                } catch {
                    hedgeLog("Error during storage migration for file \(storageKey.rawValue) at path \(legacyFileUrl.path): \(error)")
                }

                // Remove the legacy item after successful migration
                if fileManager.fileExists(atPath: legacyFileUrl.path) {
                    do {
                        try fileManager.removeItem(at: legacyFileUrl)
                    } catch {
                        hedgeLog("Could not delete file \(storageKey.rawValue) at path \(legacyFileUrl.path): \(error)")
                    }
                }
            }
        }
    }

    private static func getAppFolderUrl(from configuration: PostHogConfig) -> URL {
        var apiDir = getBaseAppFolderUrl(from: configuration)
            .appendingPathComponent(configuration.projectToken)

        createDirectoryAtURLIfNeeded(url: apiDir)

        // Exclude the entire SDK subtree, including queues and existing installations.
        // The parent bundle/app-group folder may also contain unrelated application data.
        do {
            var resourceValues = URLResourceValues()
            resourceValues.isExcludedFromBackup = true
            try apiDir.setResourceValues(resourceValues)
        } catch {
            hedgeLog("Failed to exclude storage directory from backup: \(error)")
        }

        return apiDir
    }

    func reset(keepAnonymousId: Bool = false) {
        withSurveyState { _ in
            rotateSurveyEpoch()
            // sadly the StorageKey.allCases does not work here
            deleteSafely(url(forKey: .distinctId))
            if !keepAnonymousId {
                deleteSafely(url(forKey: .anonymousId))
            }
            // .queue, .replayQeueue, .logsQueue not deleted here — each queue manages its own
            // disk state via clear() and the per-record distinctId captured at enqueue time
            // (see PostHogLogRecord) lets in-flight telemetry survive an identity change.
            deleteSafely(url(forKey: .oldQueueFolder))
            deleteSafely(url(forKey: .oldQueuePlist))
            deleteSafely(url(forKey: .oldReplayQueue))
            deleteSafely(url(forKey: .flags))
            deleteSafely(url(forKey: .enabledFeatureFlags))
            deleteSafely(url(forKey: .enabledFeatureFlagPayloads))
            deleteSafely(url(forKey: .groups))
            deleteSafely(url(forKey: .registerProperties))
            deleteSafely(url(forKey: .optOut))
            deleteSafely(url(forKey: .isIdentified))
            deleteSafely(url(forKey: .personProcessingEnabled))
            // .surveyResetEpoch and its lock file survive reset to invalidate other processes.
            // .remoteConfig is project-level config (not user data); kept across reset() so features re-arm
            deleteSafely(url(forKey: .surveySeen))
            deleteSafely(url(forKey: .surveyProgress))
            deleteSafely(url(forKey: .lastSeenSurveyDate))
            deleteSafely(url(forKey: .requestId))
            deleteSafely(url(forKey: .minimalFlagCalledEvents))
            deleteSafely(url(forKey: .personPropertiesForFlags))
            deleteSafely(url(forKey: .groupPropertiesForFlags))
            deleteSafely(url(forKey: .personPropertiesHash))
            // legacy slices, no longer written (config now lives in .remoteConfig); drop stragglers from older SDKs
            deleteSafely(url(forKey: .sessionReplay))
            deleteSafely(url(forKey: .errorTracking))
            deleteSafely(url(forKey: .capturePerformance))
            // .pushSubscription is deliberately NOT cleared here: PostHogPushSubscriptionHandler.recordForReset()
            // clears it under its own recordLock (before this runs) so a concurrent send() can't write a
            // fresh record into the gap and have it erased unlocked. When there is no push handler
            // (feature disabled/absent), no record exists to leak, so skipping the clear here is safe.
            // .pushPendingUnregister is deliberately NOT cleared here: it holds a durable "delete this
            // subscription" intent for the identity being logged out of, and must outlive reset() so an
            // offline/failed unregister keeps retrying on flush()/next launch (see PostHogPushSubscriptionHandler).
        }
    }

    func remove(key: StorageKey) {
        let url = url(forKey: key)

        deleteSafely(url)
    }

    func getString(forKey key: StorageKey) -> String? {
        getTypedValue(forKey: key)
    }

    func setString(forKey key: StorageKey, contents: String) {
        setJson(forKey: key, json: contents)
    }

    func getDictionary(forKey key: StorageKey) -> [AnyHashable: Any]? {
        let dictionary = getJson(forKey: key) as? [AnyHashable: Any]
        #if TESTING
            if key == .surveyProgress { testOnSurveyProgressRead?() }
        #endif
        return dictionary
    }

    func setDictionary(forKey key: StorageKey, contents: [AnyHashable: Any]) {
        setJson(forKey: key, json: contents)
    }

    func getBool(forKey key: StorageKey) -> Bool? {
        getTypedValue(forKey: key)
    }

    private func getTypedValue<T>(forKey key: StorageKey) -> T? {
        let value = getJson(forKey: key)
        if let typedValue = value as? T {
            return typedValue
        } else if let dictValue = value as? [String: T] {
            return dictValue[key.rawValue]
        }
        return nil
    }

    func setBool(forKey key: StorageKey, contents: Bool) {
        setJson(forKey: key, json: contents)
    }

    func getInt(forKey key: StorageKey) -> Int? {
        let value = getJson(forKey: key)
        if let intValue = value as? Int {
            return intValue
        } else if let numberValue = value as? NSNumber {
            return numberValue.intValue
        } else if let dictValue = value as? [String: Any],
                  let nestedValue = dictValue[key.rawValue]
        {
            if let intValue = nestedValue as? Int {
                return intValue
            } else if let numberValue = nestedValue as? NSNumber {
                return numberValue.intValue
            }
        }
        return nil
    }

    func setInt(forKey key: StorageKey, contents: Int) {
        setJson(forKey: key, json: contents)
    }
}
