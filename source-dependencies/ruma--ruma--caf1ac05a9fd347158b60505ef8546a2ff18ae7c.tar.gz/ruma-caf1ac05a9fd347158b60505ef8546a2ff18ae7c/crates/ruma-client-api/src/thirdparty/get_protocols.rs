//! `GET /_matrix/client/*/thirdparty/protocols`
//!
//! Fetches the overall metadata about protocols supported by the homeserver.

pub mod v3 {
    //! `/v3/` ([spec])
    //!
    //! [spec]: https://spec.matrix.org/v1.19/client-server-api/#get_matrixclientv3thirdpartyprotocols

    use std::collections::BTreeMap;

    use ruma_common::{
        api::{auth_scheme::AccessToken, request, response},
        metadata,
        thirdparty::Protocol,
    };

    metadata! {
        method: GET,
        rate_limited: false,
        authentication: AccessToken,
        history: {
            1.0 => "/_matrix/client/r0/thirdparty/protocols",
            1.1 => "/_matrix/client/v3/thirdparty/protocols",
        }
    }

    /// Request type for the `get_protocols` endpoint.
    #[request]
    #[derive(Default)]
    pub struct Request {}

    /// Response type for the `get_protocols` endpoint.
    #[response]
    pub struct Response {
        /// Metadata about protocols supported by the homeserver.
        #[ruma_api(body)]
        pub protocols: BTreeMap<String, Protocol>,
    }

    impl Request {
        /// Creates an empty `Request`.
        pub fn new() -> Self {
            Self {}
        }
    }

    impl Response {
        /// Creates a new `Response` with the given protocols.
        pub fn new(protocols: BTreeMap<String, Protocol>) -> Self {
            Self { protocols }
        }
    }
}
