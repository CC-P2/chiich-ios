//! `GET /_matrix/client/*/profile/{userId}/displayname`
//!
//! Get the display name of a user.

pub mod v3 {
    //! `/v3/` ([spec])
    //!
    //! [spec]: https://spec.matrix.org/v1.15/client-server-api/#get_matrixclientv3profileuseriddisplayname

    use ruma_common::{
        OwnedUserId,
        api::{auth_scheme::NoAccessToken, request, response},
        metadata,
    };

    metadata! {
        method: GET,
        rate_limited: false,
        authentication: NoAccessToken,
        history: {
            1.0 => "/_matrix/client/r0/profile/{user_id}/displayname",
            1.1 => "/_matrix/client/v3/profile/{user_id}/displayname",
        }
    }

    /// Request type for the `get_display_name` endpoint.
    #[request]
    pub struct Request {
        /// The user whose display name will be retrieved.
        #[ruma_api(path)]
        pub user_id: OwnedUserId,
    }

    /// Response type for the `get_display_name` endpoint.
    #[response]
    #[derive(Default)]
    pub struct Response {
        /// The user's display name, if set.
        #[serde(skip_serializing_if = "Option::is_none")]
        pub displayname: Option<String>,
    }

    impl Request {
        /// Creates a new `Request` with the given user ID.
        #[deprecated = "Use the get_profile_field endpoint instead."]
        pub fn new(user_id: OwnedUserId) -> Self {
            Self { user_id }
        }
    }

    impl Response {
        /// Creates a new `Response` with the given display name.
        pub fn new(displayname: Option<String>) -> Self {
            Self { displayname }
        }
    }
}
