//! `POST /_matrix/client/*/rendezvous/`
//!
//! Create a rendezvous session.

#[cfg(feature = "unstable-msc4108")]
pub mod unstable_msc4108 {
    //! `unstable/org.matrix.msc4108` ([MSC])
    //!
    //! [MSC]: https://github.com/matrix-org/matrix-spec-proposals/pull/4108

    use http::header::{CONTENT_TYPE, ETAG, EXPIRES, LAST_MODIFIED};
    #[cfg(feature = "client")]
    use ruma_common::api::BytesBody;
    use ruma_common::{
        api::{
            auth_scheme::NoAccessToken,
            error::{DeserializationError, Error, HeaderDeserializationError},
        },
        http_headers::TEXT_PLAIN,
        metadata,
    };
    use url::Url;
    use web_time::SystemTime;

    metadata! {
        method: POST,
        rate_limited: true,
        authentication: NoAccessToken,
        history: {
            unstable("org.matrix.msc4108") => "/_matrix/client/unstable/org.matrix.msc4108/rendezvous",
        }
    }

    /// Request type for the `POST` `rendezvous` endpoint from the 2024 version of MSC4108.
    #[derive(Debug, Default, Clone)]
    #[cfg_attr(not(ruma_unstable_exhaustive_types), non_exhaustive)]
    pub struct Request {
        /// Any data up to maximum size allowed by the server.
        pub content: String,
    }

    #[cfg(feature = "client")]
    impl ruma_common::api::OutgoingRequest for Request {
        type Body = BytesBody;
        type EndpointError = Error;
        type IncomingResponse = Response;

        fn try_into_http_request_inner(
            self,
            base_url: &str,
            considering: std::borrow::Cow<'_, ruma_common::api::SupportedVersions>,
        ) -> Result<http::Request<BytesBody>, ruma_common::api::error::IntoHttpError> {
            use http::header::CONTENT_LENGTH;
            use ruma_common::api::Metadata;

            let Self { content } = self;

            let url = Self::make_endpoint_url(considering, base_url, &[], "")?;
            let content_length = content.len();

            Ok(http::Request::builder()
                .method(Self::METHOD)
                .uri(url)
                .header(CONTENT_TYPE, TEXT_PLAIN)
                .header(CONTENT_LENGTH, content_length)
                .body(BytesBody(content.into()))?)
        }
    }

    #[cfg(feature = "server")]
    impl ruma_common::api::IncomingRequest for Request {
        type EndpointError = Error;
        type OutgoingResponse = Response;

        fn try_from_http_request_inner(
            request: http::Request<&[u8]>,
            _path_args: &[&str],
        ) -> Result<Self, DeserializationError> {
            let content_type = request
                .headers()
                .get(CONTENT_TYPE)
                .ok_or(HeaderDeserializationError::MissingHeader(CONTENT_TYPE.to_string()))?;

            if content_type != TEXT_PLAIN {
                Err(HeaderDeserializationError::InvalidHeaderValue {
                    header: CONTENT_TYPE.to_string(),
                    expected: TEXT_PLAIN
                        .to_str()
                        .expect("expected content type should be a valid static string")
                        .to_owned(),
                    unexpected: content_type.to_str()?.to_owned(),
                }
                .into())
            } else {
                let body = request.into_body().to_vec();
                let content = String::from_utf8(body)
                    .map_err(|e| DeserializationError::Utf8(e.utf8_error()))?;

                Ok(Self { content })
            }
        }
    }

    impl Request {
        /// Creates a new `Request` with the given content.
        pub fn new(content: String) -> Self {
            Self { content }
        }
    }

    /// Response type for the `POST` `rendezvous` endpoint from the 2024 version of MSC4108.
    #[derive(Debug, Clone)]
    #[cfg_attr(not(ruma_unstable_exhaustive_types), non_exhaustive)]
    pub struct Response {
        /// The absolute URL of the rendezvous session.
        pub url: Url,

        /// ETag for the current payload at the rendezvous session as
        /// per [RFC7232](https://httpwg.org/specs/rfc7232.html#header.etag).
        pub etag: String,

        /// The expiry time of the rendezvous as per
        /// [RFC7234](https://httpwg.org/specs/rfc7234.html#header.expires).
        pub expires: SystemTime,

        /// The last modified date of the payload as
        /// per [RFC7232](https://httpwg.org/specs/rfc7232.html#header.last-modified)
        pub last_modified: SystemTime,
    }

    #[doc(hidden)]
    #[derive(ruma_common::serde::_FakeDeriveSerde)]
    #[cfg_attr(feature = "server", derive(serde::Serialize, ruma_common::api::OutgoingBodyJson))]
    #[cfg_attr(feature = "client", derive(serde::Deserialize))]
    pub struct ResponseBody {
        url: Url,
    }

    #[cfg(feature = "client")]
    impl ruma_common::api::IncomingResponse for Response {
        type EndpointError = Error;

        fn try_from_http_response_inner(
            response: http::Response<&[u8]>,
        ) -> Result<Self, DeserializationError> {
            let get_date = |header: http::HeaderName| -> Result<SystemTime, DeserializationError> {
                let date = response
                    .headers()
                    .get(&header)
                    .ok_or_else(|| HeaderDeserializationError::MissingHeader(header.to_string()))?;

                let date = ruma_common::http_headers::http_date_to_system_time(date)?;

                Ok(date)
            };

            let etag = response
                .headers()
                .get(ETAG)
                .ok_or(HeaderDeserializationError::MissingHeader(ETAG.to_string()))?
                .to_str()?
                .to_owned();
            let expires = get_date(EXPIRES)?;
            let last_modified = get_date(LAST_MODIFIED)?;

            let ResponseBody { url } = serde_json::from_slice(response.body())?;

            Ok(Self { url, etag, expires, last_modified })
        }
    }

    #[cfg(feature = "server")]
    impl ruma_common::api::OutgoingResponse for Response {
        type Body = ResponseBody;

        fn try_into_http_response_inner(
            self,
        ) -> Result<http::Response<Self::Body>, ruma_common::api::error::IntoHttpError> {
            use http::header::{CACHE_CONTROL, PRAGMA};
            use ruma_common::http_headers::system_time_to_http_date;

            let Self { url, etag, expires, last_modified } = self;

            let body = ResponseBody { url };

            let expires = system_time_to_http_date(&expires)?;
            let last_modified = system_time_to_http_date(&last_modified)?;

            Ok(http::Response::builder()
                .status(http::StatusCode::OK)
                .header(PRAGMA, "no-cache")
                .header(CACHE_CONTROL, "no-store")
                .header(ETAG, etag)
                .header(EXPIRES, expires)
                .header(LAST_MODIFIED, last_modified)
                .body(body)?)
        }
    }
}

#[cfg(feature = "unstable-msc4388")]
pub mod unstable_msc4388 {
    //! `unstable/io.element.msc4388` ([MSC])
    //!
    //! [MSC]: https://github.com/matrix-org/matrix-spec-proposals/pull/4388
    use std::time::Duration;

    use ruma_common::{
        api::{auth_scheme::AccessTokenOptional, request, response},
        metadata,
    };

    metadata! {
        method: POST,
        rate_limited: true,
        authentication: AccessTokenOptional,
        history: {
            unstable => "/_matrix/client/unstable/io.element.msc4388/rendezvous",
        }
    }

    /// Request type for the `POST` `rendezvous` endpoint.
    #[request]
    pub struct Request {
        /// Data up to maximum size allowed by the server.
        pub data: String,
    }

    impl Request {
        /// Creates a new `Request` with the given content.
        pub fn new(data: String) -> Self {
            Self { data }
        }
    }

    /// Response type for the `POST` `rendezvous` endpoint.
    #[response]
    pub struct Response {
        /// The ID of the created rendezvous session.
        pub id: String,

        /// The initial sequence token for the session.
        pub sequence_token: String,

        /// The time remaining in milliseconds until the session expires.
        #[serde(with = "ruma_common::serde::duration::ms", rename = "expires_in_ms")]
        pub expires_in: Duration,
    }

    impl Response {
        /// Creates a new `Response` with the given content.
        pub fn new(id: String, sequence_token: String, expires_in: Duration) -> Self {
            Self { id, sequence_token, expires_in }
        }
    }
}
