# Changelog

## Unreleased

Bug fixes:

- In the `session::login::v3` module, the `identity_server` field is no longer
  serialized when it is `Option::None`.
- `Capabilities::get` and `Capabilities::set` now handle the `m.profile_fields`
  capability (and its unstable MSC4133 name) instead of using the custom
  capabilities map.

Improvements:

- Updated support for unstable MSC4388 with new `txn_id` field on update requests.
- Add unstable support for [MSC4540] "`m.admin` capability".
- Delay fields in `send_delayed_event` requests are now `delay_ms` instead of `delay`.
- Add unstable support for the `rtc::livekit::get_token` and
  `rtc::livekit::delegate_delayed_leave` endpoints from [MSC4195], behind the
  `unstable-msc4195` feature.
- Add unstable support for [MSC4560] "Stripped state requests over federation".

[MSC4560]: https://github.com/matrix-org/matrix-spec-proposals/pull/4560
[MSC4540]: https://github.com/matrix-org/matrix-spec-proposals/pull/4540
[MSC4195]: https://github.com/matrix-org/matrix-spec-proposals/pull/4195

## 0.25.0

Breaking changes:

- `UiaaInfo`s field `auth_error` from `Option<StandardErrorBody>` to `Option<Box<StandardErrorBody>>`
  (this saves a couple bytes when the field is not set, and gets rid of a default-warn clippy
  lint that was showing up in ruma-client and matrix-sdk)

Bug fixes:

- In the `sync_events::v3` module, fix the serialization of `Response` when only the `knock`
  field was non-empty.
- In the `room::create_room::v3` module, fix the serialization of `CreationContent` when only
  the `additional_creators` field was non-empty.
- In the `threads::get_threads::v1` module, fix the deserialization of `Request`
  when `include` parameter is omitted

Improvements:

- `profile::get_profile` is now using `ruma_common::profile::UserProfile` for its underlying data
  storage.
- Add support for MSC4262 (Profile Updates Sliding Sync Extension).
- Added new `unstable-compat-lax-syncv5-deser` feature, which allows the `name` and `avatar` fields
  for rooms and hero users to be ignored during deserialization if they have an invalid format.
- Route the MSC4133 extended profile field endpoints (`set_profile_field`, `get_profile_field`,
  `delete_profile_field`) to the stable `/v3/profile/{user}/{field}` path when a homeserver
  advertises the `uk.tcpip.msc4133.stable` unstable feature, even if it has not yet advertised
  Matrix v1.16 in its `/versions` response.
- Add unstable support for [MSC4354](https://github.com/matrix-org/matrix-spec-proposals/pull/4354) Sticky Events behind
  the `unstable-msc4354` feature flag. Adds a `sticky_duration_ms` query parameter to `send_message_event`
  and `send_state_event` as well as sync v3 support. Add sync extension v5 behind the `unstable-msc4480`
  feature flag as per [MSC4480](https://github.com/matrix-org/matrix-spec-proposals/pull/4480).
- Allow combining MSC4354 sticky events with
  [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) delayed events.
  `send_delayed_event::unstable::Request` gains a `sticky_duration_ms` field.
  Requires both `unstable-msc4140` and `unstable-msc4354`.
- The `Profiles` sliding sync extension request no longer contains an `include_history` field as
  this was removed from the MSC.
- The `Profiles` sliding sync extension response data is wrapped in a `users` field instead of
  being decoded directly. The profile updates now use a `UserProfileUpdate` enum to signal if the
  profile changed or should be dropped.
- Stabilize support for [MSC2666](https://github.com/matrix-org/matrix-spec-proposals/pull/2666) (Get rooms in common with another user).
- Add support for [MSC1763] (Configurable per-room message retention periods).
- Add unstable support for [MSC4484] "Server Administration OAuth Scope".
- Update the unstable implementation of MSC2666 to match the unstable implementation in Synapse:
  - The endpoint module was renamed to `get_mutual_rooms`.
  - The `batch_token` field of the `Request` was renamed to `from`.
  - The `next_batch_token` field of the `Response` was renamed to `next_batch`.
  - The `with_token` methods of both `Request` and `Response` were renamed to `with_batch_token`,
    to make it clearer which token we are talking about.

[MSC1763]: https://github.com/matrix-org/matrix-spec-proposals/pull/1763
[MSC4484]: https://github.com/matrix-org/matrix-spec-proposals/pull/4484

## 0.24.0

Breaking changes:

- Upgrade ruma-common and ruma-events

Improvements:

- Unify `RtcFocusInfo` and `RtcTransport`, and align the field, method
  and variant names with the "transport" terminology of MSC4195. The
  LiveKit tag changes from `livekit_multi_sfu` to `livekit` on
  `/rtc/transports`.
- Add unstable support for MSC4466 "Altering profile change propagation".
- Add unstable support for [MSC4383] (Client-Server Discovery of Server
  Version) behind the `unstable-msc4383` Cargo feature. The new `server`
  field on `discovery::get_supported_versions::Response` carries the
  homeserver implementation name and version, mirroring the federation
  `/version` payload.
- Update unstable support for [MSC4140] "Cancellable delayed events".

[MSC4383]: https://github.com/matrix-org/matrix-spec-proposals/pull/4383
[MSC4140]: https://github.com/matrix-org/matrix-spec-proposals/pull/4140

## 0.23.1

Bug fixes:

- Fix the deserialization of `RtcFocusInfo` when used with `#[serde(flatten)]`.

## 0.23.0

Breaking changes:

- The `power_level_content_override` field of `create_room::v3::Request` use a
  new `RoomPowerLevelsContentOverride` type. It has the same fields as
  `RoomPowerLevelsEventContent` except all `Int` fields are `Option<Int>`, which
  allows uploading explicit values no matter what the default ones are.
- The `server` module was renamed to `admin`, to make it easier to find since it
  contains all the administration endpoints, and it matches the namespace in the
  spec.
- `BackupAlgorithm::MegolmBackupV1Curve25519AesSha2` is now a tuple variant
  containing a non-exhaustive struct.
- The `groups` field of `ResultRoomEvents` is now a
  `ResultGroupMapsByGroupingKey`. This is a wrapper around a map that ensure
  that each `ResultGroupMap` uses the appropriate key type for their
  `GroupingKey`. As a result, the `OwnedRoomIdOrUserId` enum was removed.
- `InvitationRecipient::UserId` is now a tuple variant containing a
  non-exhaustive struct, and the `reason` field of `invite_user::v3::Request`
  was moved to `InviteUserId`, because it is not available for third-party IDs.
- `StateEventFormat` can represent any custom string value now, but it doesn't
  implement `Copy` anymore.
- Remove support for the OAuth 2.0 `WWW-AUTHENTICATE` header data in
  `ErrorKind::Forbidden`, because it was dropped from MSC2967 and it is not part
  of any new MSC. `ErrorKind::Forbidden` is now a unit variant, and the
  `ErrorKind::forbidden()` method to construct it was removed.
  `AuthenticateError` was removed.
- The following `ErrorKind` struct variants are now tuple structs containing a
  non-exhaustive struct:
  - `BadStatus`, and its serialization was fixed.
  - `IncompatibleRoomVersion`
  - `LimitExceeded`
  - `ResourceLimitExceeded`
  - `UnknownToken`
  - `WrongRoomKeysVersion`, and its `current_version` field is now required and
    its serialization was fixed.
- Remove the `score` field from `report_content::v3::Request` according to
  MSC4277 / Matrix 1.18. `report_content::v3::Request::new()` now only takes a
  room ID and an event ID.
- `Typing::Yes` now holds a non-exhaustive struct rather than a `Duration`, to
  potentially allow to add more fields in the future without it being a breaking
  change.
- The endpoints that were using the `NoAuthentication` authentication scheme now
  use `NoAccessToken`.
- `UserIdentifier` can now represent an identifier with a custom type, and its
  variants were changed to tuple variants containing a non-exhaustive struct.
  - `UserIdentifier::UserIdOrLocalpart` was renamed to `UserIdentifier::Matrix`.
- The `ProfileFieldName` and `ProfileFieldValue` enums were moved to
  `ruma_common::profile`.
- The `http_headers` module was merged into the `http_headers` module of
  `ruma-common`.
- The `error` module was merged into the `api::error` module of `ruma-common`,
  with the `Error` and `ErrorBody` types merged in the corresponding types of
  `ruma-common`.

Bug fixes:

- In the `search::search_events::v3` module, fix the deserialization of:
  - `Criteria` when the `filter` field is omitted.
  - `SearchResult` when the `context` field is omitted.
- Add a `new()` method to `account::delete_3pid::v3::Response`, allowing it to be constructed.

Improvements:

- Add the `M_TOKEN_INCORRECT` error code according to MSC4183 / Matrix 1.18.
- Add the `m.forget_forced_upon_leave` capability, according to MSC4267 / Matrix
  1.18.
- Stabilize support for the OAuth 2.0 account management URL, according to
  MSC4191 / Matrix 1.18. The `AccountManagementAction` variants that were
  replaced when the MSC was stabilized now have an `Unstable` prefix.
  - `AuthorizationServerMetadata` has helper methods to work with both stable
    and unstable account management actions:
    `is_account_management_action_supported()` allows to check whether either of
    the stable or unstable version of an action is advertised by the server, and
    `account_management_url_with_action` allows to build an account management
    URL including the proper version of the action, depending on what the server
    advertises.
- Add support for updated rendezvous session from MSC4388 behind `unstable-msc4388`.
- Stabilize support for the `M_INVITE_BLOCKED` error code, according to MSC4380
  / Matrix 1.18.
- Stabilize support for OAuth 2.0 aware clients, according to MSC3824 / Matrix
  1.18. Unstable support was dropped entirely.
- `BackupAlgorithm` can be deserialized from unsupported algorithms. The name
  and data of the algorithm can be accessed via the `algorithm()` and
  `auth_data()` methods respectively.
- `RegistrationKind` and `LoginType` can now represent custom values.
- Stabilize support for the OAuth 2.0 Device Authorization Grant, according to
  MSC4341 / Matrix 1.18.
- Add support for the Policy Server public key information endpoint, according
  to MSC4284 / Matrix 1.18.
- Add `M_USER_LIMIT_EXCEEDED` error code according to MSC4335 / Matrix 1.18.
- Add support for the user suspension and locking endpoints, according to
  MSC4323 / Matrix 1.18.
- Add support for reading PGP keys from `.well-known/matrix/support`, according
  to MSC4439.
- Add support for MSC4293 `redact_events` field to `ban_user::v3::Request` and
  `kick_user::v3::Request`, gated behind `unstable-msc4293`.

## 0.22.1

Improvements:

- Add `uiaa::LoginTermsParams`, that allows to construct or extract the
  parameters of the `m.login.terms` authentication type.
- Add `UiaaInfo::params()` as a helper to extract UIAA authentication type
  parameters.
- Add support for the `m.oauth` UIAA authentication type according to MSC4312 /
  Matrix 1.17.
- Add unstable support for RTC transports discovery endpoint from MSC4143, with
  support for the LiveKit transport from MSC4195.
- Add `Error(Code/Kind)::AppserviceLoginUnsupported` according to MSC4910 /
  Matrix 1.17.

## 0.22.0

Breaking changes:

- Upgrade `js_option` to v0.2.0
- The following endpoints use a `SinglePath` rather than a `VersionHistory` as
  `Metadata::PathBuilder`. Making a request doesn't require to provide a dummy
  `SupportedVersions` anymore.
  - `discover_homeserver`
  - `discover_support`
  - `get_supported_versions`
  - `login_fallback`
- Make the `ErrorBody::Standard` variant a newtype around `StandardErrorBody`.
- `StandardErrorBody` is non-exhaustive. Allowing to add fields in the future
  without it being a breaking change.
- The `room_id` field of `listen_to_new_events::v3::Request` is required due to
  a clarification in the specification. The struct doesn't implement `Default`
  anymore.

Fixes:

- Set the `Authorization` header with the provided access token in
  `set_profile_field::v3::Request::try_into_http_request()`.

Improvements:

- Add `M_INVITE_BLOCKED` candidate error code proposed by
  [MSC4380](https://github.com/matrix-org/matrix-spec-proposals/pull/4380)
  sharing an unstable prefix with the preceding
  [MSC4155](https://github.com/matrix-org/matrix-spec-proposals/pull/4155).
- Stabilize support for the `use_state_after` query parameter and `State::After`
  response property to `sync_events::v3`, according to Matrix 1.16.
- Stabilize support for extended profiles according to Matrix 1.16.
  - `SetDisplayNameCapability` and `SetAvatarCapability` are deprecated in
    favour of `ProfileFieldsCapability`.
  - The `get_display_name` and `get_avatar_url` endpoints are deprecated in
    favour of `get_profile_field`.
  - The `set_display_name` and `set_avatar_url` endpoints are deprecated in
    favour of `set_profile_field`.
- Add supports for the `m.tz` profile field according to Matrix 1.16.

## 0.21.0

Breaking changes:

- Use `AuthType` for the `auth_type` of `get_uiaa_fallback_page`'s Request.
- Only allow appservices to call `appservice::request_ping::v1` and
  `appservice::set_room_visibility::v1`
- The `params` field of `UiaaInfo` is now optional. It was never required in the
  specification. Servers are encouraged to keep sending it for compatibility with
  clients that required it.
- The `reason` field of `report_room::v3::Request` is now required, due to a
  clarification in the spec.
- Remove `Capabilities::iter()` and the associated types. The code is completely
  custom and hasn't been kept up-to-date, and as far as we know it is not used
  by anyone, so we prefer to remove it to avoid an unnecessary maintenance
  burden and potential issues in the future.
- Move `Capabilities` and associated types into the
  `discovery::get_capabilities::v3` module, for consistency with other endpoints.
- `get_supported_versions::Response::known_versions()` was removed.
  `as_supported_versions()` should be used instead.
- Update the endpoint metadata definitions to use the new syntax for variables.
- `SpaceHierarchyRoomsChunk` is now built around `RoomSummary`, and
  `SpaceHierarchyRoomsChunkInit` was removed.
- Add `JsonCastable` bound to `Raw::{cast, cast_ref, deserialize_as}`. When
  a type `U` implements `JsonCastable<T>` it means that it is safe to cast from
  `U` to `T` because `T` can be deserialized from the same JSON as `U`. It is
  still possible to bypass that bound by using the corresponding methods of
  `Raw` with an `_unchecked` suffix.
- Rename `state::get_state_events_for_key` to `state::get_state_event_for_key`.
- Allow specifying the event format for `state::get_state_event_for_key`, meaning the response may
  either be `Raw<AnyStateEvent>` or `Raw<AnyStateEventContent>`, depending on the format specified
  in the request.
- `sync_events::v3::State` is now an enum, to prepare for the stabilization of MSC4222. The state
  before the timeline, corresponding to the `state` field in the Matrix specification, is available
  in the `Before` variant, and the struct representing its content was renamed to `StateEvents`.
- `get_profile::v3::Response` has no public fields anymore but stores custom
  fields. The fields can be accessed with `.get()`, `.iter()` or `.into_iter()`.
  `Response::new()` takes no arguments and creates an empty response. Fields can
  be added using `.set()`, or the `FromIterator` and `Extend` implementations.
- Replace `MembershipEventFilter` with `MembershipState` in `get_member_events`, since both enums
  should always be identical.
- Add `set_presence` field to `sync_events::v5::Request` as per MSC4186; specified identically
  to the field appearing in prior sync versions.

Improvements:

- Added support for the sliding sync extension for thread subscriptions, as well as the
  accompanying endpoint, both from experimental MSC4308.
- Added support for the experiment MSC4306 thread subscription endpoints.
- For the `membership::join_room_by_id_or_alias` and `knock::knock_room`
  endpoints, the `server_name` query parameter is only serialized if the server
  doesn't advertise at least one version that supports the `via` query
  parameter. The former was removed in Matrix 1.14.
- Add `additional_creators` field to `CreationContent` of `create_room` and `Request` of
  `upgrade_room`, allowing clients to specify which other users (if any) should be considered
  additional creators from room version 12 onwards.
- Add unstable support for the `use_state_after` query parameter in `sync_events::v3::Request`, and
  the corresponding `State::After` variant in the response (`state_after` in the spec), according to
  MSC4222.
- Add unstable support for extended profiles, as per MSC4133.

## 0.20.4

Improvements:

- All the types used in `discover_homeserver::Response` now implement PartialEq
  and Eq.
- Use `ruma_common::RoomSummary` for the `room::get_summary` endpoint.
- Add the `encryption`, `room_version` and `allowed_room_ids` fields to
  `SpaceHierarchyRoomsChunk`, according to MSC3266 / Matrix 1.15.
- Stabilize the support for the room summary endpoint, according to Matrix 1.15.
- Stabilize support for the OAuth 2.0 authorization server metadata endpoint,
  according to Matrix 1.15.
  - The `discovery::get_authentication_issuer` endpoint was removed.
  - Some fields of `AuthorizationServerMetadata` are now behind the
    `unstable-msc4108` or `unstable-msc4191` cargo features.
- Add `get_supported_versions::Response::as_supported_versions()`.

## 0.20.3

Bug fixes:

- Fix `Capabilities::get()` and `Capabilities::set()`. They were not up-to-date
  to handle the `m.get_login_token` capability.

Improvements:

- Remove the unstable support for MSC3575 as it was closed. MSC4186 should be
  used instead.
- The `authentication` field of `discovery::discover_homeserver::Response` has
  been removed in favour of `discovery::get_authorization_server_metadata`.
- The `discovery::discover_homeserver::Response` well-known now includes the
  `rtc_foci` as defined in MSC4143.
- Use specialized room ID type (`ExtensionRoomConfig`) for all MSC4186
  extension requests, not just the Receipts extension.

## 0.20.2

Improvements:

- Add support for the authorization server metadata endpoint, according to the
  latest draft of MSC2965.
- Add the `guest_access_token` field to `account::register::v3::Request` to
  allow a guest user to upgrade to a regular account.
- Add the endpoints for peeking: `get_current_state` and `listen_to_new_events`.
- Add the `reporting::report_user` endpoint to report users, according to Matrix
  1.14.

## 0.20.1

Bug fixes:

- `unstable-msc4186` without `unstable-msc3575` no longer create a compilation
  failure.

Improvements:

- Add support for new dehydration format, according to the latest draft of
  MSC3814.
- Add unstable support for OIDC-aware compatibility, according to MSC3824.
- Stabilize support for reporting rooms, according to Matrix 1.13.
  - Removes the `unstable-msc4151` cargo feature.

## 0.20.0

Breaking changes:

- `ErrorKind` does not implement `AsRef<str>` and `Display` anymore. To get the
  same result, use `ErrorKind::errcode()`. The `ErrorCode` that is returned
  implements those traits.

Bug fixes:

- `knock_state` in `KnockedRoom` and `events` in `KnockState` are no longer
  required during deserialization and are no longer serialized if they are empty.
  This was a deviation from the spec, those fields were never required.

Improvements:

- Add unstable support for reporting rooms, according to MSC4151.
- The `unstable-exhaustive-types` cargo feature was replaced by the
  `ruma_unstable_exhaustive_types` compile-time `cfg` setting. Like all `cfg`
  settings, it can be enabled at compile-time with the `RUSTFLAGS` environment
  variable, or inside `.cargo/config.toml`. It can also be enabled by setting
  the `RUMA_UNSTABLE_EXHAUSTIVE_TYPES` environment variable.
- Add `ErrorKind::ThreepidMediumNotSupported`, according to MSC4178.
- Add `ErrorKind::UserSuspended`, according to MSC3823.
- `EmailPusherData` allows to set custom data for the pusher in the `data` field, due
  to a clarification in the spec.

## 0.19.0

Breaking changes:

- `RoomSummary::heroes` now properly contains only `UserId` instead of `String`
  as before.
- Change type of `client_secret` field in `ThirdpartyIdCredentials`
  from `Box<ClientSecret>` to `OwnedClientSecret`
- Make `id_server` and `id_access_token` in `ThirdpartyIdCredentials` optional
- The `content_disposition` fields of `media::get_content::v3::Response` and
  `media::get_content_as_filename::v3::Response` use now the strongly typed
  `ContentDisposition` instead of strings.
- Replace `server_name` on `knock::knock_room::v3::Request` and
  `membership::join_room_by_id_or_alias::v3::Request` with `via` as per MSC4156
  / Matrix 1.12.
- Remove `RuleScope`, due to a clarification in the Matrix 1.12 where the `global`
  scope is now hardcoded.
  - The `push` endpoints don't take a scope anymore.
- Make `Content-Type` and `Content-Disposition` mandatory when creating media
  responses, according to MSC2701 / MSC2702 / Matrix 1.12.
- Use `OwnedOneTimeKeyId` and `OneTimeKeyAlgorithm` instead of
  `OwnedDeviceKeyId` and `DeviceKeyAlgorithm` respectively to identify one-time
  and fallback keys and their algorithm.
- Use `OwnedCrossSigningOrDeviceSigningKeyId` instead of `OwnedDeviceKeyId` to
  identify signing keys in `BackupAlgorithm::MegolmBackupV1Curve25519AesSha2`'s
  `signatures`.
- Use `CrossSigningOrDeviceSignatures` for the `signatures` of `BackupAlgorithm`.
- Use `ServerSignatures` for the `signatures` of `ThirdPartySigned`.

Improvements:

- Add support for MSC4186, aka simplified sliding sync, behind
  `unstable-msc4186`.
- Add support for MSC4108 OIDC sign in and E2EE set up via QR code
- Heroes in `sync::sync_events::v4`: `SyncRequestList` and `RoomSubscription`
  both have a new `include_heroes` field. `SlidingSyncRoom` has a new `heroes`
  field, with a new type `SlidingSyncRoomHero`.
- Add support for authenticated media endpoints, according to MSC3916 / Matrix
  1.11.
  - They replace the newly deprecated `media::get_*` endpoints.
- Stabilize support for animated thumbnails, according to Matrix 1.11
- Add support for terms of service at registration, according to MSC1692 /
  Matrix 1.11
- Add unstable support for [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140)
  to send `Future` events and update `Future` events with `future_tokens`.
  (`Future` events are scheduled messages that can be controlled
  with `future_tokens` to send on demand or restart the timeout)
- Change types of `SyncRequestListFilters::{room_types,not_room_types}` to
  `Vec<RoomTypeFilter>` instead of a vector of strings
  - This is a breaking change, but only for users of `unstable-msc3575`
- Add the `get_login_token` field to `Capabilities`, according to a
  clarification in Matrix 1.12.
- Add support for account locking, according to MSC3939 / Matrix 1.12.
- Allow constructing `error::ErrorBody::NotJson` outside of this crate.
- Add function for checking if a `Content-Type` is considered "safe" for `inline`
  rendering, according to MSC2702 / Matrix 1.12.

Bug fixes:

- Rename `avatar` to `avatar_url` when (De)serializing `SlidingSyncRoomHero`
- `user_id` of `SlidingSyncRoomHero` is now mandatory
- Make authentication with access token optional for the `change_password` and
  `deactivate` endpoints, due to a clarification in Matrix 1.11.
- Do not send a request body for the `logout` and `logout_all` endpoints, due
  to a clarification in Matrix 1.11.

## 0.18.0

Bug fixes:

- Don't require the `failures` field in the
  `ruma_client_api::keys::upload_signatures::Response` type.
- `sync::sync_events::v3::Timeline::is_empty` now returns `false` when the
  `limited` or `prev_batch` fields are set.
- `login_fallback::Response` now returns the proper content type
- `sso_login[_with_provider]` responses now use the proper HTTP status code.

Breaking changes:

- The conversion from `PushRule` to `ConditionalPushRule` is infallible since
  the `conditions` field is optional.
  - `MissingConditionsError` was removed.
- The `ts` field in `Request` for `get_media_preview` is now `Option`.
- The query parameter of `check_registration_token_validity` endpoint
  has been renamed from `registration_token` to `token`
- `Error` is now non-exhaustive.
- `ErrorKind::Forbidden` is now a non-exhaustive struct variant that can be
  constructed with `ErrorKind::forbidden()`.
- The `retry_after_ms` field of `ErrorKind::LimitExceeded` was renamed to
  `retry_after` and is now an `Option<RetryAfter>`, to add support for the
  Retry-After header, according to MSC4041 / Matrix 1.10
- Make `get_uiaa_fallback::v3::Response` an enum for a redirect or an HTML page.
  It will now return the proper status code and headers depending on the variant
  used.
- The http crate had a major version bump to version 1.1

Improvements:

- Point links to the Matrix 1.10 specification
- Add the `get_authentication_issuer` endpoint from MSC2965 behind the
  `unstable-msc2965` feature.
- Add `error_kind` accessor method to `ruma_client_api::Error`
- Add `FromHttpResponseErrorExt` trait that adds an `error_kind` accessor to
  `FromHttpResponseError<ruma_client_api::Error>`
- Add deprecated `user` fields for `m.login.password` and `m.login.appservice`
  login types.
- Add deprecated `address` and `medium` 3PID fields for `m.login.password`
  login type.
- Add optional cookie field to `session::sso_login*::v3` responses.
- Add support for local user erasure to `account::deactivate::v3::Request`,
  according to MSC4025 / Matrix 1.10.
- Allow `discovery::get_supported_versions::v1` to optionally accept
  authentication, according to MSC4026 / Matrix 1.10.
- Allow `account::register::v3` and `account::login::v3` to accept
  authentication for appservices.
- Add support for recursion on the `get_relating_events` endpoints, according to
  MSC3981 / Matrix 1.10
- Add server support discovery endpoint, according to MSC1929 / Matrix 1.10
- Add `dir` `Request` field on the `get_relating_events_with_rel_types` and
  `get_relating_events_with_rel_type_and_event_type` endpoints
- Add unstable support for moderator server support discovery, according to MSC4121
- Add unstable support for the room summary endpoint from MSC3266 behind the
  `unstable-msc3266` feature.
- Add unstable support for animated thumbnails, according to MSC2705

## 0.17.4

Improvements:

- Change the `avatar` field of `SlidingSyncRoom` from `Option` to `JsOption`
  - This is a breaking change, but only for users enabling the
    `unstable-msc3575` feature

## 0.17.3

Bug fixes:

- Fix deserialization of `claim_keys` responses without a `failures` field

## 0.17.2

Improvements:

- Add unstable support for MSC3983

## 0.17.1

Improvements:

- Add a ErrorKind variant for the "M_WRONG_ROOM_KEYS_VERSION" Matrix error.

## 0.17.0

Breaking changes:

- Define `rank` as an `Option<f64>` instead of an `Option<UInt>` in
  `search::search_events::v3::SearchResult`
- Remove the `token` field from `keys::get_keys::Request`, according to a spec clarification.
- `SpaceRoomJoinRule` has been moved to the `space` module of the ruma-common crate
- `backup::SessionData(Init)` were renamed to `EncryptedSessionData(Init)`

Improvements:

- Add convenience constructors for enabling lazy-loading in filters
- Add support for using an existing session to log in another (MSC3882 / Matrix 1.7)
- Add support for media download redirects (MSC3860 / Matrix 1.7)
- Stabilize support for asynchronous media uploads (MSC2246 / Matrix 1.7)
- Add support for the appservice ping mechanism (MSC 2659 / Matrix 1.7)

## 0.16.2

Bug fixes:

- Don't serialize `None` as `null` in `report_content::v3::Request`

## 0.16.1

Improvements:

- Stabilize support for getting an event by timestamp (MSC3030 / Matrix 1.6)

## 0.16.0

Breaking changes:

- Remove `sync::sync_events::v3::DeviceLists` re-export
  - Use `sync::sync_events::DeviceLists` instead
- `fully_read` field in `read_marker::set_read_marker` is no longer required
  - Remove the `fully_read` argument from `read_marker::set_read_marker::Request::new`
- Move `message::get_message_events::v3::Direction` to `ruma-common::api`
- Make `push::set_pusher::v3::Request` use an enum to differentiate when deleting a pusher
  - Move `push::get_pushers::v3::Pusher` to `push` and make it use the new `PusherIds` type
  - Remove `push::set_pusher::v3::Pusher` and use the common type instead
- Make `push::PusherKind` contain the pusher's `data`
- Use an enum for the `scope` of the `push` endpoints
- Use `NewPushRule` to construct a `push::set_pushrule::v3::Request`
- `Error` is now an enum because endpoint error construction is infallible (see changelog for
  `ruma-common`); the previous fields are in the `Standard` variant
- Use `GlobalAccountDataEventType` for `event_type` in `config::get_global_account_data`
- Use `RoomAccountDataEventType` for `event_type` in `config::get_room_account_data`
- Use `ToDeviceEventType` for `event_type` in `to_device::send_event_to_device`

Improvements:

- Add `M_BAD_ALIAS` to `error::ErrorKind`
- Remove the `unstable-msc3440` feature
  - The fields added to `RoomEventFilter` were removed by MSC3856
- Add support for the threads list API (MSC3856 / Matrix 1.4)
- Stabilize support for private read receipts
- Add support for the pagination direction parameter to `/relations` (MSC3715 / Matrix 1.4)
- Add support for notifications for threads (MSC3773 / Matrix 1.4)
- Send CORP headers by default for media responses (MSC3828 / Matrix 1.4)
- Add support for read receipts for threads (MSC3771 / Matrix 1.4)
- Add unstable support to get an event by timestamp (MSC3030)
- Add unstable support for discovering a sliding sync proxy (MSC3575)

## 0.15.3

Bug fixes:

- Don't include sensitive information in `Debug`-format of types from the `login` module

## 0.15.2

Yanked since it the minimum version for the `ruma-common` dependency was wrong.

## 0.15.1

Improvements:

- `DeviceLists` has moved from `sync::sync_events::v3` to `sync::sync_events`
  - It is still available under the old location for backwards compatibility

## 0.15.0

Breaking changes:

- Export nothing from the crate if neither the `client` nor the `server` feature is active
  - This may partially be reverted in subsequent releases
- `UnreadNotificationsCount` has moved from `sync::sync_events::v3` to `sync::sync_events`
- Remove `PartialEq` implementations for a number of types
  - If the lack of such an `impl` causes problems, please open a GitHub issue
- Split `uiaa::UserIdentifier::ThirdParty` into two separate variants
- Remove the `from` parameter from `message::get_message_events::v3::Request`'s constructors
  - This affects `new`, `backward` and `forward`
  - Since `backward` and `forward` are equivalent to `from_end` and `from_start`, those are removed
  - A new method `.from()` was added to easily set this field after initial construction
- `receipt::create_receipt` uses its own `ReceiptType`
- Reorder parameters in `{set_global_account_data, set_room_account_data}::Request::{new, new_raw}`

Improvements:

- Add support for refresh tokens (MSC2918)
- Add `ErrorKind::{UnableToAuthorizeJoin, UnableToGrantJoin}` encountered for restricted rooms
- Add support for timestamp massaging (MSC3316)
- Add support for querying relating events (MSC2675)
- Move `filter::RelationType` to `ruma_events::relations`
- Add unstable support for discovering an OpenID Connect server (MSC2965)
- Add `SpaceRoomJoinRule::KnockRestricted` (MSC3787)
- Add unstable support for private read receipts (MSC2285)
- Add unstable support for API scope restriction (MSC2967)

## 0.14.1

Improvements:

- Add `From<&UserId>` and `From<&OwnedUserId>` implementations for `UserIdentifier`
- Add `UserIdentifier::email` constructor

## 0.14.0

Bug fixes:

- Fix HTTP method of `backup::update_backup`
- Make score and reason optional in room::report_content::Request
- Fix `uiaa::*::thirdparty_id_creds` according to a clarification in the spec

Breaking changes:

- Use `Raw` for `config::set_*_account_data::Request::data`.
- Rename the endpoints in `backup`:
  - `add_backup_key_session` => `add_backup_keys_for_session`
  - `add_backup_key_sessions` => `add_backup_keys_for_room`
  - `create_backup` => `create_backup_version`
  - `delete_backup` => `delete_backup_version`
  - `delete_backup_key_session` => `delete_backup_keys_for_session`
  - `delete_backup_key_sessions` => `delete_backup_keys_for_room`
  - `get_backup` => `get_backup_info`
  - `get_backup_key_session` => `get_backup_keys_for_session`
  - `get_backup_key_sessions` => `get_backup_keys_for_room`
  - `get_latest_backup` => `get_latest_backup_info`
  - `update_backup` => `update_backup_version`
- Rename `discover` to `discovery`
- Move `capabilities::get_capabilities` into `discovery`
- Make `from` optional in `message::get_message_events` according to a clarification in the spec

Improvements:

- Add support for the space summary API in `space::get_hierarchy` according to MSC2946.
- Add `device_id` to `account::whoami::Response` according to MSC2033
- Add `is_guest` to `account::whoami::Response` according to MSC3069
- Add `session::login::LoginInfo::ApplicationService` according to MSC2778
- Add new fields in `discovery::get_capabilities::Capabilities` according to MSC3283
- Implement Space Summary API according to MSC2946
- Add unstable support for threads in `filter::RoomEventFilter` according to MSC3440

## 0.13.0

Bug fixes:

- Fix deserialization of `r0::session::get_login_types::CustomLoginType`.
- Make fields of `r0::session::get_login_types::IdentityProvider` public.

Breaking changes:

- Use an enum for user-interactive auth stage type (used to be `&str` / `String`)
- Make `r0::uiaa::ThirdpartyIdCredentials` an owned type and remove its `Incoming` equivalent
  - Previously, we had two fields of type `&'a [ThirdpartyIdCredentials<'a>]` and this kind of
    nested borrowing can be very annoying
- `LoginInfo` no longer implements `PartialEq` and `Eq` due to the custom variant that was added.
- `LoginInfo` converted to newtype variants.
- Use `Raw` for `create_room::Request::creation_content`
- Delete `r0::contact` module
  - `request_contact_verification_token` was an out-of-date duplicate of
    `r0::account::request_3pid_management_token_via_email`
  - `get_contacts` has been can now be found at `r0::account::get_3pids`
- Move `r0::uiaa::authorize_fallback` to `r0::uiaa::get_uiaa_fallback_page`
- Change type of field `start` of `r0::message::get_message_events::Response` to
  `String` in accordance with the updated specification.
- Rename `uiaa::UserIdentifier::MatrixId` variant to `uiaa::UserIdentifier::UserIdOrLocalpart`

Improvements:

- Add support for reasons in the membership endpoints:

  ```rust
  r0::membership::{
    join_room_by_id,
    join_room_by_id_or_alias,
    invite_user,
    unban_user
  }
  ```

- Add a `.data()` accessor method to `r0::uiaa::{AuthData, IncomingAuthData}`
- Allow to construct the custom `AuthData` variant with `IncomingAuthData::new` and then call
  `IncomingAuthData::to_outgoing` on it.
- Add custom variant to `LoginInfo` which can be constructed with `IncomingLoginInfo::new` and
  then call `IncomingLoginInfo::to_outgoing` on it.
- Move MSC2858 - Multiple SSO Identity Providers out of the `unstable-pre-spec` feature flag, this
  includes:
  - The `r0::session::get_login_types::{IdentityProvider, IdentityProviderBrand}` types
  - The `session::sso_login_with_provider::v3` endpoint
- Move reason support for leaving room out of `unstable-pre-spec`
- Move room type support out of `unstable-pre-spec`
- Move knocking support out of `unstable-pre-spec`
- Move blurhash support to `unstable-msc2448`

## 0.12.3

- Add a `feature = "compat"` workaround for Element failing on `GET /_matrix/client/r0/account/3pid`
  response if the optional `threepids` field is missing

## 0.12.2

Improvements

- Add `auth_type` and `session` accessors to `uiaa::IncomingAuthData`

## 0.12.1

Improvements:

- Add `auth_type` and `session` accessors to `uiaa::AuthData`

## 0.12.0

Breaking changes:

- Change inconsistent types in `rooms` and `not_rooms` fields in
  `RoomEventFilter` structure: both types now use `RoomId`
- Move `r0::{session::login::UserIdentifier => uiaa::UserIdentifier}`
- Add `stages` parameter to `r0::uiaa::AuthFlow::new`
- Upgrade dependencies

Improvements:

- Add more endpoints:

  ```rust
  r0::knock::knock_room
  ```

- Add unstable support for room knocking
- Add unstable support for reasons for leaving rooms

## 0.11.2

Yanked since it depended on a version of ruma-api that had to be yanked too.

## 0.11.1

Yanked, wrong dependency version.

## 0.11.0

Breaking changes:

- Use `Raw<AnyInitialStateEvent>` over just `AnyInitialStateEvent` in the `initial_state` field
  of `r0::room::create_room::Request`
- Remove

  ```rust
  r0::keys::{
      CrossSigningKey, CrossSigningKeySignatures, KeyUsage, OneTimeKey, SignedKey,
      SignedKeySignatures,
  }
  ```

  These are now found in `ruma_common::encryption` (or `ruma::encryption`).
- Remove `r0::to_device::DeviceIdOrAllDevices`, now found in `ruma_common::to_device`
  (or `ruma::to_device`)
- Remove `r0::contact::get_contacts::{ThirdPartyIdentifier, ThirdPartyIdentifierInit}`, now found
  in `ruma_common::thirdparty` (or `ruma::thirdparty`)

## 0.10.2

Bug fixes:

- Remove authentication for get alias endpoint

## 0.10.1

Improvements:

- Add unstable support for room types

## 0.10.0

Bug fixes:

- Fix deserialization of `r0::room::get_room_event::Response`
- More missing fields in `r0::sync::sync_events::Response` can be deserialized
- Fix `get_tags::Response` serialization
- Fix unsetting avatar URL when `compat` feature is enabled

Breaking changes:

- Update `contains_url: Option<bool>` in `r0::filter::RoomEventFilter` to
  `url_filter: Option<UrlFilter>`.
- Borrow strings in outgoing requests and responses.
  - Explicit types may have to be updated from `endpoint::Request` to `endpoint::Request<'_>` on
    clients and `endpoint::IncomingRequest` on servers, the other way around for responses.
  - When sending a request or response, you shouldn't have to clone things as much as before. Tip:
    Use clippy to detect now-unnecessary `.into()` conversions.
- Make most types non-exhaustive
  - This means you no longer can construct many of them using struct literals.
  - Instead, constructors are provided.
  - Tip: To set optional fields that aren't set in the constructor, you may find the `assign` crate
    useful.
- Make `avatar_url` in `r0::profile::set_avatar_url::Request` an `Option`
- Update type of `canonical_alias` in `r0::directory::PublicRoomsChunk` from
  `Option<String>` to `Option<RoomAliasId>`
- Update `r0::room::create_room::CreationContent`
  - Change `federated`s type from `Option<bool>` to `bool`
  - Add `predecessor` field
- Update `r0::push::get_pushrules_all` and `r0::push::get_pushrules_global_scope` to use the
  `Ruleset` type from `ruma_common::push` (also available as `ruma::push`)
- Fix event types in `r0::context::get_context`
- Fix event types in `r0::sync::sync_events`
- Update type of `user_id` in `r0::account::whoami` from `String` to `ruma_identifiers::UserId`
- Update type of `limited` in `r0::sync::sync_events::Timeline` from `Option<bool>` to `bool`
- Use `DeviceId` for `device_id` field of `r0::session::login::Response`
- Use `ruma_identifiers::ServerName` instead of `String` for `server_name` fields in the following
  endpoints:

  ```rust
  r0::{
      account::request_openid_token,
      media::{get_content, get_content_as_filename, get_content_thumbnail},
      membership::join_room_by_id_or_alias,
      session::login,
  }
  ```

- Rename `r0::search::search_events::{RoomEventJsons => ResultRoomEvents}`. The previous name was an
  error introduced in a mass search and replace
- `r0::sync::sync_events::SetPresence` has been moved and renamed. Use `presence::PresenceState`
  from `ruma` or `ruma-common`.
- `r0::push::Action` has been moved. Import it from `ruma` or `ruma-common`.
- Update type of `limit` in `r0::user_directory::search_users` from
  `Option<UInt>` to `UInt`
- Rename `r0::message::{create_message_event => send_message_event}`
- Rename `r0::state::{create_state_event_* => send_state_event_*}`
- Replace `r0::keys::{AlgorithmAndDeviceId, KeyAlgorithm}` with
  `ruma_identifiers::{DeviceKeyId, DeviceKeyAlgorithm}`, respectively
- Use `ruma_identifiers::{ServerName, ServerKeyId}` in `signatures` fields of
  `r0::room::membership::ThirdPartySigned`.
- Move `r0::directory::{Filter, PublicRoomsChunk, RoomNetwork}` to
  the `ruma-common` crate
- Replace `r0::room::create_room::InitialStateEvent` with `ruma_events::InitialStateEvent`
- `error::ErrorKind` no longer implements `Copy`, `FromStr`
- Switch from `AnyEvent` to `AnyRoomEvent` in `r0::search::search_events`
- Move `r0::account::request_openid_token::TokenType` to `ruma-common` crate
- Move `user: UserInfo` in `r0::session::login::Request` to `identifier: UserIdentifier` in
  `r0::session::login::LoginInfo::Password`
  - `r0::session::login::Request::new` takes only `login_info: LoginInfo` as a param
- Change `ruma_events::AnyEvent` to `ruma_events::AnySyncRoomEvent` in
  `push::get_notifications::Notification`
- Use `ruma_identifiers::MxcUri` instead of `String` for `avatar_url` fields in the following
  endpoints:

  ```rust
  r0::{
      directory,
      media::create_content,
      membership::joined_members,
      profile::{get_avatar_url, get_profile, set_avatar_url},
      search::{search_events, search_users}
  }
  ```

- Change `r0::session::get_login_types::LoginType` to a non-exhaustive enum of structs.
- Move `r0::receipt::ReceiptType` to the `ruma-common` crate

Improvements:

- Add method `into_event_content` for `r0::room::create_room::CreationContent`
- Add room visibility endpoints: `r0::directory::{get_room_visibility, set_room_visibility}`.
- Add is_empty helpers for structs in `r0::sync::sync_events`
- Add a constructor for request structs of the following endpoints
  - `r0::room::create_room`
  - `r0::message::get_message_events`
- Add `logout_devices` field to `r0::account::change_password`
- Add `r0::room::aliases` (introduced in r0.6.1)
- Add constructors that use `ruma_identifiers::MxcUri` for `Request` in the following endpoints:

  ```rust
  r0::media::{
      get_content,
      get_content_as_filename,
      get_content_thumbnail
  }
  ```

- Implement MSC2858 - Multiple SSO Identity Providers under the `unstable-pre-spec` feature flag:
  - Add the `r0::session::get_login_types::{IdentityProvider, IdentityProviderBrand}` types
  - Add the `r0::session::sso_login_with_provider` endpoint

## 0.9.0

Bug fixes:

- Fix (de)serialization for `r0::media::get_content_thumbnail::Response`
- Make `r0::device::get_devices::Response::devices` public

Breaking changes:

- The `event_id` in the response for the message and state sending endpoints is now required
  - r0.6.0 doesn't say they are required, but this has been fixed for the next version of the spec
- Updated the type of `r0::sync::sync_events::DeviceLists` fields
- Change `r0::device::Device` fields according to the spec

Improvements:

- `r0::keys::AlgorithmAndDeviceId` now implements `Display`

## 0.8.0

Breaking changes:

- Update all endpoints to r0.6.0
  - Some of the changes from that might not be listed below, but it should be
    easy to figure out what changed from the documentation and compiler errors
    if you are using any of the affected endpoints.
- Add `server_name` parameter to `r0::join::join_room_by_id_or_alias`
- Modify `r0::account::AuthenticationData`:
  - Rename to `AuthData`
  - Change to an enum to facilitate fallback auth acknowledgements
  - Add `auth_parameters` field
  - Move to `r0::uiaa` module
- Add `room_network` parameter to `r0::directory::get_public_rooms_filtered` to
  represent `include_all_networks` and `third_party_instance_id` Matrix fields
- Update `r0::account::register` endpoint:
  - Remove `bind_email` request field (removed in r0.6.0)
  - Remove `inhibit_login` request field, make `access_token` and `device_id` response fields
    optional (added in r0.4.0)
  - Remove deprecated `home_server` response field (removed in r0.4.0)
- Update `r0::contact::get_contacts` endpoint to r0.6.0
- Change `UInt` timestamps to `SystemTime` in:
  - `media::get_media_preview::Request`
  - `push::get_notifications::Notification`
  - `server::get_user_info::ConnectionInfo`
  - `device::Device`
- Change all usages of `HashMap` to `BTreeMap`
- Change the messages type that gets sent out using the `r0::client_exchange::send_event_to_device`
  request.
- Add `M_USER_DEACTIVATED` to `error::ErrorKind`
- Make `display_name` field of `r0::membership::joined_events::RoomMember` optional
- Update `r0::search::search_events` to r0.6.0
- Add `account_data` field to `r0::sync::sync_events`
- Rename `r0::client_exchange` to `r0::to_device`

Improvements:

- Add types for User-Interactive Authentication API: `r0::uiaa::{AuthFlow, UiaaInfo, UiaaResponse}`
- Add missing serde attributes to `get_content_thumbnail` query parameters
- Add missing `state` response field to `r0::message::get_message_events`
- Normalize `serde_json` imports
- Remove dependency on the `url` crate

## 0.7.2

Bug fixes:

- Fix `create_room` requests without an `initial_state` field failing deserialization
- Fix `sync_events` responses without a `device_one_time_keys_count` field failing deserialization

## 0.7.1

Bug fixes:

- Fix deserialization of `sync_events::Request`
- Fix (de)serialization of `sync_events::RoomSummary`

## 0.7.0

Breaking changes:

- Update ruma-api to 0.15.0
- Update ruma-events to 0.18.0
- Fix `r0::session::get_login_types`
- Add `allow_remote` parameter to `r0::media::get_content`
- Add missing parameters for `r0::room::create_room`
- Moved `r0::room::create_room::Invite3pid` to `r0::membership::Invite3pid`
- Replaced `user_id` parameter of `r0::membership::invite_user` with `recipient`
  to allow invitation of users by either Matrix or third party identifiers.
- Remove deprecated endpoint `r0::contact::create_contact` (deprecated in r0.6.0)
- Add lazy-loading options to `r0::filter::RoomEventFilter` (introduced in r0.5.0)
- Change type for `limit` request parameter of `r0::context::get_context` from `u8` to `Option<js_int::UInt>`
- Use `std::time::Duration` for appropriate fields on several endpoints:

  ```text
  r0::{
      account::request_openid_token,
      keys::{claim_keys, get_keys},
      presence::get_presence,
      sync::sync_events,
      typing::create_typing_event,
      voip::get_turn_server_info
  }
  ```

Improvements:

- Add an `Error` type that represents the well-known errors in the client-server API
  - the response deserialization code will try to create an instance of this type from http
    responses that indicate an error
- Add OpenID token request endpoint.
- Add `r0::client_exchange::send_event_to_device` (introduced in r0.3.0)
- Add endpoints to retrieve account_data (introduced in r0.5.0)
- Add media endpoints: `r0::media::{get_media_config, get_media_preview, get_content_as_filename}`
- Add `unstable_features` to `unversioned::get_supported_versions` (introduced in r0.5.0)
- Add request and response parameters for `r0::account::deactivate`
- Add `r0::session::sso_login` (introduced in r0.5.0)
- Add `filter` type for `r0::context::get_context`

## 0.6.0

Breaking changes:

- Update ruma-api to 0.13.0
- Our Minimum Supported Rust Version is now 1.40.0
- Remove presence list endpoints `r0::presence::{get_subscribed_presences,
  update_presence_subscriptions}` (removed in r0.5.0)
- Refactor `r0::send` endpoints and remove module:
  - Move `r0::send::send_message_event` to `r0::message::create_message_event`
  - Move `r0::send::send_state_event_for_empty_key` to `r0::state:create_state_event_for_empty_key`
  - Move `r0::send::send_state_event_for_key` to `r0::state:create_state_event_for_key`
- Refactor `r0::sync` endpoints:
  - Move `r0::sync::get_member_events` to `r0::membership::get_member_events`
  - Move `r0::sync::get_message_events` to `r0::message::get_message_events`
  - Move `r0::sync::get_state_events` to `r0::state::get_state_events`
  - Move `r0::sync::get_state_events_for_empty_key` to `r0::state::get_state_events_for_empty_key`
  - Move `r0::sync::get_state_events_for_key` to `r0::state::get_state_events_for_key`
- Update endpoints for requesting account management tokens via email:
  - Move `r0::account::request_password_change_token` to `r0::account::request_password_change_token_via_email`
  - Move `r0::account::request_register_token` to `r0::account::request_registration_token_via_email`
  - Modify `r0::account::request_registration_token_via_email` not to be rate-limited and require
    authentication
- Merge duplicate enums `r0::contact::get_contact::Medium` and `r0::session::login::Medium` and move
  them to `r0::thirdparty`

Improvements:

- Add `r0::device` endpoints
- Add `r0::room::get_room_event` (introduced in r0.4.0)
- Add `r0::read_marker::set_read_marker` (introduced in r0.4.0)
- Add `r0::capabilities::get_capabilities` (introduced in r0.5.0)
- Add `r0::keys` endpoints (introduced in r0.3.0)
- Add `r0::session::get_login_types` (introduced in r0.4.0)
- Add `r0::account::get_username_availability` (introduced in r0.4.0)
- Add endpoints to request management tokens (introduced upstream in r0.4.0):
  - `r0::account::request_3pid_management_token_via_msisdn`
  - `r0::account::request_password_change_token_via_msisdn`
  - `r0::account::request_registration_token_via_msisdn`
  - `r0::account::request_3pid_management_token_via_email`
- Update `r0::presence_get_presence` from r0.4.0 to r0.6.0
- Add `r0::account::bind_3pid`
- Add `r0::account::delete_3pid`
- Add `r0::account::unbind_3pid`
- Add `r0::push` endpoints
- Add `r0::room::upgrade_room` (introduced upstream in r0.5.0)

## 0.5.0

Breaking changes:

- Our Minimum Supported Rust Version is now 1.39.0
- Update ruma-api from 0.11.0 to 0.12.0
- Move `r0::directory::get_public_rooms::PublicRoomsChunk` to `r0::directory::PublicRoomsChunk`
- Move `r0::room::create_room::Visibility` to `r0::room::Visibility`
- Move `r0::account::register::AuthenticationData` to `r0::account::AuthenticationData`

Improvements:

- Update `r0::directory::get_public_rooms` from r0.3.0 to r0.6.0
- Add `r0::directory::get_public_rooms_filtered` (introduced upstream in r0.3.0)
- Add `filter` optional parameter to `r0::sync::get_message_events` (introduced upstream in r0.3.0)
- Add `r0::appservice::set_room_visibility` (part of application service extensions for the
  client-server API)
- Add `contains_url` to `r0::filter::RoomEventFilter` (introduced upstream in r0.3.0)
- Update `r0::account::change_password` from r0.3.0 to r0.6.0
  - Add optional `auth` field
