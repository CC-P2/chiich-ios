# Changelog

## Unreleased

Breaking changes:

- `OAuthClientScope` now requires that custom values are valid OAuth scopes.
  Consequently, its `From<str>` implementation has been replaced with a `TryFrom<str>`
  implementation, and deserializing it is no longer infallible.
- The `IdDst` derive macro now requires the type to be `#[repr(transparent)]`, because the generated
  code transmutes `&str` into a reference to the type, which is only sound with this representation.

Bug fixes:

- `AnyKeyName` is now `#[repr(transparent)]`. Its `from_borrowed_unchecked` implementation
  transmutes `&str` into `&AnyKeyName`, which was undefined behavior without this attribute.
- Percent-encode `\` in path segments of endpoint URLs. Clients following the WHATWG URL standard
  treat it as `/` in paths, which changed the requested path when an argument contained a
  backslash.

Improvements:

- The `(Owned)DirectUserIdentifier` types were imported from ruma-events. Converting between an
  `OwnedDirectUserIdentifier` and an `OwnedUserId` does not perform an allocation anymore.
- Implement `From<&OwnedId> for OwnedId` and `From<&OwnedId> for String` for owned identifier types
  generated with the `IdDst` derive macro.
- Add the `KeyTooLarge`, `ProfileTooLarge` and `UnknownDevice` variants to `ErrorKind` and
  `ErrorCode`, for the `M_KEY_TOO_LARGE` and `M_PROFILE_TOO_LARGE` error codes of the profile
  endpoints (added in Matrix 1.16) and the `M_UNKNOWN_DEVICE` error code of identity assertion
  (added in Matrix 1.17).
- Add `{id}_ref!` macros for identifier types. They are currently equivalent to the `{id}!` macros,
  however there is a plan to remove identifier DST types, so these other macros' return type will
  change while the new macros are guaranteed to keep returning a static reference. They should allow
  to ease the transition for the expected change by allowing to migrate tests in advance. They are
  behind an unstable cargo feature because they are likely to be removed soon after the DST
  identifier type removal.
- Add unstable support for [MSC4363] "OAuth step up authentication".
- Add unstable support for [MSC4560] "Stripped state requests over federation".

[MSC4560]: https://github.com/matrix-org/matrix-spec-proposals/pull/4560
[MSC4363]: https://github.com/matrix-org/matrix-spec-proposals/pull/4363

## 0.20.0

Breaking changes:

- `OutgoingRequest::try_into_http_request` has been moved to a new `OutgoingRequestExt` trait
  that is automatically implemented for any `T: OutgoingRequest`
  - Implementors of `OutgoingRequest` now instead have to provide the new `type Body`
    and `fn try_into_http_request_inner`
- `OutgoingResponse::try_into_http_response` has been moved to a new `OutgoingResponseExt` trait
  that is automatically implemented for any `T: OutgoingResponse`
  - Implementors of `OutgoingResponse` now instead have to provide the new `type Body`
    and `fn try_into_http_response_inner`
- `IncomingRequest::try_from_http_request` has been moved to a new `IncomingRequestExt` trait
  that is automatically implemented for any `T: IncomingRequest`
  - Implementors of `IncomingRequest` now instead have to provide the
    `fn try_from_http_request_inner`
  - The generics were removed from `try_from_http_request`, the body of the request is a `&[u8]` and
    the path args is a `&[&str]`.
  - `IncomingRequest::check_request_method` was removed, this check is part of
    `IncomingRequestExt::try_from_http_request`.
- `IncomingResponse::try_from_http_response` has been moved to a new `IncomingResponseExt` trait
  that is automatically implemented for any `T: IncomingResponse`.
  - Implementors of `IncomingResponse` now instead have to provide the
    `fn try_from_http_response_inner` which should only perform the deserialization of the
    response type.
  - The generic parameter was removed from `try_from_http_response`, the body of the response is a
    `&[u8]`.
- Remove `Metadata::empty_request_body()`. It is now unused and the types implementing
  `OutgoingBody` should be used instead.

Bug fixes:

- Add `StatusProfileField::new()` and `CallProfileField::new()` constructors for MSC4426

Improvements:

- Add `From` conversions between `MatrixToUri` and `MatrixUri`.
- Extract a common `UserProfile` type out of `ruma_client_api::profile::get_profile`.
- Add `M_CONCURRENT_WRITE` error code, used by [MSC4438].
- Add `canonical_json::RedactingSerializer` to serialize a `CanonicalJsonObject`
  while redacting it on the fly.
- Add `MatrixVersion::V1_19`.
- Add the `zeroize(mut self)` method on identifiers, which will call the
  `zeroize` crate.
- `UserProfileUpdate` has been replaced with `UserProfileChanges` and a new `UserProfileUpdate`
  enum has been introduced to either wrap the changes or signal that the stored profile should be
  dropped.
- `UserProfile::merge` has been renamed to `UserProfile::apply`.
- Add experimental support for [MSC4495] (Selective Presence).
- Add experimental support for [MSC4494] (Membership-based invite blocking).
- Add `required_client_scopes` function to `Metadata` and accompanying `required_client_scopes` syntax
  to `metadata!` macro, to allow request structs to define what OAuth 2.0 scopes they require.
- Add unstable support for [MSC4484] "Server Administration OAuth Scope".
- `ruma_identifiers_storage` supports new values:
  - `ThinArc` uses `triomphe::ThinArc<(), u8>` as internal representation for the owned identifier
    types, and requires the `triomphe` cargo feature.
  - `SmallVec` uses `smallvec::SmallVec<[u8; N]>` as internal representation for the owned identifier
    types, and requires the `smallvec` cargo feature.
- In the `http_headers` module, add:
  - `TEXT_PLAIN` for the `text/plain` media type.
  - `TEXT_HTML_UTF8` for the `text/html; charset=utf-8` media type.

[MSC4438]: https://github.com/matrix-org/matrix-spec-proposals/pull/4438
[MSC4484]: https://github.com/matrix-org/matrix-spec-proposals/pull/4484
[MSC4495]: https://github.com/matrix-org/matrix-spec-proposals/pull/4495
[MSC4494]: https://github.com/matrix-org/matrix-spec-proposals/pull/4494

## 0.19.0

Bug fixes:

- Properly check the room type filter in `ruma_common::directory::Filter`'s `is_empty` function.

Breaking changes:

- `RedactionError` was renamed to `CanonicalJsonFieldError` and its `MissingField` variant was
  renamed to `Missing`.

Improvements:

- The `IdDst` macro generates `Borrow<str>` implementations for the borrowed and
  owned identifier structs.
- Add `CanonicalJsonObjectExt` as a helper trait to extract fields from a `CanonicalJsonObject`.
- Implement `TryFrom` trait and `checked_add` method for working with
  `MilliSecondsSinceUnixEpoch` and rust time types.
- Add support for MSC4426 (User Status Profile Fields).

## 0.18.0

Breaking changes:

- The variants of `CanonicalJsonError` variants changed.
- `to_canonical_value()` has stricter rules, it now returns errors for the
  following cases which were never documented to work in the first place:
  - Serializing bytes.
  - Serializing booleans and integers as keys for an object.
  - Serializing the same key twice in an object.
- The `canonical-json` feature was removed. The `canonical_json` module is no
  longer gated behind a cargo feature.
- The `IdDst` macro doesn't generate methods and trait implementations anymore
  for `Box{id}`, `Arc<id>` and `Rc<{id}>`. Using `Owned{id}` should be
  preferred.
- `EventId::new()` was renamed to `EventId::new_v1()`, since it works only for
  the first format of event IDs.
- The `NoAuthentication` authentication scheme doesn't take a `SendAccessToken`
  as input anymore, because it doesn't make sense to be able to send access
  tokens for APIs that don't use them as a form of authentication. The new
  `NoAccessToken` authentication scheme should be used instead for APIs that
  rely on access tokens as a form of authentication.
- It is no longer possible to construct custom `Action` types directly through
  the hidden `_Custom` variant. They should be constructed with `Action::new()`
  and their data should be accessed with `Action::data()`.
- The `Tweak` type uses stronger enum types for its variants, and the `Custom`
  variant is now hidden and cannot be constructed directly. It should be
  constructed with `Tweak::new()` and its data should be accessed with
  `Tweak::set_tweak()` and `Tweak::value()`.
- The struct variants of `PushCondition` are now tuple variants containing a
  non-exhaustive struct.
- `JsonType` was renamed to `CanonicalJsonType` to reflect that it only
  represents the possible types of a `CanonicalJsonValue`. It can also be
  accessed with `CanonicalJsonValue::json_type()`.
- Refactor and improve the variants of `RedactionError`:
  - `NotOfType` was renamed to `InvalidType` and provides more details about the
    invalid field.
  - `JsonFieldMissingFromObject` was renamed to `MissingField` an provides the
    full path of the missing field.
- `redact_content_in_place()` is now infallible.
- `MatrixError` and `MatrixErrorBody` were renamed to `Error` and `ErrorBody`
  respectively. The `Matrix` prefix is redundant in a crate about the Matrix
  protocol.
- The `error` module from `ruma-client-api` was merged into the `api::error`
  module. `Error` is now non-exhaustive and `ErrorBody` has a new `Standard`
  variant.

Improvements:

- Add `canonical_json::Serializer`, which allows to serialize a type directly to
  a `CanonicalJsonValue`, with stricter rules than
  `serde_json::value::Serializer`. This serializer is also used in
  `to_canonical_value()`.
- Add the `assert_to_canonical_json_eq!` macro that can be used in tests to
  check the canonical JSON serialization of a type against its expected value.
- Add crate-internal `into_raw()` / `from_raw()` helpers for `IdDst` owned IDs
  and use them in `OwnedRoomId` / `OwnedRoomAliasId` <-> `OwnedRoomOrAliasId`
  conversions.
- Use raw ownership transfer for conversions from `OwnedDeviceId` and
  `OwnedBase64PublicKey` to `OwnedBase64PublicKeyOrDeviceId`.
- Identifier types implement `(Try)From<Box<str>>`, `(Try)From<Cow<'a, str>>`
  and `PartialEq<Cow<'a, str>>` and conversions between owned types try not to
  reallocate when possible.
- Add `EventId::new_v2_or_v3()` to construct event IDs formats which are based
  on the event reference hash.
- Add `RoomType::Call` & `RoomTypeFilter::Call` to support MSC3417 behind
  `unstable-msc3417`
- It is now possible to use `Base64::parse` when the inner `B` "bytes" type is
  an array, and the inner bytes can be accessed without consuming the wrapper
  type with `Base64::as_inner()`.
- Add `MatrixVersion::V1_18`.
- `CanonicalJsonValue::json_type()` allows to get the `JsonType` of a value.
- Add `FeatureFlag::Msc4323`, the unstable feature flag for the user suspension
  and locking endpoints, according to MSC4323.
- Add unstable support for MSC4406.
- Add `rule_type()` and `data()` methods to `AllowRule`.
- Implement `PartialEq` and `Eq` on `CrossSigningKey` and `Signatures`.
- Add `Error::is_endpoint_not_implemented()` helper method to check if it
  matches the expected format for endpoints that are not implemented by the
  homeserver.

## 0.17.1

Bug fixes:

- Fix the `Clone` implementation of the `Owned*` types generated with the
  `IdDst` macro. It used to always create a new instance from the borrowed type
  instead of using the `Clone` implementation of the internal type.

Improvements:

- Add `AppserviceUserIdentity::maybe_add_to_uri()` to add an identity
  assertion to an `http::Uri`. This allows to reimplement the behavior of
  `OutgoingRequestAppserviceExt::try_into_http_request_with_identity()` outside
  of Ruma, if using this trait is inconvenient.
- Add `MatrixVersion::V1_17`.
- `JoinRule` holds arbitrary data in its fallback variant, with can be accessed
  with `JoinRule::data()`. It also means that this type won't fail to serialize
  for undocumented variants anymore.

## 0.17.0

Breaking changes:

- Merge the `PartialOrdAsRefStr` derive macro into `OrdAsRefStr`, so both traits
  are always implemented using the same logic.
- Rename the `PartialEqAsRefStr` derive macro to `EqAsRefStr` and make it
  implement both `PartialEq` and `Eq`.
- The `StringEnum` derive macro also implements `Ord`, `PartialOrd`, `Eq` and
  `PartialEq` using the `AsRef<str>` implementation of the enum.
- The predefined push rules for legacy mentions
  `PatternedPushRule::contains_user_name()`,
  `ConditionalPushRule::contains_display_name()` and
  `ConditionalPushRule::roomnotif()` were removed, according to MSC4210.
  Their rule IDs are still available in `PredefinedContentRuleId` and
  `PredefinedOverrideRuleId`, and they are still supported in
  `PatternedPushRule::applies_to()` and `ConditionalPushRule::applies()`, for
  backwards-compatibility for clients.
- Macros no longer support importing the `ruma` and `ruma-events` crate from the
  `matrix-sdk-appservice` crate. This crate was dropped 2 years ago.
- `Metadata` was changed from a `struct` to a `trait`. It is a supertrait of
  `OutgoingRequest` and `IncomingRequest`, and its fields are now associated
  types or constants.
  - The `authentication` field of the `Metadata` struct is now an associated
    type named `Authentication`. The `AuthScheme` enum was changed from an
    `enum` to a `trait`. Its variants are now structs implementing the
    `AuthScheme` trait. The `None` variant was renamed to `NoAuthentication` and
    the `ServerSignatures` variant was moved to ruma-federation-api.
    The `access_token` argument of `OutgoingRequest::try_into_http_request()` is
    renamed to `authentication_input` and is generic over the `Input` associated
    type of the `AuthScheme` trait.
  - The `history` field of the `Metadata` struct is now an associated constant
    named `PATH_BUILDER`. The type of this constant is defined by the
    `PathBuilder` associated type, which must implement the `PathBuilder` trait.
    The `considering` argument of `OutgoingRequest::try_into_http_request()` is
    renamed to `path_builder_input` and is generic over the `Input` associated
    type of the `PathBuilder` trait. The `Input` of `VersionHistory` was changed
    from `&'_ SupportedVersions` to `Cow<'_, SupportedVersions>`.
  - The other fields of the `Metadata` struct are now associated constants with
    the same name converted to uppercase.
  - The `metadata!` macro generates the `Metadata` trait implementation for a
    type named `Request` by default. This type can be changed with an `@for`
    setting.
- The `http_headers` module is now behind the `api` cargo feature.
- `OutgoingRequestAppserviceExt::try_into_http_request_with_user_id()` is
  renamed to `try_into_http_request_with_identity()` and takes an
  `AppserviceUserIdentity` instead of a `UserId`. This allows to specify a
  device ID, according to MSC4326.
- `IntoHttpError::NeedsAuthentication` is a newtype variant renamed to
  `Authentication` that accepts any error type.
- Remove support for the following rules for the `StringEnum`, `AsRefStr` and
  `FromString` derive macros' `rename_all` attribute, because they either can be
  replaced by the `(prefix = "prefix", rule = "rule")` syntax or are unused as
  far as we know:
  - `"PascalCase"`
  - `"SCREAMING-KEBAB-CASE"`
  - `"m.dotted.case"`
  - `"M_MATRIX_ERROR_CASE"`
  - `"m.lowercase"`
  - `"m.snake_case"`
  - `".m.rule.snake_case"`
  - `"m.role.snake_case"`

Bug fixes:

- With the `request` and `response` attribute macros, the `Content-Type` header
  defaults to `application/octet-stream` instead of `application/json` if the
  `raw_body` attribute is set on a field.
- Fix the check to make sure that all paths used to build `VersionHistory`
  contain the same number of variables. It was broken since the syntax was
  changed from `:variable` to `{variable}`.

Improvements:

- Add `org.matrix.msc4380` unstable feature support to `/versions`.
- Add `MatrixVersion::V1_16`
- Remove support for the `org.matrix.hydra.11` room version and the
  corresponding `unstable-hydra` cargo feature. It should only have been used
  for development, and room version 12 should be used instead.
- `Metadata::make_endpoint_url()` is also available as `VersionHistory::make_endpoint_url()`.
- `PushCondition::ContainsDisplayName` is deprecated, according to MSC4210.
- Add `SinglePath` as a `PathBuilder`. It should be used for APIs that don't
  have a `/versions` endpoint and for endpoints that can't be versioned.
- `AuthScheme` data can be extracted from incoming HTTP requests with
  `AuthScheme::extract_authentication()`.
- The `StringEnum`, `AsRefStr` and `FromString` derive macros allow to set a
  custom prefix alongside the rule to rename all the variants, like this:
  `#[ruma_enum(rename_all(prefix = "m.", rule = "snake_case"))]`. The previous
  syntax using `#[ruma_enum(rename_all = "snake_case")]` still works and assumes
  that the prefix is empty.

## 0.16.0

Breaking changes:

- `PushCondition::applies`, `ConditionalPushRule::applies`, `AnyPushRuleRef::applies`,
  `AnyPushRule::applies`, `Ruleset::applies`, `Ruleset::get_actions`, `Ruleset::get_match` all
  became async, to allow for lazy evaluation of push rules.
- `UserId` parsing and deserialization are now compatible with all non-compliant
  user IDs in the wild by default, due to a clarification in the spec.
  - The `compat-user-id` cargo feature was removed.
  - `UserId::validate_historical()` and `UserId::validate_strict()` allow to
    check for spec compliance.
  - The `(owned_)user_id!` macros always validate against the strict grammar in
    the spec, regardless of the compat features that are enabled.
- `(owned_)room_id!` macros disallow the `NUL` byte, due to a clarification in
  the spec.
- `(owned_)room_alias_id!` macros disallow the `NUL` byte for the localpart, due
  to a clarification in the spec.
- `MatrixVersion` does not implement `Display` anymore as it is not correct to
  convert `V1_0` to a string. Instead `MatrixVersion::as_str()` can be used that
  only returns `None` for that same variant.
- `MatrixVersion::(into/from)_parts` are no longer exposed as public methods.
  They were usually used to sort `MatrixVersion`s, now the `PartialOrd` and
  `Ord` implementations can be used instead.
- `Protocol` and `ProtocolInit` are generic on the protocol instance type.
- Add support for endpoints that only allow appservices to call them, renaming
  `AppserviceToken` to `AppserviceTokenOptional`, with the new variant taking
  `AppserviceToken`'s place.
- The `redact*` functions in `canonical_json` take `RedactionRules` instead of
  `RoomVersionId`. This avoids undefined behavior for unknown room versions.
- `OutgoingRequest::try_into_http_request()`,
  `OutgoingRequestAppserviceExt::try_into_http_request_with_user_id()` and
  `Metadata::make_endpoint_url()` take a `SupportedVersions` instead of a
  `&[MatrixVersion]`.
- The `metadata` macro allows to specify stable and unstable feature flags for
  the paths in `history`.
  - `VersionHistory::new()` takes a
    `&'static [(Option<&'static str>, &'static str)]` for the unstable paths and
    a `&'static [(StablePathSelector, &'static str)]` for the stable paths.
  - `VersionHistory::unstable_paths()` returns an
    `impl Iterator<Item = (Option<&'static str>, &'static str)>`.
  - `VersionHistory::stable_paths()` returns an
    `impl Iterator<Item = (StablePathSelector, &'static str)>`.
  - `VersionHistory::stable_endpoint_for()` was renamed to `version_path()`.
  - `VersioningDecision`'s `Stable` variant was renamed to `Version` and
    `Unstable` was renamed to `Feature`.
- The syntax of variables in endpoint paths segments in the `metadata` macro has
  changed: the variable must now be surrounded by `{}` instead of being preceded
  by `:`. For example `/_matrix/client/foo/{bar}`. This matches the OpenAPI
  syntax and the new syntax supported by axum 0.8.
- `JoinRule` and its associated types where imported from `ruma-events` into the
  `room` module.
- `space::SpaceRoomJoinRule` was removed and replaced by `room::JoinRuleSummary`.
- `directory::PublicRoomJoinRule` was moved and renamed to `room::JoinRuleKind`.
  - It can be constructed with `JoinRule::kind()` and `JoinRuleSummary::kind()`.
- Make `PushConditionRoomCtx` and `PushConditionPowerLevelsCtx` non-exhaustive.
- The `versions` field of `SupportedVersions` is now a `BTreeSet<MatrixVersion>`,
  to make sure that the versions are always deduplicated and sorted.
- `NotificationPowerLevels` now takes a `NotificationPowerLevelsKey` for the
  `key`, an enum that accepts any string.
  - The `key` field of `PushCondition::SenderNotificationPermission` uses the
    same type.
- `RoomId::new()` was renamed to `RoomId::new_v1()`, as several formats are now
  supported for this type.
- `StateResolutionVersion::V2` now takes `StateResolutionV2Rules` as a unit field, to specify
  tweaks to be used when resolving state with version 2 of the state resolution algorithm.
  - This field can be accessed with `StateResolutionVersion::v2_rules`, returning `None` if
    `state_res` is not `StateResolutionVersion::V2`.
  - `StateResolutionV2Rules` has the following fields:
    - `begin_iterative_auth_checks_with_empty_state_map`, to determine whether to begin the first
      phase of iterative auth checks with an empty state map.
    - `consider_conflicted_state_subgraph`, to determine whether to include the conflicted state
      subgraph in the full conflicted state.

Bug fix:

- Set the `disposition` of `RoomVersionRules::MSC2870` as unstable.

Improvements:

- Implement the `Zeroize` trait for the `Base64` type.
- `ProtocolInstance` has an `instance_id` field, due to a clarification in the
  spec.
- The `unstable-unspecified` cargo feature was removed.
- Add `AnyKeyName` as a helper type to use `KeyId` APIs without validating the
  key name.
- Add `IdentityServerBase64PublicKey` as a helper type to decode identity server
  public keys encoded using standard or URL-safe base64.
- `RoomVersion` was imported from ruma-state-res and renamed to
  `RoomVersionRules`, along with the following changes:
  - `RoomVersionRules::new()` was removed and replaced by
    `RoomVersionId::rules()`.
  - The `RoomDisposition` enum was renamed to `RoomVersionDisposition`.
  - The `event_format` field was renamed to `event_id_format` and the
    `EventFormat` enum was renamed to `EventIdFormat`.
  - The tweaks in the authorization rules were extracted into the
    `AuthorizationRules` struct, which is available in the `authorization` field
    of `RoomVersionRules`.
  - The `special_case_aliases_auth` field was renamed to
    `special_case_room_aliases`.
  - The `strict_canonicaljson` field was renamed to `strict_canonical_json`.
  - The `extra_redaction_checks` field was renamed to
    `special_case_room_redaction`.
  - The `allow_knocking` field was renamed to `knocking`.
  - The `restricted_join_rules` field was renamed to `restricted_join_rule`.
  - `RedactionRules` was added under the `redaction` field.
  - `SignaturesRules` was added under the `signatures` field.
- `RoomVersionId` has an `MSC2870` variant for the `org.matrix.msc2870` room
  version defined in MSC2870.
- Add `OutgoingRequest::is_supported()` and `VersionHistory::is_supported()` to
  be able to know if a server advertises support for an endpoint.
- Re-export `ID_MAX_BYTES` from `ruma-identifiers-validation`.
- Implement `From<PublicRoomsChunk>` for `RoomSummary`.
- Add `content_field_redacts` field to `RedactionRules`, which is used to determine whether the
  `content` or top-level `redacts` field should be used to determine what event an
  `m.room.redaction` event redacts.
- Add `SpaceChildOrder` which allows to validate the `order` of an
  `m.space.child` event.
- Add support for room version 12 and its unstable version `org.matrix.hydra.11`.
- Add `explicitly_privilege_room_creators` and `additional_room_creators` to `AuthorizationRules`
  to indicate whether room creators are considered to have "infinite" power level and whether
  additional room creators can be specified with the `content.additional_creators` field of an
  `m.room.create` event respectively.
- Add `RoomPowerLevelsRules`, to provide tweaks to how the power level of a user is determined,
  and add it to `PushConditionPowerLevelsCtx` via the `rules` field.
- Add `room_id_format` to `RoomVersionRules`, to identify the format to use for room IDs depending
  on the room version.
- Add `RoomId::new_v2()` for the new format of room IDs. `RoomId::strip_sigil()` allows to access
  the reference hash used in that format.
- Add unstable support for in-app-only notifications as per MSC3768 under a new `unstable-msc3768`
  feature.
- Add `room_create_event_id_as_room_id` to `AuthorizationRules` to indicate whether the reference
  hash of the `m.room.create` event is used to construct the room ID. It has other implications,
  like the `m.room.create` event not having a room ID, and the `m.room.create` event not listed in
  the `auth_events` of a PDU.
- Add `require_room_create_room_id` and `allow_room_create_in_auth_events` to `EventFormatRules` to
  indicate whether the room ID is required for `m.room.create` events and whether the
  event ID of the `m.room.create` is allowed in the `auth_events`, respectively.

## 0.15.4

Bug fix:

- Fix `serde::default_on_error` deserialization helper. It was working with
  `serde_json::from_value` but not other functions like
  `serde_json::from_(str/slice)`. It now works with all 3 methods but is limited
  to deserializing JSON.

## 0.15.3

Improvements:

- Add `RoomSummary` that represents the summary of a room's state.
  - Implement `From<RoomSummary>` for `PublicRoomsChunk`
- Add `MatrixVersion::V1_15`.
- `PublicRoomJoinRule` now includes all possible join rule kinds, due to a
  clarification in Matrix 1.15.
- Add `serde::default_on_error()` as a helper to ignore errors during
  deserialization.
- Implement conversions between `PublicRoomJoinRule` and `SpaceRoomJoinRule`.
- Add `FeatureFlag` as an enum whose variants are the flags of features supported by Ruma.
- Add `SupportedVersions`, a type to parse `/versions` responses to get lists
  of supported versions and features.

## 0.15.2

Bug fixes:

- `MatrixVersion::V1_0` now also matches Identity Service API versions r0.2.0 to
  r0.3.0.
- Allow configure exhaustive types via `RUMA_UNSTABLE_EXHAUSTIVE_TYPES` environment variable

Improvements:

- `MatrixVersion` implements `PartialOrd` and `Ord`. The variants are ordered by
  release date, with a newer version being greater than an older version.
- `Signatures` implements `IntoIterator`
- Implement `PartialEqAsRefStr`, `Eq`, `PartialOrdAsRefStr`, `OrdAsRefStr` for
  `ruma_common::media::Method`.
- `DeviceId::new()` generates a string with 10 chars instead of 8.
- Add `ignore_invalid_vec_items`, to assist deserialization of `Vec`s, where
  invalid items should be ignored.
- Add `MatrixVersion::V1_14`.

## 0.15.1

Improvements:

- Add `MatrixVersion::V1_13`.

## 0.15.0

Breaking changes:

- `#[serde(flatten)]` on the only body field of a `#[request]` or `#[response]`
  struct is disallowed. `#[ruma_api(body)]` must be used instead.

Improvements:

- The `ruma_identifiers_storage` compile-time `cfg` setting can also be
  configured by setting the `RUMA_IDENTIFIERS_STORAGE` environment variable at
  compile time. It has the benefit of not requiring to re-compile all the crates
  of the dependency chain when the value is changed.
- The `unstable-exhaustive-types` cargo feature was replaced by the
  `ruma_unstable_exhaustive_types` compile-time `cfg` setting. Like all `cfg`
  settings, it can be enabled at compile-time with the `RUSTFLAGS` environment
  variable, or inside `.cargo/config.toml`. It can also be enabled by setting
  the `RUMA_UNSTABLE_EXHAUSTIVE_TYPES` environment variable.
- `HttpPusherData` allows to set custom data for the pusher in the `data` field,
  due to a clarification in the spec.
  - The `default_payload` field that was behind the `unstable-unspecified`
    cargo feature was removed. It can be added manually to the custom data.

## 0.14.1

Bug fixes:

- The `KeyId::key_name` method now returns the key name. In 0.14.0, `key_name`
  mistakenly returned the algorithm.

## 0.14.0

Bug fixes:

- The `instance_id` field was removed from `ProtocolInstanceInit` and is now an
  `Option<String>` for `ProtocolInstance`. It made the `unstable-unspecified`
  feature non-additive.

Breaking changes:

- Rename the `query_map` attribute of the `request` macro to `query_all`, and
  remove the required bound to implement `IntoIterator<Item = (String, String)>`.
  This allows to use a struct or enum as well as a map to represent the list of
  query parameters. Note that the (de)serialization of the type used must work
  with `serde_html_form`.
- The `header` attribute for the `request` and `response` macros accepts any
  type that implements `ToString` and `FromStr`.
- The `compat-key-id` cargo feature was renamed to
  `compat-server-signing-key-version`.
- `(Owned)KeyName` was renamed to `(Owned)ServerSigningKeyVersion` and is now
  validated according to the set of allowed characters defined in the docs,
  unless the `compat-server-signing-key-version` cargo feature is enabled.
- The bounds on `KeyId` changed. The algorithm part must implement
  `KeyAlgorithm` and the key name part must implement `KeyName`.
- The `(owned_)server_signing_key_id` macros were removed. For compile-time
  validated construction, use `ServerSigningKeyId::from_parts` with a
  `SigningKeyAlgorithm` and the `server_signing_key_version` macro.
- Rename `Signatures::insert` to `Signatures::insert_signature`.
  `Signatures::insert` is now dereferenced to `BTreeMap::insert`.
- Move the `DeviceKeyAlgorithm::SignedCurve25519` into the new
  `OneTimeKeyAlgorithm` type.
- Add `(Owned)CrossSigningKeyId` and use it instead of `OwnedDeviceKeyId` to
  identify `CrossSigningKey`'s `keys`.
- Add `(Owned)CrossSigningOrDeviceSigningKeyId` and use it instead of
  `OwnedDeviceKeyId` to identify signing keys in `DeviceKeys`'s and
  `CrossSigningKey`'s `signatures`.
- Use `OwnedDeviceSigningKeyId` instead of `OwnedDeviceKeyId` to identify
  signing keys in `SignedKey`'s `signatures`.
- `(Owned)DeviceKeyId` is now a type alias of `(Owned)KeyId`.
  - Remove the `(owned_)device_key_id` macro, instead use
    `DeviceKeyId::from_parts`.
- Use `CrossSigningOrDeviceSignatures` for the `signatures` of `DeviceKeys`.
- Remove `SignedKeySignatures` and replace it with `DeviceSignatures`.
- Remove `CrossSigningKeySignatures` and replace it with
  `CrossSigningOrDeviceSignatures`.

Improvements:

- Add the `InvalidHeaderValue` variant to the `DeserializationError` struct, for
  cases where we receive a HTTP header with an unexpected value.
- Implement `Eq`/`Hash`/`PartialEq` for `ThirdPartyIdentifier`, to check whether
  a `ThirdPartyIdentifier` has already been added by another user.
- Add `MatrixVersion::V1_11` and `MatrixVersion::V1_12`.
- Clarify in the docs of `AuthScheme` that sending an access token via a query
  parameter is deprecated, according to MSC4126 / Matrix 1.11.
- Constructing a Matrix URI for an event with a room alias is deprecated,
  according to MSC4132 / Matrix 1.11
- Implement `Eq` and `PartialEq` for `Metadata`
- Allow constructing `api::error::MatrixErrorBody::NotJson` outside of this
  crate.
- Improve the API of `Signatures`, by implementing `Deref` and `DerefMut`, as
  well as `From`, `Extend` and `FromIterator` from a list of
  `(entity, key_identifier, value)` tuples.
- Add `(Owned)OneTimeKeyId` and `(Owned)OneTimeKeyName` to identify one-time and
  fallback keys instead of using `(Owned)DeviceKeyId`.
- Add `(Owned)Base64PublicKey` and `(Owned)Base64PublicKeyOrDeviceId` to
  identify cross-signing keys.
  - Add `(owned_)base_64_public_key` to construct a compile-time validated
    `(Owned)Base64PublicKey`.

## 0.13.0

Bug fixes:

- Allow to deserialize `Ruleset` with missing fields.

Breaking changes:

- The power levels fields in `PushConditionRoomCtx` are grouped in an optional `power_levels` field.
  If the field is missing, push rules that depend on it will never match. However, this allows to
  match the `.m.rule.invite_for_me` push rule because usually the `invite_state` doesn't include
  `m.room.power_levels`.
- Add support for endpoints that take an optional authentication
- Add support for endpoints that require authentication for appservices
- `deserialize_as_f64_or_string` has been extended to also support parsing integers, and renamed to
  `deserialize_as_number_or_string` to reflect that.
- The http crate had a major version bump to version 1.1
- `IntoHttpError::Header` now contains a `HeaderSerializationError`

Improvements:

- Use the [web-time](https://github.com/daxpedda/web-time) crate to return a
  `SystemTime` that works under WASM in the
  `MilliSecondsSinceUnixEpoch::to_system_time()` method.
- Stabilize support for `.m.rule.suppress_edits` push rule (MSC3958 / Matrix 1.9)
- Add `MatrixVersion::V1_9` and `V1_10`
- Point links to the Matrix 1.10 specification
- Implement `as_str()` and `AsRef<str>` for `push::PredefinedRuleId`
- Implement `kind()` for `push::Predefined{*}RuleId`
- Implement `Clone` for `MatrixToUri` and `MatrixUri`

## 0.12.1

Bug fixes:

- Allow to deserialize `(New)ConditionalPushRule` with a missing `conditions` field.

## 0.12.0

Bug fixes:

- Set the predefined server-default `.m.rule.tombstone` push rule as enabled by default, as defined
  in the spec.

Breaking changes:

- `FlattenedJson::get` returns a `FlattenedJsonValue` instead of a string
- Remove the `DontNotify` and `Coalesce` variants of `push::Action` according to MSC3987
  - Old push rules will still deserialize successfully but the `Coalesce` variant will not return
    `true` for `Action::should_notify()` anymore
- Removed the `events` module, it is once again its own crate (`ruma-events`)
- Removed `From` and `TryFrom` implementations for `RedactedBecause` in favor of named constructors
  (`from_json` and `from_raw_event`)
- Updated room IDs to not require a servername
  - Removed `localpart` method from `RoomId` and `RoomOrAliasId`
  - Changed `server_name` method on `RoomId` and `RoomOrAliasId` to return `Option<&str>`

Improvements:

- Allow padding when decoding the `Base64` type from a string
- Add convenience methods for `push::Ruleset`:
  - To update the server-default push rules
  - To remove a user-defined push rule
- Add `AsRef<[u8]>` implementations for identifier types
- `PushCondition::EventMatch` and `FlattenedJson` now use escaped dotted paths (MSC3873 / Matrix 1.7)
- Add support for `event_property_is` push condition (MSC3758 / Matrix 1.7)
- Add support for `event_property_contains` push condition (MSC3966 / Matrix 1.7)
- Add `MatrixVersion::V1_7` and `MatrixVersion::V1_8`
- Add support for room version 11 according to MSC3820 / Matrix 1.8
  - Adapt the redaction algorithm in `canonical_json`
- Add unstable support for suppress edits push rule (MSC3958)

## 0.11.3

Bug fixes:

- Move `.m.rule.roomnotif` push rule before `.m.rule.tombstone` in the server default push rules,
  according to a spec clarification in Matrix 1.6

Improvements:

- Add `MatrixVersion::V1_6`
- Stabilize support for fixed base64 for SAS verification (MSC3783 / Matrix 1.6)
  - Deprecate `MessageAuthenticationCode::HkdfHmacSha256`

## 0.11.2

Bug fixes:

- Don't accept colons in the localpart given to `UserId::parse_with_servername`
  even with `feature = "compat"`

Improvements:

- Derive `Hash` for `ReceiptType` and `ReceiptThread`
- Update `EventContent` derive macro to emit new type definitions and type
  aliases under the same visibility as the input type (this fixes a future-
  compatibility warning when deriving `EventContent` on a non-`pub` type)

## 0.11.1

Improvements:

- Make alternate Debug representation of `MilliSecondsSinceUnixEpoch` and
  `SecondsSinceUnixEpoch` more compact (remove newlines)

## 0.11.0

Bug fixes:

- HTML-relevant characters (`<`, `>`, etc) in plaintext replies are now escaped
  during creation of the rich reply
- Don't include sensitive information in `Debug`-format of types from the `events::key`
  and `events::secret` modules
- Fix deserialization of `RoomMessageEventContent` and `RoomEncryptedEventContent` when there
  is no relation
- Fix deserialization of `StateUnsigned` when the `prev_content` is redacted
- Allow to deserialize `PushCondition` with unknown kind
- Allow to deserialize `push::Action` with unknown value
- Only percent-encode reserved characters in endpoint URL path

Breaking changes:

- Remove deprecated `EventType` enum
- Remove deprecated constructors for `RoomMessageEventContent`
- Remove `serde::vec_as_map_of_empty` from the public API
- Remove the `api::AuthScheme::QueryOnlyAccessToken` variant, which is no longer used
- The `#[ruma_api(header)]` attribute of the `ruma_api` macro now accepts an arbitrary
  `http::header::HeaderName`
  - To continue using constants from `http::header`, they must be imported in
    the module calling the macro.
- Make `name` optional on `SecretStorageKeyEventContent`. Default constructor has been
  adjusted as well to not require this field.
- Rename `push::PusherData` to `HttpPusherData` and make the `url` field required
- Remove `Ruleset::add` and the implementation of `Extend<AnyPushRule>` for `Ruleset`
- Make `EndpointError` construction infallible
  - `EndpointError::try_from_http_request` has been replaced by `EndpointError::from_http_request`
  - `FromHttpResponseError<E>::Server` now contains `E` instead of `ServerError<E>`
  - `ServerError<E>` has been removed
  - `MatrixError` is now an enum with the `Json` variant containing the previous fields
- Change the `ignored_users` field of `IgnoredUserListEventContent` to a map of empty structs, to
  allow eventual fields to be added, as intended by the spec
- Make `SimplePushRule` and associated types generic over the expected type of the `rule_id`
- Deduplicate and group relation structs in `events::relation`:
  - Move relation structs under `events::room::message` to `events::relation`
  - Move common relation structs under `events::room::encrypted` to `events::relation` and remove
    duplicate types
  - Remove `events::reaction::Relation` and use `events::relation::Annotation` instead
  - Remove `events::key::verification::Relation` and use `events::relation::Reference` instead
- Rename `events::relation::Relations` to `BundledRelations`
- Make the `redacted_because` field in `UnsignedRedacted` non-optional and replace parameterless
  `new` constructor by one that takes a redaction event (like `new_because` previously, which is
  now removed)
- Move the `Unsigned` associated type from `StateEventContent` to `OriginalStateEventContent`
  - `Redacted*EventContent`s don't have an `unsigned` type anymore
- Remove the `serde::urlencoded` module
  - Query string (de)serialization is now done by the `serde_html_form` crate
- Rename `RoomEventType` to `TimelineEventType`
- Remove `SecretStorageKeyEventContent`'s implementation of `Deserialize`
  - Use `EventContentFromType::from_parts` instead
- Remove `StateUnsignedFromParts`
  - Replace it with a bound on `DeserializeOwned`
- Remove `Raw::deserialize_content`
  - Instead, use `.deserialize_as::<T>()` or `.cast_ref::<T>().deserialize_with_type()`
- Remove `EventContent::from_parts`
  - Replace it with `EventContentFromType::from_parts`
- The `serde::StringEnum` derive now also generates a `Debug` implementation

Improvements:

- Add `MatrixVersion::V1_4` and `MatrixVersion::V1_5`
- Stabilize default room server ACL push rule
- Stabilize `room_types` in `directory::Filter` and `room_type` in `directory::PublicRoomsChunk`
- Stabilize support for private read receipts
- Add stable support for threads
  - Move `Relation::Thread` and associated types and methods out of `unstable-msc3440`
  - Add parameter to `RoomMessageEventContent::make_reply_to` to be thread-aware
  - Add `RoomMessageEventContent::make_for_reply`
- Stabilize support for event replacements (edits)
- Add support for read receipts for threads (MSC3771 / Matrix 1.4)
- Add `push::PredefinedRuleId` and associated types as a list of predefined push rule IDs
- Add convenience methods to `Ruleset`
  - `Ruleset::get` to access a push rule
  - `Ruleset::insert` to add or update user push rules
  - `Ruleset::set_enabled` to change the enabled state of push rules
  - `Ruleset::set_actions` to change the actions of push rules
- Add support for bundled reference relations (MSC3267 / Matrix 1.5)
- Add the `formatted` field on `KeyVerificationRequestEventContent` (Matrix 1.5)
- Add `content` accessors for `Any*StateEvent` enums
- Add the `DebugAsRefStr` derive macro to `ruma_common::serde`

## 0.10.5

Improvements:

- Add support for `#[incoming_derive(!Debug)]` to the `Incoming` derive macro

## 0.10.4

Bug fixes:

- Fix `MatrixToUri` parsing for non-url-encoded room aliases

## 0.10.3

Bug fixes:

- Fix ruma-common not compiling with the Cargo features `events` and
  `unstable-msc2677` active, and `unstable-msc2676` inactive

## 0.10.2

Improvements:

- Add `relations` accessors to event enum types:
  - `AnyMessageLikeEvent` and `AnySyncMessageLikeEvent`
  - `AnyStateEvent` and `AnySyncStateEvent`
  - `AnyTimelineEvent` and `AnySyncTimelineEvent`

## 0.10.1

Improvements:

- Add `RoomMessageEventContent::make_reply_to`
  - Deprecate reply constructors in favor of the new method

## 0.10.0

Bug fixes:

- Expose `MatrixIdError`, `MatrixToError`, `MatrixUriError` and `MxcUriError` at
  the crate root
- Fix matching of `event_match` condition
  - The spec clarified its behavior:
    <https://github.com/matrix-org/matrix-spec-proposals/pull/3690>

Breaking changes:

- Add `user_id` field to `PushConditionRoomCtx`
- Remove `PartialEq` implementation on `NotificationPowerLevels`
- Remove `PartialEq` implementation for `events::call::SessionDescription`
- Use new `events::call::AnswerSessionDescription` for `CallAnswerEventContent`
  and `OfferSessionDescription` for `CallInviteEventContent`
- Use new `VoipVersionId` and `VoipId` types for `events::call` events
- Remove `RoomName` / `OwnedRoomName` and replace usages with `str` / `String`
  - Room name size limits were never enforced by servers
    ([Spec change removing the size limit][spec])
- Remove `RoomMessageFeedbackEvent` and associated types and variants according to MSC3582
- Move `CanonicalJson`, `CanonicalJsonObject` and `CanonicalJsonError` out of
  the `serde` module and behind the cargo feature flag `canonical-json`
- Make identifiers matrix URI constructors generic over owned parameters
  - Split `RoomId` matrix URI constructors between methods with and without routing
- Allow to add routing servers to `RoomId::matrix_to_event_uri()`
- Move `receipt::ReceiptType` to `events::receipt`
- Make `Clone` as supertrait of `api::OutgoingRequest`
- Rename `Any[Sync]RoomEvent` to `Any[Sync]TimelineEvent`
- `RoomMemberEvent` and related types now have a custom unsigned type including the
  `invite_room_state` field, instead of the `StateUnsigned` type used by other state
  events

[spec]: https://github.com/matrix-org/matrix-spec-proposals/pull/3669

Improvements:

- All push rules are now considered to not apply to events sent by the user themselves
- Change `events::relation::BundledAnnotation` to a struct instead of an enum
  - Remove `BundledReaction`
- Add unstable support for polls (MSC3381)
- Add unstable support for Improved Signalling for 1:1 VoIP (MSC2746)
- Add support for knocking in `events::room::member::MembershipChange`
- Add `MatrixVersion::V1_3`
- Deprecate the `sender_key` and `device_id` fields for encrypted events (MSC3700)
- Move the `relations` field of `events::unsigned` types out of `unstable-msc2675`
- Deserialize stringified integers for power levels without the `compat` feature
- Add `JoinRule::KnockRestricted` (MSC3787)
- Add `MatrixVersionId::V10` (MSC3604)
- Add methods to sanitize messages according to the spec behind the `html` feature
  - Can also remove rich reply fallbacks
- Implement `From<Owned*Id>` for `identifiers::matrix_uri::MatrixId`
- Add unstable default push rule to ignore room server ACLs events (MSC3786)
- Add unstable support for private read receipts (MSC2285)
- Add unstable support for filtering public rooms by room type (MSC3827)

## 0.9.2

Bug fixes:

- Fix serialization and deserialization of events with a dynamic `event_type`

## 0.9.1

Improvements:

- Add `StrippedPowerLevelsEvent::power_levels`
- Add (`Sync`)`RoomMemberEvent::membership`
- Export `events::room::member::Change`
  - Prior to this, you couldn't actually do anything with the
    `membership_change` functions on various member event types

## 0.9.0

Bug fixes:

- Change default `invite` power level to `0`
  - The spec was determined to be wrong about the default:
    <https://github.com/matrix-org/matrix-spec/pull/1021>

Breaking changes:

- Several ruma crates have been merged into `ruma-common`
  - `ruma-api` has moved into `api`, behind a feature flag
  - `ruma-events` has moved into `events`, behind a feature flag
  - `ruma-identifiers` types are available at the root of the crate
  - `ruma-serde` has moved into `serde`
- The `events::*MessageEvent` types have been renamed to `*MessageLikeEvent`
- Change `events::room` media types to accept either a plain file or an
  encrypted file, not both simultaneously
- Change `events::room` media types to use `Duration` where applicable
- Move `prev_content` into `unsigned`
- Rename `identifiers::Error` to `IdParseError`
- Fix the `RoomMessageEventContent::*_reply_plain` methods that now return a
  message with a `formatted_body`, according to the spec. Therefore, they only
  accept `OriginalRoomMessageEvent`s like their HTML counterparts.
- Update the `state_key` field of state events to be of a different type
  depending on the content type. You now no longer need to validate manually
  that `m.room.member` events have a user ID as their state key!

Improvements:

- Add unstable support for extensible events (MSCs 1767, 3551, 3552, 3553, 3246, 3488)
- Add unstable support for translatable text content (MSC3554)
- Add unstable support for voice messages (MSC3245)
- Add unstable support for threads (MSC3440)
- Add `ReceiptEventContent::user_receipt`
- Make `Restricted::allow` public
- Conversion from `RoomPowerLevels` to `RoomPowerLevelsEventContent`

## 0.8.0

Breaking changes:

- Update `ruma-identifiers` dependency

## 0.7.0

Breaking changes:

- Update `ruma-identifiers` dependency
- Use new `Base64` type for `key` field of `SignedKey`

## 0.6.0

Breaking changes:

- Make a few enums non-exhaustive
- Upgrade dependencies

## 0.5.4

Improvements:

- Add `to_device` module containing `DeviceIdOrAllDevices`

## 0.5.3

Improvements:

- Add `instance_id` field to `ProtocolInstance[Init]` under the
  `unstable-pre-spec` feature

## 0.5.2

Improvements:

- Add `thirdparty::ThirdPartyIdentifier`

## 0.5.1

Improvements:

- Add `receipt::ReceiptType`
- Add `MilliSecondsSinceUnixEpoch` and `SecondsSinceUnixEpoch` types
- Bump dependency versions

## 0.5.0

Breaking changes:

- Rename `push::RulesetIter` to `push::RulesetIntoIter`
- Change the return type of `push::Ruleset::get_actions` from an iterator to a
  slice

Improvements:

- Add `push::Ruleset::iter()` for borrowing iteration of rulesets
- Add conversions between `AnyPushRule` and `AnyPushRuleRef`
  (`AnyPushRule::as_ref` and `AnyPushRuleRef::to_owned`)
- Add `push::Ruleset::get_match()` for finding the first matching push rule for
  an event. This is pretty much the same thing as `get_actions()` but returns
  the entire push rule, not just its actions.

## 0.4.0

Breaking changes:

- Use `ruma_identifiers::MxcUri` instead of `String` for `avatar_url` field in
  `directory::PublicRoomsChunk`
- Use `ruma_identifiers::RoomId` instead of `String` for `room_id` field in
  `push::PushConditionRoomCtx`
- Upgrade ruma-identifiers dependency to 0.19.0

## 0.3.1

Bug fixes:

- Fix `push::PushCondition::applies` for empty value and pattern

## 0.3.0

Breaking changes:

- Update set of conversion trait implementations for enums
- Replace `Vec` by `IndexSet` in `push::Ruleset`
- Replace `push::AnyPushRule` with an enum (the original struct still exists as
  just `PushRule` in `ruma-client-api`)
- … (there's a lot more, but this changelog was not kept up to date; PRs to
  improve it are welcome)

Improvements:

- Add the `thirdparty` module
- Add `directory::{Filter, PublicRoomsChunk, RoomNetwork}` (moved from
  `ruma_client_api::r0::directory`)
- Add `push::{PusherData, PushFormat}` (moved from `ruma_client_api::r0::push`)
- Add `authentication::TokenType` (moved from
  `ruma_client_api::r0::account:request_openid_token`)
- Add an `IntoIterator` implementation for `Ruleset`
- Add `push::Ruleset::get_actions`
  - Add `push::PushCondition::applies`
  - Add `push::{FlattenedJson, PushConditionRoomCtx}`

## 0.2.0

Breaking changes:

- Make most types defined by the crate `#[non_exhaustive]`
