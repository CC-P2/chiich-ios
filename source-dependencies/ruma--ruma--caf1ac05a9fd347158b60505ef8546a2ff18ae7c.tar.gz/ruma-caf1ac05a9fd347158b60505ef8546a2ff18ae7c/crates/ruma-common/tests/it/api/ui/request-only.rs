#![allow(unexpected_cfgs)]

use ruma_common::{
    api::{
        EmptyBody, IncomingResponse, OutgoingResponse,
        auth_scheme::NoAuthentication,
        error::{DeserializationError, Error, IntoHttpError},
        request,
    },
    metadata,
};

metadata! {
    method: POST, // An `http::Method` constant. No imports required.
    rate_limited: false,
    authentication: NoAuthentication,
    history: {
        unstable => "/_matrix/some/endpoint/{foo}",
    }
}

#[request]
#[derive(PartialEq)] // Make sure attributes work
pub struct Request {
    // With no attribute on the field, it will be put into the body of the request.
    #[ruma_api(path)]
    pub foo: String,
}

pub struct Response;

impl IncomingResponse for Response {
    type EndpointError = Error;

    fn try_from_http_response_inner(
        _: http::Response<&[u8]>,
    ) -> Result<Self, DeserializationError> {
        todo!()
    }
}

impl OutgoingResponse for Response {
    type Body = EmptyBody<false>;

    fn try_into_http_response_inner(self) -> Result<http::Response<Self::Body>, IntoHttpError> {
        todo!()
    }
}

fn main() {
    let req1 = Request { foo: "foo".into() };
    let req2 = req1.clone();

    assert_eq!(req1, req2);
}
