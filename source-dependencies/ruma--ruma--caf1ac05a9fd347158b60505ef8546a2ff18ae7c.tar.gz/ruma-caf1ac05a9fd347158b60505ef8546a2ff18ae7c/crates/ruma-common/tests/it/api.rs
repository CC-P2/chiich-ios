#![cfg(feature = "api")]
#![allow(unreachable_pub)]

mod auth_scheme;
mod conversions;
mod default_status;
mod header_override;
mod manual_endpoint_impl;
mod no_fields;
mod optional_headers;
mod required_headers;
mod ruma_api;
mod ruma_api_macros;
mod status_override;
