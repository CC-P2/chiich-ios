#if !os(macOS)
import SwiftUI
import SwiftUIIntrospect
import Testing

@MainActor
struct NavigationViewWithStackStyleTests {
	typealias PlatformNavigationViewWithStackStyle = UINavigationController

	@Test func introspect() async throws {
		try await introspection(of: PlatformNavigationViewWithStackStyle.self) { spy in
			NavigationView {
				ZStack {
					Color.red
					Text("Something")
				}
			}
			.navigationViewStyle(.stack)
			.introspect(
				.navigationView(style: .stack),
				on: .iOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
				.tvOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
				.visionOS(.v1, .v2, .v26, .v27),
				customize: spy,
			)
		}
	}

	@Test func `introspect as ancestor`() async throws {
		try await introspection(of: PlatformNavigationViewWithStackStyle.self) { spy in
			NavigationView {
				ZStack {
					Color.red
					Text("Something")
						.introspect(
							.navigationView(style: .stack),
							on: .iOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
							.tvOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
							.visionOS(.v1, .v2, .v26, .v27),
							scope: .ancestor,
							customize: spy,
						)
				}
			}
			.navigationViewStyle(.stack)
		}
	}
}
#endif
