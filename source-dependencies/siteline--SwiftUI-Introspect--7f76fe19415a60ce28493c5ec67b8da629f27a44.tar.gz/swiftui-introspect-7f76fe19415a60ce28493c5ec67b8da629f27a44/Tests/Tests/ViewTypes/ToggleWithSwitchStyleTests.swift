#if !os(tvOS) && !os(visionOS)
import SwiftUI
import SwiftUIIntrospect
import Testing

@MainActor
struct ToggleWithSwitchStyleTests {
	#if canImport(UIKit)
	typealias PlatformToggleWithSwitchStyle = UISwitch
	#elseif canImport(AppKit)
	typealias PlatformToggleWithSwitchStyle = NSSwitch
	#endif

	@Test func introspect() async throws {
		let (
			entity1,
			entity2,
			entity3,
		) = try await introspection(of: PlatformToggleWithSwitchStyle.self) { spy1, spy2, spy3 in
			VStack {
				Toggle("", isOn: .constant(true))
					.toggleStyle(.switch)
					#if os(iOS)
					.introspect(
						.toggle(style: .switch),
						on: .iOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
						customize: spy1,
					)
					#elseif os(macOS)
					.introspect(
						.toggle(style: .switch),
						on: .macOS(.v10_15, .v11, .v12, .v13, .v14, .v15, .v26, .v27),
						customize: spy1,
					)
					#endif

				Toggle("", isOn: .constant(false))
					.toggleStyle(.switch)
					#if os(iOS)
					.introspect(
						.toggle(style: .switch),
						on: .iOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
						customize: spy2,
					)
					#elseif os(macOS)
					.introspect(
						.toggle(style: .switch),
						on: .macOS(.v10_15, .v11, .v12, .v13, .v14, .v15, .v26, .v27),
						customize: spy2,
					)
					#endif

				Toggle("", isOn: .constant(true))
					.toggleStyle(.switch)
					#if os(iOS)
					.introspect(
						.toggle(style: .switch),
						on: .iOS(.v13, .v14, .v15, .v16, .v17, .v18, .v26, .v27),
						customize: spy3,
					)
					#elseif os(macOS)
					.introspect(
						.toggle(style: .switch),
						on: .macOS(.v10_15, .v11, .v12, .v13, .v14, .v15, .v26, .v27),
						customize: spy3,
					)
					#endif
			}
		}
		#if canImport(UIKit)
		#expect(entity1.isOn == true)
		#expect(entity2.isOn == false)
		#expect(entity3.isOn == true)
		#elseif canImport(AppKit)
		#expect(entity1.state == .on)
		#expect(entity2.state == .off)
		#expect(entity3.state == .on)
		#endif
	}
}
#endif
