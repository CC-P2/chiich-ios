//
// Copyright 2026 Element Creations Ltd.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

// GENERATED FILE, DO NOT EDIT. FOR MORE INFORMATION VISIT
// https://github.com/matrix-org/matrix-analytics-events/

/// Triggered when user changes room list sorting algorithm.
extension AnalyticsEvent {
    public struct RoomListSortingAlgorithmChanged: AnalyticsEventProtocol {
        public let eventName = "RoomListSortingAlgorithmChanged"

        /// The new sorting algorithm.
        public let newAlgorithm: NewAlgorithm
        /// The old sorting algorithm.
        public let oldAlgorithm: OldAlgorithm

        public init(newAlgorithm: NewAlgorithm, oldAlgorithm: OldAlgorithm) {
            self.newAlgorithm = newAlgorithm
            self.oldAlgorithm = oldAlgorithm
        }

        public enum OldAlgorithm: String {
            case Activity = "Activity"
            case Alphabetic = "Alphabetic"
            case Unread = "Unread"
        }

        public enum NewAlgorithm: String {
            case Activity = "Activity"
            case Alphabetic = "Alphabetic"
            case Unread = "Unread"
        }

        public var properties: [String: Any] {
            return [
                "newAlgorithm": newAlgorithm.rawValue,
                "oldAlgorithm": oldAlgorithm.rawValue
            ]
        }
    }
}
