# Changelog

All notable changes to this project will be documented in this file.

<!-- changelog start -->

## [0.19.1](https://github.com/matrix-org/matrix-rust-sdk/tree/0.19.1) - 2026-09-18

No significant changes.

## [0.19.0](https://github.com/matrix-org/matrix-rust-sdk/tree/0.19.0) - 2026-09-16

### Changed

- **breaking** The `StoreCipher::export_with_key` and
  `StoreCipher::import_with_key` now accept a variable sized key. The functions
  derive a 32-byte sub-key to encrypt and decrypt the `StoreCipher`. Importing
  existing exports which didn't use the sub-key mechanism will continue working.
  ([#6929](https://github.com/matrix-org/matrix-rust-sdk/pull/6929))

## [0.18.0](https://github.com/matrix-org/matrix-rust-sdk/tree/0.18.0) - 2026-06-02

No significant changes.

## [0.17.0] - 2026-05-08

### Refactor

- **breaking** The `Random` error variant has been removed. An infallible random
  number generator is used in the crate.
  ([#5502](https://github.com/matrix-org/matrix-rust-sdk/pull/5502))

## [0.16.1] - 2026-05-08

No notable changes in this release.

## [0.16.0] - 2025-12-04

No notable changes in this release.

## [0.14.0] - 2025-09-04

No notable changes in this release.

## [0.13.0] - 2025-07-10

No notable changes in this release.

## [0.12.0] - 2025-06-10

No notable changes in this release.

## [0.11.0] - 2025-04-11

No notable changes in this release.

## [0.10.0] - 2025-02-04

### Bug fixes

- Remove the usage of an unwrap in the `StoreCipher::import_with_key` method.
  This could have lead to panics if the second argument was an invalid
  `StoreCipher` export.
  ([#4506](https://github.com/matrix-org/matrix-rust-sdk/pull/4506))

## [0.9.0] - 2024-12-18

No notable changes in this release.

## [0.8.0] - 2024-11-19

No notable changes in this release.
