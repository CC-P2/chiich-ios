// Copyright 2025 The Matrix.org Foundation C.I.C.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for that specific language governing permissions and
// limitations under the License.

use std::{str::FromStr, sync::Arc};

use futures_util::StreamExt;
use matrix_sdk::encryption::{self, backups, dehydrated_devices, recovery, vodozemac};
use matrix_sdk_base::crypto::{
    store::types::DehydratedDeviceKey,
    types::{BackupSecrets, RoomKeyBackupInfo},
};
use matrix_sdk_common::{SendOutsideWasm, SyncOutsideWasm};
use ruma::OwnedUserId;
use serde::de::Error;
use thiserror::Error;
use tracing::{error, info};
use zeroize::Zeroize;

use crate::{
    client::Client, error::ClientError, ruma::AuthData, runtime::get_runtime_handle,
    task_handle::TaskHandle, timeline::ShieldState,
};

#[derive(uniffi::Object)]
pub struct Encryption {
    pub(crate) inner: matrix_sdk::encryption::Encryption,

    /// A reference to the FFI client.
    ///
    /// Note: we do this to make it so that the FFI `NotificationClient` keeps
    /// the FFI `Client` and thus the SDK `Client` alive. Otherwise, we would
    /// need to repeat the hack done in the FFI `Client::drop` method.
    pub(crate) _client: Arc<Client>,
}

/// The encryption data of an event that was sent encrypted (and which we
/// managed to decrypt).
#[derive(Clone, uniffi::Record)]
pub struct EventEncryptionInfo {
    /// The user id this event is cryptographically attested to come from.
    ///
    /// For a to-device message this is what should be trusted, rather than the
    /// `sender` claimed in the event JSON.
    pub sender_id: String,
    /// The device the event was sent from, as claimed by the sender.
    pub sender_device_id: Option<String>,
    /// The curve25519 key of the device that sent the event.
    pub sender_curve25519_key: Option<String>,
    /// The megolm session the event was sent in, if it was sent with megolm.
    pub session_id: Option<String>,
    /// The shield to show for this event, lax interpretation.
    pub shield_state: ShieldState,
    /// The shield to show for this event, strict interpretation.
    pub shield_state_strict: ShieldState,
}

impl From<&matrix_sdk_base::deserialized_responses::EncryptionInfo> for EventEncryptionInfo {
    fn from(info: &matrix_sdk_base::deserialized_responses::EncryptionInfo) -> Self {
        use matrix_sdk_base::deserialized_responses::AlgorithmInfo;
        use matrix_sdk_ui::timeline::TimelineEventShieldState;

        let sender_curve25519_key = match &info.algorithm_info {
            AlgorithmInfo::MegolmV1AesSha2 { curve25519_key, .. } => Some(curve25519_key.clone()),
            AlgorithmInfo::OlmV1Curve25519AesSha2 { curve25519_public_key_base64 } => {
                Some(curve25519_public_key_base64.clone())
            }
        };

        Self {
            sender_id: info.sender.to_string(),
            sender_device_id: info.sender_device.as_ref().map(ToString::to_string),
            sender_curve25519_key,
            session_id: info.session_id().map(ToOwned::to_owned),
            shield_state: TimelineEventShieldState::from(
                info.verification_state.to_shield_state_lax(),
            )
            .into(),
            shield_state_strict: TimelineEventShieldState::from(
                info.verification_state.to_shield_state_strict(),
            )
            .into(),
        }
    }
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait BackupStateListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_update(&self, status: BackupState);
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait BackupSteadyStateListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_update(&self, status: BackupUploadState);
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait RecoveryStateListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_update(&self, status: RecoveryState);
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait VerificationStateListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_update(&self, status: VerificationState);
}

#[derive(uniffi::Enum)]
pub enum BackupUploadState {
    Waiting,
    Uploading { backed_up_count: u32, total_count: u32 },
    Error,
    Done,
}

#[derive(Debug, Error, uniffi::Error)]
#[uniffi(flat_error)]
pub enum SteadyStateError {
    #[error("The backup got disabled while waiting for the room keys to be uploaded.")]
    BackupDisabled,
    #[error("There was a connection error.")]
    Connection,
    #[error("We couldn't read status updates from the upload task quickly enough.")]
    Lagged,
}

#[derive(Debug, Error, uniffi::Error)]
pub enum RecoveryError {
    /// A backup already exists on the homeserver, the recovery subsystem does
    /// not allow backups to be overwritten, disable recovery first.
    #[error(
        "A backup already exists on the homeserver and the method does not allow to overwrite it"
    )]
    BackupExistsOnServer,

    /// A typical SDK error.
    #[error(transparent)]
    Client { source: crate::ClientError },

    /// Error in the secret storage subsystem, except for when importing a
    /// secret.
    #[error("Error in the secret-storage subsystem: {error_message}")]
    SecretStorage { error_message: String },

    /// Error when importing a secret from secret storage.
    #[error("Error importing a secret: {error_message}")]
    Import { error_message: String },
}

impl From<matrix_sdk::encryption::recovery::RecoveryError> for RecoveryError {
    fn from(value: matrix_sdk::encryption::recovery::RecoveryError) -> Self {
        match value {
            recovery::RecoveryError::BackupExistsOnServer => Self::BackupExistsOnServer,
            recovery::RecoveryError::Sdk(e) => Self::Client { source: ClientError::from(e) },
            recovery::RecoveryError::SecretStorage(
                matrix_sdk::encryption::secret_storage::SecretStorageError::ImportError { .. },
            ) => Self::Import { error_message: value.to_string() },
            recovery::RecoveryError::SecretStorage(e) => {
                Self::SecretStorage { error_message: e.to_string() }
            }
        }
    }
}

pub type Result<A, E = RecoveryError> = std::result::Result<A, E>;

impl From<matrix_sdk::encryption::backups::futures::SteadyStateError> for SteadyStateError {
    fn from(value: matrix_sdk::encryption::backups::futures::SteadyStateError) -> Self {
        match value {
            backups::futures::SteadyStateError::BackupDisabled => Self::BackupDisabled,
            backups::futures::SteadyStateError::Connection => Self::Connection,
            backups::futures::SteadyStateError::Lagged => Self::Lagged,
        }
    }
}

#[derive(uniffi::Enum)]
pub enum BackupState {
    Unknown,
    Creating,
    Enabling,
    Resuming,
    Enabled,
    Downloading,
    Disabling,
}

impl From<backups::BackupState> for BackupState {
    fn from(value: backups::BackupState) -> Self {
        match value {
            backups::BackupState::Unknown => Self::Unknown,
            backups::BackupState::Creating => Self::Creating,
            backups::BackupState::Enabling => Self::Enabling,
            backups::BackupState::Resuming => Self::Resuming,
            backups::BackupState::Enabled => Self::Enabled,
            backups::BackupState::Downloading => Self::Downloading,
            backups::BackupState::Disabling => Self::Disabling,
        }
    }
}

impl From<backups::UploadState> for BackupUploadState {
    fn from(value: backups::UploadState) -> Self {
        match value {
            backups::UploadState::Idle => Self::Waiting,
            backups::UploadState::Uploading(count) => Self::Uploading {
                backed_up_count: count.backed_up.try_into().unwrap_or(u32::MAX),
                total_count: count.total.try_into().unwrap_or(u32::MAX),
            },
            backups::UploadState::Error => Self::Error,
            backups::UploadState::Done => Self::Done,
        }
    }
}

#[derive(uniffi::Enum)]
pub enum RecoveryState {
    Unknown,
    Enabled,
    Disabled,
    Incomplete,
}

impl From<recovery::RecoveryState> for RecoveryState {
    fn from(value: recovery::RecoveryState) -> Self {
        match value {
            recovery::RecoveryState::Unknown => Self::Unknown,
            recovery::RecoveryState::Enabled => Self::Enabled,
            recovery::RecoveryState::Disabled => Self::Disabled,
            recovery::RecoveryState::Incomplete => Self::Incomplete,
        }
    }
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait EnableRecoveryProgressListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_update(&self, status: EnableRecoveryProgress);
}

#[derive(uniffi::Enum)]
pub enum EnableRecoveryProgress {
    Starting,
    CreatingBackup,
    CreatingRecoveryKey,
    BackingUp { backed_up_count: u32, total_count: u32 },
    RoomKeyUploadError,
    Done { recovery_key: String },
}

impl From<recovery::EnableProgress> for EnableRecoveryProgress {
    fn from(value: recovery::EnableProgress) -> Self {
        match &value {
            recovery::EnableProgress::Starting => Self::Starting,
            recovery::EnableProgress::CreatingBackup => Self::CreatingBackup,
            recovery::EnableProgress::CreatingRecoveryKey => Self::CreatingRecoveryKey,
            recovery::EnableProgress::BackingUp(counts) => Self::BackingUp {
                backed_up_count: counts.backed_up.try_into().unwrap_or(u32::MAX),
                total_count: counts.backed_up.try_into().unwrap_or(u32::MAX),
            },
            recovery::EnableProgress::RoomKeyUploadError => Self::RoomKeyUploadError,
            recovery::EnableProgress::Done { recovery_key } => {
                Self::Done { recovery_key: recovery_key.to_owned() }
            }
        }
    }
}

#[derive(uniffi::Enum)]
pub enum VerificationState {
    Unknown,
    Verified,
    Unverified,
}

impl From<encryption::VerificationState> for VerificationState {
    fn from(value: encryption::VerificationState) -> Self {
        match &value {
            encryption::VerificationState::Unknown => Self::Unknown,
            encryption::VerificationState::Verified => Self::Verified,
            encryption::VerificationState::Unverified => Self::Unverified,
        }
    }
}

/// Struct containing the bundle of secrets to fully activate a new device for
/// end-to-end encryption.
#[derive(uniffi::Object)]
pub struct SecretsBundleWithUserId {
    user_id: OwnedUserId,
    inner: matrix_sdk_base::crypto::types::SecretsBundle,
}

/// Result for the check if a store has a valid secrets bundle.
#[derive(uniffi::Enum)]
pub enum DetectedSecretsBundle {
    /// The store doesn't contain a secrets bundle at all.
    None,
    /// The store contains a bundle without a backup.
    WithoutBackup,
    /// The store contains a bundle with an unused backup, the backup key in the
    /// bundle isn't used on the homeserver.
    UnusedBackup,
    /// The store contains a complete secrets bundle.
    Complete,
}

/// Error type describing failures that can happen while exporting a
/// [`SecretsBundle`] from a SQLite store.
#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum BundleExportError {
    /// The SQLite store couldn't be opened.
    #[error("the store couldn't be opened: {msg}")]
    OpenStoreError { msg: String },
    /// Data from the SQLite store couldn't be exported.
    #[error("the bundle couldn't be exported due to a storage error: {msg}")]
    StoreError { msg: String },
    /// The store doesn't contain a secrets bundle or it couldn't be read from
    /// the store.
    #[error("the bundle couldn't be exported: {msg}")]
    SecretError { msg: String },
    /// The store is empty and doesn't contain a secrets bundle.
    #[error("the store is completely empty")]
    StoreEmpty,
    /// A JSON object couldn't be deserialized while the secrets bundle was
    /// exported.
    #[error("Couldn't deserialize a JSON value: {msg}")]
    Json { msg: String },
    /// Error returned when the secrets bundle is missing a backup key or
    /// includes one that doesn’t match the key configured for the active backup
    /// version.
    #[error(
        "The bundle is missing a backup key or has one that isn't the one that's currently used"
    )]
    InvalidBackup,
}

#[cfg(feature = "sqlite")]
impl From<matrix_sdk::encryption::BundleExportError> for BundleExportError {
    fn from(value: matrix_sdk::encryption::BundleExportError) -> Self {
        match value {
            matrix_sdk::encryption::BundleExportError::OpenStoreError(e) => {
                BundleExportError::OpenStoreError { msg: e.to_string() }
            }
            matrix_sdk::encryption::BundleExportError::StoreError(e) => {
                BundleExportError::StoreError { msg: e.to_string() }
            }
            matrix_sdk::encryption::BundleExportError::SecretExport(e) => {
                BundleExportError::SecretError { msg: e.to_string() }
            }
        }
    }
}

impl From<serde_json::Error> for BundleExportError {
    fn from(value: serde_json::Error) -> Self {
        Self::Json { msg: value.to_string() }
    }
}

#[cfg(feature = "sqlite")]
#[matrix_sdk_ffi_macros::export]
impl SecretsBundleWithUserId {
    /// Attempt to export a [`SecretsBundle`] from a crypto store.
    ///
    /// This method can be used to retrieve a [`SecretsBundle`] from an existing
    /// `matrix-sdk`-based client in order to import the [`SecretsBundle`] in
    /// another [`Client`] instance.
    ///
    /// This can be useful for migration purposes or to allow existing client
    /// instances create new ones that will be fully verified.
    #[uniffi::constructor]
    pub async fn from_database(
        database_path: &str,
        mut passphrase: Option<String>,
        backup_info: &str,
    ) -> Result<Arc<Self>, BundleExportError> {
        let backup_info = serde_json::from_str(backup_info)?;

        let ret = if let Some((user_id, bundle)) =
            matrix_sdk::encryption::export_secrets_bundle_from_store(
                database_path,
                passphrase.as_deref(),
            )
            .await?
        {
            let is_backup_ok =
                bundle.backup.as_ref().is_some_and(|backup| is_valid_backup(backup, &backup_info));

            if is_backup_ok {
                Ok(SecretsBundleWithUserId { user_id, inner: bundle }.into())
            } else {
                Err(BundleExportError::InvalidBackup)
            }
        } else {
            Err(BundleExportError::StoreEmpty)
        };

        passphrase.zeroize();

        ret
    }
}

#[matrix_sdk_ffi_macros::export]
impl SecretsBundleWithUserId {
    /// Attempt to create a [`SecretsBundle`] from a previously JSON serialized
    /// bundle.
    #[uniffi::constructor]
    pub fn from_str(
        user_id: &str,
        bundle: &str,
        backup_info: &str,
    ) -> Result<Arc<Self>, BundleExportError> {
        let user_id =
            OwnedUserId::from_str(user_id).map_err(|e| serde_json::Error::custom(e.to_string()))?;
        let bundle: matrix_sdk_base::crypto::types::SecretsBundle = serde_json::from_str(bundle)?;
        let backup_info = serde_json::from_str(backup_info)?;

        let is_backup_ok =
            bundle.backup.as_ref().is_some_and(|backup| is_valid_backup(backup, &backup_info));

        if is_backup_ok {
            Ok(Self { user_id, inner: bundle }.into())
        } else {
            Err(BundleExportError::InvalidBackup)
        }
    }

    /// Does the bundle contain a backup key.
    ///
    /// Since enabling a backup is optional, the backup key might be missing
    /// from the bundle. Returns `false` if the backup key is missing, otherwise
    /// `true`.
    pub fn contains_backup_key(&self) -> bool {
        self.inner.backup.is_some()
    }
}

fn is_valid_backup(secrets: &BackupSecrets, info: &RoomKeyBackupInfo) -> bool {
    match secrets {
        BackupSecrets::MegolmBackupV1Curve25519AesSha2(secrets) => {
            secrets.key.backup_key_matches(info)
        }
    }
}

fn check_bundle_and_info(
    bundle: &matrix_sdk_base::crypto::types::SecretsBundle,
    info: Option<&RoomKeyBackupInfo>,
) -> DetectedSecretsBundle {
    match (&bundle.backup, info) {
        (None, None) => DetectedSecretsBundle::WithoutBackup,
        (None, Some(_)) => DetectedSecretsBundle::WithoutBackup,
        (Some(_), None) => DetectedSecretsBundle::UnusedBackup,
        (Some(backup), Some(info)) => {
            if is_valid_backup(backup, info) {
                DetectedSecretsBundle::Complete
            } else {
                DetectedSecretsBundle::UnusedBackup
            }
        }
    }
}

/// Check if a JSON encoded string contains a valid [`SecretsBundle`].
#[uniffi::export]
pub fn json_string_contains_secrets_bundle(
    bundle: &str,
    backup_info: Option<String>,
) -> Result<DetectedSecretsBundle, ClientError> {
    let info: Option<RoomKeyBackupInfo> =
        backup_info.map(|info| serde_json::from_str(&info)).transpose()?;

    let bundle: matrix_sdk_base::crypto::types::SecretsBundle = serde_json::from_str(bundle)?;

    Ok(check_bundle_and_info(&bundle, info.as_ref()))
}

/// Check if a crypto store contains a valid [`SecretsBundle`].
#[cfg(feature = "sqlite")]
#[matrix_sdk_ffi_macros::export]
pub async fn database_contains_secrets_bundle(
    database_path: &str,
    mut passphrase: Option<String>,
    backup_info: Option<String>,
) -> Result<DetectedSecretsBundle, BundleExportError> {
    let info: Option<RoomKeyBackupInfo> =
        backup_info.map(|info| serde_json::from_str(&info)).transpose()?;

    let maybe_bundle = matrix_sdk::encryption::export_secrets_bundle_from_store(
        database_path,
        passphrase.as_deref(),
    )
    .await?;

    passphrase.zeroize();

    Ok(match maybe_bundle {
        Some((_, bundle)) => check_bundle_and_info(&bundle, info.as_ref()),
        None => DetectedSecretsBundle::None,
    })
}

/// Lifecycle event emitted by the dehydrated-device manager.
///
/// Mirrors [`dehydrated_devices::DehydratedDeviceEvent`]; subscribe via
/// [`Encryption::dehydrated_device_event_listener`].
#[derive(uniffi::Enum)]
pub enum DehydratedDeviceEvent {
    /// A fresh dehydrated device was constructed in the local crypto store,
    /// before the upload PUT.
    Created { device_id: String },
    /// The homeserver accepted the upload of the dehydrated device.
    Uploaded { device_id: String },
    /// The dehydrated device on the homeserver was deleted.
    Deleted,
    /// A pickle key was cached in the local crypto store.
    KeyCached,
    /// Rehydration of a dehydrated device began.
    RehydrationStarted { device_id: String },
    /// A batch of to-device events has been imported during rehydration.
    RehydrationProgress { room_keys_imported: u64, to_device_events: u64 },
    /// Rehydration finished successfully.
    RehydrationCompleted { device_id: String, room_keys_imported: u64, to_device_events: u64 },
    /// Rehydration failed.
    RehydrationError { error: String },
    /// A scheduled rotation tick failed; the rotation task remains scheduled.
    RotationError { error: String },
}

impl From<dehydrated_devices::DehydratedDeviceEvent> for DehydratedDeviceEvent {
    fn from(value: dehydrated_devices::DehydratedDeviceEvent) -> Self {
        match value {
            dehydrated_devices::DehydratedDeviceEvent::Created { device_id } => {
                Self::Created { device_id: device_id.to_string() }
            }
            dehydrated_devices::DehydratedDeviceEvent::Uploaded { device_id } => {
                Self::Uploaded { device_id: device_id.to_string() }
            }
            dehydrated_devices::DehydratedDeviceEvent::Deleted => Self::Deleted,
            dehydrated_devices::DehydratedDeviceEvent::KeyCached => Self::KeyCached,
            dehydrated_devices::DehydratedDeviceEvent::RehydrationStarted { device_id } => {
                Self::RehydrationStarted { device_id: device_id.to_string() }
            }
            dehydrated_devices::DehydratedDeviceEvent::RehydrationProgress {
                room_keys_imported,
                to_device_events,
            } => Self::RehydrationProgress {
                room_keys_imported: room_keys_imported as u64,
                to_device_events: to_device_events as u64,
            },
            dehydrated_devices::DehydratedDeviceEvent::RehydrationCompleted {
                device_id,
                room_keys_imported,
                to_device_events,
            } => Self::RehydrationCompleted {
                device_id: device_id.to_string(),
                room_keys_imported: room_keys_imported as u64,
                to_device_events: to_device_events as u64,
            },
            dehydrated_devices::DehydratedDeviceEvent::RehydrationError { error } => {
                Self::RehydrationError { error }
            }
            dehydrated_devices::DehydratedDeviceEvent::RotationError { error } => {
                Self::RotationError { error }
            }
        }
    }
}

#[matrix_sdk_ffi_macros::export(callback_interface)]
pub trait DehydratedDeviceEventListener: SyncOutsideWasm + SendOutsideWasm {
    fn on_event(&self, event: DehydratedDeviceEvent);
}

/// Settings for [`Encryption::start_dehydrated_devices`].
#[derive(uniffi::Record)]
pub struct StartDehydratedDevicesSettings {
    /// Force generation of a fresh random pickle key on start, replacing any
    /// existing entry in Secret Storage and the local cache.
    #[uniffi(default = false)]
    pub create_new_key: bool,
    /// Whether to attempt to rehydrate the existing dehydrated device, if any,
    /// before creating the next one.
    #[uniffi(default = true)]
    pub rehydrate: bool,
    /// If `true`, the call becomes a no-op when no pickle key is cached
    /// locally.
    #[uniffi(default = false)]
    pub only_if_key_cached: bool,
}

/// Errors returned by the dehydrated-device FFI surface.
#[derive(Debug, Error, uniffi::Error)]
#[uniffi(flat_error)]
pub enum DehydratedDeviceError {
    /// The client is not logged in.
    #[error("the client is not logged in")]
    NotLoggedIn,
    /// The supplied base64-encoded pickle key did not decode to 32 bytes.
    #[error("the dehydrated-device pickle key must decode to 32 bytes of base64")]
    InvalidPickleKey,
    /// Opening Secret Storage with the supplied recovery key failed.
    #[error("could not open Secret Storage: {0}")]
    SecretStorage(String),
    /// Any other failure surfaced by the SDK.
    #[error("{0}")]
    Sdk(String),
}

impl From<dehydrated_devices::DehydratedDeviceError> for DehydratedDeviceError {
    fn from(value: dehydrated_devices::DehydratedDeviceError) -> Self {
        match value {
            dehydrated_devices::DehydratedDeviceError::NotLoggedIn => Self::NotLoggedIn,
            other => Self::Sdk(other.to_string()),
        }
    }
}

fn decode_pickle_key(base64: &str) -> Result<DehydratedDeviceKey, DehydratedDeviceError> {
    let bytes =
        vodozemac::base64_decode(base64).map_err(|_| DehydratedDeviceError::InvalidPickleKey)?;
    DehydratedDeviceKey::from_slice(&bytes).map_err(|_| DehydratedDeviceError::InvalidPickleKey)
}

#[matrix_sdk_ffi_macros::export]
impl Encryption {
    /// Get the public ed25519 key of our own device. This is usually what is
    /// called the fingerprint of the device.
    pub async fn ed25519_key(&self) -> Option<String> {
        self.inner.ed25519_key().await
    }

    /// Get the public curve25519 key of our own device in base64. This is
    /// usually what is called the identity key of the device.
    pub async fn curve25519_key(&self) -> Option<String> {
        self.inner.curve25519_key().await.map(|k| k.to_base64())
    }

    pub fn backup_state_listener(&self, listener: Box<dyn BackupStateListener>) -> Arc<TaskHandle> {
        let mut stream = self.inner.backups().state_stream();

        let stream_task = TaskHandle::new(get_runtime_handle().spawn(async move {
            while let Some(state) = stream.next().await {
                let Ok(state) = state else { continue };
                listener.on_update(state.into());
            }
        }));

        stream_task.into()
    }

    pub fn backup_state(&self) -> BackupState {
        self.inner.backups().state().into()
    }

    /// Does a backup exist on the server?
    ///
    /// Because the homeserver doesn't notify us about changes to the backup
    /// version, the [`BackupState`] and its listener are a bit crippled. The
    /// `BackupState::Unknown` state might mean there is no backup at all or a
    /// backup exists but we don't have access to it.
    ///
    /// Therefore it is necessary to poll the server for an answer every time
    /// you want to differentiate between those two states.
    pub async fn backup_exists_on_server(&self) -> Result<bool, ClientError> {
        Ok(self.inner.backups().fetch_exists_on_server().await?)
    }

    pub fn recovery_state(&self) -> RecoveryState {
        self.inner.recovery().state().into()
    }

    pub fn recovery_state_listener(
        &self,
        listener: Box<dyn RecoveryStateListener>,
    ) -> Arc<TaskHandle> {
        let mut stream = self.inner.recovery().state_stream();

        let stream_task = TaskHandle::new(get_runtime_handle().spawn(async move {
            while let Some(state) = stream.next().await {
                listener.on_update(state.into());
            }
        }));

        stream_task.into()
    }

    pub async fn enable_backups(&self) -> Result<()> {
        Ok(self.inner.recovery().enable_backup().await?)
    }

    pub async fn is_last_device(&self) -> Result<bool> {
        Ok(self.inner.recovery().is_last_device().await?)
    }

    /// Does the user have other devices that the current device can verify
    /// against?
    ///
    /// The device must be signed by the user's cross-signing key, must have an
    /// identity, and must not be a dehydrated device.
    pub async fn has_devices_to_verify_against(&self) -> Result<bool, ClientError> {
        Ok(self.inner.has_devices_to_verify_against().await?)
    }

    pub async fn wait_for_backup_upload_steady_state(
        &self,
        progress_listener: Option<Box<dyn BackupSteadyStateListener>>,
    ) -> Result<(), SteadyStateError> {
        let backups = self.inner.backups();
        let wait_for_steady_state = backups.wait_for_steady_state();

        let task = if let Some(listener) = progress_listener {
            let mut progress_stream = wait_for_steady_state.subscribe_to_progress();

            Some(get_runtime_handle().spawn(async move {
                while let Some(progress) = progress_stream.next().await {
                    let Ok(progress) = progress else { continue };
                    listener.on_update(progress.into());
                }
            }))
        } else {
            None
        };

        let result = wait_for_steady_state.await;

        if let Some(task) = task {
            task.abort();
        }

        Ok(result?)
    }

    pub async fn enable_recovery(
        &self,
        wait_for_backups_to_upload: bool,
        mut passphrase: Option<String>,
        progress_listener: Box<dyn EnableRecoveryProgressListener>,
    ) -> Result<String> {
        let recovery = self.inner.recovery();

        let enable = if wait_for_backups_to_upload {
            recovery.enable().wait_for_backups_to_upload()
        } else {
            recovery.enable()
        };

        let enable = if let Some(passphrase) = &passphrase {
            enable.with_passphrase(passphrase)
        } else {
            enable
        };

        let mut progress_stream = enable.subscribe_to_progress();

        let task = get_runtime_handle().spawn(async move {
            while let Some(progress) = progress_stream.next().await {
                let Ok(progress) = progress else { continue };
                progress_listener.on_update(progress.into());
            }
        });

        let ret = enable.await?;

        task.abort();
        passphrase.zeroize();

        Ok(ret)
    }

    pub async fn disable_recovery(&self) -> Result<()> {
        Ok(self.inner.recovery().disable().await?)
    }

    pub async fn reset_recovery_key(&self) -> Result<String> {
        Ok(self.inner.recovery().reset_key().await?)
    }

    pub async fn recover_and_reset(&self, mut old_recovery_key: String) -> Result<String> {
        let result = self.inner.recovery().recover_and_reset(&old_recovery_key).await;

        old_recovery_key.zeroize();

        Ok(result?)
    }

    /// Completely reset the current user's crypto identity: reset the cross
    /// signing keys, delete the existing backup and recovery key.
    pub async fn reset_identity(&self) -> Result<Option<Arc<IdentityResetHandle>>, ClientError> {
        if let Some(reset_handle) =
            self.inner.recovery().reset_identity().await.map_err(ClientError::from_err)?
        {
            return Ok(Some(Arc::new(IdentityResetHandle { inner: reset_handle })));
        }

        Ok(None)
    }

    /// Download identity and key backup information from Recovery
    pub async fn recover(&self, mut recovery_key: String) -> Result<()> {
        let result = self.inner.recovery().recover(&recovery_key).await;

        recovery_key.zeroize();

        Ok(result?)
    }

    /// Download identity and key backup information from Recovery, and, if the
    /// key backup information is inconsistent, create a new key backup.
    ///
    /// This will create a new key backup if:
    ///
    /// - Key backup is enabled and the backup decryption key is missing from
    ///   Recovery, or
    /// - Key backup is enabled and the backup decryption key does not match the
    ///   public key
    pub async fn recover_and_fix_backup(&self, mut recovery_key: String) -> Result<()> {
        let result = self.inner.recovery().recover_and_fix_backup(&recovery_key).await;

        recovery_key.zeroize();

        Ok(result?)
    }

    pub fn verification_state(&self) -> VerificationState {
        self.inner.verification_state().get().into()
    }

    pub fn verification_state_listener(
        self: Arc<Self>,
        listener: Box<dyn VerificationStateListener>,
    ) -> Arc<TaskHandle> {
        let mut subscriber = self.inner.verification_state();

        listener.on_update(subscriber.next_now().into());

        Arc::new(TaskHandle::new(get_runtime_handle().spawn(async move {
            while let Some(verification_state) = subscriber.next().await {
                listener.on_update(verification_state.into());
            }
        })))
    }

    /// Waits for end-to-end encryption initialization tasks to finish, if any
    /// was running in the background.
    pub async fn wait_for_e2ee_initialization_tasks(&self) {
        self.inner.wait_for_e2ee_initialization_tasks().await;
    }

    /// Get the E2EE identity of a user.
    ///
    /// This method always tries to fetch the identity from the store, which we
    /// only have if the user is tracked, meaning that we are both members of
    /// the same encrypted room. If no user is found locally, a request will be
    /// made to the homeserver unless `fallback_to_server` is set to `false`.
    ///
    /// # Arguments
    ///
    /// - `user_id` - The ID of the user that the identity belongs to.
    /// - `fallback_to_server` - Should we request the user identity from the
    ///   homeserver if one isn't found locally.
    ///
    /// Returns a `UserIdentity` if one is found. Returns an error if there was
    /// an issue with the crypto store or with the request to the homeserver.
    ///
    /// This will always return `None` if the client hasn't been logged in.
    pub async fn user_identity(
        &self,
        user_id: String,
        fallback_to_server: bool,
    ) -> Result<Option<Arc<UserIdentity>>, ClientError> {
        match self.inner.get_user_identity(user_id.as_str().try_into()?).await {
            Ok(Some(identity)) => {
                return Ok(Some(Arc::new(UserIdentity { inner: identity })));
            }
            Ok(None) => {
                info!("No identity found in the store.");
            }
            Err(error) => {
                error!("Failed fetching identity from the store: {error}");
            }
        }

        info!("Requesting identity from the server.");

        if fallback_to_server {
            let identity = self.inner.request_user_identity(user_id.as_str().try_into()?).await?;
            Ok(identity.map(|identity| Arc::new(UserIdentity { inner: identity })))
        } else {
            Ok(None)
        }
    }

    /// This method will import all the private cross-signing keys and the
    /// private part of a backup key and its accompanying version into the
    /// store.
    ///
    /// Importing all the secrets will mark the device as verified and enable
    /// backups.
    ///
    /// **Warning**: Only import this from a trusted source, i.e. if an existing
    /// device is sharing this with a new device.
    ///
    /// **Warning*: Only call this method right after logging in and before the
    /// initial sync has been started.
    pub async fn import_secrets_bundle(
        &self,
        secrets_bundle: &SecretsBundleWithUserId,
    ) -> Result<(), ClientError> {
        let user_id = self._client.inner.user_id().expect(
            "We should have a user ID available now, this is only called once we're logged in",
        );

        if user_id == secrets_bundle.user_id {
            self.inner
                .import_secrets_bundle(&secrets_bundle.inner)
                .await
                .map_err(ClientError::from_err)?;

            self.inner.wait_for_e2ee_initialization_tasks().await;

            Ok(())
        } else {
            Err(ClientError::Generic {
                msg: "Secrets bundle does not belong to the user which was logged in".to_owned(),
                details: None,
            })
        }
    }

    /// Return whether the homeserver advertises support for MSC3814 dehydrated
    /// devices.
    pub async fn is_dehydrated_device_supported(&self) -> Result<bool, DehydratedDeviceError> {
        Ok(self.inner.dehydrated_devices().is_supported().await?)
    }

    /// Build a fresh dehydrated device, encrypt it with the supplied pickle
    /// key, and upload it to the homeserver. Returns the new device ID.
    ///
    /// The pickle key is a 32-byte secret, base64 encoded. Callers are
    /// responsible for storing the pickle key safely (typically in Secret
    /// Storage via [`Encryption::start_dehydrated_devices`]).
    pub async fn create_dehydrated_device(
        &self,
        display_name: Option<String>,
        pickle_key: String,
    ) -> Result<String, DehydratedDeviceError> {
        let key = decode_pickle_key(&pickle_key)?;
        let id = self.inner.dehydrated_devices().create(display_name.as_deref(), &key).await?;
        Ok(id.to_string())
    }

    /// Rehydrate the dehydrated device currently on the server, if any.
    ///
    /// Returns `true` if a device was rehydrated end to end, `false` if the
    /// server reports no dehydrated device or does not implement the endpoint.
    pub async fn rehydrate_dehydrated_device(
        &self,
        pickle_key: String,
    ) -> Result<bool, DehydratedDeviceError> {
        let key = decode_pickle_key(&pickle_key)?;
        Ok(self.inner.dehydrated_devices().rehydrate(&key).await?)
    }

    /// Delete the current dehydrated device, if one exists. Silent if no device
    /// is on the server or the server does not implement MSC3814.
    pub async fn delete_dehydrated_device(&self) -> Result<(), DehydratedDeviceError> {
        Ok(self.inner.dehydrated_devices().delete().await?)
    }

    /// Start using dehydrated devices for this client, resolving the pickle key
    /// through Secret Storage and scheduling weekly rotation.
    ///
    /// The Rust-side copy of the recovery key is zeroized after Secret Storage
    /// has been unlocked; the caller keeps responsibility for the string it
    /// passed in.
    pub async fn start_dehydrated_devices(
        &self,
        mut recovery_key: String,
        settings: StartDehydratedDevicesSettings,
    ) -> Result<(), DehydratedDeviceError> {
        let secret_store = self
            .inner
            .secret_storage()
            .open_secret_store(&recovery_key)
            .await
            .map_err(|e| DehydratedDeviceError::SecretStorage(e.to_string()))?;
        recovery_key.zeroize();

        let dehydrated = self.inner.dehydrated_devices();
        let mut start = dehydrated.start(&secret_store);
        if settings.create_new_key {
            start = start.create_new_key();
        }
        if !settings.rehydrate {
            start = start.skip_rehydration();
        }
        if settings.only_if_key_cached {
            start = start.only_if_key_cached();
        }
        start.await?;
        Ok(())
    }

    /// Stop the scheduled dehydrated-device rotation.
    ///
    /// Has no effect when no rotation is scheduled. Existing dehydrated devices
    /// on the server are left in place; pair with
    /// [`Encryption::delete_dehydrated_device`] to remove them.
    pub fn stop_dehydrated_devices(&self) {
        self.inner.dehydrated_devices().stop();
    }

    /// Subscribe to lifecycle events emitted by the dehydrated-device manager.
    /// The returned [`TaskHandle`] keeps the listener alive; drop it to
    /// unsubscribe.
    pub fn dehydrated_device_event_listener(
        &self,
        listener: Box<dyn DehydratedDeviceEventListener>,
    ) -> Arc<TaskHandle> {
        let mut events = Box::pin(self.inner.dehydrated_devices().state_stream());
        Arc::new(TaskHandle::new(get_runtime_handle().spawn(async move {
            while let Some(event) = events.next().await {
                let Ok(event) = event else { continue };
                listener.on_event(event.into());
            }
        })))
    }
}

/// The E2EE identity of a user.
#[derive(uniffi::Object)]
pub struct UserIdentity {
    inner: matrix_sdk::encryption::identities::UserIdentity,
}

#[matrix_sdk_ffi_macros::export]
impl UserIdentity {
    /// Remember this identity, ensuring it does not result in a pin violation.
    ///
    /// When we first see a user, we assume their cryptographic identity has not
    /// been tampered with by the homeserver or another entity with
    /// man-in-the-middle capabilities. We remember this identity and call this
    /// action "pinning".
    ///
    /// If the identity presented for the user changes later on, the newly
    /// presented identity is considered to be in "pin violation". This method
    /// explicitly accepts the new identity, allowing it to replace the
    /// previously pinned one and bringing it out of pin violation.
    ///
    /// UIs should display a warning to the user when encountering an identity
    /// which is not verified and is in pin violation.
    pub(crate) async fn pin(&self) -> Result<(), ClientError> {
        Ok(self.inner.pin().await?)
    }

    /// Get the public part of the Master key of this user identity.
    ///
    /// The public part of the Master key is usually used to uniquely identify
    /// the identity.
    ///
    /// Returns None if the master key does not actually contain any keys.
    pub(crate) fn master_key(&self) -> Option<String> {
        self.inner.master_key().get_first_key().map(|k| k.to_base64())
    }

    /// Is the user identity considered to be verified.
    ///
    /// If the identity belongs to another user, our own user identity needs to
    /// be verified as well for the identity to be considered to be verified.
    pub fn is_verified(&self) -> bool {
        self.inner.is_verified()
    }

    /// True if we verified this identity at some point in the past.
    ///
    /// To reset this latch back to `false`, one must call
    /// [`UserIdentity::withdraw_verification()`].
    pub fn was_previously_verified(&self) -> bool {
        self.inner.was_previously_verified()
    }

    /// Remove the requirement for this identity to be verified.
    ///
    /// If an identity was previously verified and is not anymore it will be
    /// reported to the user. In order to remove this notice users have to
    /// verify again or to withdraw the verification requirement.
    pub(crate) async fn withdraw_verification(&self) -> Result<(), ClientError> {
        Ok(self.inner.withdraw_verification().await?)
    }

    /// Was this identity previously verified, and is no longer?
    pub fn has_verification_violation(&self) -> bool {
        self.inner.has_verification_violation()
    }
}

#[derive(uniffi::Object)]
pub struct IdentityResetHandle {
    pub(crate) inner: matrix_sdk::encryption::recovery::IdentityResetHandle,
}

#[matrix_sdk_ffi_macros::export]
impl IdentityResetHandle {
    /// Get the underlying [`CrossSigningResetAuthType`] this identity reset
    /// process is using.
    pub fn auth_type(&self) -> CrossSigningResetAuthType {
        self.inner.auth_type().into()
    }

    /// This method starts the identity reset process and will go through the
    /// following steps:
    ///
    /// 1. Disable backing up room keys and delete the active backup
    /// 2. Disable recovery and delete secret storage
    /// 3. Go through the cross-signing key reset flow
    /// 4. Finally, re-enable key backups only if they were enabled before
    pub async fn reset(&self, auth: Option<AuthData>) -> Result<(), ClientError> {
        self.inner.reset(auth.map(Into::into)).await.map_err(ClientError::from_err)
    }

    pub async fn cancel(&self) {
        self.inner.cancel().await;
    }
}

#[derive(uniffi::Enum)]
pub enum CrossSigningResetAuthType {
    /// The homeserver requires user-interactive authentication.
    Uiaa,
    /// OAuth is used for authentication and the user needs to open a URL to
    /// approve the upload of cross-signing keys.
    OAuth { info: OAuthCrossSigningResetInfo },
}

impl From<&matrix_sdk::encryption::CrossSigningResetAuthType> for CrossSigningResetAuthType {
    fn from(value: &matrix_sdk::encryption::CrossSigningResetAuthType) -> Self {
        match value {
            encryption::CrossSigningResetAuthType::Uiaa(_) => Self::Uiaa,
            encryption::CrossSigningResetAuthType::OAuth(info) => Self::OAuth { info: info.into() },
        }
    }
}

#[derive(uniffi::Record)]
pub struct OAuthCrossSigningResetInfo {
    /// The URL where the user can approve the reset of the cross-signing keys.
    pub approval_url: String,
}

impl From<&matrix_sdk::encryption::OAuthCrossSigningResetInfo> for OAuthCrossSigningResetInfo {
    fn from(value: &matrix_sdk::encryption::OAuthCrossSigningResetInfo) -> Self {
        Self { approval_url: value.approval_url.to_string() }
    }
}
