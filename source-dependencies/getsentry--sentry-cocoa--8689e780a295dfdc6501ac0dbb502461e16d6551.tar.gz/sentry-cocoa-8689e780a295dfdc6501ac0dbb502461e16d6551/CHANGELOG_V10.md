# Changelog

## Unreleased

### Features

- Copy scope data into KSCrash crash reports in `SentryV10` (#8851)
- Sync scope data to KSCrash crash reports in `SentryV10` (#8759)
- Process pending KSCrash reports into fatal Sentry events in `SentryV10` (#8515)
- Install KSCrash crash handler in `SentryV10` with production-safe monitors matching SentryCrash's existing monitor set (#8469)
  - Respect `options.enableMemoryIntrospection` when configuring KSCrash
- Add `options.dataCollection` to configure data collection behaviour (#8448)
  - Allows dictionary initialization for `options.dataCollection` (#8371)
  - Renamed `options.dataCollection.queryParams` to `options.dataCollection.urlQueryParams` (#8414)
  - Add query parameter filtering for network spans, breadcrumbs, and failed requests using `options.dataCollection.urlQueryParams` (#8414)
  - Enable automatic user information for logs, metrics, and IP inference by default; configure it with `options.dataCollection.userInfo` (#8254)
  - Add HTTP header and cookie filtering for failed requests using `options.dataCollection` (#8460)
  - Scrub sensitive Session Replay request and response body values, replacing unparseable bodies with `[Filtered]` (#8547)
- Add `beforeSendTransaction` to modify or drop transaction events before sending (#8745)
- Attach crash screenshots via KSCrash sidecar in `SentryV10` (#8986)
- Attach crash view hierarchy via KSCrash sidecar in `SentryV10` (#9018)
- Write session replay recovery checkpoints from KSCrash in `SentryV10` (#9038)
- Add a `Hint` parameter to `beforeSendTransaction` to inspect and edit the attachments sent with a transaction (#9099)
- Persist the active transaction when crashing in `SentryV10` (#8735)

### Breaking Changes

- Enable MetricKit integration by default (#8716)
- Enable logging by default (#8717)
- Remove `enableLogs`; logs are always enabled in v10 (#8769)
- Change the default diagnostic level to warning (#8732)
- Enable `swiftAsyncStacktraces` by default (#8718)
- Remove `sendDefaultPii`; use `dataCollection` to configure automatic data collection (#8253)
- Remove Objective-C `@objc` attributes from SentrySDK (#8308)
- Remove deprecated `locale` from device context; use `locale` in culture context instead (#8325)
- Change `SentryRequest.cookies` from a string to a dictionary of cookie names and values (#8460)
- Remove data collection options without applicable Cocoa collectors (#8563)
- Standalone app starts are now the default and only mode; the legacy `ui.load` attach-to-transaction path and `enableStandaloneAppStartTracing` experimental option are removed (#8719)
- Removed deprecated user feedback widget configuration and API (#8731)
- Remove legacy app hang event tracking in V10 (#8817)
  - Remove the `enableAppHangTracking` and `enableReportNonFullyBlockingAppHangs` options
  - Remove the `pauseAppHangTracking` and `resumeAppHangTracking` APIs
  - Remove the `enableWatchdogTerminationsV2` option; watchdog termination tracking always uses the run-loop-based tracker
- Remove `enableSigtermReporting`; KSCrash treats `SIGTERM` as a clean exit and never reports it as a crash (#9019)

### Fixes

- Compile only explicitly allowlisted shared SentryCrash tools in V10
- Restore foreground app-hang detection and debugger-aware behavior in V10
- Disambiguate V9 and V10 target dependencies in Xcode builds
- Keep V10 compiler flags and KSCrash dependencies aligned across Xcode and SwiftPM build paths
- Filter sensitive values from selected Session Replay network headers and cookies (#8566)
- Omit failed-request headers when `options.dataCollection.httpHeaders` is disabled (#8562)
- Normalize profiling CPU usage to 0–100 percent (#8323)
- Bump KSCrash to `2.6.0`
- Restore memory metrics and initial OS, device, app, and runtime contexts in `SentryV10` (#8836)
- Remove unused `SentryFramesTracker` dependency from `SentryAppStartTracker` in V10 (#8859)
- Restore binary images and `debug_meta` in `SentryV10` with KSCrash RecordingCore (#8798)
- Restore macOS AppKit NSException forwarding in `SentryV10` (#8874)
- Honor `swiftAsyncStacktraces` in `SentryV10` with KSCrash (#8856)
- Populate `beforeSendTransaction` trace context from the transaction's own tracer, preserving its `op`, trace IDs, and status when the scope span is cleared or replaced. V9 `beforeSend` behavior is unchanged (#9040)
- Seed extras, tags, user, context, breadcrumbs, and other nested scope fields into KSCrash crash reports at install time, instead of relying on KSCrash user info scalars
