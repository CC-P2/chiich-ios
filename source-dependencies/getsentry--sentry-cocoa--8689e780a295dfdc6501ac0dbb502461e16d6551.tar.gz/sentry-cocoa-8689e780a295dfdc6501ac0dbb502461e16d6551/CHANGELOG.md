# Changelog

## 9.29.2

### Fixes

- Stop sending scope attachments with crashes and other fatal events captured from a previous app run, because those attachments belong to the current run. Use `beforeSendWithHint` to attach files to fatal events (#9153)
- Prevent an `isMetricKitEvent` unrecognized selector crash when statically linking the SDK without `-ObjC`, including when MetricKit is disabled (#9155)

## 9.29.1

> [!CAUTION]
> **Known issue:** This release can crash apps statically linking the SDK without `-ObjC` with `-[SentryEvent isMetricKitEvent]: unrecognized selector`, even when MetricKit is disabled. Add `-ObjC` to the app target's linker flags, preserving `$(inherited)`, or pin to **9.29.0** until a fix is released. See [#9154](https://github.com/getsentry/sentry-cocoa/issues/9154).

### Fixes

- Add experimental support for the new URLSession HTTP loader for automatic network instrumentation, preserving original request details in Session Replay after redirects. Opt in with `options.experimental.enableNewURLLoaderSwizzling = true` (disabled by default) (#8845)
- Preserve MetricKit diagnostics containing frames without a binary UUID instead of dropping the entire diagnostic (#9080)
- Session Replay: Populate `trace_ids` in replay events to enable searching replays by trace ID (#9092)
- Retain raw MetricKit diagnostic attachments when call-stack decoding fails and `enableMetricKitRawPayload` is enabled, without attaching unrelated current-thread stack traces (#9070)
- Prevent duplicate HTTP spans and breadcrumbs when watchOS resumes an internal URLSession task copy after the original request finishes (#9095)
- Remove the compiler deprecation warning for `enableAppHangTracking` so applications can continue opting out of App Hang tracking until its removal in v10 (#9094)
- Reset `appHangTimeoutInterval` values of 0 or lower to the default of 2 seconds, which previously spun the app hang tracker thread in a busy loop (#9020)
- Release App Hang tracking listener wrappers when listeners are removed (#9127)

## 9.29.0

> [!WARNING]
> Native crashes now set `mechanism.synthetic`, which takes the mach exception name (`EXC_BAD_ACCESS`) or signal name (`SIGSEGV`) out of the grouping hash. Expect a one-time regrouping as your app adopts this version: existing crash issues stop receiving events and new ones open. Crashes that differ only by signal at the same stacktrace now share one issue. The mach and signal detail stays on `mechanism.meta`.

### Fixes

- Store the binary image cache in zero-fill memory to reduce the SDK binary size. (#9003)
- Fix crash in `[NSURLSessionTask cancel]` when cancelling an in-flight task with swizzling enabled (#9009)
- Clear the scope's `replayId` when Session Replay is stopped manually, so events captured after `stop()` are no longer linked to a replay that is no longer recording (#9017)
- Mark the fabricated `mach` and `signal` crash mechanisms as `synthetic` so an Apple crash groups with the identical crash reported by the other Sentry SDKs (#9004)
- Set `mechanism.handled` to `false` on crash reports without mach context, which previously left it unset (#9004)
- Sample and flush Session Replay when the feedback form opens or feedback is captured manually, preserving the form's opening-time replay association even if the session changes before submission (#9046)

### Deprecations

- Deprecate legacy App Hang tracking because it can produce less relevant stack traces and false positives. Enable the MetricKit integration for system-provided hang diagnostics by setting `options.enableMetricKit = true`. The `appHangTimeoutInterval` option remains supported for watchdog termination classification. (#8944)

## 9.28.0

### Features

- Add a `device.event` breadcrumb (`SYSTEM_CLOCK_CHANGE`) when the system clock changes, for example due to a manual time change or NTP sync (#8946)
- Add Hints API with `beforeSendWithHint` and `beforeBreadcrumbWithHint` callbacks (#8942)

  Use hints to inspect the original source material that produced an event or breadcrumb, and to
  add or remove attachments before they are sent:

  ```swift
  SentrySDK.start { options in
      options.beforeSendWithHint = { event, hint in
          if let error = hint.originalError as? NSError,
             error.domain == NSURLErrorDomain {
              return nil // drop network errors
          }
          return event
      }
      options.beforeBreadcrumbWithHint = { breadcrumb, hint in
          if hint.urlRequest?.url?.host == "internal.example.com" {
              return nil // redact internal traffic
          }
          return breadcrumb
      }
  }
  ```

- Add hint parameter to public capture methods on `SentrySDK` (#8955)

  Pass a `Hint` when capturing events or errors to attach metadata that `beforeSendWithHint`
  can inspect:

  ```swift
  let hint = Hint()
  hint.setHintValue("checkout", forKey: "flow")
  SentrySDK.capture(error: error, hint: hint)
  ```

- Auto-populate HTTP request and response on hints for network breadcrumbs and HTTP client errors (#8967)

  Network breadcrumbs and HTTP client error events now include the originating `URLRequest` and
  `HTTPURLResponse` on the hint, so callbacks can inspect status codes, headers, or URLs:

  ```swift
  options.beforeBreadcrumbWithHint = { breadcrumb, hint in
      if let statusCode = hint.httpResponse?.statusCode,
         statusCode == 401 {
          breadcrumb.level = .warning
      }
      return breadcrumb
  }
  ```

- Include screenshot and view hierarchy attachments in `hint.attachments` before `beforeSendWithHint` runs (#8989)

  Screenshot and view hierarchy attachments are now available in `hint.attachments` when
  `beforeSendWithHint` is called, so they can be inspected or removed:

  ```swift
  options.beforeSendWithHint = { event, hint in
      hint.attachments = hint.attachments.filter { $0.filename != "screenshot.png" }
      return event
  }
  ```

### Fixes

- Prevent relevant view controller traversal from recursively loading parent views and invoking `viewDidLoad` twice when tracing is enabled. (#8941)
- Classify MetricKit hangs over 500 ms as errors. (#8948)
- Prevent Session Replay video encoding from reusing pixel buffers retained by AVFoundation. (#8950)
- Prevent deadlock when a signal interrupts memory allocation by avoiding thread-local storage and unsafe formatting during signal handling. (#8271)
- Remove invalid DWARF references from `SentryObjC-Static` XCFrameworks to prevent `dsymutil` missing-object warnings. (#8979)

### Internal

- Fix `SentrySDK.internal.replay.replayId` returning nil for buffered replays (#8976)

## 9.27.0

> [!NOTE]
> `enableLogs` and `enableMetrics` are now deprecated and will be removed in the next major version. Manual log and metric capture is no longer gated by these flags.

### Improvements

- Install idle Session Replay recovery infrastructure at zero sample rates. (#8865)
- Manual log and metrics APIs are no longer gated by behind `enableLogs` / `enableMetrics` (#8918)

### Features

- Add manual Session Replay controls through `SentrySDK.replay`. (#8868)
  - Explicit `start()` and `startBuffering()` calls bypass the configured replay sample rates; sampling still controls automatic startup.
  - `start()` starts a full-session replay and does nothing if one is already recording.
  - `startBuffering()` keeps a rolling buffer that is sent on `flush()` or an error, then continues in session mode.
  - `stop()` ends the current replay; the next `start()` creates a new replay session.
  - `pause()` suspends recording until `resume()` and remains paused across background and foreground transitions and automatic replay restarts in the same process.
  - `resume()` continues the same manually paused replay.
  - `flush()` sends the current replay data to Sentry, or starts a full-session replay when recording is stopped.
- Copy `app.vitals.start.type` and `app.vitals.start.screen` onto standalone `app.start` children, including `app.start.extended` and user descendants (#8888)
- Add `maxFeatureFlags` option to configure how many feature flag evaluations the scope retains, matching sentry-java. Defaults to 100 (#8858)
- Log a warning when `SentrySDK.start` is called again without `close()`. Reinitialization still runs and remains unsupported (#8928)
- Add `SentrySDK.internal.envelope.captureNonTerminating` for hybrid SDKs, which keeps the current session running and reports it with the `unhandled` status when an unhandled exception doesn't terminate the process (#8654)
- Add `SentrySDK.internal.envelope.updateSessionForDroppedEventNonTerminating` so hybrid SDKs can update the native session when an error is dropped by sampling, without sending an envelope (#8907)
- Expose continuous profiling configuration on `SentryObjCOptions` via `configureProfiling` and `SentryObjCProfileOptions` (#8937)

### Fixes

- Silence spurious ERROR log in `SentryCrashCxaThrowSwapper` for empty sections (#8915)
- Stop recording touch events while Session Replay is paused. (#8887)
- Synchronize access to the current trace profiler in debug and test builds. (#8936)

### Internal

- Add visionOS support to internal screen APIs (#8913)

## 9.26.1

### Fixes

- Prevent duplicate automatic HTTP spans and breadcrumbs for URLSession task wrappers (#8846)
- Prevent breadcrumb persistence for watchdog termination events from blocking the calling thread (#8653)
- Fix data races when reading and updating network tracker feature flags (#8832)
- Avoid lossy JPEG compression for user feedback screenshot fallbacks from non-previewable formats (#8876)

## 9.26.0

> [!WARNING]
> The 3rd-party integration packages (SentryCocoaLumberjack, SentryPulse, SentrySwiftLog, SentrySwiftyBeaver) now require Swift 6.1+ to support SPM package traits. Users on older Swift toolchains should pin to an earlier release of these packages.

### Features

- Promote `enableStandaloneAppStartTracing` from `options.experimental` to a top-level option on `Options` (#8715)
- Add `SentryFromBinary` (default) and `SentryFromSource` SPM package traits to 3rd-party integrations, allowing users to choose between precompiled xcframeworks and building from source. Requires Swift 6.1+ (#8795)
- Add experimental option `enableUIViewControllerInitSwizzling` that defers `UIViewController` swizzling to first instantiation instead of eagerly discovering and swizzling all subclasses at SDK start. This avoids realizing `@available`-gated `UIViewController` subclasses on OS versions below their gate, which crashes apps on start (#8687).
- Add screenshot picker to feedback (#8655)
  - Enable it with `form.enableScreenshot = true` in the `configureForm` callback.
- Expose transaction as a public event type (#8745)

### Improvements

- Session Replay keeps captured frames in memory for live video encode while still writing PNGs to disk for crash durability. Encode prefers the in-memory image and only falls back to disk for frames recovered after a crash, avoiding a PNG readback on the streaming hot path. (#8636)
- Remove the per-frame render loop from the Session Replay masking preview. (#8730)

### Fixes

- Fix misleading duplicate SDK detection message: "same binary" → "same address space" (#8710)
- Fix a race caused by mutating `URLSessionTask.currentRequest` during trace header propagation (#8650)
- Prevent Session Replay network-detail breadcrumbs from blocking URLSession cancellation on the task monitor (#8497)
- Fix Session Replay adaptive capture backoff pinning at the maximum interval due to mask compositing being included in the measured capture duration, which could produce single-frame segments that appear stuck on one screen (#8740)

### Internal

- Add internal hybrid SDK APIs to serialize native events and retrieve scope contexts for .NET event processing (#8708)

## 9.25.0

> [!WARNING]
> This release raises the minimum deployment targets to macOS 12 and watchOS 9. Apps that support older OS versions must use an earlier Sentry Cocoa release.

### Breaking Changes

- Bump the minimum deployment targets to macOS 12 and watchOS 9 because Xcode 27 no longer supports earlier versions. This lets the SDK adopt Xcode 27 without blocking users from building and submitting their apps with the latest Xcode. (#8595, #8113, #8189)

### Features

- Add `SentrySDK.feedback.enableOnShake()` and `disableOnShake()` to toggle the shake-to-report gesture at runtime (#8591)

### Fixes

- Reduce memory usage when storing envelopes with large attachments (#8649)
- Fix incorrect `duration` sent for active sessions (#8612)
  - Session `duration` is now set only when the session ends. Active sessions (including on error increments) no longer emit a bogus `duration`.
- Fix a race that could prevent consecutive app hangs from being reported (#8627)
- Fix malformed itms-services URL in SentryDistribution updater (#8567)
- Fix off-main thread reads of `-[UIApplication applicationState]` (8672)

## 9.24.0

> [!IMPORTANT]
> Due to a potential risk of revealing PII or security-relevant data in crash events in specific circumstances, we're shipping this strictly speaking breaking change in a minor version.

### Breaking Changes

- Add `enableMemoryIntrospection` option to allow users to control memory introspection in crash reports, defaults to false (was previously true) (#8571)
  - You can re-enable this feature by setting the option `enableMemoryIntrospection` to true
  - When this option is disabled, string stack contents found near the crash site will not be included in the event sent to Sentry. These contents are displayed in the 'message' subtitle shown underneath the main issue title in Sentry.

### Features

- Add `Breadcrumb.setData(value:key:)` to set a single breadcrumb data entry and deprecate the `Breadcrumb.data` setter in its favor. (#8572)

### Fixes

- Fix screenshots not being captured by hybrid SDKs (#8578)
- Fix trace propagation for manually instrumented transactions when automatic performance tracing is disabled (#8522)
- Prevent a Session Replay crash (`NSInvalidArgumentException` / `-[NSConcreteValue doubleValue]`) when Core Animation raises while redacting the view hierarchy, e.g. during React Navigation transitions or video fullscreen presentation (#8537)
- Remove x/y coordinates from UI breadcrumbs, as they are a potential security risk, for example leaking input on custom PIN code views (#8534)

## 9.23.0

### Features

- Record trace_metric_byte client reports (#8490)

### Fixes

- Add a depth limit to view hierarchy serialization to prevent a stack overflow crash on deeply nested view hierarchies (#8292)
- Persist the configured environment in crash reports so later app launches don't overwrite it (#8511)
- Only expose `experimental.dataCollection` APIs in SDK V10 (#8435)

### Improvements

- Reduce slight overhead during SDK start by skipping an unnecessary main thread dispatch when there's no work to do (#8494)

## 9.22.0

### Features

- Mark opt in option `swiftAsyncStacktraces` as stable (#8373)
- Add `dataCollection` option under `experimental` for configuring data scrubbing behavior (#8369)
- Add scope API to clear feature flags (#8364)
- Add dictionary initialization for `options.experimental.dataCollection` (#8371)

### Fixes

- Session Replay now correctly reads the response `Content-Type` for HTTP/2 and HTTP/3, so it captures HTTP response bodies as it was supposed to (when body capturing is enabled via `options.sessionReplay.networkCaptureBodies`) (#8390)
- Log the actual request error instead of `(null)` when a Spotlight request fails (#8401)
- Decoding dictionary to Options sets value of key `"dsn"` to property `dsn` instead of `nil` (#8393)

### Improvements

- Remove `enableReplayNetworkDetailsCapturing` experimental flag; network detail capture is now enabled automatically when `networkDetailAllowUrls` is non-empty (#8396)

## 9.21.0

### Fixes

- Fix use-after-free race in `span`, `startProfiler`, and `stopProfiler` by snapshotting `currentHub` under `currentHubLock` before dereferencing. (#8318)
- Add `userInfo` context for unhandled `NSExceptions` (#8332)

### Features

- Attach feature flag evaluations to active spans (#8158)
- Add feature flag scope ObjC API (#8160)

## 9.20.0

> [!IMPORTANT]
> This release contains an important fix for dropping too much data when the SDK gets rate limited. (#8324) This fix changes how rate limits are handled. Previously, if one data type (for example, user feedback) was rate limited, other data such as spans or sessions could also be dropped. Now, only the rate-limited data is dropped, while all other data continues to be sent. This may also reduce cases where unexpectedly large amounts of data appear to be dropped due to rate limiting.

### Fixes

- Fix rate limiting all data categories when data category rate-limit is active. (#8324)
- Fix EXC_BAD_ACCESS in SentryNetworkTracker caused by repeated reads of the volatile `NSURLSessionTask.currentRequest` property (#8058)

### Features

- Record log_byte client reports (#8186)
- Add scope feature flag API (#8147)

## 9.19.1

### Fixes

- Fix use-after-free crash in `SentrySDKInternal.isEnabled` (#8310)
- Fix dropped `platform` item header in profile-chunk envelopes (#8269)
- Fix crash report ID generation so reports created at certain timestamps are not ignored (#8216)
- Fix C++ exception capture on newer OS versions by page-aligning `mprotect` calls in the `__cxa_throw` swapper (#8221)
- Fix client report discarded-event counts for categories reported in quantities greater than one (e.g. spans): each drop now adds the full dropped quantity instead of incrementing by one (#8230)
- Rename extended app start span operation from `app.start.extended_app_start` to `app.start.extended` (#8220)
- Fix unsynchronized debug-mode access in the binary image cache (#8309)

## 9.19.0

> [!WARNING]
> **The minimum macOS deployment target will be raised to macOS 12 (Monterey)** with the upcoming release that adopts Xcode 27. Xcode 27 no longer supports deployment targets below macOS 12. If your app must support macOS 11 or earlier, please stay on the last SDK version released before this change. See [#8113](https://github.com/getsentry/sentry-cocoa/issues/8113) for full details.

### Features

- Renamed experimental extended app start API (#8161):
  - `extendAppLaunch()` -> `extendAppStart()`
  - `finishExtendedAppLaunch()` -> `finishExtendedAppStart()`
  - Added `getExtendedAppStartSpan()` to get the extended app span
- Add extended app start APIs to ObjC wrapper SDK (#8163)

### Improvements

- Reduce Session Replay capture stutters by scheduling screenshots after run loop UI work instead of from display refresh callbacks (#7851)

### Fixes

- Don't send logs and metrics when the SDK is disabled (#8173)
- Fixes crash caused by modifying breadcrumbs from multiple threads (#8114)
- Prevent feedback form on external displays (#8071)
- Keep the User Feedback screenshot trigger active after form dismissal. (#8048)
- Prevent lazy TLS-init in the signal crash monitor for non-managed runtime builds (#8148)
- Include breadcrumbs in recovered buffer-mode session replays (#8153)
- Fix missing `Info.plist` entries `MinimumOSVersion` and `CFBundleSupportedPlatforms` in `SentryObjC.xcframework` (#8157)
- Harden crash-time attachment path creation to avoid secondary crashes while handling crashes (#8170)
- Session replay video assembly: drop empty video segments, avoid duplicating frames at segment boundaries, and keep video timing stable when captured frames are skipped or unreadable (#8041)

### Internal

- Add `SentrySDK.internal` structured API for hybrid SDKs, replacing `PrivateSentrySDKOnly` with namespaced sub-APIs (`replay`, `profiling`, `appStart`, `performance`, `screenshot`, `viewHierarchy`, `screen`, `envelope`, `swizzle`, `sdk`, `debug`, `breadcrumbs`, `user`) (#8097)

## 9.18.0

### Features

- Add SentryObjC User Feedback presentation APIs and a feedback form factory returning `UIViewController` instances. (#8027)

### Fixes

- Show feedback form from shake or screenshot without widget (#8050)

### Deprecations

- Deprecate the managed User Feedback custom button. It will be removed in v10. Present the feedback form from your own UI with `SentrySDK.feedback.show()`, `SentrySDK.FeedbackForm`, or `.sentryFeedback(isPresented:)` instead. (#8052)

## 9.17.1

### Fixes

- Ship dSYMs in SentryObjC-Dynamic.xcframework artifacts (#8036)
- Fix missing `_OBJC_CLASS_$_` symbols in x86_64 slice of SentryObjC dynamic framework (#8037)
- Mark feedback form aliases and conformances unavailable in app extensions (#8040)
- Silence retroactive conformance warning for `SentryLevel: CustomStringConvertible` when building with SPM from source (#8032)

## 9.17.0

### Features

- Support creating envelope items from attachments via SentryObjC (#8001)
- Add format-string logging to `SentryObjCLogger` with automatic message template extraction (#7996)

  ```objc
  [SentryObjCSDK.logger infoWithFormat:@"User %@ processed %d items", userName, count];
  ```
- Add managed user feedback form presentation APIs (#7873)

  Apps using the managed User Feedback integration can now present the form directly:
  - Use `SentrySDK.feedback.show()` to let the SDK pick the best presenter.
  - In UIKit, present the `SentrySDK.FeedbackForm()` view controller yourself.
  - In SwiftUI, use `.sentryFeedback(isPresented:)`, or present `SentrySDK.FeedbackFormView()` from a container such as `.sheet`.

  These APIs use the global `SentryOptions.configureUserFeedback` configuration and temporarily hide the managed widget
  while the form is open, when possible.
- Add per-form feedback configuration (#8018)

  Managed feedback presentation APIs now accept a configuration closure, so apps can customize a single
  form on top of the global `SentryOptions.configureUserFeedback` settings without mutating them:

  ```swift
  SentrySDK.feedback.show { config in
      config.configureForm = { form in
          form.formTitle = "Report a Bug"
          form.submitButtonLabel = "Send Report"
      }
      config.tags = ["screen": "settings"]
  }
  ```
- Standalone app start sub-spans operations have been renamed for better clarity (#8003):
  - Pre Runtime Init: app.start	-> app.start.pre_runtime_init
  - Runtime Init to Pre Main Initializers: app.start -> app.start.runtime_init
  - UIKit Init: app.start -> app.start.uikit_init
  - Application Init: app.start -> app.start.application_init
  - Extended App Start: app.start -> app.start.extended_app_start

### Deprecations

- Deprecate the managed User Feedback widget/FAB. It will be removed in v10. Present the feedback form from your own UI with `SentrySDK.feedback.show()`, `SentrySDK.FeedbackForm`, or `.sentryFeedback(isPresented:)` instead. (#8022)

### Fixes

- App start duration on the Vitals dashboard now reflects the extended app launch time when using `extendAppLaunch()` (#8028)

## 9.16.1

> [!NOTE]
> No documented changes. This is the same as 9.16.0, re-released to fix the SentryObjC-Static SPM checksum.

> [!IMPORTANT]
> The new SentryObjC SDK introduced in this release should be considered experimental and may be subject to breaking changes.

### Features

- Add SentryObjC wrapper SDK — a pure Objective-C interface for projects that cannot enable Clang modules (e.g., ObjC++ with `-fmodules=NO`). (#7918)

  Ships as a compile-from-source SPM product `SentryObjC`, a static pre-compiled framework `SentryObjC-Static.xcframework.zip` and a dynamic pre-compiled framework `SentryObjC-Dynamic.xcframework.zip`.

  Steps to migrate:
  - Replace your dependency on the target `Sentry` or `SentrySPM` with `SentryObjC` (or `SentryObjC-Static` / `SentryObjC-Dynamic` if you want to use the precompiled binary targets).
  - Change `#import <Sentry/Sentry.h>` to `#import <SentryObjC/SentryObjC.h>`
  - Rename `Sentry`-prefixed types to `SentryObjC` (e.g., `SentrySDK` → `SentryObjCSDK`, `SentryOptions` → `SentryObjCOptions`).
- `SentrySDK.extendAppLaunch()` now returns the extended app launch span, allowing users to add child spans for granular breakdown of the app start period (#7985)

### Fixes

- Fix crash in `SentryFramesTracker.add/removeListener` when called from a listener's own `init` / `deinit` on a background thread, observed on iOS 26 (#7943)
- Report only `cold` or `warm` as `start_type` for standalone app starts, removing the `.prewarmed` suffix per sentry-conventions (#7968)
- Fix reporting arbitrary Objective-C object throws via the C++ exception monitor (#7984)

## 9.16.0

> [!WARNING]
> The `SentryObjC-Static` SPM binary target in this release has an incorrect checksum and resolving dependencies might fail, but the release artifacts are not affected.

> [!IMPORTANT]
> The new SentryObjC SDK introduced in this release should be considered experimental and may be subject to breaking changes.

### Features

- Add SentryObjC wrapper SDK — a pure Objective-C interface for projects that cannot enable Clang modules (e.g., ObjC++ with `-fmodules=NO`). (#7918)

  Ships as a compile-from-source SPM product `SentryObjC`, a static pre-compiled framework `SentryObjC-Static.xcframework.zip` and a dynamic pre-compiled framework `SentryObjC-Dynamic.xcframework.zip`.

  Steps to migrate:
  - Replace your dependency on the target `Sentry` or `SentrySPM` with `SentryObjC` (or `SentryObjC-Static` / `SentryObjC-Dynamic` if you want to use the precompiled binary targets).
  - Change `#import <Sentry/Sentry.h>` to `#import <SentryObjC/SentryObjC.h>`
  - Rename `Sentry`-prefixed types to `SentryObjC` (e.g., `SentrySDK` → `SentryObjCSDK`, `SentryOptions` → `SentryObjCOptions`).
- `SentrySDK.extendAppLaunch()` now returns the extended app launch span, allowing users to add child spans for granular breakdown of the app start period (#7985)

### Fixes

- Fix crash in `SentryFramesTracker.add/removeListener` when called from a listener's own `init` / `deinit` on a background thread, observed on iOS 26 (#7943)
- Report only `cold` or `warm` as `start_type` for standalone app starts, removing the `.prewarmed` suffix per sentry-conventions (#7968)
- Fix reporting arbitrary Objective-C object throws via the C++ exception monitor (#7984)

## 9.16.0-alpha.3

> [!IMPORTANT]
> The new SentryObjC SDK introduced in this release should be considered experimental and may be subject to breaking changes.

### Features

- Add SentryObjC wrapper SDK — a pure Objective-C interface for projects that cannot enable Clang modules (e.g., ObjC++ with `-fmodules=NO`). (#7918)

  Ships as a compile-from-source SPM product `SentryObjC`, a static pre-compiled framework `SentryObjC-Static.xcframework.zip` and a dynamic pre-compiled framework `SentryObjC-Dynamic.xcframework.zip`.

  Steps to migrate:
  - Replace your dependency on the target `Sentry` or `SentrySPM` with `SentryObjC` (or `SentryObjC-Static` / `SentryObjC-Dynamic` if you want to use the precompiled binary targets).
  - Change `#import <Sentry/Sentry.h>` to `#import <SentryObjC/SentryObjC.h>`
  - Rename `Sentry`-prefixed types to `SentryObjC` (e.g., `SentrySDK` → `SentryObjCSDK`, `SentryOptions` → `SentryObjCOptions`).

### Fixes

- Fix crash in `SentryFramesTracker.add/removeListener` when called from a listener's own `init` / `deinit` on a background thread, observed on iOS 26 (#7943)
- Report only `cold` or `warm` as `start_type` for standalone app starts, removing the `.prewarmed` suffix per sentry-conventions (#7968)
- Fix reporting arbitrary Objective-C object throws via the C++ exception monitor (#7984)

## 9.16.0-alpha.2

> [!IMPORTANT]
> The new SentryObjC SDK introduced in this release should be considered experimental and may be subject to breaking changes.

### Features

- Add SentryObjC wrapper SDK — a pure Objective-C interface for projects that cannot enable Clang modules (e.g., ObjC++ with `-fmodules=NO`). Ships as `SentryObjC-Dynamic.xcframework.zip` and as a compile-from-source SPM product. (#7918)
  Steps to migrate:
  - Replace your dependency on `Sentry` with `SentryObjC` (SPM product or xcframework)
  - Change `#import <Sentry/Sentry.h>` to `#import <SentryObjC/SentryObjC.h>`
  - Rename `Sentry`-prefixed types to `SentryObjC` (e.g., `SentrySDK` → `SentryObjCSDK`, `SentryOptions` → `SentryObjCOptions`).

### Fixes

- Fix crash in `SentryFramesTracker.add/removeListener` when called from a listener's own `init` / `deinit` on a background thread, observed on iOS 26 (#7943)
- Report only `cold` or `warm` as `start_type` for standalone app starts, removing the `.prewarmed` suffix per sentry-conventions (#7968)

## 9.16.0-alpha.1

> [!IMPORTANT]
> The new SentryObjC SDK introduced in this release should be considered experimental and may be subject to breaking changes.

### Features

- Add SentryObjC wrapper SDK — a pure Objective-C interface for projects that cannot enable Clang modules (e.g., ObjC++ with `-fmodules=NO`). Ships as `SentryObjC-Dynamic.xcframework.zip` and as a compile-from-source SPM product. (#7918)
  Steps to migrate:
  - Replace your dependency on `Sentry` with `SentryObjC` (SPM product or xcframework)
  - Change `#import <Sentry/Sentry.h>` to `#import <SentryObjC/SentryObjC.h>`
  - Rename `Sentry`-prefixed types to `SentryObjC` (e.g., `SentrySDK` → `SentryObjCSDK`, `SentryOptions` → `SentryObjCOptions`).

### Fixes

- Fix crash in `SentryFramesTracker.add/removeListener` when called from a listener's own `init` / `deinit` on a background thread, observed on iOS 26 (#7943)

## 9.15.0

### Features

- Add `SentrySDK.extendAppLaunch()` and `SentrySDK.finishExtendedAppLaunch()` to extend standalone app start spans beyond the default end point (e.g. include initial data loading). Call `extendAppLaunch()` after `SentrySDK.start(options:)` and before the app start transaction is created, then call `finishExtendedAppLaunch()` when your app is fully ready. Requires `options.experimental.enableStandaloneAppStartTracing = true`. (#7936)
- Skip max app start duration limit for standalone app start tracing (#7949)

### Fixes

- Fix UIViewController transactions lost during launch profiling (#7920)

## 9.14.0

### Features

- Add standalone app start tracing as an experimental option (#7660), enable it via `options.experimental.enableStandaloneAppStartTracing = true`

### Fixes

- Defer Session Replay startup until a foreground window is available (#7928)
- Fix race conditions in scope observer iteration and propagation context locking (#7897)
- Support stack traces for standalone clients (#7817)
- Prevent SessionTracker crash with profiling (#7927)
  - Reevaluation of sampling decision is only done for new sessions.
- Call SentrySessionListener on main thread (#7917)

## 9.13.0

### Fixes

- Fix crash with AVAssetDownloadTask in urlSessionTask:setState: (#7891)
- Prevent crash-loop from malformed recrash reports (#7892)

### Features

- Prevent memory strings in stack overflow crash reports (#7841)
- Add Set conformance to SentryAttributeValue (#7876)

## 9.12.1

> [!WARNING]
> ⚠️ **Known Issue:** Sentry Cocoa **9.12.0+** crashes apps using `AVAssetDownloadURLSession` ([#7886](https://github.com/getsentry/sentry-cocoa/issues/7886)). Fixed in [**9.13.0**](https://github.com/getsentry/sentry-cocoa/releases/tag/9.13.0).

### Fixes

- Prevent memory strings in stack overflow crash reports (#7841)
- Report crashed thread for null function calls (#7866)
- Add depth limits to data sanitization and JSON encoder (#7857)
- Moved `BinaryImageCache` initialization to a background thread to reduce blocking on dyld reader locks on the main thread (#7823)
- Init vars before `task_threads` and `vm_deallocate` (#7858)
- Handle extra length call in `SentryInvalidJSONString` (#7859)

## 9.12.0

> [!WARNING]
> ⚠️ **Known Issue:** Sentry Cocoa **9.12.0+** crashes apps using `AVAssetDownloadURLSession` ([#7886](https://github.com/getsentry/sentry-cocoa/issues/7886)). Fixed in [**9.13.0**](https://github.com/getsentry/sentry-cocoa/releases/tag/9.13.0).

> [!WARNING]
> This release promotes Metrics out of experimental and **removes** `options.experimental.enableMetrics` and `options.experimental.beforeSendMetric`. If you set either of these, your app will fail to compile after upgrading.
> Migrate to `options.enableMetrics` and `options.beforeSendMetric` (top-level on `Options`) — the defaults and behavior are unchanged.

> [!WARNING]
> Session Replay now runs on iOS 26 with Liquid Glass. Previously, the SDK auto-disabled Session Replay on iOS 26 builds that adopted Liquid Glass (built with Xcode 26+ and `UIDesignRequiresCompatibility` not set). Now that the underlying redaction issues have been addressed, replays will be captured in those environments — verify your masking still meets your privacy requirements.
> If you want to keep Session Replay disabled on Liquid Glass builds, you will need to gate the sample rates yourself. For reference, see how the SDK used to perform the check: https://github.com/getsentry/sentry-cocoa/blob/adef457c1344e5efda4b74a1f33913d4d49ef7e0/Sources/Swift/Integrations/SessionReplay/SentrySessionReplayEnvironmentChecker.swift
>
> Example — disable Session Replay when Liquid Glass is active:
>
> ```swift
> import Sentry
>
> SentrySDK.start { options in
>     options.dsn = "___PUBLIC_DSN___"
>
>     var sessionRate: Float = 0.2
>     var errorRate: Float = 1.0
>
>     if #available(iOS 26.0, *) {
>         let compatibilityMode = Bundle.main.object(forInfoDictionaryKey: "UIDesignRequiresCompatibility") as? Bool ?? false
>         let xcodeVersion = Int(Bundle.main.object(forInfoDictionaryKey: "DTXcode") as? String ?? "") ?? 0
>         let builtWithXcode26OrLater = xcodeVersion >= 2600
>         let liquidGlassActive = builtWithXcode26OrLater && !compatibilityMode
>         if liquidGlassActive {
>             sessionRate = 0
>             errorRate = 0
>         }
>     }
>
>     options.sessionReplay.sessionSampleRate = sessionRate
>     options.sessionReplay.onErrorSampleRate = errorRate
> }
> ```

### Improvements

- Remove `enableSessionReplayInUnreliableEnvironment` experimental option and the environment checker that temporarily disabled Session Replay on iOS 26 (#7831)

### Features

- Make feature Metrics generally available, moving experimental options to top-level options (#7843)
- Add Session Replay network details capture, including request/response headers and bodies extraction (#7580, #7582, #7584, #7585, #7588, #7590, #7854)
  - Find more details [here](https://docs.sentry.dev/platforms/apple/guides/ios/session-replay/configuration/).

### Fixes

- Fix infinite loop in `sentrycrashfu_readBytesFromFD` when `read()` returns EOF on a truncated file (#7853)
- Disable app hang and watchdog termination tracking in Notification Service Extensions (#7818)
- Fix JSON encoding of infinite numeric values in crash reports (#7802)
- Fix race condition in `SentryFramesTracker` listeners causing `EXC_BAD_ACCESS` in `NSConcreteHashTable removeItem:` when a listener is deallocated on a background thread (#7839)

## 9.11.0

### Features

- Track low power mode in device context (#7777)

### Fixes

- Added `Package@swift-6.2.swift` to avoid issues with unsafe build flags on SPM > 6.2 (#7778)
- Detect development builds via provisioning profile and debugger attachment (#7702)
- Keep replayType as `buffer` for Session Replay triggered by an error (#7804)
- Fix race condition in scope observer notifications causing EXC_BAD_ACCESS during cold launch (#7807)
- Unsubscribe to system event during background to avoid reporting breadcrumbs with wrong timestamps on return to foreground (#7702)
- Fix SwiftUI's images and text redaction in iOS 26 (#7781)
- Add foreground state to app context in app hang events (#7801)

## 9.10.0

### Features

- Prevent cross-organization trace continuation (#7705)
  - By default, the SDK now extracts the organization ID from the DSN (e.g. `o123.ingest.sentry.io`) and compares it with the `sentry-org_id` value in incoming baggage headers. When the two differ, the SDK starts a fresh trace instead of continuing the foreign one. This guards against accidentally linking traces across organizations.
  - New option `strictTraceContinuation` (default `false`): when enabled, both the SDK's org ID **and** the incoming baggage org ID must be present and match for a trace to be continued. Traces with a missing org ID on either side are rejected.
  - New option `orgId`: allows explicitly setting the organization ID for self-hosted and Relay setups where it cannot be extracted from the DSN.

### Fixes

- Scope clipOut masking to active clip bounds (#7780)
- Fix AOT interop with managed .NET runtimes (#6193)

## 9.9.0

### Features

- Add `attachAllThreads` option to `SentryOptions` to attach full stack traces for all threads to captured events (#7764)
- Add per-call `attachAllThreads` parameter to `capture(event:)`, `capture(error:)`, `capture(exception:)`, and `capture(message:)` to override the global option for specific calls (#7767)

### Improvements

- Align app lifecycle breadcrumb `state` values with `in_foreground`/`is_active` app context (#7703)
  - **Breaking**: Update any `beforeBreadcrumb` filters or dashboard queries matching on the old `state` values:
    - iOS/tvOS/visionOS
      - `didBecomeActive` state changed from `foreground` to `active`
    - macOS
      - `didBecomeActive` state changed from `foreground` to `active`
      - `willResignActive` state changed from `background` to `inactive`

### Fixes

- Copy incoming tags dict to prevent crash (#7763)
- Per-instance unmaskView propagates to child views (#7733)
  - **Warning:** If you relied on children of an unmasked view still being individually redacted, verify your Session Replay redaction after updating. An explicit `maskView(_:)` on a descendant still takes precedence.
- Move SessionTracker file I/O off the main thread (#7704)

## 9.8.0

### Features

- Add `SentrySDK.lastRunStatus` to distinguish unknown, no-crash and crash (#7469)

### Fixes

- Make SentryBreadcrumb thread-safe to prevent crashes in addBreadcrumb (#7665)

## 9.7.0

### Features

- Show feedback form on device shake (#7579)
  - Enable via `config.useShakeGesture = true` in `SentryUserFeedbackConfiguration`
  - Uses UIKit's built-in shake detection — no special permissions required
- Add package traits for UI framework opt-out (#7578).
  When building from source with Swift 6.1+ (using `Package@swift-6.1.swift`), you can enable the `NoUIFramework` trait to avoid linking UIKit or AppKit. Use this for command-line tools, headless server contexts, or other environments where UI frameworks are unavailable.
  In Xcode 26.4 and later, add the Sentry package as a dependency and the `SentrySPM` product, then enable the `NoUIFramework` trait on the package reference (Package Dependencies → select Sentry → Traits).
- Metric kit app hangs now report a full flamegraph rather than just one stacktrace during the hang. (#7185)

### Fixes

- Capture transactions that finish during the launch profiling window instead of silently discarding them (#7602)
- Capture instance and class method `[NSApplication _crashOnException]` exceptions (#7510)

## 9.6.0

### Features

- Add watchdog termination hang tracker using RunLoop observer. Can be enabled by setting `options.experimental.enableWatchdogTerminationsV2 = true` (#7464)

### Fixes

- Preserve NSException and C++ exception reason instead of overwriting with unrelated `crash_info_message` from `libswiftCore.dylib` (#7515)
- Fix unexpected null value when unwrapping view controller window (#7508)

## 9.5.1

### Fixes

- Don't report NSException subclasses as C++ exceptions (#7420)
- Write reports on concurrent crashes (#7340)
- Resolve data race crash in monitorCachedData (#7423)
- Don't finish network spans for suspended URL session tasks (#7471)
- Use different fallback for when MetricKit does not have file path (#7473)
- Remove launch profiling logs in sandboxed environments breaking CLI tools (#7294)

## 9.5.0

### Features

- Enable MetricKit Integration for visionOS (#7466)

### Improvements

- The watchdog termination integration uses a runloop observer instead of fixed interval main thread work to avoid creating a busy runloop ([#7464](https://github.com/getsentry/sentry-cocoa/pull/7464))

### Fixes

- SentryRedactViewHelper had been erroneously made public, it has been removed from the public interface (#7474)
- Write reports on concurrent crashes (#7340)

## 9.4.1

### Improvements

- Record client report when dropping in `beforeSendLog` (#7379)

### Fixes

- Fix user attributes from scope being omitted from logs when sendDefaultPII is false (#7437)
- Cleanup SessionReplay when maximum duration reached (#7421)
- Fix App hangs report with high durations (#7354)

### Deprecations

- The `SentrySwiftUI` module is now deprecated. All SwiftUI APIs (`SentryTracedView`, `sentryTrace()`, `sentryReplayMask()`, `sentryReplayUnmask()`) have been merged into the main `Sentry` module. You can replace `import SentrySwiftUI` with `import Sentry` in your code. The `SentrySwiftUI` module still works via a re-export but will be removed in the next major version. (#7422)

## 9.4.0

### Breaking Changes

- `Sentry.metrics.count(..)` does not support units, therefore the API was incorrectly defined. This breaking change applies to a method marked as experimental. (#7358)

### Fixes

- Fix mismatch of `in_foreground` app context (#7188) The app context `in_foreground` for handled and unhandled events was sometimes different. This is fixed now by aligning the implementation and adding a new `is_active` app context field.
- Fix missing stack traces for `NSException` objects reported via `NSApplication.shared.reportException(_:)` on macOS (#7284)

## 9.3.0

### Features

- Transport logs error message for HTTP 413 responses (#7261)
- Add `installGroupsOverride` parameter to `CheckForUpdateParams` and `installGroups` property to `ReleaseInfo` for SentryDistribution (#7278)

### Fixes

- Fix deadlock in network reachability observer when restarting the SDK (#7246)

## 9.2.0

> [!IMPORTANT]
> This release contains a bug fix to only include user attributes in logs when `options.sendDefaultPii = true`.
> Make sure to enable the option in case you rely on these attributes to be set.

### Features

- Add options `options.sessionReplay.includedViewClasses` and `options.sessionReplay.excludedViewClasses` to ignore views from subtree traversal (#7063)
- Add isiOSAppOnVisionOS, isiOSAppOnMac, isMacCatalystApp to device context #6939
- Add integration to collect Metrics, enabled by default. Can be disabled by setting `options.experimental.enableMetrics = false` (#6956)
- Add implementation for Metrics Protocol with modification of items in `options.experimental.beforeSendMetrics` (#6960)
- Add `Sentry.metrics.count(..)`, `Sentry.metrics.distribution(..)` and `Sentry.metrics.gauge(..)` to public API (#6957)
- Add flushing of Metrics to `SentrySDK.flush()` (#7182)

### Fixes

- Encode SwiftUI internal class names in session replay redaction to avoid false-positive App Store review rejections (#7123)
- The transport now correctly discard envelopes on 4xx and 5xx responses and records client reports `send_error` (#6618) This also fixes edge cases in which the SDK kept retrying sending a faulty envelope until the offline cache overflowed.
- Change default attributes of Logs to only include user attributes when `options.sendDefaultPii = true` (#7055)
- Rename log attribute `sentry.trace.parent_span_id` to `span_id` (#7055)
- Fixes stacktraces for MetricKit events (#6908)
- Fix `raw_description` in `runtime` context on Mac Catalyst (#7082)
- Deprecates `configureDarkTheme` for user feedback (#7114)
- Fix incorrect variable assignment for 'sampled' key (#7120)
- Resolve crash in caused by calling `SentryFramesTracker.removeListener(_:)` (#7155)

## 9.1.0

> [!Warning]
> The class `SentryDsn` has been converted from Objective-C to Swift. While the public API remains the same, you might have to remove imports of the `SentryDsn.h` from your Objective-C code.
> We acknowledge that this is a breaking change introduced in a minor release, but it should have been part of the major release 9.0.0 already before - apologies for any inconveniences caused.

### Breaking Changes

- Refactored type `SentryDsn` from Objective-C to Swift, removing the `SentryDsn.h` from the public header files.

### Features

- Add attributes data to `SentryScope` (#6830)
- Add `SentryScope` attributes into log messages (#6834)

### Improvements

- Flush Logs on `WillTerminate` or `WillResignActive` Notifications (#6909)

### Fixes

- Save app context information (release name, dist, environment) on app hang events before saving to disk to prevent incorrect version information when an app hang turns fatal (#6998)
- Disabled automatic session tracking in system extensions to prevent extension blocking and unwanted dock icon behavior (#6962) (#6962)
- Fixes crash when null values are passed to `UIApplication sendAction:to:from:forEvent:` (#6970)
- Fixes `user.id` not set to installationId if no user is set (#7005)

## 9.0.0

This changelog lists every breaking change. For a high-level overview and upgrade guidance, see the [migration guide](https://docs.sentry.io/platforms/apple/migration/).

### Breaking Changes

- Bumped minimum OS versions to iOS 15.0, macOS 10.14.0, tvOS 15.0, visionOS 1.0, and watchOS 8.0 (#6873)
- Moves `SentryEventDecoder` to SPI (#6365)
- Makes `PreviewRedactOptions`, `SentryProfileOptions`, `SentryRedactViewHelper`, `SentryViewScreenshotOptions`, `SentryReplayOptions`, `SentryUserFeedbackConfiguration`, `SentryUserFeedbackFormConfiguration`, `SentryUserFeedbackThemeConfiguration`, `SentryUserFeedbackWidgetConfiguration`, `SentryFeedback`, and `SentryExperimentalOptions` `final` (#6365)
- Removes Decodable conformances from the public API of model classes (#5691)
- Removes unused SentryLogLevel (#5591)
- Removes deprecated `setExtraValue` from SentrySpan (#5864)
- Removes deprecated getStoreEndpoint (#5591)
- Remove legacy profiling, the only supported profiling is now what was known as continuous V2 (#6386)
- Removes deprecated useSpan function (#5591)
- Makes app hang tracking V2 the default only on **iOS and tvOS** and removes the option to enable/disable it (#5615). macOS still uses V1.
- Removes initializers for SentryTraceContext from the public API (#6662)
- Removes `integrations` property from `SentryOptions` (#5749)
- Removes `defaultIntegrations` function from `SentryOptions` (#6664)
- Makes `SentryEventDecodable` internal (#5808)
- The `span` property on `SentryScope` is now readonly (#5866)
- Removes `SentryIntegrationProtocol` from the API. This is not used after the removal of the `integrations` property (#6660)
- Removes deprecated SentryDebugImageProvider class (#5598)
- Properties on SentryOptions that had no effect on the WithoutUIKit variant are now removed from the API (#6644)
- Removes the SentryOptions.inAppExclude property because it had no effect (#6646)
- Removes segment property on SentryUser, SentryBaggage, and SentryTraceContext (#5638)
- Removes local symbolication when `debug=True` which fixes various deadlocks (#6562)
- Removes deprecated TraceContext initializers (#6348)
- Removes deprecated user feedback API, this is replaced with the new feedback API (#5591)
- Removes `enablePerformanceV2` option and makes this the default. The app start duration will now finish when the first frame is drawn instead of when the OS posts the UIWindowDidBecomeVisibleNotification. (#6008)
- Removes enableTracing property from SentryOptions (#5694)
- Structured Logs: Move options out of experimental (#6359)
- Remove unused `SentryFrame.instruction` property (#6504)
- Remove `uuid` and `name` of `SentryDebugMeta` (#6512) Use `debugID` instead of `uuid` and `codeFile` instead of `name`.
- Enable enablePreWarmedAppStartTracing by default (#6508). With this option enabled, the SDK collects [prewarmed app starts](https://docs.sentry.io/platforms/apple/tracing/instrumentation/automatic-instrumentation/#prewarmed-app-start-tracing).
- Set `SentryFrame.function` default to `nil` instead of `<redacted>` (#6608)
- Change `value` and `type` of `SentryException` to be nullable (#6563)
- Change the default trace context status to "ok" instead of "undefined" (#6611)
- Remove `getHash` from SentryDsn (#6605)
- The precompiled XCFramework is now built with Xcode 16. To submit to the App Store, [Apple now requires Xcode 16](https://developer.apple.com/news/upcoming-requirements/?id=02212025a).
  If you need a precompiled XCFramework built with Xcode 15, continue using Sentry SDK 8.x.x.
- Set `SentryException.type` to `nil` when `NSException` has no `reason` (#6653). The backend then can provide a proper message when there is no reason.
- Rename `SentryLog.Level` and `SentryLog.Attribute` for ObjC (#6666)
- Change `SentryFeedback` initializer to support multiple attachments (#6752)
- App hang tracking is now automatically disabled for Widgets, Live Activities, Action Extensions, (Siri) Intent Extensions, and Share Extensions (#6670).
  These components run in separate processes or sandboxes with different execution characteristics, which can cause false positive app hang reports.
- [HTTP Client errors](https://docs.sentry.io/platforms/apple/guides/ios/configuration/http-client-errors/) now mark sessions as errored (#6633)
- The Package.swift has swift-tools-version set to 6.0 (#6764)
- Converts the `SentryLevel` enum to be written in ObjC (#6802)
- Removes SentryEnvelopeItemHeader from the public API (#6870)
- Change the `http.response.status_code` for spans to int (#6896)

### Features

- Add SentryDistribution as Swift Package Manager target (#6149)
- Moves SentryClient and SentryHub to be written in Swift (#6627)
- Add option `enablePropagateTraceparent` to support OTel/W3C trace propagation (#6356)
- Move `enableFileManagerSwizzling` from experimental options to top-level options (#6592).
  This option is still disabled by default and will be enabled in a future major release.
- Move `enableDataSwizzling` from experimental options to top-level options (#6592). This option remains enabled by default.
- Add `sentry.replay_id` attribute to logs ([#6515](https://github.com/getsentry/sentry-cocoa/pull/6515))
- Structured Logs: Add log APIs to `Hub` and `Client` (#6737)
- Add options to customize UserFeedback error messages (#6790)

### Fixes

- Fixes warnings about minimum OS version being lower than Xcode supported version (#5591)
- Fixes a crash when setting configureUserFeedback to nil (#6642)
- Fix issue where the thread that generated an event could be missing when more than 100 threads are running (#6377)
- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6381)
- Rename `SentryMechanismMeta` to `SentryMechanismContext` to resolve Kotlin Multi-Platform build errors (#6607)
- Remove unnecesary dependency on `SentryCppHelper` to Sentry (#6754)
- Limit log batching to maximum 100 logs per batch (#6768)
- Fix UIWindow being possibly accessed from a background thread in SentryCrashWrapper (#6905)
- Ensure SentrySDK.close resets everything on the main thread (#6907)
- Allow transaction tags to be accessed and modified in `beforeSend` (#6910)
- Convert bools to Swift in Options code docs (#6922)

### Improvements

- Replace deprecated SCNetworkReachability with NWPathMonitor (#6019)
- Expose attachment type on `SentryAttachment` for downstream SDKs (like sentry-godot) (#6521)
- Increase attachment max size to 100MB (#6537)
- Increase maximum attachment size to 200MB (#6726)

## 9.0.0-rc.1

### Breaking Changes

- Bumped minimum OS versions to iOS 15.0, macOS 10.14.0, tvOS 15.0, visionOS 1.0, and watchOS 8.0 (#6873)
- Moves `SentryEventDecoder` to SPI (#6365)
- Makes `PreviewRedactOptions`, `SentryProfileOptions`, `SentryRedactViewHelper`, `SentryViewScreenshotOptions`, `SentryReplayOptions`, `SentryUserFeedbackConfiguration`, `SentryUserFeedbackFormConfiguration`, `SentryUserFeedbackThemeConfiguration`, `SentryUserFeedbackWidgetConfiguration`, `SentryFeedback`, and `SentryExperimentalOptions` `final` (#6365)
- Removes Decodable conformances from the public API of model classes (#5691)
- Removes unused SentryLogLevel (#5591)
- Removes deprecated `setExtraValue` from SentrySpan (#5864)
- Removes deprecated getStoreEndpoint (#5591)
- Remove legacy profiling, the only supported profiling is now what was known as continuous V2 (#6386)
- Removes deprecated useSpan function (#5591)
- Makes app hang tracking V2 the default and removes the option to enable/disable it (#5615)
- Removes initializers for SentryTraceContext from the public API (#6662)
- Removes `integrations` property from `SentryOptions` (#5749)
- Removes `defaultIntegrations` function from `SentryOptions` (#6664)
- Makes `SentryEventDecodable` internal (#5808)
- The `span` property on `SentryScope` is now readonly (#5866)
- Removes `SentryIntegrationProtocol` from the API. This is not used after the removal of the `integrations` property (#6660)
- Removes deprecated SentryDebugImageProvider class (#5598)
- Properties on SentryOptions that had no effect on the WithoutUIKit variant are now removed from the API (#6644)
- Removes the SentryOptions.inAppExclude property because it had no effect (#6646)
- Removes segment property on SentryUser, SentryBaggage, and SentryTraceContext (#5638)
- Removes local symbolication when `debug=True` which fixes various deadlocks (#6562)
- Removes deprecated TraceContext initializers (#6348)
- Removes deprecated user feedback API, this is replaced with the new feedback API (#5591)
- Removes `enablePerformanceV2` option and makes this the default. The app start duration will now finish when the first frame is drawn instead of when the OS posts the UIWindowDidBecomeVisibleNotification. (#6008)
- Removes enableTracing property from SentryOptions (#5694)
- Structured Logs: Move options out of experimental (#6359)
- Remove unused `SentryFrame.instruction` property (#6504)
- Remove `uuid` and `name` of `SentryDebugMeta` (#6512) Use `debugID` instead of `uuid` and `codeFile` instead of `name`.
- Enable enablePreWarmedAppStartTracing by default (#6508). With this option enabled, the SDK collects [prewarmed app starts](https://docs.sentry.io/platforms/apple/tracing/instrumentation/automatic-instrumentation/#prewarmed-app-start-tracing).
- Set `SentryFrame.function` default to `nil` instead of `<redacted>` (#6608)
- Change `value` and `type` of `SentryException` to be nullable (#6563)
- Change the default trace context status to "ok" instead of "undefined" (#6611)
- Remove `getHash` from SentryDsn (#6605)
- The precompiled XCFramework is now built with Xcode 16. To submit to the App Store, [Apple now requires Xcode 16](https://developer.apple.com/news/upcoming-requirements/?id=02212025a).
  If you need a precompiled XCFramework built with Xcode 15, continue using Sentry SDK 8.x.x.
- Set `SentryException.type` to `nil` when `NSException` has no `reason` (#6653). The backend then can provide a proper message when there is no reason.
- Rename `SentryLog.Level` and `SentryLog.Attribute` for ObjC (#6666)
- Change `SentryFeedback` initializer to support multiple attachments (#6752)
- App hang tracking is now automatically disabled for Widgets, Live Activities, Action Extensions, (Siri) Intent Extensions, and Share Extensions (#6670).
  These components run in separate processes or sandboxes with different execution characteristics, which can cause false positive app hang reports.
- [HTTP Client errors](https://docs.sentry.io/platforms/apple/guides/ios/configuration/http-client-errors/) now mark sessions as errored (#6633)
- The Package.swift has swift-tools-version set to 6.0 (#6764)
- Converts the `SentryLevel` enum to be written in ObjC (#6802)
- Removes SentryEnvelopeItemHeader from the public API (#6870)

### Features

- Add SentryDistribution as Swift Package Manager target (#6149)
- Moves SentryClient and SentryHub to be written in Swift (#6627)
- Add option `enablePropagateTraceparent` to support OTel/W3C trace propagation (#6356)
- Move `enableFileManagerSwizzling` from experimental options to top-level options (#6592).
  This option is still disabled by default and will be enabled in a future major release.
- Move `enableDataSwizzling` from experimental options to top-level options (#6592). This option remains enabled by default.
- Add `sentry.replay_id` attribute to logs ([#6515](https://github.com/getsentry/sentry-cocoa/pull/6515))
- Structured Logs: Add log APIs to `Hub` and `Client` (#6737)

### Fixes

- Fixes warnings about minimum OS version being lower than Xcode supported version (#5591)
- Fixes a crash when setting configureUserFeedback to nil (#6642)
- Fix issue where the thread that generated an event could be missing when more than 100 threads are running (#6377)
- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6381)
- Rename `SentryMechanismMeta` to `SentryMechanismContext` to resolve Kotlin Multi-Platform build errors (#6607)
- Remove unnecesary dependency on `SentryCppHelper` to Sentry (#6754)
- Limit log batching to maximum 100 logs per batch (#6768)

### Improvements

- Replace deprecated SCNetworkReachability with NWPathMonitor (#6019)
- Expose attachment type on `SentryAttachment` for downstream SDKs (like sentry-godot) (#6521)
- Increase attachment max size to 100MB (#6537)
- Increase maximum attachment size to 200MB (#6726)

## 9.0.0-rc.0

### Breaking Changes

- Bumped minimum OS versions to iOS 15.0, macOS 12.0, tvOS 15.0, visionOS 1.0, and watchOS 8.0
- Moves `SentryEventDecoder` to SPI (#6365)
- Makes `PreviewRedactOptions`, `SentryProfileOptions`, `SentryRedactViewHelper`, `SentryViewScreenshotOptions`, `SentryReplayOptions`, `SentryUserFeedbackConfiguration`, `SentryUserFeedbackFormConfiguration`, `SentryUserFeedbackThemeConfiguration`, `SentryUserFeedbackWidgetConfiguration`, `SentryFeedback`, and `SentryExperimentalOptions` `final` (#6365)
- Removes Decodable conformances from the public API of model classes (#5691)
- Removes unused SentryLogLevel (#5591)
- Removes deprecated `setExtraValue` from SentrySpan (#5864)
- Removes deprecated getStoreEndpoint (#5591)
- Remove legacy profiling, the only supported profiling is now what was known as continuous V2 (#6386)
- Removes deprecated useSpan function (#5591)
- Makes app hang tracking V2 the default and removes the option to enable/disable it (#5615)
- Removes initializers for SentryTraceContext from the public API (#6662)
- Removes `integrations` property from `SentryOptions` (#5749)
- Removes `defaultIntegrations` function from `SentryOptions` (#6664)
- Makes `SentryEventDecodable` internal (#5808)
- The `span` property on `SentryScope` is now readonly (#5866)
- Removes `SentryIntegrationProtocol` from the API. This is not used after the removal of the `integrations` property (#6660)
- Removes deprecated SentryDebugImageProvider class (#5598)
- Properties on SentryOptions that had no effect on the WithoutUIKit variant are now removed from the API (#6644)
- Removes the SentryOptions.inAppExclude property because it had no effect (#6646)
- Removes segment property on SentryUser, SentryBaggage, and SentryTraceContext (#5638)
- Removes local symbolication when `debug=True` which fixes various deadlocks (#6562)
- Removes deprecated TraceContext initializers (#6348)
- Removes deprecated user feedback API, this is replaced with the new feedback API (#5591)
- Removes `enablePerformanceV2` option and makes this the default. The app start duration will now finish when the first frame is drawn instead of when the OS posts the UIWindowDidBecomeVisibleNotification. (#6008)
- Removes enableTracing property from SentryOptions (#5694)
- Structured Logs: Move options out of experimental (#6359)
- Remove unused `SentryFrame.instruction` property (#6504)
- Remove `uuid` and `name` of `SentryDebugMeta` (#6512) Use `debugID` instead of `uuid` and `codeFile` instead of `name`.
- Enable enablePreWarmedAppStartTracing by default (#6508). With this option enabled, the SDK collects [prewarmed app starts](https://docs.sentry.io/platforms/apple/tracing/instrumentation/automatic-instrumentation/#prewarmed-app-start-tracing).
- Set `SentryFrame.function` default to `nil` instead of `<redacted>` (#6608)
- Change `value` and `type` of `SentryException` to be nullable (#6563)
- Change the default trace context status to "ok" instead of "undefined" (#6611)
- Remove `getHash` from SentryDsn (#6605)
- The precompiled XCFramework is now built with Xcode 16. To submit to the App Store, [Apple now requires Xcode 16](https://developer.apple.com/news/upcoming-requirements/?id=02212025a).
  If you need a precompiled XCFramework built with Xcode 15, continue using Sentry SDK 8.x.x.
- Set `SentryException.type` to `nil` when `NSException` has no `reason` (#6653). The backend then can provide a proper message when there is no reason.
- Rename `SentryLog.Level` and `SentryLog.Attribute` for ObjC (#6666)
- Change `SentryFeedback` initializer to support multiple attachments (#6752)
- App hang tracking is now automatically disabled for Widgets, Live Activities, Action Extensions, (Siri) Intent Extensions, and Share Extensions (#6670).
  These components run in separate processes or sandboxes with different execution characteristics, which can cause false positive app hang reports.
- [HTTP Client errors](https://docs.sentry.io/platforms/apple/guides/ios/configuration/http-client-errors/) now mark sessions as errored (#6633)
- The Package.swift has swift-tools-version set to 6.0 (#6764)
- Converts the `SentryLevel` enum to be written in ObjC (#6802)

### Features

- Add SentryDistribution as Swift Package Manager target (#6149)
- Moves SentryClient and SentryHub to be written in Swift (#6627)
- Add option `enablePropagateTraceparent` to support OTel/W3C trace propagation (#6356)
- Move `enableFileManagerSwizzling` from experimental options to top-level options (#6592).
  This option is still disabled by default and will be enabled in a future major release.
- Move `enableDataSwizzling` from experimental options to top-level options (#6592). This option remains enabled by default.
- Add `sentry.replay_id` attribute to logs ([#6515](https://github.com/getsentry/sentry-cocoa/pull/6515))
- Structured Logs: Add log APIs to `Hub` and `Client` (#6737)

### Fixes

- Fixes warnings about minimum OS version being lower than Xcode supported version (#5591)
- Fixes a crash when setting configureUserFeedback to nil (#6642)
- Fix issue where the thread that generated an event could be missing when more than 100 threads are running (#6377)
- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6381)
- Rename `SentryMechanismMeta` to `SentryMechanismContext` to resolve Kotlin Multi-Platform build errors (#6607)
- Remove unnecesary dependency on `SentryCppHelper` to Sentry (#6754)
- Limit log batching to maximum 100 logs per batch (#6768)

### Improvements

- Replace deprecated SCNetworkReachability with NWPathMonitor (#6019)
- Expose attachment type on `SentryAttachment` for downstream SDKs (like sentry-godot) (#6521)
- Increase attachment max size to 100MB (#6537)
- Increase maximum attachment size to 200MB (#6726)

## 9.0.0-alpha.1

### Breaking Changes

- Bumped minimum OS versions to iOS 15.0, macOS 12.0, tvOS 15.0, visionOS 1.0, and watchOS 8.0
- Moves `SentryEventDecoder` to SPI (#6365)
- Makes `PreviewRedactOptions`, `SentryProfileOptions`, `SentryRedactViewHelper`, `SentryViewScreenshotOptions`, `SentryReplayOptions`, `SentryUserFeedbackConfiguration`, `SentryUserFeedbackFormConfiguration`, `SentryUserFeedbackThemeConfiguration`, `SentryUserFeedbackWidgetConfiguration`, `SentryFeedback`, and `SentryExperimentalOptions` `final` (#6365)
- Removes Decodable conformances from the public API of model classes (#5691)
- Removes unused SentryLogLevel (#5591)
- Removes deprecated `setExtraValue` from SentrySpan (#5864)
- Removes deprecated getStoreEndpoint (#5591)
- Remove legacy profiling, the only supported profiling is now what was known as continuous V2 (#6386)
- Removes deprecated useSpan function (#5591)
- Makes app hang tracking V2 the default and removes the option to enable/disable it (#5615)
- Removes initializers for SentryTraceContext from the public API (#6662)
- Removes `integrations` property from `SentryOptions` (#5749)
- Removes `defaultIntegrations` function from `SentryOptions` (#6664)
- Makes `SentryEventDecodable` internal (#5808)
- The `span` property on `SentryScope` is now readonly (#5866)
- Removes `SentryIntegrationProtocol` from the API. This is not used after the removal of the `integrations` property (#6660)
- Removes deprecated SentryDebugImageProvider class (#5598)
- Properties on SentryOptions that had no effect on the WithoutUIKit variant are now removed from the API (#6644)
- Removes the SentryOptions.inAppExclude property because it had no effect (#6646)
- Removes segment property on SentryUser, SentryBaggage, and SentryTraceContext (#5638)
- Removes local symbolication when `debug=True` which fixes various deadlocks (#6562)
- Removes deprecated TraceContext initializers (#6348)
- Removes deprecated user feedback API, this is replaced with the new feedback API (#5591)
- Removes `enablePerformanceV2` option and makes this the default. The app start duration will now finish when the first frame is drawn instead of when the OS posts the UIWindowDidBecomeVisibleNotification. (#6008)
- Removes enableTracing property from SentryOptions (#5694)
- Structured Logs: Move options out of experimental (#6359)
- Remove unused `SentryFrame.instruction` property (#6504)
- Remove `uuid` and `name` of `SentryDebugMeta` (#6512) Use `debugID` instead of `uuid` and `codeFile` instead of `name`.
- Enable enablePreWarmedAppStartTracing by default (#6508). With this option enabled, the SDK collects [prewarmed app starts](https://docs.sentry.io/platforms/apple/tracing/instrumentation/automatic-instrumentation/#prewarmed-app-start-tracing).
- Set `SentryFrame.function` default to `nil` instead of `<redacted>` (#6608)
- Change `value` and `type` of `SentryException` to be nullable (#6563)
- Change the default trace context status to "ok" instead of "undefined" (#6611)
- Remove `getHash` from SentryDsn (#6605)
- The precompiled XCFramework is now built with Xcode 16. To submit to the App Store, [Apple now requires Xcode 16](https://developer.apple.com/news/upcoming-requirements/?id=02212025a).
  If you need a precompiled XCFramework built with Xcode 15, continue using Sentry SDK 8.x.x.
- Set `SentryException.type` to `nil` when `NSException` has no `reason` (#6653). The backend then can provide a proper message when there is no reason.
- Rename `SentryLog.Level` and `SentryLog.Attribute` for ObjC (#6666)
- Change `SentryFeedback` initializer to support multiple attachments (#6752)

### Fixes

- Fixes warnings about minimum OS version being lower than Xcode supported version (#5591)
- Fixes a crash when setting configureUserFeedback to nil (#6642)
- Fix issue where the thread that generated an event could be missing when more than 100 threads are running (#6377)
- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6381)
- Rename `SentryMechanismMeta` to `SentryMechanismContext` to resolve Kotlin Multi-Platform build errors (#6607)
- Remove unnecesary dependency on `SentryCppHelper` to Sentry (#6754)

### Improvements

- Replace deprecated SCNetworkReachability with NWPathMonitor (#6019)
- Expose attachment type on `SentryAttachment` for downstream SDKs (like sentry-godot) (#6521)
- Increase attachment max size to 100MB (#6537)
- Increase maximum attachment size to 200MB (#6726)

### Features

- Add SentryDistribution as Swift Package Manager target (#6149)
- Moves SentryClient and SentryHub to be written in Swift (#6627)
- Add option `enablePropagateTraceparent` to support OTel/W3C trace propagation (#6356)
- Move `enableFileManagerSwizzling` from experimental options to top-level options (#6592).
  This option is still disabled by default and will be enabled in a future major release.
- Move `enableDataSwizzling` from experimental options to top-level options (#6592). This option remains enabled by default.
- Add `sentry.replay_id` attribute to logs ([#6515](https://github.com/getsentry/sentry-cocoa/pull/6515))
- Structured Logs: Add log APIs to `Hub` and `Client` (#6737)

## 9.0.0-alpha.0

### Breaking Changes

- Moves `SentryEventDecoder` to SPI (#6365)
- Makes `PreviewRedactOptions`, `SentryProfileOptions`, `SentryRedactViewHelper`, `SentryViewScreenshotOptions`, `SentryReplayOptions`, `SentryUserFeedbackConfiguration`, `SentryUserFeedbackFormConfiguration`, `SentryUserFeedbackThemeConfiguration`, `SentryUserFeedbackWidgetConfiguration`, `SentryFeedback`, and `SentryExperimentalOptions` `final` (#6365)
- Removes Decodable conformances from the public API of model classes (#5691)
- Removes unused SentryLogLevel (#5591)
- Removes deprecated `setExtraValue` from SentrySpan (#5864)
- Removes deprecated getStoreEndpoint (#5591)
- Remove legacy profiling, the only supported profiling is now what was known as continuous V2 (#6386)
- Removes deprecated useSpan function (#5591)
- Makes app hang tracking V2 the default and removes the option to enable/disable it (#5615)
- Removes initializers for SentryTraceContext from the public API (#6662)
- Removes `integrations` property from `SentryOptions` (#5749)
- Removes `defaultIntegrations` function from `SentryOptions` (#6664)
- Makes `SentryEventDecodable` internal (#5808)
- Removes `SentryIntegrationProtocol` from the API. This is not used after the removal of the `integrations` property (#6660)
- Removes deprecated SentryDebugImageProvider class (#5598)
- Properties on SentryOptions that had no effect on the WithoutUIKit variant are now removed from the API (#6644)
- Removes the SentryOptions.inAppExclude property because it had no effect (#6646)
- Removes segment property on SentryUser, SentryBaggage, and SentryTraceContext (#5638)
- Removes local symbolication when `debug=True` which fixes various deadlocks (#6562)
- Removes deprecated TraceContext initializers (#6348)
- Removes deprecated user feedback API, this is replaced with the new feedback API (#5591)
- Removes `enablePerformanceV2` option and makes this the default. The app start duration will now finish when the first frame is drawn instead of when the OS posts the UIWindowDidBecomeVisibleNotification. (#6008)
- Removes enableTracing property from SentryOptions (#5694)
- Structured Logs: Move options out of experimental (#6359)
- Remove unused `SentryFrame.instruction` property (#6504)
- Remove `uuid` and `name` of `SentryDebugMeta` (#6512) Use `debugID` instead of `uuid` and `codeFile` instead of `name`.
- Enable enablePreWarmedAppStartTracing by default (#6508). With this option enabled, the SDK collects [prewarmed app starts](https://docs.sentry.io/platforms/apple/tracing/instrumentation/automatic-instrumentation/#prewarmed-app-start-tracing).
- Set `SentryFrame.function` default to `nil` instead of `<redacted>` (#6608)
- Change `value` and `type` of `SentryException` to be nullable (#6563)
- Change the default trace context status to "ok" instead of "undefined" (#6611)
- Remove `getHash` from SentryDsn (#6605)
- The precompiled XCFramework is now built with Xcode 16. To submit to the App Store, [Apple now requires Xcode 16](https://developer.apple.com/news/upcoming-requirements/?id=02212025a).
  If you need a precompiled XCFramework built with Xcode 15, continue using Sentry SDK 8.x.x.
- Set `SentryException.type` to `nil` when `NSException` has no `reason` (#6653). The backend then can provide a proper message when there is no reason.
- Rename `SentryLog.Level` and `SentryLog.Attribute` for ObjC (#6666)

### Fixes

- Fixes warnings about minimum OS version being lower than Xcode supported version (#5591)
- Fixes a crash when setting configureUserFeedback to nil (#6642)
- Fix issue where the thread that generated an event could be missing when more than 100 threads are running (#6377)
- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6381)
- Rename `SentryMechanismMeta` to `SentryMechanismContext` to resolve Kotlin Multi-Platform build errors (#6607)

### Improvements

- Replace deprecated SCNetworkReachability with NWPathMonitor (#6019)
- Expose attachment type on `SentryAttachment` for downstream SDKs (like sentry-godot) (#6521)
- Increase attachment max size to 100MB (#6537)

### Features

- Add SentryDistribution as Swift Package Manager target (#6149)
- Moves SentryClient and SentryHub to be written in Swift (#6627)
- Add option `enablePropagateTraceparent` to support OTel/W3C trace propagation (#6356)
- Move `enableFileManagerSwizzling` from experimental options to top-level options (#6592).
  This option is still disabled by default and will be enabled in a future major release.
- Move `enableDataSwizzling` from experimental options to top-level options (#6592). This option remains enabled by default.
- Add `sentry.replay_id` attribute to logs ([#6515](https://github.com/getsentry/sentry-cocoa/pull/6515))

## 8.58.0

### Features

- Add options `options.sessionReplay.includedViewClasses` and `options.sessionReplay.excludedViewClasses` to ignore views from subtree traversal (#7063)

### Fixes

- Encode SwiftUI internal class names in session replay redaction to avoid false-positive App Store review rejections (#7123)

## 8.57.3

### Fixes

- Remove unnecesary dependency on `SentryCppHelper` to Sentry (#6754) (#6761)
- Resolve SDK crash caused by UIPrintPanelViewController incorrectly casting to UISplitViewController (#6771)

## 8.57.2

### Fixes

- Fix rendering method for fast view rendering (#6360)
- Session Replay masking improvements (#6292)
  - Fix SwiftUI.List background decoration view causing incorrect clipping of screen content
  - Fix sublayer rendering order by properly sorting by zPosition with insertion order as tie-breaker
  - Fix UISwitch internal images being incorrectly redacted
  - Fix UITextField placeholder text (UITextFieldLabel) not being detected for redaction
  - Use string-based class comparison to avoid triggering Objective-C +initialize on background threads
  - Add layer class filtering for views used in multiple contexts (e.g., SwiftUI.\_UIGraphicsView)
  - Improve transform calculations for views with custom anchor points
  - Fix axis-aligned transform detection for optimized opaque view clipping
- Fix conversion of frame rate to time interval for session replay (#6623)
- Change Session Replay masking to prevent semi‑transparent full‑screen overlays from clearing redactions by making opaque clipping stricter (#6629)
  Views now need to be fully opaque (view and layer backgrounds with alpha == 1) and report opaque to qualify for clip‑out.
  This avoids leaks at the cost of fewer clip‑out optimizations.

## 8.57.1

### Fixes

- Fix crash from accessing UITouch instances from background thread in SentryTouchTracker (#6584)
- Disable SessionSentryReplayIntegration if the environment is unsafe [#6573]
- Fix crash when last replay info is missing some keys [#6577]

## 8.57.0

> [!Warning]
> **Session Replay is disabled by default on iOS 26.0+ with Xcode 26.0+ to prevent PII leaks**
>
> Due to potential masking issues introduced by Apple's Liquid Glass rendering changes in iOS 26.0, Session Replay is now **automatically disabled** on apps running iOS 26.0+ when built with Xcode 26.0 or later. This is a defensive measure to protect user privacy and prevent potential PII leaks until masking is reliably supported.
>
> Session replay will work normally if:
>
> - Your app runs on iOS versions older than 26.0, OR
> - Your app is built with Xcode versions older than 26.0, OR
> - Your app explicitly sets `UIDesignRequiresCompatibility` to `YES` in `Info.plist`
>
> **Override (use with caution):** If you understand the PII risks and want to enable session replay anyway, you can set:
>
> ```swift
> options.experimental.enableSessionReplayInUnreliableEnvironment = true
> ```
>
> This experimental override option will be removed in a future minor version once the masking issues are resolved.

### Fixes

- Fix wrong Frame Delay when becoming active, which lead to false reported app hangs when the app moves to the foreground after being in the background (#6393)
- Session replay is now automatically disabled in environments with unreliable masking to prevent PII leaks (#6389)
  - Detects iOS 26.0+ runtime with Xcode 26.0+ builds (DTXcode >= 2600)
  - Detects missing or disabled `UIDesignRequiresCompatibility`
  - Uses defensive approach: assumes unsafe unless proven safe
- Add `options.experimental.enableSessionReplayInUnreliableEnvironment` to allow overriding the automatic disabling (#6389)

## 8.56.2

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Fixes

- Fix crash from null UIApplication in SwiftUI apps (#6264)

## 8.56.1

> [!Warning]
> This version can cause runtime crashes because the `UIApplication.sharedApplication`/`NSApplication.sharedApplication` is not yet available during SDK initialization, due to the changes in [PR #5900](https://github.com/getsentry/sentry-cocoa/pull/5900), released in [8.56.0](https://github.com/getsentry/sentry-cocoa/releases/tag/8.56.0).

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Fixes

- Fix potential app launch hang caused by the SentrySDK (#6181)
  Fixed by removing the call to `_dyld_get_image_header` on the main thread.
- Fix dynamic selector crash in SentryReplayRecording (#6211)

## 8.56.0

> [!Warning]
> This version can cause runtime crashes because the `UIApplication.sharedApplication`/`NSApplication.sharedApplication` is not yet available during SDK initialization, due to the changes in [PR #5900](https://github.com/getsentry/sentry-cocoa/pull/5900), released in [8.56.0](https://github.com/getsentry/sentry-cocoa/releases/tag/8.56.0).

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Features

- Structured Logs: Flush logs on SDK flush/close (#5834)
- Add masking options for screenshots (#5401)
- Add significant time change breadcrumb (#6112)
- Add support for iOS 26, macOS 26, visionOS 26, watchOS 26, and tvOS 26 in device tests (#6063)

### Improvements

- Lazily CharacterSet only once in SentryBaggageSerialization (#5871)
- Structured Logging: Log `SentrySDK.logger` calls to `SentrySDKLog` (#5991)
- The build type in the app context now differentiates between `enterprise` and `adhoc` (#6044)
- visionOS no longer needs swift's interoperability mode (#6077)
- Ensure IP address is only inferred by Relay if sendDefaultPii is true (#5877)
- Sentry without UIKit / AppKit is available to install with SPM (#6160)

### Fixes

- Don't capture replays for events dropped in `beforeSend` (#5916)
- Fix linking with SentrySwiftUI on Xcode 26 for visionOS (#5823)
- Structured Logging: Logger called before `SentrySDK.start` becomes unusable (#5984)
- Add masking for AVPlayerView (#5910)
- Fix missing view hierachy when enabling `attachScreenshot` too (#5989)
- Fix macOS's frameworks not following the versioned framework structure (#6049)
- Add warning to addBreadcrumb when used before SDK init (#6083)
- Add null-handling for parsed DSN in SentryHTTPTransport (#5800)
- Fix crash in Session Replay when opening the camera UI on iOS 26+ by skipping redaction of internal views.
  This may result in more of the camera screen being redacted. (#6045)
- Fix crash in SentryDependencyContainer init when using the SDK as a static framework (#6125)
- Fixes a React Native legacy build failure by adding the missing self references for explicit capture semantics (#6156)

## 8.56.0-alpha.3

### Fixes

- Fixes a React Native legacy build failure by adding the missing self references for explicit capture semantics (#6156)

## 8.56.0-alpha.2

### Features

- Add significant time change breadcrumb (#6112)
- Add support for iOS 26, macOS 26, visionOS 26, watchOS 26, and tvOS 26 in device tests (#6063)

### Fixes

- Fix crash in Session Replay when opening the camera UI on iOS 26+ by skipping redaction of internal views.
  This may result in more of the camera screen being redacted. (#6045)
- Fix crash in SentryDependencyContainer init when using the SDK as a static framework (#6125)

## 8.56.0-alpha.1

- No documented changes.

## 8.56.0-alpha.0

### Features

- Structured Logs: Flush logs on SDK flush/close (#5834)
- Add masking options for screenshots (#5401)

### Fixes

- Don't capture replays for events dropped in `beforeSend` (#5916)
- Fix linking with SentrySwiftUI on Xcode 26 for visionOS (#5823)
- Structured Logging: Logger called before `SentrySDK.start` becomes unusable (#5984)
- Add masking for AVPlayerView (#5910)
- Fix missing view hierachy when enabling `attachScreenshot` too (#5989)
- Fix macOS's frameworks not following the versioned framework structure (#6049)
- Add warning to addBreadcrumb when used before SDK init (#6083)
- Add null-handling for parsed DSN in SentryHTTPTransport (#5800)

### Improvements

- Lazily CharacterSet only once in SentryBaggageSerialization (#5871)
- Structured Logging: Log `SentrySDK.logger` calls to `SentrySDKLog` (#5991)
- The build type in the app context now differentiates between `enterprise` and `adhoc` (#6044)
- visionOS no longer needs swift's interoperability mode (#6077)
- Ensure IP address is only inferred by Relay if sendDefaultPii is true (#5877)

## 8.55.1

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Features

### Fixes

- Fix macOS's frameworks not following the versioned framework structure (#6049)

## 8.54.1-alpha.1

### Fixes

- Add padding to tap area of widget button (#5949)

## 8.55.0

> [!Important]
> Xcode 26 no longer allows individual frameworks to contain arm64e slices anymore if the main binary doesn't contain them.
> We have decided to split the Dynamic variant and Sentry-WithoutUIKitOrAppKit of Sentry into two variants:
>
> - `Sentry-Dynamic`: Without ARM64e
> - `Sentry-Dynamic-WithARM64e`: _With_ ARM64e slice
> - `Sentry-WithoutUIKitOrAppKit`: Without ARM64e
> - `Sentry-WithoutUIKitOrAppKit-WithARM64e`: _With_ ARM64e slice
>
> If your app does not need arm64e, you don't need to make any changes.
> But if your app _needs arm64e_ please use `Sentry-Dynamic-WithARM64e` or `Sentry-WithoutUIKitOrAppKit-WithARM64e` from 8.55.0 so you don't have issues uploading to the App Store.

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Features

- Add a new prebuilt framework with arm64e and remove it from the regular one (#5788)
- Add `beforeSendLog` callback to `SentryOptions` (#5678)
- Structured Logs: Flush logs on SDK flush/close (#5834)
- Add a new prebuilt framework with ARM64e for WithoutUIKitOrAppKit (#5897)
- Add source context and vars fields to SentryFrame (#5853)

### Fixes

- Add support for PDFKit views in session replay (#5750)
- Fix Infinite Session Replay Processing Loop (#5765)
- Fix memory leak in SessionReplayIntegration (#5770)
- Fix reporting of energy used while profiling (#5768)
- Fixed a build error in `SentryFeedback.swift` when building with cocoapods on Xcode 14.2 (#5917)
- Fix linking against Sentry on an app extension (#5813)

### Internal

- Add nullability property for `screenName` (#5782)

## 8.54.0

> [!Warning]
> Session Replay in this version does not correctly mask views when built with Xcode 26 and running on iOS 26 with Liquid Glass, which may lead to PII leaks. Please upgrade to 8.57.0 or later, which automatically **disables session replay** in such environments.

### Features

- Add experimental support for capturing structured logs via `SentrySDK.logger` (#5532, #5593, #5639, #5628, #5637, #5643)
- Add `isiOSAppOnMac` and `isMacCatalystApp` from ProcessInfo to the runtime context (#5570)
- The SDK will show a warning in the console if it detects it was loaded twice (#5298)

### Fixes

- Add null-handling for internal array sanitization (#5722)
- Fix video replay crashes due to video writer inputs not marked as finished on cancellation (#5608)
- Fix wrong flush timeout (#5565). When flush timed out before the SDK finished sending data, it always blocked the full flush timeout the next time being called. This is fixed now.
- Launch profiling now respects original configured options if they change on the next launch (#5417)
- User feedback no longer subject to sample rates or `beforeSend` (#5692)
- Build error in app extensions (#5682)
- Fix frame metrics including time while in background (#5681)

### Improvements

- Extract video processing to a new class (#5604)
- Move continuous profiling payload serialization off of the main thread (#5613)
- Improve video generation using apple recommended loop (#5612)
- Use -OSize for release builds (#5721)
- Mark The `integrations` parameter of `SentryOptions` as deprecated rather than printing a warning (#5749)

## 8.53.2

### Fixes

- Set handled to false for fatal app hangs (#5514)
- User feedback widget can now be displayed in SwiftUI apps (#5223)
- Fix crash when SentryFileManger is nil (#5535)
- Fix crash when capturing events at the same time `bindClient:` is called from a different thread (#5523)
- Record user for watchdog termination events (#5558)
- Add support for dist and environment fields for termination watch (#5560)
- Add support for tags and context fields for termination watch (#5561)
- Add support for extras, fingerprint, and level watchdog termination events (#5569)

### Improvements

- Removed `APPLICATION_EXTENSION_API_ONLY` requirement (#5524)
- Improve launch profile configuration management (#5318)
- Deprecate getStoreEndpoint (#5591)

## 8.53.1

### Fixes

- Fix XCFramework version including commit sha on release. (#5493)

## 8.53.0

> [!Warning]
> This version can cause build errors when using one of the XCFrameworks, such as
> `The value for key CFBundleVersion [8.53.0+f92cfa9b1199c75411a263d2d9bc2df8ea8029cf] in the Info.plist file must be no longer than 18 characters.`
> Updating to 8.53.1 fixes this problem.

### Features

- Capturing fatal CPPExceptions via hooking into cxa_throw when enabling `options.experimental.enableUnhandledCPPExceptionsV2 = true` (#5256)

### Fixes

- Fix building with Xcode 26 (#5386)
- Fix usage of `@available` to be `iOS` instead of `iOSApplicationExtension` (#5361)
- Fix stacktrace symbolication of fatal app hangs (#5438)
- Robustness against corrupt launch profile configuration files (#5447)
- Fix auto-start for session tracker when SDK is started after app did become active (#5121)
- Sessions will now be marked as exited instead of abnormal exit when closing the SDK (#5121)
- Manually add `dyld` image to image cache to fix dyld symbols appearing as `unknown` (#5418)

### Improvements

- Converted SentryUserFeedback from Objective-C to Swift (#5377)
- Crashes for uncaught NSExceptions will now report the stracktrace recorded within the exception (#5306)
- Move SentryExperimentalOptions to a property defined in Swift (#5329)
- Add redaction in session replay for `SFSafariView` used by `SFSafariViewController` and `ASWebAuthenticationSession` (#5408)
- Convert SentryNSURLRequest to Swift (#5457)

## 8.53.0-alpha.0

### Features

- Capturing fatal CPPExceptions via hooking into cxa_throw when enabling `options.experimental.enableUnhandledCPPExceptionsV2 = true` (#5256)
- [Structured Logging] Models + Preparation ([#5441](https://github.com/getsentry/sentry-cocoa/pull/5441))

### Fixes

- Fix building with Xcode 26 (#5386)
- Fix usage of `@available` to be `iOS` instead of `iOSApplicationExtension` (#5361)
- Fix stacktrace symbolication of fatal app hangs (#5438)
- Robustness against corrupt launch profile configuration files (#5447)
- Fix auto-start for session tracker when SDK is started after app did become active (#5121)
- Sessions will now be marked as exited instead of abnormal exit when closing the SDK (#5121)
- Manually add `dyld` image to image cache to fix dyld symbols appearing as `unknown` (#5418)

### Improvements

- Converted SentryUserFeedback from Objective-C to Swift (#5377)
- Crashes for uncaught NSExceptions will now report the stracktrace recorded within the exception (#5306)
- Move SentryExperimentalOptions to a property defined in Swift (#5329)
- Add redaction in session replay for `SFSafariView` used by `SFSafariViewController` and `ASWebAuthenticationSession` (#5408)
- Convert SentryNSURLRequest to Swift (#5457)

## 8.52.1

### Fixes

- Missing debug meta for non fatal events (#5352)

## 8.52.0

> [!Warning]
> This version has a [known issue](https://github.com/getsentry/sentry-cocoa/issues/5334) where events captured with `captureMessage` or `captureError` will have unsymbolicated stack traces. A fix is incoming and will be released in 8.52.1

### Features

- XCFrameworks are now signed (#5271)

### Improvements

- Slightly reduce performance impact by removing unnecessary lock in SentryLog.configure (#5297)
- Redact React Native text and images by default without the RN SDK (#5302)

### Fixes

- Add missing context for watchdog termination events (#5242)
- Use timestamp of screenshot for frames (#5342)
- Use frame rate for cache max size of session replay (#5341)

## 8.52.0-beta

### Features

- XCFrameworks are now signed (#5271)

### Improvements

- Slightly reduce performance impact by removing unnecessary lock in SentryLog.configure (#5297)
- Redact React Native text and images by default without the RN SDK (#5302)

## 8.51.1

> [!Warning]
> This version introduces a [known issue](https://github.com/getsentry/sentry-cocoa/issues/5334) where events captured with `captureMessage` or `captureError` will have unsymbolicated stack traces. A fix is incoming and will be released in 8.52.1

### Fixes

- Uses low-priority queues to reduce the chance of session replay internal multi-threading processes being dropped (#5280)

### Improvements

- Threading issues in internal dependency container (#5225)

## 8.51.0

> [!Important]
> This version creates new issue groups for your unhandled C++ exceptions because it now again reports the message of unhandled C++ exceptions, which we use for grouping.

### Features

- Apps can now manually show and hide the included feedback widget button (#5236)

### Fixes

- Reporting unhandled C++ exception message (#5190)
- Improved internal multi-threading of session replay to fix thread inversion warning and reduce chance of queue starvation (#5018)

### Improvements

- Add `itemCount` to `SentryEnvelopeItemHeader` ([#5230](https://github.com/getsentry/sentry-cocoa/pull/5230))
- Improve warn log in SentryTracer (#5248)

## 8.50.2

### Fixes

- Improved time-to-display tracker to not crash when using view life cycle methods incorrectly (#5048)
- Enable view renderer V2 by default in session replay and preview redact options when using initializer with default values (#5210)

## 8.50.1

### Fixes

- Detect AppHangsV2 when tracing not enabled (#5184)

### Improvements

- Add `frameRate`, `errorReplayDuration`, `errorReplayDuration`, `sessionSegmentDuration` and `maximumDuration` to session replay options dictionary initializer for Hybrid SDKs (#5210)

## 8.50.1-beta.0

### Fixes

- Detect AppHangsV2 when tracing not enabled (#5184)

## 8.50.0

> [!Important]
> This version enables the better view renderer V2 used by Session Replay by default.
> You can disable it by setting the option `options.sessionReplay.enableViewRendererV2` to `false`.
>
> In case you are noticing issues with view rendering, please report them on [GitHub](https://github.com/getsentry/sentry-cocoa).

### Features

- Added ability to bring your own button for user feedback form display (#5107)
- Make enableAppHangTrackingV2 general available (#5149)

### Fixes

- Correctly rate limit envelopes from the new UI profiling system (#5131)
- Race condition in ANRTrackerV1 (#5137)

### Improvements

- More logging for Session Replay video info (#5132)
- Improve session replay frame presentation timing calculations (#5133)
- Use wider compatible video encoding options for Session Replay (#5134)
- GA of better session replay view renderer V2 (#5054)
- Explicitly check malloc result for SRSync to fix a Veracode Security Scan warning (#5160)
- Revert max key-frame interval to once per session replayvideo segment (#5156)
- Add more detailed debug logs for session replay (#5173)

## 8.49.2

> [!Important]
> Version 8.21.0 introduced an issue for app launch profiling **only for macOS apps that run without a sandbox** (i.e. distributed outside the Mac App Store).
> This issue could lead to starting the app launch profiler even when it's not configured via the options.
> We recommend upgrading to at least this version.

### Fixes

- Non-sandboxed macOS app launch profile configuration are now respected (#5144)

## 8.49.1

### Fixes

- Crash in setMeasurement when name is nil (#5064)
- Make setMeasurement thread safe (#5067, #5078)
- Truncation of Swift crash messages (#5036)
- Add error logging for move current replay to last path (#5083)
- Async safe log for backtrace in CPPException (#5098)

## 8.49.0

### Features

- New continuous profiling configuration API (#4952 and #5063)

> [!Important]
> With the addition of the new profiling configuration API, the previous profiling API are deprecated and will be removed in the next major version of the SDK:
>
> - `SentryOptions.enableProfiling`
> - `SentryOptions.isProfilingEnabled`
> - `SentryOptions.profilesSampleRate`
> - `SentryOptions.profilesSampler`
> - `SentryOptions.enableLaunchProfiling`
>
> Additionally, note that the behavior of `SentrySDK.startProfiler()` will change once the above APIs are removed, as follows: before adding the new configuration API (`SentryProfileOptions`), `SentrySDK.startProfiler()` would unconditionally start a continuous profile if both `SentryOptions.profilesSampleRate` and `SentryOptions.profilesSampler` were `nil`, or no-op if either was non-`nil` (meaning the SDK would operate under original, transaction-based, profiling model). In the next major version, `SentryOptions.profilesSampleRate` and `SentryOptions.profilesSampler` will be removed, and `SentrySDK.startProfile()` will become a no-op unless you configure `SentryProfileOptions.sessionSampleRate` to a value greater than zero (which is its default). If you already have calls to `SentrySDK.startProfiler()` in your code, ensure you properly configure `SentryProfileOptions` via `SentryOptions.configureProfiling` to avoid losing profiling coverage.

### Fixes

- Continuous profile stop requests are cancelled by subsequent timely calls to start (#4993)

### Improvements

- Remove SDK side character limit of 8192 for SentryMessage (#5005) Now, the backend handles the character limit, which has the advantage of showing in the UI when the message was truncated.

## 8.48.0

### Features

- Add extension for `FileManager` to track file I/O operations with Sentry (#4863)

### Improvements

- Slightly speed up adding breadcrumbs (#4984)

### Fixes

- Fixes experimental Replay view renderer options initialisation (#4988)

## 8.47.0

> [!Important]
> This version fixes an important bug for applying scope data to crash events (#4969).
>
> Previously, the SDK always set the event's user to the user of the scope of the app launch after the crash event, which could result in incorrect user data if the user changed between the crash and the next launch.
> Additionally, if specific properties on the crash event were nil, the SDK replaced them with values from the scope of the app launch after the crash event. This affected the following event properties: tags, extra, fingerprints, breadcrumbs, dist, environment, level, and trace context. However, since most of these properties are infrequently nil, the fix should have minimal impact on most users.

### Deprecations

- Some profiling API are deprecated in favor of new ways to manage starting and stopping continuous profiling sessions (#4854)

### Features

- Add extension for `Data` to track file I/O operations with Sentry (#4862)
- Send fatal app hang session updates (#4921) only when enabling the option `enableAppHangTrackingV2`.
- Add experimental flag `options.sessionReplay.enableExperimentalViewRenderer` to enable up to 5x times more performance in Session Replay (#4940)

### Fixes

- Correctly finish TTFD span when no new frame (#4941)
- Only delete envelopes when receiving HTTP 200 (#4956)
- Set foreground true for watchdog terminations (#4953)
- Fix removing value from context not updating observer context (#4960)
- Fix wrongly applying scope to crash events (#4969)
- Changed parameter of `SDKInfo.initWithOptions` to be nullable (#4968)

### Improvements

- More debug logs for UIViewController tracing (#4942)
- Avoid creating unnecessary User Interaction transactions (#4957)

## 8.46.0

### Features

- Report fatal app hangs (#4889) only when enabling the option `enableAppHangTrackingV2`
- New user feedback API and Widget (#4874)

### Improvements

- Log message when setting user before starting the SDK (#4882)
- Add experimental flag to disable swizzling of `NSData` individually (#4859)
- Replace calls of `SentryScope.useSpan` with callback to direct span accessor (#4896)
- Slightly reduce size of SentryCrashReports (#4915)

### Fixes

- Fix rare memory access issue for auto tracing (#4894). For more details, see issue (#4887).
- Move assignment of file IO span origin outside of block (#4888)
- Deadline timeout crash in SentryTracer (#4911)
- Improve memory-safety by converting Swift constants to Objective-C (#4910)
- Fix C++ compilation error due to changes in Xcode 16.3 beta's compiler toolchain (#4917 and #4918)

### Internal

- Add injectable mask and view renderer (#4938)

## 8.45.0

> [!WARNING]
> We have been made aware that this version can cause crashes in certain configurations when using network tracking, file I/O tracking, or CoreData tracking features.
> We recommend staying on version 8.43.0 or disabling the mentioned features until a fix is released.
> See issue [#4887](https://github.com/getsentry/sentry-cocoa/issues/4887) for more details.

### Features

- Add `showMaskPreview` to `SentrySDK.replay` api to debug replay masking (#4761)
- Session replay masking preview for SwiftUI (#4737)
- HTTP Breadcrumb level based on response status code (#4779) 4xx is warning, 5xx is error.
- Measure app hang duration for AppHangTrackingV2 (#4836)

### Improvements

- Add more debug logs for SentryViewHierarchy (#4780)
- Add `sample_rand` to baggage (#4751)
- Add timeIntervalSince1970 to log messages (#4781)
- Add `waitForFullDisplay` to `sentryTrace` view modifier (#4797)
- Increase continuous profiling buffer size to 60 seconds (#4826)

### Fixes

- Fix missing `sample_rate` in baggage (#4751)
- Serializing SentryGeo with `nil` values (#4724)
- Add type-safety for screenshots result array (#4843)

### Internal

- Deserializing SentryEvents with Decodable (#4724)
- Remove internal unknown dict for Breadcrumbs (#4803) This potentially only impacts hybrid SDKs.

## 8.44.0

> [!WARNING]
> We have been made aware that this version can cause crashes in certain configurations when using network tracking, file I/O tracking, or CoreData tracking features.
> We recommend staying on version 8.43.0 or disable the mentioned features until a fix is released.
> See issue [#4887](https://github.com/getsentry/sentry-cocoa/issues/4887) for more details.

### Fixes

- Don't start the SDK inside Xcode preview (#4601)
- Use strlcpy to save session replay info path (#4740)
- `sentryReplayUnmask` and `sentryReplayUnmask` preventing interaction (#4749)
- Missing `SentryCrashExceptionApplication` implementation for non-macOS target (#4759)
- Add `NSNull` handling to `sentry_sanitize` (#4760)

### Improvements

- Add native SDK information in the replay option event (#4663)
- Add error logging for invalid `cacheDirectoryPath` (#4693)
- Add SentryHub to all log messages in the Hub (#4753)
- More detailed log message when can't start session in SentryHub (#4752)

### Features

- SwiftUI time for initial display and time for full display (#4596)
- Add protocol for custom screenName for UIViewControllers (#4646)
- Allow hybrid SDK to set replay options tags information (#4710)
- Add threshold to always log fatal logs (#4707)

### Internal

- Change macros TEST and TESTCI to SENTRY_TEST and SENTRY_TEST_CI (#4712)
- Convert constants SentrySpanOperation to Swift (#4718)
- Convert constants SentryTraceOrigins to Swift (#4717)

## 8.44.0-beta.1

### Fixes

- Don't start the SDK inside Xcode preview (#4601)

### Improvements

- Add native SDK information in the replay option event (#4663)
- Add error logging for invalid `cacheDirectoryPath` (#4693)

### Features

- SwiftUI time for initial display and time for full display (#4596)
- Add protocol for custom screenName for UIViewControllers (#4646)
- Allow hybrid SDK to set replay options tags information (#4710)
- Add threshold to always log fatal logs (#4707)

### Internal

- Change macros TEST and TESTCI to SENTRY_TEST and SENTRY_TEST_CI (#4712)
- Convert constants SentrySpanOperation to Swift (#4718)
- Convert constants SentryTraceOrigins to Swift (#4717)

## 8.43.1-beta.0

### Fixes

- Memory growth issue in profiler (#4682)
- Replace occurences of `strncpy` with `strlcpy` (#4636)
- Fix span recording for `NSFileManager.createFileAtPath` starting with iOS 18, macOS 15 and tvOS 18. This feature is experimental and must be enabled by setting the option `experimental.enableFileManagerSwizzling` to `true` (#4634)

### Internal

- Update to Xcode 16.2 in workflows (#4673)
- Add method unswizzling (#4647)

## 8.43.0

> [!WARNING]
> This release contains a breaking change for the previously experimental session replay options. We moved the options from Session from `options.experimental.sessionReplay` to `options.sessionReplay`.

### Features

- Session replay GA (#4662)
- Show session replay options as replay tags (#4639)

### Fixes

- Remove empty session replay tags (#4667)
- `SentrySdkInfo.packages` should be an array (#4626)
- Use the same SdkInfo for envelope header and event (#4629)

### Improvements

- Improve compiler error message for missing Swift declarations due to APPLICATION_EXTENSION_API_ONLY (#4603)
- Mask screenshots for errors (#4623)
- Slightly speed up serializing scope (#4661)

### Internal

- Remove loading `integrations` names from `event.extra` (#4627)
- Add Hybrid SDKs API to add extra SDK packages (#4637)

## 8.43.0-beta.1

### Improvements

- Improve compiler error message for missing Swift declarations due to APPLICATION_EXTENSION_API_ONLY (#4603)
- Mask screenshots for errors (#4623)
- Slightly speed up serializing scope (#4661)

### Features

- Show session replay options as replay tags (#4639)

### Fixes

- `SentrySdkInfo.packages` should be an array (#4626)
- Use the same SdkInfo for envelope header and event (#4629)

### Internal

- Remove loading `integrations` names from `event.extra` (#4627)
- Add Hybrid SDKs API to add extra SDK packages (#4637)

## 8.42.1

### Fixes

- Fixes Session replay screenshot provider crash (#4649)
- Session Replay wrong clipping order (#4651)

## 8.42.0

### Features

- Add in_foreground app context to transactions (#4561)
- Add in_foreground app context to crash events (#4584)
- Promote the option `performanceV2` from experimental to stable (#4564)

### Fixes

- Session replay touch tracking race condition (#4548)
- Use `options.reportAccessibilityIdentifier` for Breadcrumbs and UIEvents (#4569)
- Session replay transformed view masking (#4529)
- Load integration from same binary (#4541)
- Masking for fast animations #4574
- Fix GraphQL context for HTTP client error tracking (#4567)

### Improvements

- impr: Speed up getBinaryImages V2 (#4539). Follow up on (#4435)
- Make SentryId Sendable (#4553)
- Expose `Sentry._Hybrid` explicit module (#4440)
- Track adoption of `enablePersistingTracesWhenCrashing` (#4587)

## 8.42.0-beta.2

### Fixes

- Fix GraphQL context for HTTP client error tracking (#4567)

### Improvements

- Track adoption of `enablePersistingTracesWhenCrashing` (#4587)

## 8.42.0-beta.1

### Features

- Add in_foreground app context to transactions (#4561)
- Add in_foreground app context to crash events (#4584)
- Promote the option `performanceV2` from experimental to stable (#4564)

### Fixes

- Session replay touch tracking race condition (#4548)
- Use `options.reportAccessibilityIdentifier` for Breadcrumbs and UIEvents (#4569)
- Session replay transformed view masking (#4529)
- Load integration from same binary (#4541)
- Masking for fast animations #4574

### Improvements

- impr: Speed up getBinaryImages V2 (#4539). Follow up on (#4435)
- Make SentryId Sendable (#4553)
- Expose `Sentry._Hybrid` explicit module (#4440)

## 8.41.0

### Features

- Transactions for crashes (#4504): Finish the transaction bound to the scope when the app crashes. This **experimental** feature is disabled by default. You can enable it via the option `enablePersistingTracesWhenCrashing`.

### Fixes

- Keep PropagationContext when cloning scope (#4518)
- UIViewController with Xcode 16 in debug (#4523). The Xcode 16 build setting [ENABLE_DEBUG_DYLIB](https://developer.apple.com/documentation/xcode/build-settings-reference#Enable-Debug-Dylib-Support), which is turned on by default only in debug, could lead to missing UIViewController traces.
- Concurrency crash with Swift 6 (#4512)
- Make `Scope.span` fully thread safe (#4519)
- Finish TTFD when not calling reportFullyDisplayed before binding a new transaction to the scope (#4526).
- Session replay opacity animation masking (#4532)

## 8.41.0-beta.1

### Features

- Transactions for crashes (#4504): Finish the transaction bound to the scope when the app crashes. This **experimental** feature is disabled by default. You can enable it via the option `enablePersistingTracesWhenCrashing`.

### Fixes

- Keep PropagationContext when cloning scope (#4518)
- UIViewController with Xcode 16 in debug (#4523). The Xcode 16 build setting [ENABLE_DEBUG_DYLIB](https://developer.apple.com/documentation/xcode/build-settings-reference#Enable-Debug-Dylib-Support), which is turned on by default only in debug, could lead to missing UIViewController traces.
- Concurrency crash with Swift 6 (#4512)
- Make `Scope.span` fully thread safe (#4519)
- Finish TTFD when not calling reportFullyDisplayed before binding a new transaction to the scope (#4526).
- Session replay opacity animation masking (#4532)

## 8.40.1

### Fixes

- Session replay masking not working inside scroll view (#4498)

### Improvements

- Add extra logs for UIViewControllerSwizzling (#4511)

## 8.40.0

### Features

- Add option to report uncaught NSExceptions on macOS (#4471)
- Build visionOS project with static Sentry SDK (#4462)
- Too many navigation breadcrumbs for Session Replay (#4480)
- Time-of-check time-of-use filesystem race condition (#4473)
- Capture all touches with session replay (#4477)

### Improvements

- Improve frames tracker performance (#4469)
- Log a warning when dropping envelopes due to rate-limiting (#4463)
- Expose `SentrySessionReplayIntegration-Hybrid.h` as `private` (#4486)
- Stops session replay if rate limiting is activated (#4496)
- Add `maskedViewClasses` and `unmaskedViewClasses` to SentryReplayOptions init via dict (#4492)
- Add `quality` to SentryReplayOptions init via dict (#4495)

### Fixes

- Masking text with transparent text color (#4499)

## 8.39.0

### Removal of Experimental API

- Remove the deprecated experimental Metrics API (#4406): [Learn more](https://sentry.zendesk.com/hc/en-us/articles/26369339769883-Metrics-Beta-Coming-to-an-End)

### Features

- feat: API to manually start/stop Session Replay (#4414)
- Custom redact modifier for SwiftUI (#4362, #4392)
- Track usage of appHangTrackingV2 (#4445)
- AppHangV2 detection (#4379) Add a new algorithm for detecting app hangs that differentiates between fully blocking and non-fully blocking app hangs. Read more in-depth in our [docs](https://docs.sentry.io/platforms/apple/guides/ios/configuration/app-hangs/#app-hangs-v2).

### Fixes

- Edge case for swizzleClassNameExclude (#4405): Skip creating transactions for UIViewControllers ignored for swizzling via the option `swizzleClassNameExclude`.
- Add TTID/TTFD spans when loadView gets skipped (#4415)
- Finish TTID correctly when viewWillAppear is skipped (#4417)
- Swizzling RootUIViewController if ignored by `swizzleClassNameExclude` (#4407)
- Data race in SentrySwizzleInfo.originalCalled (#4434)
- Delete old session replay files (#4446)
- Thread running at user-initiated quality-of-service for session replay (#4439)
- Don't create transactions for unused UIViewControllers (#4448)

### Improvements

- Serializing profile on a BG Thread (#4377) to avoid potentially slightly blocking the main thread.
- Session Replay performance for SwiftUI (#4419)
- Speed up getBinaryImages (#4435) for finishing transactions and capturing events
- Align SDK dispatch queue names (#4442) to start with `io.sentry`
- Use UInts in envelope deserialization (#4441)
- Make `SentrySDK.replay.start()` thread safe (#4455)

## 8.39.0-beta.1

### Removal of Experimental API

- Remove the deprecated experimental Metrics API (#4406): [Learn more](https://sentry.zendesk.com/hc/en-us/articles/26369339769883-Metrics-Beta-Coming-to-an-End)

### Features

- feat: API to manually start/stop Session Replay (#4414)
- Custom redact modifier for SwiftUI (#4362, #4392)
- Track usage of appHangTrackingV2 (#4445)
- AppHangV2 detection (#4379) Add a new algorithm for detecting app hangs that differentiates between fully blocking and non-fully blocking app hangs. Read more in-depth in our [docs](https://docs.sentry.io/platforms/apple/guides/ios/configuration/app-hangs/#app-hangs-v2).

### Fixes

- Edge case for swizzleClassNameExclude (#4405): Skip creating transactions for UIViewControllers ignored for swizzling via the option `swizzleClassNameExclude`.
- Add TTID/TTFD spans when loadView gets skipped (#4415)
- Finish TTID correctly when viewWillAppear is skipped (#4417)
- Swizzling RootUIViewController if ignored by `swizzleClassNameExclude` (#4407)
- Data race in SentrySwizzleInfo.originalCalled (#4434)
- Delete old session replay files (#4446)
- Thread running at user-initiated quality-of-service for session replay (#4439)
- Don't create transactions for unused UIViewControllers (#4448)

### Improvements

- Serializing profile on a BG Thread (#4377) to avoid potentially slightly blocking the main thread.
- Session Replay performance for SwiftUI (#4419)
- Speed up getBinaryImages (#4435) for finishing transactions and capturing events
- Align SDK dispatch queue names (#4442) to start with `io.sentry`
- Use UInts in envelope deserialization (#4441)
- Make `SentrySDK.replay.start()` thread safe (#4455)

## 8.38.0

### Features

- Added breadcrumb.origin private field (#4358)
- Custom redact modifier for SwiftUI (#4362)
- Add support for arm64e (#3398)
- Add mergeable libraries support to dynamic libraries (#4381)

### Improvements

- Speed up HTTP tracking for multiple requests in parallel (#4366)
- Slightly speed up SentryInAppLogic (#4370)
- Rename session replay `redact` options and APIs to `mask` (#4373)
- Stop canceling timer for manual transactions (#4380)

### Fixes

- Fix the versioning to support app release with Beta versions (#4368)
- Linking ongoing trace to crash event (#4393)

## 8.38.0-beta.1

### Features

- Added breadcrumb.origin private field (#4358)
- Custom redact modifier for SwiftUI (#4362)
- Add support for arm64e (#3398)
- Add mergeable libraries support to dynamic libraries (#4381)

### Improvements

- Speed up HTTP tracking for multiple requests in parallel (#4366)
- Slightly speed up SentryInAppLogic (#4370)
- Rename session replay `redact` options and APIs to `mask` (#4373)
- Stop canceling timer for manual transactions (#4380)

### Fixes

- Fix the versioning to support app release with Beta versions (#4368)
- Linking ongoing trace to crash event (#4393)

## 8.37.0

### Features

- Added `thermal_state` to device context (#4305)
- Send envelopes that cannot be cached to disk (#4294)

### Refactoring

- Moved session replay API to `SentrySDK.replay` (#4326)
- Changed default session replay quality to `medium` (#4326)

### Fixes

- Resumes replay when the app becomes active (#4303)
- Session replay redact view with transformation (#4308)
- Correct redact UIView with higher zPosition (#4309)
- Don't redact clipped views (#4325)
- Session replay for crash not created because of a race condition (#4314)
- Double-quoted include, expected angle-bracketed instead (#4298)
- Discontinue use of NSApplicationSupportDirectory in favor of NSCachesDirectory (#4335)
- Safe guard `strncpy` usage (#4336)
- Stop using `redactAllText` as an indicator tha redact is enabled (#4327)

### Improvements

- Avoid extra work when storing invalid envelopes (#4337)

## 8.37.0-beta.1

### Features

- Added `thermal_state` to device context (#4305)
- Send envelopes that cannot be cached to disk (#4294)

### Refactoring

- Moved session replay API to `SentrySDK.replay` (#4326)
- Changed default session replay quality to `medium` (#4326)

### Fixes

- Resumes replay when the app becomes active (#4303)
- Session replay redact view with transformation (#4308)
- Correct redact UIView with higher zPosition (#4309)
- Don't redact clipped views (#4325)
- Session replay for crash not created because of a race condition (#4314)
- Double-quoted include, expected angle-bracketed instead (#4298)
- Discontinue use of NSApplicationSupportDirectory in favor of NSCachesDirectory (#4335)
- Safe guard `strncpy` usage (#4336)
- Stop using `redactAllText` as an indicator tha redact is enabled (#4327)

### Improvements

- Avoid extra work when storing invalid envelopes (#4337)

## 8.36.0

### Features

- Continuous mode profiling (see `SentrySDK.startProfiler` and `SentryOptions.profilesSampleRate`) (#4010)

### Fixes

- Proper redact SR during animation (#4289)

## 8.35.1

### Fixes

- Crash when reading corrupted envelope (#4297)

## 8.35.0

### Features

- Expose span baggage API (#4207)

### Fixes

- Fix `SIGABRT` when modifying scope user (#4274)
- Crash during SDK initialization due to corrupted envelope (#4291)
  - Reverts [#4219](https://github.com/getsentry/sentry-cocoa/pull/4219) as potential fix

## 8.34.0

### Features

- Pause replay in session mode when offline (#4264)
- Add replay quality option for Objective-C (#4267)

### Fixes

- Session replay not redacting buttons and other non UILabel texts (#4277)
- Rarely reporting too long frame delays (#4278) by fixing a race condition in the frames tracking logic.
- Crash deserializing empty envelope length>0 (#4281]
- Guard dereferencing of stack frame pointer in SentryBacktrace ([#4268](https://github.com/getsentry/sentry-cocoa/pull/4268))

## 8.33.0

### Note: Due to a bug (#4280) introduced in this release, we recommend upgrading to [8.35.0](https://github.com/getsentry/sentry-cocoa/releases/tag/8.35.0) or newer.

---

This release fixes a bug (#4230) that we introduced with a refactoring (#4101) released in [8.30.1](https://github.com/getsentry/sentry-cocoa/releases/tag/8.30.1).
This bug caused unhandled/crash events to have the unhandled property and mach info missing, which is required for release health to show events in the unhandled tab. It's essential to mention that this bug **doesn't impact** release health statistics, such as crash-free session or user rates.

### Features

- Support orientation change for session replay (#4194)
- Replay for crashes (#4171)
- Redact web view from replay (#4203)
- Add beforeCaptureViewHierarchy callback (#4210)
- Rename session replay `errorSampleRate` property to `onErrorSampleRate` (#4218)
- Add options to redact or ignore view for Replay (#4228)

### Fixes

- Skip UI crumbs when target or sender is nil (#4211)
- Guard FramesTracker start and stop (#4224)
- Long-lasting TTID/TTFD spans (#4225). Avoid long TTID spans when the FrameTracker isn't running, which is the case when the app is in the background.
- Missing mach info for crash reports (#4230)
- Crash reports not generated on visionOS (#4229)
- Don’t force cast to `NSComparisonPredicate` in TERNARY operator (#4232)
- Fix accessing UI API on bg thread in enrichScope (#4245)
- EXC_BAD_ACCESS in SentryMetricProfiler (#4242)
- Missing `#include <sys/_types/_ucontext64.h>` (#4244)
- Rare flush timeout when called in tight loop (#4257)

### Improvements

- Reduce memory usage of storing envelopes (#4219)
- Skip enriching scope when nil (#4243)

## 8.32.0

### Features

- Add `reportAccessibilityIdentifier` option (#4183)
- Record dropped spans (#4172)
- Collect only unique UIWindow references (#4159)

### Fixes

- Session replay crash when writing the replay (#4186)

### Deprecated

- options.enableTracing was deprecated. Use options.tracesSampleRate or options.tracesSampler instead. (#4182)

## 8.31.1

### Fixes

- Session replay video duration from seconds to milliseconds (#4163)

## 8.31.0

### Features

- Include the screen names in the session replay (#4126)

### Fixes

- Properly handle invalid value for `NSUnderlyingErrorKey` (#4144)
- Session replay in buffer mode not working (#4160)

## 8.30.1

### Fixes

- UIKitless configurations now produce a module with a different name (#4140)
- Sentry Replay Serialized Breadcrumbs include level name ([#4141](https://github.com/getsentry/sentry-cocoa/pull/4141))

## 8.30.0

### Features

- Restart replay session with mobile session (#4085)
- Add pause and resume AppHangTracking API (#4077). You can now pause and resume app hang tracking with `SentrySDK.pauseAppHangTracking()` and `SentrySDK.resumeAppHangTracking()`.
- Add `beforeSendSpan` callback (#4095)

### Fixes

- `storeEnvelope` ends session for unhandled errors (#4073)
- Deprecate `SentryUser.segment`(#4092). Please remove usages of this property. We will remove it in the next major.
- Double-quoted include in framework header (#4115)
- Sentry Replay Network details should be available without Tracing (#4091)

## 8.29.1

### Fixes

- Fix potential deadlock in app hang detection (#4063)
- Swizzling of view controllers `loadView` that don't implement `loadView` (#4071)

## 8.29.0

### Features

- Add a touch tracker for replay (#4041)
- Add enableMetricKitRawPayload (#4044)
- Resume session replay when app enters foreground (#4053)

### Fixes

- `SentryCrashMonitor_CPPException.cpp` compilation using Xcode 16b1 (#4051)

## 8.28.0

### Features

- Add replay quality option (#4035)

## 8.27.0

### Features

- Add breadcrumbs to session replay (#4002)
- Add start time to network request breadcrumbs (#4008)
- Add C++ exception support for `__cxa_rethrow` (#3996)
- Add beforeCaptureScreenshot callback (#4016)
- Disable SIGTERM reporting by default (#4025). We added support
  for SIGTERM reporting in the last release and enabled it by default.
  For some users, SIGTERM events were verbose and not actionable.
  Therefore, we disable it per default in this release. If you'd like
  to receive SIGTERM events, set the option `enableSigtermReporting = true`.

### Improvements

- Stop FramesTracker when app is in background (#3979)
- Speed up adding breadcrumbs (#4029, #4034)
- Skip evaluating log messages when not logged (#4028)

### Fixes

- Fix retrieving GraphQL operation names crashing ([#3973](https://github.com/getsentry/sentry-cocoa/pull/3973))
- Fix SentryCrashExceptionApplication subclass problem (#3993)
- Fix wrong value for `In Foreground` flag on UIKit applications (#4005)
- Fix a crash in baggageEncodedDictionary (#4017)
- Session replay wrong video size (#4018)

## 8.26.0

### Features

- Add SIGTERM support ([#3895](https://github.com/getsentry/sentry-cocoa/pull/3895))

### Fixes

- Fix data race when calling reportFullyDisplayed from a background thread (#3926)
- Ensure flushing envelopes directly after capturing them (#3915)
- Unable to find class: SentryCrashExceptionApplication (#3957)
- Clang error for Xcode 15.4 (#3958)
- Potential deadlock when starting the SDK (#3970)

### Improvements

- Send Cocoa SDK features (#3948)

## 8.25.2

### Features

The following two features, disabled by default, were mistakenly added to the release. We usually only add features in minor releases.

- Add option to use own NSURLSession for transport (#3811)
- Support sending GraphQL operation names in HTTP breadcrumbs (#3931)

### Fixes

- 'SentryFileManager+Test.h' file not found (#3950)

## 8.25.1

### Fixes

- Ignore SentryFramesTracker thread sanitizer data races (#3922)
- Handle no releaseName in WatchDogTerminationLogic (#3919)
- Stop SessionReplay when closing SDK (#3941)

### Improvements

- Remove not needed lock for logging (#3934)
- Session replay Improvements (#3877)
  - Use image average color and text font color to redact session replay
  - Removed iOS 16 restriction from session replay
  - Performance improvement

## 8.25.0

### Features

- Add Session Replay, which is **still experimental**. (#3625)
  - Access is limited to early access orgs on Sentry. If you're interested, [sign up for the waitlist](https://sentry.io/lp/mobile-replay-beta/)

### Fixes

- Crash due to a background call to -[UIApplication applicationState] (#3855)
- Save framework without UIKit/AppKit as Github Asset for releases (#3858)
- Fix crash associated with runtime collision in global C function names (#3862)
- Remove wrong error log in SentryCoreDataTracker (#3894)
- Don't transmit device boot time in envelopes enriched with crash data (#3912, #3916)

### Improvements

- Capture transactions on a background thread (#3892)

## 8.25.0-alpha.0

### Features

- Add Session Replay, which is **still experimental**. (#3625)
  - Access is limited to early access orgs on Sentry. If you're interested, [sign up for the waitlist](https://sentry.io/lp/mobile-replay-beta/)

### Fixes

- Crash due to a background call to -[UIApplication applicationState] (#3855)
- Save framework without UIKit/AppKit as Github Asset for releases (#3858)
- Fix crash associated with runtime collision in global C function names (#3862)
- Remove wrong error log in SentryCoreDataTracker (#3894)

## 8.24.0

### Features

- Add timing API for Metrics (#3812):
- Add [rate limiting](https://develop.sentry.dev/sdk/rate-limiting/) for Metrics (#3838)
- Data normalization for Metrics (#3843)

## 8.23.0

### Features

- Add Metrics API (#3791, #3799): Read our [docs](https://docs.sentry.io/platforms/apple/metrics/) to learn
  more about how to use the Metrics API.
- Pre-main profiling data is now attached to the app start transaction (#3736)
- Release framework without UIKit/AppKit (#3793)
- Add the option swizzleClassNameExcludes (#3813)

### Fixes

- Don't run onCrashedLastSession for nil Events (#3785)
- Redistributable static libraries should never be built with module debugging enabled (#3800)
- Fixed certain views getting loaded twice when adding a child view controller (#3753)
- Fixed broken imports in SentrySwiftUI Carthage build (#3817)
- Fix NSInvalidArgumentException for `NSError sentryErrorWithDomain` (#3819)
- Again fix runtime error when including Sentry as a static lib (#3820)
- Fix crash in hasUnfinishedChildSpansToWaitFor (#3821)

## 8.22.4

### Fixes

- CFBundleShortVersionString in the Info.plist file is invalid (#3787)

## 8.22.3

### Fixes

- Sentry.framework does not support the minimum OS Version specified in the Info.plist (#3774)
- Add reference to Swift classes for hybrid SDKs (#3771)

## 8.22.3-beta.0

### Fixes

- Sentry.framework does not support the minimum OS Version specified in the Info.plist (#3774)
- Add reference to Swift classes for hybrid SDKs (#3771)

## 8.22.2

- Fix runtime error when including Sentry as a static lib (#3764)
- Fix Mac Catalyst support for the prebuilt XCFramework used by SPM and Carthage (#3767)

## 8.22.1

### Fixes

- Checksum error when resolving the SDK via SPM (#3760)

## 8.22.0

**Warning:** this version is not working with SPM

### Improvements

- **SPM uses a prebuilt XCFramework and remove SentryPrivate (#3623)**:
  We now provide a prebuilt XCFramework for SPM, which speeds up your build and allows us to write
  more code in Swift. To make this happen, we had to remove the SentryPrivate target for SPM and
  CocoaPods, which you shouldn't have included directly.

### Fixes

- Write NSException reason for crash report (#3705)
- Add context to event with CrashIntegration disabled (#3699)

## 8.21.0

> [!Important]
> This version introduced an issue for app launch profiling **only for macOS apps that run without a sandbox** (i.e. distributed outside the Mac App Store).
> This issue could lead to starting the app launch profiler even when it's not configured via the options.
> We recommend upgrading to at least version 8.49.2.

### Features

- Add support for Sentry [Spotlight](https://spotlightjs.com/) (#3642), which is basically Sentry
  for development. Read our [blog post](https://blog.sentry.io/sentry-for-development/) to find out more.
- Add field `SentrySDK.detectedStartUpCrash` (#3644)
- Automatically profile app launches (#3529)
- Use CocoaPods resource_bundles for PrivacyInfo (#3651)
- Make tags of SentryScope public (#3650)

### Improvements

- Cache installationID async to avoid file IO on the main thread when starting the SDK (#3601)
- Add reason for NSPrivacyAccessedAPICategoryFileTimestamp (#3626)

### Fixes

- Finish TTID span when transaction finishes (#3610)
- Don't take screenshot and view hierarchy for app hanging (#3620)
- Remove `free_storage` and `storage_size` from the device context (#3627), because Apple forbids sending
  information retrieved via `NSFileSystemFreeSize` and `NSFileSystemSize` off a device; see
  [Apple docs](https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api?language=objc).
- Make SentryFramesTracker available for HybridSDKs ([#3683](https://github.com/getsentry/sentry-cocoa/pull/3683))
- Make SentrySwizzle available for HybridSDKs ([#3684](https://github.com/getsentry/sentry-cocoa/pull/3684))
- Move headers reference out of "extern C" (#3690)

## 8.21.0-beta.0

### Features

- Add support for Sentry [Spotlight](https://spotlightjs.com/) (#3642), which is basically Sentry
  for development. Read our [blog post](https://blog.sentry.io/sentry-for-development/) to find out more.
- Add field `SentrySDK.detectedStartUpCrash` (#3644)
- Automatically profile app launches (#3529)
- Use CocoaPods resource_bundles for PrivacyInfo (#3651)
- Make tags of SentryScope public (#3650)

### Improvements

- Cache installationID async to avoid file IO on the main thread when starting the SDK (#3601)
- Add reason for NSPrivacyAccessedAPICategoryFileTimestamp (#3626)

### Fixes

- Finish TTID span when transaction finishes (#3610)
- Don't take screenshot and view hierarchy for app hanging (#3620)
- Remove `free_storage` and `storage_size` from the device context (#3627), because Apple forbids sending
  information retrieved via `NSFileSystemFreeSize` and `NSFileSystemSize` off a device; see
  [Apple docs](https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api?language=objc).

## 8.20.0

### Features

- Add visionOS as device family (#3548)
- Add VisionOS Support for Carthage (#3565)

### Fixes

- Move header reference out of "extern C" (#3538)
- Clarify FramesTracker log message (#3570)
- Fix rare battery breadcrumbs crash (#3582)
- Fix synchronization issue in FramesTracker (#3571)
- Fix SentryFileManager logs warning for .DS_Files (#3584)
- Fix FileManager logs info instead of error when a path doesn't exist (#3594)

## 8.19.0

### Features

- Send debug meta for app start transactions (#3543)

### Fixes

- Fix typo in BUILD_LIBRARY_FOR_DISTRIBUTION variable in Makefile (#3488)
- Remove dispatch queue metadata collection to fix crash (#3522)
- Make SentryScope.useSpan non-blocking (#3568)
- Don't override `sentry-trace` and `baggage` headers (#3540)

## 8.18.0

### Features

- Add frames delay to transactions and spans (#3487, #3496)
- Add slow and frozen frames to spans (#3450, #3478)
- Split up UIKit and App Init App Start Span (#3534)
- Prewarmed App Start Tracing is stable (#3536)

### Fixes

- TTFD waits for next drawn frame (#3505)
- Fix TTID/TTFD for app start transactions (#3512): TTID/TTFD spans and measurements for app start transaction now include the app start duration.
- Crash when adding a crumb for a timezone change (#3524)
- Fix a race condition in SentryTracer (#3523)
- App start ends when first frame is drawn when performanceV2 is enabled (#3530)
- Use correct rendered frames timestamp for TTID/TTFD and app start (#3531)
- Missing transactions when not calling `reportFullyDisplayed` (#3477)

## 8.17.2

### Fixes

- **Fix marking manual sessions as crashed (#3501)**: When turning off autoSessionTracking and manually starting and ending sessions, the SDK didn't mark sessions as crashed when sending a crash event to Sentry. This is fixed now.

## 8.17.1

### Fixes

- Crash when UINavigationController doesn't have rootViewController (#3455)
- Crash when synchronizing invalid JSON breadcrumbs to SentryWatchdogTermination (#3458)
- Check for NULL in binary image cache (#3469)
- Threading issues in binary image cache (#3468)
- Finish transaction for external view controllers (#3440)

## 8.17.0

### Features

- SwiftUI support is no longer in Beta (#3441)

## 8.16.1

### Fixes

- Fix inaccurate number of frames for transactions (#3439)

## 8.16.0

### Features

- Add screen name to app context (#3346)
- Add cache directory option (#3369)

### Fixes

- Infinite loop when parsing MetricKit data (#3395)
- Fix incorrect implementation in #3398 to work around a profiling crash (#3405)
- Fix crash in SentryFramesTracker (#3424)

### Improvements

- Build XCFramework with Xcode 15 (#3415)

The XCFramework attached to GitHub releases is now built with Xcode 15.

## 8.15.2

### Fixes

- Crash when logging from certain profiling contexts (#3390)

## 8.15.1

### Fixes

- Crash when initializing SentryHub manually (#3374)

## 8.15.0

### Features

- Enrich error events with any underlying NSErrors reported by Cocoa APIs (#3230)
- Add experimental visionOS support (#3328)
- Improve OOM detection by ignoring system reboot (#3352)
- Add thread id and name to span data (#3359)

### Fixes

- Reporting app hangs from background (#3298)
- Thread sanitizer data race warnings in ANR tracker, network tracker and span finish (#3303)
- Stop sending empty thread names (#3361)
- Work around edge case with a thread info kernel call sometimes returning invalid data, leading to a crash (#3364)
- Crashes when trace ID is externally modified or profiler fails to initialize (#3365)

## 8.14.2

### Fixes

- Missing `mechanism.handled` is not considered crash (#3353)

## 8.14.1

### Fixes

- SPM build failure involving "unsafe settings" (#3348)

## 8.14.0

### Features

- Sentry can now be used without linking UIKit; this is helpful for using the SDK in certain app extension contexts (#3175)
  **Note:** this is an experimental feature not yet available for with SPM.
  **Warning:** this breaks some SPM integrations. Use 8.14.1 if you integrate using SPM.

- GA of MetricKit integration (#3340)

Once enabled, this feature subscribes to [MetricKit's](https://developer.apple.com/documentation/metrickit) [MXDiagnosticPayload](https://developer.apple.com/documentation/metrickit/mxdiagnosticpayload) data, converts it to events, and sends it to Sentry.
The MetricKit integration subscribes to [MXHangDiagnostic](https://developer.apple.com/documentation/metrickit/mxhangdiagnostic),
[MXDiskWriteExceptionDiagnostic](https://developer.apple.com/documentation/metrickit/mxdiskwriteexceptiondiagnostic),
and [MXCPUExceptionDiagnostic](https://developer.apple.com/documentation/metrickit/mxcpuexceptiondiagnostic).

## 8.13.1

### Fixes

- Always start SDK on the main thread (#3291)
- App hang with race condition for tick counter (#3290)
- Remove "duplicate library" warning (#3312)
- Fix multiple issues in Reachability (#3338)
- Remove unnecessary build settings (#3325)
- Crash in SentryTracer when cancelling timer (#3333)

## 8.13.0

### Fixes

- Remove sync call to main thread from SentryUIDeviceWrapper (#3295)

### Features

- Record changes to network connectivity in breadcrumbs (#3232)
- Add Sampling Decision to Trace Envelope Header (#3286)

## 8.12.0

### Fixes

- Remove warning about non-portable path to file "SentryDsn.h" (#3270)
- Privacy manifest collection purposes type (#3276)
- Fix how profiles were identified in the backend for grouping and issue correlation purposes (#3282)
- Ensure GPU frame data is always sent with profiles even if `enableAutoPerformanceTracing` is `NO` (#3273)
- Gather metric readings fully covering the duration of a profile (#3272)
- Remove spammy logs (#3284)

### Features

- Rename "http.method" to "http.request.method" for network Spans (#3268)

## 8.11.0

### Features

- Distributed tracing without performance (#3196)
- Report database backing store information for Core Data (#3231)
- Add "data use" in privacy manifests (#3259)
- Add required reason API (#3206)

### Fixes

- Report correct units (nanojoules) for profiling energy metrics (#3262)

## 8.10.0

### Features

- Record energy usage estimates for profiling (#3217)

### Fixes

- Remove a noisy NSLog (#3227)
- WatchOS build for Xcode 15 (#3204)

## 8.9.6

### Fixed

- Fix CPU usage collection for upcoming visualization in profiling flamecharts (#3214)

## 8.9.5

### Hybrid SDK support

- Allow profiling from hybrid SDKs (#3194)

## 8.9.4

### Fixes

- Remove linker settings from Package.swift (#3188)
- Free memory returned by backtrace_symbols() in debug builds ([#3202](https://github.com/getsentry/sentry-cocoa/pull/3202))

## 8.9.3

### Fixes

- Reclaim memory used by profiler when transactions are discarded (#3154)
- Crashed session not being reported as crashed (#3183)

## 8.9.2

## Important Note

**Do not use this version** if you use Release Health. It introduces a bug where crashed Sessions would not be reported correctly. This has been fixed in [version `8.9.3`](https://github.com/getsentry/sentry-cocoa/releases/tag/8.9.3).

### Improvements

- Reduced macOS SDK footprint by 2% (#3157) with similar changes for tvOS and watchOS (#3158, #3159, #3161)

### Fixes

- Fix a crash in SentryCoreDataTracker for nil error params (#3152)

## 8.9.1

### Fixes

- Fix potential unbounded memory growth when starting profiled transactions from non-main contexts (#3135)

## 8.9.0

### Features

- Symbolicate locally only when debug is enabled (#3079)

This change considerably speeds up retrieving stacktraces, which the SDK uses for captureMessage, captureError and also for reporting file IO or DB operation on the main thread.

- Sanitize HTTP info from breadcrumbs, spans and events (#3094)

### Breaking change

- Renamed `enableTimeToFullDisplay` to `enableTimeToFullDisplayTracing` (#3106)
  - This is an experimental feature and may change at any time without a major revision.

## 8.9.0-beta.1

### Features

- Symbolicate locally only when debug is enabled (#3079)
- Sanitize HTTP info from breadcrumbs, spans and events (#3094)

## 8.8.0

### Features

- Experimental support for Swift Async stacktraces (#3051)
- Cache binary images to be used for crashes (#2939)

### Fixes

- Fix a data race for `SentryId.empty` (#3072)
- Duplicated HTTP breadcrumbs (#3058)
- Expose SentryPrivate and SentrySwiftUI schemes for cartahge clients that have `--no-use-binaries` option (#3071)
- Convert last remaining `sprintf` call to `snprintf` (#3077)
- Fix a crash when serializing profiling data (#3092)

## 8.7.4

### Fixes

- Changed `Trace` serialized value of `sampled` from string to boolean (#3067)

### Breaking Changes

- Removed `nameForSentrySampleDecision` which shouldn't have been public (#3067)

## 8.7.3

### Fixes

- Convert one of the two remaining usages of `sprintf` to `snprintf` (#2866)
- Fix use-after-free ASAN warning (#3042)
- Fix memory leaks in the profiler (#3055, #3061)

## 8.7.2

### Fixed

- Fix crashes in profiling serialization race condition (#3018, #3035)
- Fix a crash for user interaction transactions (#3036)

## 8.7.1

### Fixes

- Add `sent_at` to envelope header (#2859)
- Fix import of `User` & `Breadcrumb` (#3017)

## 8.7.0

### Features

- Allow starting the SDK with an initial scope (#2982)
- Swift Error Names (#2960)

```Swift
enum LoginError: Error {
    case wrongUser(id: String)
    case wrongPassword
}

SentrySDK.capture(error: LoginError.wrongUser("12345678"))
```

For the Swift error above Sentry displays:

| sentry-cocoa SDK | Title        | Description                           |
| ---------------- | ------------ | ------------------------------------- |
| Since 8.7.0      | `LoginError` | `wrongUser(id: "12345678") (Code: 1)` |
| Before 8.7.0     | `LoginError` | `Code: 1`                             |

[Customized error descriptions](https://docs.sentry.io/platforms/apple/usage/#customizing-error-descriptions) have precedence over this feature.
This change has no impact on grouping of the issues in Sentry.

### Fixes

- Propagate span when copying scope (#2952)
- Remove "/" from crash report file name (#3005)

## 8.6.0

### Features

- Send trace origin (#2957)

[Trace origin](https://develop.sentry.dev/sdk/performance/trace-origin/) indicates what created a trace or a span. Not all transactions and spans contain enough information to tell whether the user or what precisely in the SDK created it. Origin solves this problem. The SDK now sends origin for transactions and spans.

- Create User and Breadcrumb from map (#2820)

### Fixes

- Improved performance serializing profiling data (#2863)
- Possible crash in Core Data tracking (#2865)
- Ensure the current GPU frame rate is always reported for concurrent transaction profiling metrics (#2929)
- Move profiler metric collection to a background queue (#2956)

### Removed

- Remove experimental `stitchAsyncCode` from SentryOptions (#2973)

The `stitchAsyncCode` experimental option has been removed from `SentryOptions` as its behavior was unpredictable and sometimes resulted in unexpected errors. We plan to add it back once we fix it, but we don't have an ETA for it.

## 8.5.0

### Features

- feat: Core data operation in the main thread (#2879)

### Fixes

- Crash when serializing invalid objects (#2858)
- Don't send screenshots with either width or height of 0 (#2876)
- GPU frame alignment with stack traces in profiles (#2856)

## 8.4.0

### Features

- Time to initial and full display (#2724)
- Add time-to-initial-display and time-to-full-display measurements to ViewController transactions (#2843)
- Add `name` and `geo` to User (#2710)

### Fixes

- Correctly track and send GPU frame render data in profiles (#2823)
- Xcode 14.3 compiling issue regarding functions declaration with no prototype (#2852)

## 8.3.3

### Fixes

- View hierarchy not sent for crashes (#2781)
- Crash in Tracer for idle timeout (#2834)

## 8.3.2

### Features

- Add CPU core count in device context (#2814)

### Fixes

- Updating AppHang state on main thread (#2793)
- App Hang report crashes with too many threads (#2811)

### Improvements

- Remove not needed locks in SentryUser (#2809)

## 8.3.1

### Fixes

- Stop using UIScreen.main (#2762)
- Profile timestamp alignment with transactions (#2771) and app start spans (#2772)
- Fix crash when compiling profiling data during transaction serialization (#2786)

## 8.3.0

### Important Note

This release can cause crashes when Profiling is enabled (#2779). Please update to `8.3.1`.

### Fixes

- Crash in AppHangs when no threads (#2725)
- MetricKit stack traces (#2723)
- InApp for MetricKit stack traces (#2739)
- Mutating while enumerating crash in Tracer (#2744)
- Normalize profiling timestamps relative to transaction start (#2729)

## 8.2.0

### Features

- Add enableTracing option (#2693)
- Add isMain thread to SentryThread (#2692)
- Add `in_foreground` to App Context (#2692)
- Combine UIKit and SwiftUI transactions (#2681)

### Fixes

- Cleanup AppHangTracking properly when closing SDK (#2671)
- Add EXC_BAD_ACCESS subtypes to events (#2667)
- Keep status of auto transactions when finishing (#2684)
- Fix atomic import error for profiling (#2683)
- Don't create breadcrumb for UITextField editingChanged event (#2686)
- Fix EXC_BAD_ACCESS in SentryTracer (#2697)
- Serialization of nullable booleans (#2706)

### Improvements

- Change debug image type to macho (#2701)

This change might mark 3rd party library frames as in-app, which the SDK previously marked as system frames.

## 8.1.0

### Features

- Add thread information to File I/O spans (#2573)
- AttachScreenshots is GA (#2623)
- Gather profiling timeseries metrics for CPU usage and memory footprint (#2493)
- Change SentryTracedView `transactionName` to `viewName` (#2630)

### Fixes

- Support uint64 in crash reports (#2631, #2642, #2663)
- Always fetch view hierarchy on the main thread (#2629)
- Carthage Xcode 14 compatibility issue (#2636)
- Crash in CppException Monitor (#2639)
- fix: Disable watchdog when disabling crash handler (#2621)
- MachException Improvements (#2662)

## 8.0.0

### Features

This version adds a dependency on Swift.
We renamed the default branch from `master` to `main`. We are going to keep the `master` branch for backwards compatibility for package managers pointing to the `master` branch.

- Properly demangle Swift class name (#2162)
- Change view hierarchy attachment format to JSON (#2491)
- Experimental SwiftUI performance tracking (#2271)
- Enable [File I/O Tracking](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/#file-io-tracking) by default (#2497)
- Enable [AppHang Tracking](https://docs.sentry.io/platforms/apple/configuration/app-hangs/) by default (#2600)
- Enable [Core Data Tracing](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/#core-data-tracking) by default (#2598)
- [User Interaction Tracing](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/#user-interaction-tracing) is stable and enabled by default(#2503)
- Add synthetic for mechanism (#2501)
- Enable CaptureFailedRequests by default (#2507)
- Support the [`SENTRY_DSN` environment variable](https://docs.sentry.io/platforms/apple/guides/macos/configuration/options/#dsn) on macOS (#2534)
- Experimental MetricKit integration (#2519) for
  - [MXHangDiagnostic](https://developer.apple.com/documentation/metrickit/mxhangdiagnostic)
  - [MXDiskWriteExceptionDiagnostic](https://developer.apple.com/documentation/metrickit/mxdiskwriteexceptiondiagnostic)
  - [MXCPUExceptionDiagnostic](https://developer.apple.com/documentation/metrickit/mxcpuexceptiondiagnostic)
- Add a timeout for auto-generated transactions (#2535)

### Fixes

- Errors shortly after `SentrySDK.init` now affect the session (#2430)
- Use the same default environment for events and sessions (#2447)
- Increase `SentryCrashMAX_STRINGBUFFERSIZE` to reduce the instances where we're dropping a crash due to size limit (#2465)
- `SentryAppStateManager` correctly unsubscribes from `NSNotificationCenter` when closing the SDK (#2460)
- The SDK no longer reports an OOM when a crash happens after closing the SDK (#2468)
- Don't capture zero size screenshots ([#2459](https://github.com/getsentry/sentry-cocoa/pull/2459))
- Use the preexisting app release version format for profiles (#2470)
- Don't add out of date context for crashes (#2523)
- Fix ARC issue for FileManager (#2525)
- Remove delay for deleting old envelopes (#2541)
- Fix strong reference cycle for HttpTransport (#2552)
- Deleting old envelopes for empty DSN (#2562)
- Remove `SentrySystemEventBreadcrumbs` observers with the most specific detail possible (#2489)

### Breaking Changes

- Rename `- [SentrySDK startWithOptionsObject:]` to `- [SentrySDK startWithOptions:]` (#2404)
- Make `SpanProtocol.data` non nullable (#2409)
- Mark `- [SpanProtocol setExtraValue:forKey:]` as deprecated (#2413)
- Make SpanContext immutable (#2408)
  - Remove tags from SpanContext
  - Remove context property from SentrySpan
- Bump minimum supported OS versions to macOS 10.13, iOS 11, tvOS 11, and watchOS 4 (#2414)
- Make public APIs Swift friendly
  - Rename `SentrySDK.addBreadcrumb(crumb:)` to `SentrySDK.addBreadcrumb(_ crumb:)` (#2416)
  - Rename `SentryScope.add(_ crumb:)` to `SentryScope.addBreadcrumb(_ crumb:)` (#2416)
  - Rename `SentryScope.add(_ attachment:)` to `SentryScope.addAttachment(_ attachment:)` (#2416)
  - Rename `Client` to `SentryClient` (#2403)
- Remove public APIs
  - Remove `SentryScope.apply(to:)` (#2416)
  - Remove `SentryScope.apply(to:maxBreadcrumb:)` (#2416)
  - Remove `- [SentryOptions initWithDict:didFailWithError:]` (#2404)
  - Remove `- [SentryOptions sdkInfo]` (#2404)
  - Make SentrySession and SentrySDKInfo internal (#2451)
- Marks App hang's event stacktrace snapshot as true (#2441)
- Enable user interaction tracing by default (#2442)
- Remove default attachment content type (#2443)
- Rename APM tracking feature flags to tracing (#2450)
  - Rename `SentryOptions.enableAutoPerformanceTracking` to `enableAutoPerformanceTracing`
  - Rename `SentryOptions.enableUIViewControllerTracking` to `enableUIViewControllerTracing`
  - Rename `SentryOptions.enablePreWarmedAppStartTracking` to `enablePreWarmedAppStartTracing`
  - Rename `SentryOptions.enableFileIOTracking` to `enableFileIOTracing`
  - Rename `SentryOptions.enableCoreDataTracking` to `enableCoreDataTracing`
- SentrySDK.close calls flush, which is a blocking call (#2453)
- Bump minimum Xcode version to 13 (#2483)
- Rename `SentryOptions.enableOutOfMemoryTracking` to `SentryOptions.enableWatchdogTerminationTracking` (#2499)
- Remove the automatic `viewAppearing` span for UIViewController APM (#2511)
- Remove the permission context for events (#2529)
- Remove captureEnvelope from Hub and Client (#2580)
- Remove confusing transaction tag (#2574)

## 7.31.5

### Fixes

- Crash in SentryOutOfMemoryScopeObserver (#2557)

## 7.31.4

### Fixes

- Screenshot crashes when application delegate has no window (#2538)

## 7.31.3

### Fixes

- Reporting crashes when restarting the SDK (#2440)
- Core data span status with error (#2439)

## 7.31.2

### Fixes

- Crash in Client when reading integrations (#2398)
- Don't update session for dropped events (#2374)

## 7.31.1

### Fixes

- Set the correct OOM event timestamp (#2394)

## 7.31.0

### Features

- Store breadcrumbs to disk for OOM events (#2347)
- Report pre-warmed app starts (#1969)

### Fixes

- Too long flush duration (#2370)
- Do not delete the app state when OOM tracking is disabled. The app state is needed to determine the app start type on the next app start. (#2382)

## 7.30.2

### Fixes

- Call UIDevice methods on the main thread (#2369)
- Avoid sending profiles with 0 samples or incorrectly deduplicated backtrace elements (#2375)

## 7.30.1

### Fixes

- Fix issue with invalid profiles uploading (#2358 and #2359)

## 7.30.0

### Features

- Profile concurrent transactions (#2227)
- HTTP Client errors (#2308)
- Disable bitcode for Carthage distribution (#2341)

### Fixes

- Stop profiler when app moves to background (#2331)
- Clean up old envelopes (#2322)
- Crash when starting a profile from a non-main thread (#2345)
- SentryCrash writing nan for invalid number (#2348)

## 7.29.0

### Features

- Offline caching improvements (#2263)
- Report usage of stitchAsyncCode (#2281)

### Fixes

- Enable bitcode (#2307)
- Fix moving app state to previous app state (#2321)
- Use CoreData entity names instead of "NSManagedObject" (#2329)

## 7.28.0

### Features

- [Custom measurements API](https://docs.sentry.io/platforms/apple/performance/instrumentation/custom-instrumentation/) (#2268)

### Fixes

- Device info details for profiling (#2205)

### Performance Improvements

- Use double-checked lock for flush (#2290)

## 7.27.1

### Fixes

- Add app start measurement to first finished transaction (#2252)
- Return SentryNoOpSpan when starting a child on a finished transaction (#2239)
- Fix profiling timestamps for slow/frozen frames (#2226)

## 7.27.0

### Features

- Report [start up crashes](https://docs.sentry.io/platforms/apple/guides/ios/) (#2220)
- Add segment property to user (#2234)
- Support tracePropagationTargets (#2217)

### Fixes

- Correctly attribute enterprise builds (#2235)

## 7.26.0

### Features

- [Core Data Tracking](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/#core-data-tracking) is stable (#2213)
- [File I/O Tracking](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/#file-io-tracking) is stable (#2212)
- Add flush (#2140)
- Add more device context (#2190)

### Fixes

- Sentry-trace header incorrectly assigned to http requests (#2167)
- Use the `component` name source for SentryPerformanceTracker (#2168)
- Add support for arm64 architecture to the device context (#2185)
- Align core data span operations (#2222)

## 7.25.1

### Performance Improvements

- Prewarmed app start detection (#2151)

## 7.25.0

### Features

- Users can [customize the error description](https://docs.sentry.io/platforms/apple/usage/#customizing-error-descriptions) shown in the Sentry UI by providing an NSDebugDescriptionErrorKey value in the error user info dictionary. (#2120)
- Add support for dynamic library (#1726)

### Fixes

- Can't find app image when swizzling (#2124)
- Crash with screenshot is reported twice (#2134)
- Setting SDK name through `options[sdk][name]` shouldn't clear version (#2139)

## 7.24.1

### Fixes

- Remove Media Library Permission check from permission observer (#2123)

## 7.24.0

### Features

- App permissions are now also included when running from an app extension (#2106)
- Report App Memory Usage (#2027)
- Include app permissions with event (#1984)
- Add culture context to event (#2036)
- Attach view hierarchy to events (#2044)
- Clean up SentryOptions: added `enableCrashHandler` and deprecated `integrations` (#2049)
- Integrations send the [transaction name source](https://develop.sentry.dev/sdk/event-payloads/transaction/#transaction-annotations) (#2076)
- Added extra logs when creating automatic transactions and spans (#2087)

### Fixes

- Fix Swift 5.5 compatibility (#2060)
- Add span finish flag (#2059)
- SentryUser.userId should be nullable (#2071)
- Send time zone name, not abbreviation (#2091)
- Use a prime number for the profiler's sampling rate to reduce the potential for [lock-step](https://stackoverflow.com/a/45471031) issues (#2055).
- Improve App Hangs detection (#2100)
- Send `environment` set from `SentryOptions` or `configureScope` with profiling data (#2095)

## 7.24.0-beta.0

### Features

- Report App Memory Usage (#2027)
- Include app permissions with event (#1984)
- Add culture context to event (#2036)
- Attach view hierarchy to events (#2044)
- Clean up SentryOptions: added `enableCrashHandler` and deprecated `integrations` (#2049)
- Integrations send the [transaction name source](https://develop.sentry.dev/sdk/event-payloads/transaction/#transaction-annotations) (#2076)
- Added extra logs when creating automatic transactions and spans (#2087)

### Fixes

- Fix Swift 5.5 compatibility (#2060)
- Add span finish flag (#2059)
- SentryUser.userId should be nullable (#2071)
- Send time zone name, not abbreviation (#2091)
- Use a prime number for the profiler's sampling rate to reduce the potential for [lock-step](https://stackoverflow.com/a/45471031) issues (#2055).
- Improve App Hangs detection (#2100)
- Send `environment` set from `SentryOptions` or `configureScope` with profiling data (#2095)

## 7.23.0

### Features

- Add sampling configuration for profiling (#2004)
- Add transaction to baggage and trace headers (#1992)

### Fixes

- Log empty samples instead of collecting stacks for idle threads (#2013)
- Remove logging that could occur while a thread is suspended (#2014)
- Handle failure to read thread priority gracefully (#2015)
- Fix address sanitizer compilation error (#1996)

## 7.22.0

### Features

- Read free_memory when the event is captured, not only at SDK startup (#1962)
- Provide private access to SentryOptions for hybrid SDKs (#1991)

### Fixes

- Remove Sentry keys from cached HTTP request headers (#1975)
- Collect samples for idle threads in iOS profiler (#1978)
- Fix removeNonSdkFrames working incorrectly for os users named sentry(#2002)
- Don't override already-set timestamp when finishing Span (#1993)
- Respect existing baggage header instead of overwriting it (#1995)

## 7.21.0

### Features

- Enhance the UIViewController breadcrumbs with more data (#1945)
- feat: Add extra app start span (#1952)
- Add enableAutoBreadcrumbTracking option (#1958)
- Automatic nest spans with the UI life cycle (#1959)
- Upload frame rendering timestamps to correlate to sampled backtraces (#1910)
- Remove PII from auto-generated core data spans (#1982)

### Fixes

- Don't track OOMs for simulators (#1970)
- Properly sanitize the event context and SDK information (#1943)
- Don't send error 429 as `network_error` (#1957)
- Sanitize Span data (#1963)
- Deprecate not needed option `sdkInfo` (#1960)
- Crash in profiling logger (#1964)

## 7.20.0

### Features

- Add screenshot at crash (#1920)
- Track timezone changes as breadcrumbs (#1930)
- Add sample rate in the baggage header, remove Userid and Transaction (#1936)

## 7.19.0

### Features

- Add main thread ID to profiling payload (#1918)
- Add App Hangs tracking (#1906)

### Fixes

- Remove WebKit optimization check (#1921)
- Detect prewarmed starts with env variable (#1927)

## 7.18.1

### Fixes

- Fix high percentage of slow frames (#1915)

## 7.18.0

### Features

- Replace tracestate header with baggage (#1867)

### Fixes

- Discard long-lasting auto-generated transactions (#1903)
- Unset scope span when finishing idle transaction (#1902)
- Set max app start duration to 60s (#1899)
- Screenshot wrongly attached in crash events (#1901)

## 7.17.0

### Features

- Implement description for SentryBreadcrumb (#1880)

### Fixes

- Propagate configured SDK info from options to events (#1853)
- Stop reporting pre warmed app starts (#1896)

## 7.16.1

### Fixes

- Fix reporting wrong OOM when starting SDK twice (#1878)
- Fix JSON conversion error message (#1856)
- Transaction tag and data serialization (#1826)

## 7.16.0

### Features

- UI event transactions for clicks (#1784)
- Collect queue label information for profiles (#1828)
- Use the macho format for debug information in Profiling (#1830)
- Allow partial SDK info override (#1816)

### Fixes

- Hub uses its scope (#1821)

## 7.15.0

### Features

- Add profile data category for rate limiting (#1799)
- Allow setting SDK info with Options initWithDict (#1793)
- Remove ViewController name match for swizzling (#1802)

### Fixes

- Apply patch for SentryCrashCachedData (#1790)
- Fix getting class data mask in SentryCrash (#1788)
- Use pod_target_xcconfig for Podspec #1792
- Case sensitive header import error (#1794)
- Parsing of output from backtrace_symbols() (#1782)

## 7.14.0

- fix: User feedback crash (#1766)
- feat: Attach screenshots for errors (#1751)
- fix: Remove authenticated pointer stripping for iOS backtraces (#1757)
- perf: Filter binary images on Sentry Crash (#1767)
- fix: NSURL warning during SDK initialization (#1764)

## 7.13.0

If you are using self-hosted Sentry, this version requires Sentry version >= [21.9.0](https://github.com/getsentry/relay/blob/master/CHANGELOG.md#2190)
to work or you have to manually disable sending client reports via the `sendClientReports` option.

- feat: Add Client Reports (#1733)
- fix: enableProfiling option via initWithDict (#1743)

## 7.12.0

### Important notice

This release contains a fix for the sampling of transactions. The SDK applied both sample rates for events and transactions when capturing transactions. Previously, when setting sampleRate to 0.0, the SDK would discard all transactions.
This is fixed now by ignoring the sampleRate for transactions. If you use custom values for sampleRate and traceSampleRate or traceSampler, this change will have an impact on you.

If you are using profiling and self-hosted Sentry, this version requires Sentry version >= [22.3.0](https://github.com/getsentry/relay/releases/tag/22.3.0).

### Various fixes & improvements

- fix: Avoid race condition in SentryCrash (#1735)
- fix: Possible endless loop for onCrashedLastRun (#1734)
- fix: Wrongly sampling transactions (#1716)
- feat: Add flag for UIViewControllerTracking (#1711)
- feat: Add more info to touch event breadcrumbs (#1724)
- feat: Add support for profiling on iOS (#1652) by @armcknight

## 7.12.0-beta.0

### Various fixes & improvements

- feat: Add support for profiling on iOS (#1652) by @armcknight

## 7.11.0

- feat: Add CoreData performance tracking (#1682)
- fix: Detecting ANRs as false OOMs (#1695)

## 7.10.2

- fix: Crash in UIViewControllerSwizzling (#1692)

## 7.10.1

- fix: Swizzling UIViewControllers crash (#1670)
- feat: Expose Installation ID for Hybrid SDKs (#1680)
- fix: SentryNSURLSessionTaskSearch using invalid nil parameter with NSURLSession (#1669)

## 7.10.0

- fix: Always tracks App start for Hybrid SDKs (#1662)
- feat: Send SDK integrations (#1647)
- fix: Don't track OOMs for unit tests (#1651)
- fix: Add verification for vendor UUID in OOM logic (#1648)
- fix crash in dirContentsCount() when dir == NULL (#1658)

## 7.9.0

- fix: Crash in SentrySubClassFinder (#1635)
- fix: Set timestamp in init of event (#1629)
- fix: Load invalid CrashState json (#1625)
- feat: Auto I/O spans for NSData (#1557)

## 7.8.0

- feat: Support for fatalError, assert, precondition (#1596)
- feat: Include unfinished spans in transactions (#1592)
- build: Disable NSAssertions for Release Builds (#1545)

## 7.7.0

- feat: Send Locale with Events (#1539)

## 7.6.1

- fix: iOS13-Swift build (#1522)
- fix: Check task support on setState: (#1523)

## 7.6.0

- fix: Create span for loadView (#1495)
- feat: Add flag to control network requests breadcrumbs (#1505)
- feat: Support for ignored signals with SIGN_IGN (#1489)

## 7.5.4

- fix: Sending OOM when SDK is closed (#1487)

## 7.5.3

- fix: Use swizzling instead of KVO for network tracking (#1452)

## 7.5.2

### Various fixes & improvements

- fix: AppStart Transaction for Apps Using UIScenes (#1427) by @brustolin

## 7.5.1

- fix: SentryOptions initWithDict type errors (#1443)
- fix: Transaction default status should be OK (#1439)
- fix: AppStart Transaction for Apps Using UIScenes (#1427)

## 7.5.0

- feat: Add one flag to disable all swizzling (#1430)
- fix: Dispatch Queue ARC Warning for RN (#1424)
- fix: Dictionary Key cannot be nil, in SentryPerformanceTracer (#1434)

## 7.4.8

- fix: Crash when objc_getClassList returns different values (#1420)

## 7.4.7

- fix: Only enable APM when traceRate set (#1417)
- fix: Crash in Span when Tracer nil (#1416)
- fix: Instrumenting multiple UIViewControllers (#1409)
- fix: Clear unfinished transaction in UIViewController APM (#1408)

## 7.4.6

- fix: Crash when Getting Subclasses (#1396)

## 7.4.5

- fix: Remove Check for Original Method Call When Swizzling (#1383)
- fix: Init for Span, Tracer, Transaction (#1385)

## 7.4.4

- fix: Crash for Call Should be on Main Thread (#1371)

## 7.4.3

- fix: Crash for Custom ViewController init on iOS 15 (#1361)

## 7.4.2

- fix: Crash When Observing Span Finished (#1360)

## 7.4.1

- fix: HTTP instrumentation KVO crash (#1354)

## 7.4.0

- feat: Add enableNetworkTracking flag (#1349)
- fix: Memory Leak for Span (#1352)

## 7.3.0

- fix: Trying to swizzle a class without a library name (#1332)

## 7.3.0-beta.0

- fix: maxBreadcrumb zero crashes when adding (#1326)

- feat: Add tracestate HTTP header support (#1291)

## 7.2.10

- No documented changes.

## 7.2.9

- Nothing

## 7.2.8

- fix: SpanProtocol add setData for Swift (#1305)
- fix: SentryHub not checking spanContext sampled value (#1318)

## 7.2.7

- fix: Remove Trace Headers below iOS 14.0 (#1309)
- fix: XCFramework output not preserving symlinks for macOS (#1281)

## 7.2.6

- fix: Add Trace Headers below iOS 14.0 (#1302)

## 7.2.5

- fix: Swizzling crash on iOS 13 (#1297)

## 7.2.4

- fix: Sentry HTTP Trace Header Breaking Requests (#1295)
- fix: Apps crash when using a URLSessionTask subclass with currentRequest unavailable (#1294)

## 7.2.3

- fix: Build failure for SPM (#1284)
- fix: Set app state on main thread when terminating (#1272)

## 7.2.2

- fix: Crash when swizzling Nib UIViewController (#1277)

## 7.2.1

This release fixes a crucial issue for auto performance instrumentation that caused crashes when using nested ViewControllers.

- fix: Callback issue for auto performance (#1275)

## 7.2.0

This release contains support for [auto performance instrumentation](https://docs.sentry.io/platforms/apple/performance/instrumentation/automatic-instrumentation/)
for ViewControllers, HTTP requests, app start and slow and frozen frames.

### Auto Performance Features

- feat: Auto UI Performance Instrumentation (#1105, #1150, #1136, #1139, #1042, #1264, #1164, #1202, #1231, #1242)
- feat: Measure slow and frozen frames (#1123)
- feat: Measure app start time (#1111, #1228)
- feat: Add automatic HTTP request performance monitoring (#1178, #1237, #1250, #1255)
- feat: Add tags to Sentry Span (#1243)
- feat: Sub-millis precision for spans and events (#1234)
- feat: Add Sentry Trace HTTP Header (#1213)

### More Features

- feat: Add flag stichAsyncCode (#1172)
- feat: Support XCFramework for Carthage (#1175)
- feat: Add isEnabled property in SentrySDK (#1265)
- feat: Add breadcrumbs for HTTP requests (#1258)
- feat: Add clearAttachments to Scope (#1195)
- feat: Expose tracked screen frames (#1262)
- feat: Expose AppStartMeasurement for Hybrid SDKs (#1251)

### Fixes

- fix: Remove invalid excludes from `Package.swift` (#1169)
- fix: Compile failure with C99 (#1224)
- fix: Race on session task (#1233)
- fix: Remove tags and data if empty for Span (#1246)

### Performance Improvements

- perf: Scope sync to SentryCrash (#1193)

## 7.2.0-beta.9

- feat: Expose tracked screen frames (#1262)
- feat: Expose AppStartMeasurement for Hybrid SDKs (#1251)
- fix: Span serialization HTTP data in wrong place. (#1255)
- feat: Add tags to Sentry Span (#1243)

## 7.2.0-beta.8

- fix: Remove tags and data if empty for Span (#1246)
- fix: Race Conditions in NetworkTracker (#1250)
- fix: Don't create transactions for HTTP Requests. (#1237)

## 7.2.0-beta.7

- fix: Swizzle only inApp ViewControllers (#1242)
- feat: Add Sentry Trace HTTP Header (#1213)
- feat: Sub-millis precision for spans and events (#1234)
- fix: Race on session task (#1233)

## 7.2.0-beta.6

- fix: ViewController swizzling before iOS 13 (#1231)
- fix: AppStartMeasurement didFinishLaunching is nil (#1228)

## 7.2.0-beta.5

- perf: Scope sync to SentryCrash (#1193)
- fix: Compile failure with C99 (#1224)

## 7.2.0-beta.4

- fix: Add viewAppearing to UIViewController spans (#1202)

## 7.2.0-beta.3

- feat: Add automatic http request performance monitoring (#1178)
- feat: Add clearAttachments to Scope (#1195)

## 7.2.0-beta.2

- feat: Add flag stichAsyncCode (#1172)
- feat: Support XCFramework for Carthage (#1175)
- fix: Remove invalid excludes from `Package.swift` (#1169)

## 7.2.0-beta.1

- feat: Measure slow and frozen frames (#1123)
- fix: Operation names for auto instrumentation (#1164)

## 7.2.0-beta.0

- feat: Measure app start time (#1111)
- feat: Auto UI Performance Instrumentation (#1105, #1150, #1136, #1139, #1042)

## 7.1.4

- fix: Compile failure with C99 (#1224)

## 7.1.3

- feat: Add PrivateSentrySDKOnly (#1131)

## 7.1.2

- fix: Serialization of span description (#1128)

## 7.1.1

- No documented changes. This is the same as 7.1.0. Ignore this release and please use 7.1.2 instead.

## 7.1.0

- fix: Remove SentryUnsignedLongLongValue (#1118)
- feat: Expose SentryDebugImageProvider (#1094)
- docs: Improve code doc on start and endSession (#1098)

## 7.0.3

- fix: Add SentryMechanismMeta to Sentry.h (#1102)

## 7.0.2

- No documented changes. This is the same as 7.0.1. Ignore this release and please use 7.0.3 instead.

## 7.0.1

ref: Prefix TracesSampler with Sentry (#1091)

## 7.0.0

This is a major bump with the [Performance Monitoring API](https://docs.sentry.io/platforms/apple/performance/) and [Out of Memory Tracking](https://docs.sentry.io/platforms/apple/configuration/out-of-memory/), many improvements and a few breaking changes.
For a detailed explanation how to upgrade please checkout the [migration guide](https://docs.sentry.io/platforms/apple/migration/).

### Breaking Changes

- ref: Add SentryMechanismMeta (#1048)
- ref: Align SentryException with unified API (#1026)
- ref: Remove deprecated SentryHub.getScope (#1025)
- ref: Make closeCachedSessionWithTimestamp private (#1022)
- ref: Improve envelope API for Hybrid SDKs (#1020)
- ref: Remove currentHub from SentrySDK (#1019)
- feat: Add maxCacheItems (#1017)
- ref: SentryEvent.timestamp changed to nullable.
- ref: Add read-only scope property to Hub (#975)
- ref: Remove SentryException.userReported (#974)
- ref: Replace SentryLogLevel with SentryLevel (#979)
- fix: Mark frames as inApp (#956)

### Features

- feat: Performance Monitoring API (#909, #977, #961, #932, #919, #992, #1065, #1042, #1079, #1061, #1069, #1066, #1040, #1084)
- feat: Out Of Memory Tracking (#1001, #1015)
- feat: Add close method to SDK (#1046)
- feat: Add start and endSession to SentrySDK (#1021)
- feat: Add urlSessionDelegate option to SentryOptions (#965)

### Fixes

- ref: Set sample rates to default if out of range (#1074): When setting a value `SentryOptions.sampleRate` that is not >= 0.0 and <= 1.0 the SDK sets it to the default of 1.0.
- fix: Release builds in CI (#1076)
- perf: Avoid allocating dict in BreadcrumbTracker (#1027)
- fix: Crash when passing garbage to maxBreadcrumbs (#1018)
- fix: macOS version for Mac Catalyst (#1011)

## 7.0.0-beta.1

### Features and Fixes

- ref: Set sample rates to default if out of range (#1074): When setting a value `SentryOptions.sampleRate` that is not >= 0.0 and <= 1.0 the SDK sets it to the default of 1.0.
- feat: Add trace information from scope to event capture (#1065)
- fix: SentryOptions.tracesSampleRate default value (#1069)
- ref: Discard unfinished spans when capturing transaction (#1066)
- ref: Make calls to customSamplingContext nonnull (#1061)
- ref: Mark async call chains explicitly as such (#1071)
- fix: fix: performance headers (#1079)
- fix: performance headers (#1079)
- fix: Release builds in CI (#1076)

## 7.0.0-beta.0

- feat: Add close method to SDK #1046

## 7.0.0-alpha.5

### Breaking Changes

- ref: Add SentryMechanismMeta #1048: Replaced dict `SentryMechanism.meta` with new class `SentryMechanismMeta`. Moved `SenryNSError` to `SentryMechanismMeta`.

### Features and Fixes

- feat: Async callstacks are being tracked by wrapping the `dispatch_async` and related APIs. #998
- feat: Add transaction to the scope #992
- fix: Pass SentryTracer to span child #1040
- feat: Add span to SentrySDK #1042
- feat: Add urlSessionDelegate option to SentryOptions #965

## 7.0.0-alpha.4

### Breaking Changes

- ref: Align SentryException with unified API #1026: Replaced `SentryException.thread` with `SentryException.threadId` and `SentryException.stacktrace`.
- ref: Remove deprecated SentryHub.getScope #1025: Use `SentryHub.scope` instead.
- ref: Make closeCachedSessionWithTimestamp private #1022
- ref: Improve envelope API for Hybrid SDKs #1020: We removed `SentryClient.storeEnvelope`, which is reserved for Hybrid SDKs.
- ref: Remove currentHub from SentrySDK #1019: We removed `SentrySDK.currentHub` and `SentrySDK.setCurrentHub`. In case you need this methods, please open up an issue.
- feat: Add maxCacheItems #1017: This changes the maximum number of cached envelopes from 100 to 30. You can configure this number with `SentryOptions.maxCacheItems`.

### Features and Fixes

- perf: Avoid allocating dict in BreadcrumbTracker #1027
- feat: Add start and endSession to SentrySDK #1021
- fix: Crash when passing garbage to maxBreadcrumbs #1018
- fix: OutOfMemory exception type #1015
- fix: macOS version for Mac Catalyst #1011

## 7.0.0-alpha.3

- feat: Out Of Memory Tracking #1001

## 7.0.0-alpha.2

### Features

- feat: Performance Monitoring API (#909, #977, #961, #932, #919)

### Breaking Changes

- SentryEvent.timestamp changed to nullable.

## 7.0.0-alpha.1

Features and fixes:

- ref: Add read-only scope property to Hub #975

### Breaking Changes

- ref: Add read-only scope property to Hub #975
- ref: Remove SentryException.userReported #974
- ref: Replace SentryLogLevel with SentryLevel #978

## 7.0.0-alpha.0

**Breaking Change**: This version introduces a change to the grouping of issues. The SDK now sets the `inApp`
flag for frames originating from only the main executable using [CFBundleExecutable](https://developer.apple.com/documentation/bundleresources/information_property_list/cfbundleexecutable).
In previous versions, all frames originating from the application bundle were marked as `inApp`. This had the
downside of marking frames of private frameworks inside the bundle as `inApp`. This problem is fixed now.
Applications using static frameworks shouldn't be affected by this change.
For more information on marking frames as inApp [docs](https://docs.sentry.io/platforms/apple/data-management/event-grouping/stack-trace-rules/#mark-in-app-frames).

- fix: Mark frames as inApp #956

## 6.2.1

- fix: Redundant x29 GP register on arm64 and UBSan crash #964

## 6.2.0

With this version, Sentry groups errors by domain and code. MyDomain 1 and MyDomain 2
are going to be two separate issues in Sentry. If you are using self-hosted Sentry,
it requires Sentry version >= v21.2.0 to work. Staying on Sentry < v21.2.0 and upgrading
to this version of the SDK won't do any damage. Sentry will group like in previous
versions, but you will see a new group because we slightly changed the wording. If you
are using sentry.io no action is needed. In case you are not satisfied with this change,
you can take a look at
[SDK fingerprinting](https://docs.sentry.io/platforms/apple/data-management/event-grouping/sdk-fingerprinting/)
to group by domain only.

- fix: Use mechanism meta for error grouping #946
- fix: Sanitize SentryMechanism.data on serialize #947
- feat: Add error to SentryEvent #944
- fix: Mark SentryEvent.message as Nullable #943
- fix: Stacktrace inApp marking on Simulators #942
- feat: Group NSError by domain and code #941
- fix: Discard Sessions when JSON is faulty #939
- feat: Add sendDefaultPii to SentryOptions #923

## 6.1.4

- fix: Sessions for Hybrid SDKs #913

## 6.1.3

- fix: Capture envelope updates session state #906

## 6.1.2

- fix: Clash with KSCrash functions #905

## 6.1.1

- fix: Duplicate symbol clash with KSCrash #902

## 6.1.0

- perf: Improve locks in SentryScope #888

## 6.1.0-alpha.1

- fix: Change maxAttachmentSize from MiB to bytes #891
- feat: Add maxAttachmentSize to SentryOptions #887
- ref: Remove SentryAttachment.isEqual and hash #885
- ref: Remove SentryScope.isEqual and hash #884

## 6.1.0-alpha.0

- feat: Add basic support for attachments #875

## 6.0.12

- fix: Crash in SentrySession.serialize #870

## 6.0.11

- perf: Drop global dispatch queue (#869)
- fix: Increase precision of iso8601 date formatter #860

## 6.0.10

- feat: Add onCrashedLastRun #808
- feat: Add SentrySdkInfo to SentryOptions #859

## 6.0.9

- fix: Serialization of SentryScope #841
- fix: Recrash parsing in SentryCrash #850
- fix: Not crash during crash reporting #849

## 6.0.8

- feat: Add storeEnvelope on SentryClient #836
- perf: Async synching of scope on to SentryCrash #832

## 6.0.7

- fix: Drop Sessions without release name #826
- feat: Bring back SentryOptions.enabled #818
- fix: Remove enum specifier for SentryLevel #822
- feat: Send environment 'production' if nothing was set #825
- fix: Typo for Swift name: UserFeedback #829

## 6.0.6

- fix: Call beforeBreadcrumb for Breadcrumb Tracker #815

## 6.0.5

- fix: Add eventId to user feedback envelope header #809
- feat: Manually capturing User Feedback #804

## 6.0.4

- fix: Sanitize UserInfo of NSError and NSException #770
- fix: Xcode 12 warnings for Cocoapods #791

## 6.0.3

- fix: Making SentrySdkInfo Public #788

## 6.0.2

- fix: iOS 13.4 Runtime Crash #786
- fix: Using wrong SDK name #782
- feat: Expose `captureEnvelope` on the client #784
- fix: Remove initWithJSON from SentryEvent #781
- fix: Carthage for Xcode 12 #780
- fix: Add missing SentrySdkInfo.h to umbrella header #779
- ref: Remove event.json field #768

## 6.0.1

- fix: Warning Duplicate build file in Copy Headers #761
- fix: Warning when integrating SDK via Carthage #760
- feat: Set installationId to userId if no user is set #757

## 6.0.0

This is a major bump with lots of internal improvements and a few breaking changes.
For a detailed explanation how to updgrade please checkout the [migration guide](https://docs.sentry.io/platforms/apple/migration/).

Breaking changes:

- fix: Make SentryMessage formatted required #756
- feat: Add SentryMessage #752
- feat: Replace passing nullable Scope with overloads #743
- feat: Remove SentryOptions.enabled #736
- fix: Public Headers #735
- feat: Attach stacktraces to all events by default #705
- feat: Replace NSNumber with BOOL in SentryOptions #719
- feat: Enable auto session tracking per default #689
- feat: Remove deprecated SDK inits #673
- feat: Bump minimum iOS version to 9.0 #669
- fix: Umbrella header #671
- feat: Replace NSString for eventId with SentryId #668
- feat: Use envelopes for sending events #650

Features and fixes:

- fix: Make public isEqual \_Nullable #751
- feat: Use error domain and code for event message #750
- feat: Remove SDK frames when attaching stacktrace #739
- fix: captureException crates a event type=error #746
- fix: Setting environment for Sessions #734
- feat: Crash event and session in same envelope #731
- feat: Allow nil in setExtraValue on SentryScope to remove key #703
- fix: Header Imports for the Swift Package Manager #721
- fix: Async storing of envelope to disk #714
- feat: Migrate session init for stored envelopes #693
- fix: Remove redundant sdk options enable check in SentryHttpTransport #698
- fix: Sending envelopes multiple times #687
- fix: Rate limiting for cached envelope items #685
- feat: Errors and sessions in the same envelope #686
- feat: Implement NSCopying for SentrySession #683
- fix: Crash when SentryClient is nil in SentryHub #681
- feat: Send cached envelopes first #676

## 6.0.0-beta.2

Breaking changes:

- feat: Remove SentryOptions.enabled #736
- fix: Public Headers #735

Fix:

- fix: Setting environment for Sessions #734

## 6.0.0-beta.1

This release also enables by default the option `attackStacktrace` which includes
the stacktrace in all events, including `captureMessage` by default.

Breaking Changes:

- feat: Attach stacktraces to all events by default #705

Features and fixes:

- feat: Crash event and session in same envelope #731
- feat: Allow nil in setExtraValue on SentryScope to remove key #703

## 6.0.0-beta.0

Breaking changes:

- feat: Replace NSNumber with BOOL in SentryOptions #719

Features and fixes:

- fix: Header Imports for the Swift Package Manager #721
- fix: Async storing of envelope to disk #714
- feat: Migrate session init for stored envelopes #693
- fix: Remove redundant sdk options enable check in SentryHttpTransport #698

## 6.0.0-alpha.0

**Breaking Change**: This version uses the [envelope endpoint](https://develop.sentry.dev/sdk/envelopes/).
If you are using an on-premise installation it requires Sentry version
`>= v20.6.0` to work. If you are using sentry.io nothing will change and
no action is needed. Furthermore, with this version
[auto session tracking](https://github.com/getsentry/sentry-cocoa/blob/7876949ca78aebfe7883432e35727993c5c30829/Sources/Sentry/include/SentryOptions.h#L101)
is enabled per default.
[This feature](https://docs.sentry.io/product/releases/health/)
is collecting and sending health data about the usage of your
application.
We are going to add the official migration guide in one of the next beta releases.

Here is an overview of all the breaking changes:

- feat: Enable auto session tracking per default #689
- feat: Remove deprecated SDK inits #673
- feat: Bump minimum iOS version to 9.0 #669
- fix: Umbrella header #671
- feat: Replace NSString for eventId with SentryId #668
- feat: Use envelopes for sending events #650

Other new features and fixes:

- fix: Sending envelopes multiple times #687
- fix: Rate limiting for cached envelope items #685
- feat: Errors and sessions in the same envelope #686
- feat: Implement NSCopying for SentrySession #683
- fix: Crash when SentryClient is nil in SentryHub #681
- feat: Send cached envelopes first #676

## 5.2.2

- feat: Add crashedLastRun to SentrySDK #688

## 5.2.1

- fix: Add IP address to user serialization #665
- fix: Crash in SentryEnvelope.initWithEvent #643
- fix: Build failure for Apple Silicon Macs #588
- feat: capture userinfo from NSError and NSException #679

## 5.2.0

- fix: nxgetlocalarch app store #651

## 5.1.10

- fix: Crash when converting Recrash Report #627
- feat: Add SdkInfo to Envelope Header #626
- fix: Deserialize envelope with header and item #620
- fix: Set LogLevel in startWithConfigureOptions #613

## 5.1.10-beta.0

- fix: Abnormal sessions #607

## 5.1.9

- fix: beforeSend callback in SentryClient #608

## 5.1.8

- fix: Cocoapods build

## 5.1.7

- fix: Overwriting stack trace for crashes #605
- fix: Deployment target warning for Swift Package Manager for Xcode 12 #586

## 5.1.6

- feat: Simplified SDK start #580
- fix: Custom release name for crash reports #590

## 5.1.5

- feat: Attach the stacktrace to custom events #583
- fix: SentryCrashJSON encodeObject crash #576
- feat: Added automatic breadcrumbs for system events #559

## 5.1.4

- fix: Increase max report length #569
- fix: Remove weak ref file contents #571

## 5.1.3

- fix: UUID for SentryCrashReport is null #566

## 5.1.2

- feat: Attach stacktrace of current thread to events #561

## 5.1.1

- fix: Prefix categories methods with sentry #555
- feat: Attach DebugMeta to Events #545
- fix: Duplicate symbol for SentryMeta #549
- feat: Set SUPPORTS_MACCATALYST to YES explicitly #547

## 5.1.0

- fix: Make properties of Session readonly #541
- fix: Remove MemoryWarningIntegration #537
- fix: Avoid Implicit conversion in SentrySession #540
- fix: Change SentryScope setTagValue to NSString #524

## 5.0.5

- feat: Add remove methods for SentryScope #529
- fix: Failing MacOS build #530
- ref: Session values are unsigned #527

## 5.0.4

- fix: End file at the right place with #ifdef #521

## 5.0.3

- fix: Exit session with timestamp #518
- feat: Add sentry_sanitize for NSArray #509

## 5.0.2

- fix: Keep maximum rate limit #498
- fix: Ignore unknown rate limit categories #497
- fix: On app exit, close session as healthy #500

## 5.0.1

- fix: Flakey concurrent test for RateLimits #493
- fix: missing breadcrumbs data on hardcrash #492

## 5.0.0

- GA of major version 5

## 5.0.0-rc.1

- feat: Add support for mac catalyst #479
- fix: RateLimitCategories #482
- fix: RetryAfter treated like all categories #481
- feat: RateLimiting for cached events and envelopes #480
- fix: EnvelopeRateLimit init envelope with header #478

## 5.0.0-beta.7

- feat: RateLimit for non cached Envelopes #476
- fix: Use RateLimitCategoryError for events #470
- feat: Store SentryEnvelopes in extra path #468
- feat: Adds setUser to SentrySDK and SentryHub #467
- feat: Add auto session starting for macOS #463
- fix: Take release name from options #462
- feat: Use new envelope endpoint #475
- feat: App lifecycle events as breadcrumbs #474

## 5.0.0-beta.6

- feat: RateLimit for sendAllStoredEvents #458
- fix: Use maxBreadcrumbs from options #451
- fix: Send vmaddr if available for apple crash reports #459

## 5.0.0-beta.5

- fix: Limit number of breadcrumbs #450

## 5.0.0-beta.4

- feat: Add Sentry initialization function 'start' #441
- fix: Crashed sessions are marked as such #448

## 5.0.0-beta.3

- fix: Persisting Scope with CrashReport
- fix: Frame in app detection #438
- fix: Session ending as Crashed #439

## 5.0.0-beta.2

- fix: The order of how integrations are initialized (fixes not sending crashes on startup)
- fix: Add missing header files to umbrella header

## 5.0.0-beta.1

- feat: Added Session Feature
- feat: New option `enableAutoSessionTracking` set to `true` if you want sessions to be enabled
- feat: Add `_crashOnException:` to handle exceptions for AppKit apps on macOS

## 5.0.0-beta.0

- feat: Added internal `captureEnvelope` method

## 5.0.0-alpha.0

**_BREAKING_**: This is the first public release of our new `5.0.0` #339 version of the SDK.
The majority of the public API of the SDK changed, now it's more streamlined with other Sentry SDKs and prepared for future updates.
Please read the migration guide how to use the new SDK [MIGRATION.MD](MIGRATION.md)

## 4.5.0

- fix: Mac Catalyst detection
- fix: Add null checks in crash reporter
- fix: Check type of key before use it as NSString (#383)
- fix: Use rawKey to get object from dictionary (#392)
- fix: Change instantiating SentryMechanism of unknown exception type (#385)

## 4.4.3

- feat: Swift Package Manager support #352
- fix: travis lane lint #345

## 4.4.2

- feat: Prefer snprintf over sprintf #342

## 4.4.1

- feat: Add support for custom context and event types

## 4.4.0

- feat: Helper property on event to send raw payload

## 4.3.4

- fix: #305

## 4.3.3

- fix: 64 int conversion #296
- fix: Extracting reason of NSException

## 4.3.2

- fix: [SentryThread serialize] will crash when threadId is nil #292

## 4.3.1

- ref: Make `event_id` all lowercase
- feat: Emit log error in case no shared client is set and crash handler was started
- ref: Renamed `Container+DeepSearch` to `Container+SentryDeepSearch`
- ref: Renamed `NSData+Compression` to `NSData+SentryCompression`
- ref: Renamed `NSDate+Extras` to `NSDate+SentryExtras`
- ref: Renamed `NSDictionary+Sanitize` to `NSDictionary+SentrySanitize`

## 4.3.0

- feat: Added `initWithOptions` function, it takes an Dictionary of key value. Possible values are `dsn`, `enabled`, `environment`, `release`, `dist`
- feat: Added `enabled` on the `Client`
- feat: Added `environment` on the `Client`
- feat: Added `release` on the `Client`
- feat: Added `dist` on the `Client`
- ref: Renamed `NSError+SimpleConstructor.h` to `NSError+SentrySimpleConstructor.h`

## 4.2.1

- fix: Add environment to Event in JavaScriptHelper

## 4.2.0

- feat: Add `Client.shared?.trackMemoryPressureAsEvent()` to emit an event if application receives memory pressure notification
- feat: `Client.shared?.enableAutomaticBreadcrumbTracking()` now adds a breadcrumb in case of memory pressure notification

## 4.1.3

- Fix: WatchOS build

## 4.1.2

- fix(react-native): Correctly label fingerprints for JS bridge. (#279)
- Fix error for empty array creation (#278)
- Fix NSInvalidArgumentException in SentryBreadcrumbStore (#272)

## 4.1.1

- Add fingerprint support to JavaScript bridge
- Fix internal variable naming conflict with KSCrash

## 4.1.0

- Introduce `maxEvents` `maxBreadcrumbs` to increase the max count of offline stored assets

## 4.0.1

- Fixes CocoaPods build to include C++ as a library #252

## 4.0.0

- Moved KSCrash into Codebase while renaming it to SentryCrash.
  Removed KSCrash dep in Podspec.
  Still if you do not call `startCrashHandlerWithError` crash handlers will not be installed.

**This should be safe to upgrade from 3.x.x, there are no code changes what so ever.
If you are using CocoaPods or Carthage an update should take care of everything, if you were using the source code directly, make sure to remove KSCrash if you were using it.**

We recommend updating if you experience any KSCrash related crashes since we fixed bunch of stuff directly in our codebase now.

## 3.13.1

- Updated KSCrash project to SKIP_INSTALL

## 3.13.0

- Update docs to use public DSN
- Don't emit nslog if loglevel is none
- Send new mechanism
- Add transaction of current uiviewcontroller

## 3.12.4

- Fixed a bug for empty timestamp if created from JavaScript

## 3.12.3

- Fixed #239

## 3.12.2

- Synchronize storing of breadcrumbs and events

## 3.12.1

- Fixed and error in javascript helper for new exception structure

## 3.12.0

- Fixed #235
- Fixed #236

## 3.11.1

- Fixed #231

## 3.11.0

- Greatly improved handling for rate limiting see: #230
- Added `shouldQueueEvent`
- There is a hardlimit for offline stored events of 10 and 200 for breadcrumbs

## 3.10.0

- This update will create a subfolder for each instance of SentryClient depending on the DSN.
  This also fixes a bug where under rare circumstances on MacOS for not sandboxed apps got sent with the wrong SentryClient.
  **We recommend updating to this version if you are running a un-sandboxed macOS app**
- Fixes #216

## 3.9.1

- Fixed #213

## 3.9.0

- Added JavaScriptBridgeHelper for react-native, cordova SDK

## 3.8.5

- Send breadcrumbs in the order in which they got created

## 3.8.4

- Tick allow-app-extension-API-only box for Carthage builds

## 3.8.3

- Fixed an issue where a crash and the actual event diverge in release version/ dist #218

## 3.8.2

- Fixed #217
- Fixed #214

## 3.8.1

- Fixed failing test

## 3.8.0

- Make KSCrash default CocoaPod subspec
- macOS: Call super exception handler when crash happens
- Added `sampleRate` parameter to configure the likelihood of sending an event [0.0-1.0]

## 3.7.1

- Fixes a bug where stack trace is nil when snapshotting stacktrace

## 3.7.0

- Bump KSCrash to `1.15.12`
- Add `SentryCrashExceptionApplication` for macOS uncaught exception handling

## 3.6.1

- Add `storeEvent` function, mainly used for `react-native`

## 3.6.0

- Fixed a bug in crash Thread detection which caused the Sentry web interface to sometimes show the wrong culprit

## 3.5.0

- Fixed https://github.com/getsentry/sentry-cocoa/issues/200 Make userId optional of `SentryUser`
- Fixed https://github.com/getsentry/sentry-cocoa/issues/198

## 3.4.3

- Initialize extra and tags in private instead of setter in Client init

## 3.4.2

- Fixed #196

## 3.4.1

Fixed messed up Travis build.

## 3.4.0

Expose `sdk` property for `SentryEvent` to allow users to set specific SDK information. -> mainly used in react-native

## 3.3.3

Remove stripping of \_\_sentry extra because it breaks if the event is serialized more than once.

## 3.3.2

Fix `integrations` for `sdk` context.

## 3.3.1

Pretty print json request when verbose logging is active.

## 3.3.0

Change the way `extra` `tags` and `user` is stored.

## 3.2.1

- Fixed #190
- Fixed #191

## 3.2.0

- Add `appendStacktraceToEvent` function in addition to `snapshotStacktrace` to add stacktraces reliably.

## 3.1.3

- Bump KSCrash to `1.15.11`

## 3.1.2

- Add support for SDK integrations

## 3.1.1

- Prefix internal category function

## 3.1.0

- Added new callback `shouldSendEvent` to make it possible to prevent the event from being sent.
- Fixes #178

## 3.0.11

- Fix `snapshotStacktrace` to also include `debug_meta` to fix grouping

## 3.0.10

- Sanitize all extra's array before serialization (Convert NSDate -> NSString)

## 3.0.9

- Change internal locking mechanism for swizzling

## 3.0.8

- Use `KSCrash` `1.15.9` `Core` subspec which only uses bare minimum for Crash reporting
- Fixes #174

## 3.0.7

- Fix system name

## 3.0.6

- Fix `NSNumber` properties in DebugMeta

## 3.0.5

- Rename `RSSwizzle` to `SentrySwizzle`

## 3.0.4

- Fix empty frames on specific crash

## 3.0.3

- Fix carthage builds

Bundled KSCrash into Sentry. Note that this is just for Carthage, CocoaPods knows how to link 2 dynamic frameworks together.

## 3.0.2

- Fix Sentry dynamic framework

## 3.0.1

- Fix carthage build

## 3.0.0

This release is a rewrite of the existing codebase, `sentry-cocoa` now uses Objective-C instead of Swift.
Please make sure to check out the docs since this update introduced many breaking changes.
https://docs.sentry.io/clients/cocoa/

`KSCrash` is now optional, you can use Sentry without it, we still recommend using KSCrash by default otherwise Sentry will not catch any crashes.

## 2.1.11

- Fix swift 3 async operation -> Operation never got removed from queue due using private vars instead of setter

## 2.1.10

- Fixed release naming to `bundleIdentifier`-`shortVersion`

## 2.1.9

- Add support for distributions in sentry
- Make `eventID` `var` instead of `let`

## 2.1.8

- Update KSCrash

## 2.1.7

- Fix duplicate symbols in crash report

  1884.42s user 368.70s system 171% cpu 21:55.70 total

## 2.1.6

- Add additional Info about device

```
("app_identifier", bundleID)
("app_name", bundleName)
("app_build", bundleVersion)
("app_version", bundleShortVersion)
```

## 2.1.5

- Only switflint in Xcode builds, do not while building with CARTHAGE

## 2.1.4

- No longer automatically clear breadcrumbs when an event is sent

## 2.1.3

- Set `ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES` back to `NO` since it prevents upload to iTunes Connect

## 2.1.2

- Prefix react-native frames with `app://`

## 2.1.1

- Update swiftlint to whitelist rules
- Add app context

## 2.1.0

- Added `addTag` `addExtra` function to `SentryClient` and `Event`
  e.g.:

```
SentryClient.shared?.addExtra("key", value: "value")
event.addTag("key", value: "value")
```

- Fixed a bug where 64bit uInt got converted to 32bit
- Added compatiblity for incomplete Crashreports from KSCrash
- Added internal support for upcoming react-native support
- Exposed `maxCrumbs` so the maximum amount of breadcrumbs can be adjusted

## 2.0.1

- Fixed a bug with not sending `release` with event
- Changed the way how swizzling works, there should not be a problem with e.g.: New Relic anymore

## 2.0.0 - Rename from SentrySwift to Sentry

- We decided to rename `SentrySwift` to just `Sentry`

  Version `2.0.0` has the same features as `1.4.5`.
  The name of the Framework has been changed from:
  `import SentrySwift`
  to
  `import Sentry`
  Also in the `Podfile` you have to change to `pod Sentry` instead of `pod SentrySwift`.
  Everything else stayed the same.

## 1.4.5

- Now sending `registers` with stacktrace for better symbolication results
- Added `verbose` logging option which outputs raw events and crash reports
- Add `relevant_address` to stacktrace
- Extended `mechanism`
- Add `build` to `release` e.g.: `1.0 (1337)`
- Added `objcBeforeSendEventBlock` as equivalent to swifts `beforeSendEventBlock`

## 1.4.4

- Removed `SentryClient.shared?.enableThreadNames` because KSCrash changed the mechanism on how threadnames are fetched. They will show up in sentry if available.
- Now sending build number with every event.

## 1.4.3

- Fixed an issue where properties of an event will be overwritten before sending
- Added `SentryClient.shared?.enableThreadNames` variable which can be set to true in order to retrieve the thread names when a crash happens. Enable this on you own risk this could deadlock you app therefore its not yet officially documented.

## 1.4.2

- Fixed Xcode 7 support

## 1.4.1

- enable `searchThreadNames` to display thread names in sentry

## 1.4.0

- Update KSCrash to 1.13.x

**Warning**

- Added namespace for Objc
  e.g.: `User` -> `SentryUser` but Xcode should suggest the new class names ... Swift code does not change

## 1.3.4

- Store events now in `Library/Caches` instead of `Documents` folder

## 1.3.3

- Add `RequestManager` for improved handling on many requests

## 1.3.2

- Reuse `URLSession` when sending events
- Optimize `BreadcrumbStore`

## 1.3.1

- Default log level `.Error`
- Don't strip filepath from frames
- Add `reportReactNativeFatalCrash`

## 1.3.0

- Moved `docs/` to this repo
- You can now take a snapshot of the stacktrace and send it with your event ... see https://docs.sentry.io/clients/cocoa/advanced/#adding-stacktrace-to-message for more information
- Added `beforeSendEventBlock` to change a event before sending it https://docs.sentry.io/clients/cocoa/advanced/#change-event-before-sending-it

## 1.2.0

- Reverse frames in stacktrace
- Remove in_app from stacktrace

## 1.1.0

- Added `SentryClient.shared?.enableAutomaticBreadcrumbTracking()` for iOS which sends all actions and viewDidAppear as breadcrumbs to the server
- Fixed podspec for all target
- Improved UserFeedback controller
- Updated KSCrash to 1.11.2

## 1.0.0

- Refactored a lot of internal classes
- Added `UserFeedback` feature to iOS
- Added basic support for watchOS

## 0.5.0 - Remove Apple Crash Report

- Remove appleCrashReport from request
- Add mechanism to request
- Switch version/build to make iOS version in sentry more understandable
- Use `diagnosis` from KSCrash for crash reasons

## 0.4.1

Fixed for breadcrumbs not always sending on fatal

## 0.4.0

- Support for Swift 2.3 and Swift 3.0

## 0.3.3

- Fixes issue in where capturing `NSError` was not sending up to API

## 0.3.2

- Release was not getting sent up on crashes
- Contexts was getting sent up on wrong key

## 0.3.1

- Defaulting release to main bundle version

## 0.3.0

- Added support for crashing reporting for Mac apps
- Requests are now gzip before going off to Sentry API

## 0.2.1

- Fixed breadcrumbs for updated spec
- Removed all references of "raven"
  - Fixed #13
- Changed merging behaviour in EventProperties
  - Event takes priority over client

## 0.2.0

- Added tvOS support
- Fixes with KSCrash that will build KSCrash for all platforms

## 0.1.0

First pre-release that is ready for testers
