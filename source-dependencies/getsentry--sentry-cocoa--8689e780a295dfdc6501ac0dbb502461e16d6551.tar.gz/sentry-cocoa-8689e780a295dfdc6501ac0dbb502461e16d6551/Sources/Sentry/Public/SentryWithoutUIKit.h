#if __has_include(<SentryWithoutUIKit/Sentry.h>)
#    import <Foundation/Foundation.h>

//! Project version number for Sentry.
FOUNDATION_EXPORT double SentryVersionNumber;

//! Project version string for Sentry.
FOUNDATION_EXPORT const unsigned char SentryVersionString[];

#    import <SentryWithoutUIKit/Sentry.h>
#    import <SentryWithoutUIKit/SentryAttachment.h>
#    import <SentryWithoutUIKit/SentryBaggage.h>
#    import <SentryWithoutUIKit/SentryBreadcrumb.h>
#    import <SentryWithoutUIKit/SentryCrashExceptionApplication.h>
#    import <SentryWithoutUIKit/SentryDebugMeta.h>
#    import <SentryWithoutUIKit/SentryDefines.h>
#    import <SentryWithoutUIKit/SentryError.h>
#    import <SentryWithoutUIKit/SentryEvent.h>
#    import <SentryWithoutUIKit/SentryException.h>
#    import <SentryWithoutUIKit/SentryFrame.h>
#    import <SentryWithoutUIKit/SentryGeo.h>
#    import <SentryWithoutUIKit/SentryHttpStatusCodeRange.h>
#    import <SentryWithoutUIKit/SentryId.h>
#    import <SentryWithoutUIKit/SentryMeasurementUnit.h>
#    import <SentryWithoutUIKit/SentryMechanism.h>
#    import <SentryWithoutUIKit/SentryMechanismContext.h>
#    import <SentryWithoutUIKit/SentryMessage.h>
#    import <SentryWithoutUIKit/SentryNSError.h>
#    import <SentryWithoutUIKit/SentryReplayApi.h>
#    import <SentryWithoutUIKit/SentryRequest.h>
#    import <SentryWithoutUIKit/SentrySampleDecision.h>
#    import <SentryWithoutUIKit/SentrySamplingContext.h>
#    import <SentryWithoutUIKit/SentryScope.h>
#    import <SentryWithoutUIKit/SentrySerializable.h>
#    import <SentryWithoutUIKit/SentrySpanContext.h>
#    import <SentryWithoutUIKit/SentrySpanId.h>
#    import <SentryWithoutUIKit/SentrySpanProtocol.h>
#    import <SentryWithoutUIKit/SentrySpanStatus.h>
#    import <SentryWithoutUIKit/SentryStacktrace.h>
#    import <SentryWithoutUIKit/SentryThread.h>
#    import <SentryWithoutUIKit/SentryTraceContext.h>
#    import <SentryWithoutUIKit/SentryTraceHeader.h>
#    import <SentryWithoutUIKit/SentryTransaction.h>
#    import <SentryWithoutUIKit/SentryTransactionContext.h>
#    import <SentryWithoutUIKit/SentryUser.h>

// Headers here are to be used by Hybrid SDKs
// Be careful when using them
#    import <SentryWithoutUIKit/PrivatesHeader.h>
#    import <SentryWithoutUIKit/SentryAppStartMeasurement.h>
#    import <SentryWithoutUIKit/SentrySessionReplayHybridSDK.h>
#endif // __has_include(<SentryWithoutUIKit/Sentry.h>)
