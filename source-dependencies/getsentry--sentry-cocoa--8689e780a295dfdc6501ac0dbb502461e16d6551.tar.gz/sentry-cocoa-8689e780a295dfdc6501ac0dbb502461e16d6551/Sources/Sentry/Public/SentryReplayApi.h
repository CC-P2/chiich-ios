#if __has_include(<Sentry/Sentry.h>)
#    import <Sentry/SentryDefines.h>
#elif __has_include(<SentryWithoutUIKit/Sentry.h>)
#    import <SentryWithoutUIKit/SentryDefines.h>
#else
#    import <SentryDefines.h>
#endif

#if SENTRY_TARGET_REPLAY_SUPPORTED

@class UIView;

NS_ASSUME_NONNULL_BEGIN

/**
 * API for controlling Session Replay.
 *
 * Replay lifecycle methods may be called from any thread. They return before the requested
 * operation completes and execute serially in call order.
 */
@interface SentryReplayApi : NSObject

/**
 * Marks this view to be masked during replays.
 */
- (void)maskView:(UIView *)view NS_SWIFT_NAME(maskView(_:));

/**
 * Marks this view to not be masked during redact step of session replay.
 */
- (void)unmaskView:(UIView *)view NS_SWIFT_NAME(unmaskView(_:));

/**
 * Pauses the current replay until @c resume is called.
 * Automatically started replays remain paused within the same process.
 */
- (void)pause;

/**
 * Resumes a replay paused with @c pause.
 */
- (void)resume;

/**
 * Starts a new replay session. Does nothing if a replay is already active.
 *
 * This explicit start bypasses session sampling. Recording and delivery remain subject to
 * active Replay rate limits.
 */
- (void)start;

/**
 * Starts Replay in buffer mode. Does nothing if a replay is already active.
 *
 * The rolling buffer is sent when @c flush is called or when an error is captured and selected
 * by the configured error sample rate. This explicit start bypasses session sampling.
 */
- (void)startBuffering;

/**
 * Sends buffered replay data to Sentry and continues recording in session mode. If Replay is
 * inactive, starts a new replay session. This explicit operation bypasses error sampling.
 */
- (void)flush;

/**
 * Stops the current replay. A subsequent @c start or @c startBuffering call creates a new replay.
 */
- (void)stop;

/**
 * Shows an overlay on the app to debug session replay masking.
 *
 * By calling this function an overlay will appear covering the parts
 * of the app that will be masked for the session replay.
 * This will only work if the debugger is attached and it will
 * cause some slow frames.
 *
 * @note This method must be called from the main thread.
 *
 * @warning This is an experimental feature and may still have bugs.
 * Do not use this in production.
 */
- (void)showMaskPreview;

/**
 * Shows an overlay on the app to debug session replay masking.
 *
 * By calling this function an overlay will appear covering the parts
 * of the app that will be masked for the session replay.
 * This will only work if the debugger is attached and it will
 * cause some slow frames.
 *
 * @param opacity The opacity of the overlay.
 *
 * @note This method must be called from the main thread.
 *
 * @warning This is an experimental feature and may still have bugs.
 * Do not use this in production.
 */
- (void)showMaskPreview:(CGFloat)opacity;

/**
 * Removes the overlay that shows replay masking.
 *
 * @note This method must be called from the main thread.
 *
 * @warning This is an experimental feature and may still have bugs.
 * Do not use this in production.
 */
- (void)hideMaskPreview;

@end

NS_ASSUME_NONNULL_END

#endif
