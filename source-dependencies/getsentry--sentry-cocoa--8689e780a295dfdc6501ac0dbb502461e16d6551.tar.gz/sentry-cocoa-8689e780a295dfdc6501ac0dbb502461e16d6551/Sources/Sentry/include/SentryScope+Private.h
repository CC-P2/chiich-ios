#import <Foundation/Foundation.h>

#import "SentryLevel.h"
#import "SentryScope+PrivateSwift.h"
#import "SentryScope.h"

@class SentryAttachment;
@class SentryPropagationContext;
@class SentrySession;
@class SentrySpanInternal;

@protocol SentryScopeObserver;

NS_ASSUME_NONNULL_BEGIN

@interface SentryScope ()

@property (atomic, copy, nullable) NSString *environmentString;

@property (atomic, strong, readonly) NSArray<SentryAttachment *> *attachments;

/**
 * Attachments the SDK captured when the app crashed, added via @c addCrashReportAttachmentInPath:.
 * Unlike @c attachments, these are sent with fatal events.
 */
@property (atomic, strong, readonly) NSArray<SentryAttachment *> *crashReportAttachments;

/**
 * The propagation context has a setter, requiring it to be nonatomic
 */
@property (nonatomic, strong) SentryPropagationContext *propagationContext;

/**
 * This distribution of the application.
 */
@property (atomic, copy) NSString *_Nullable distString;

/**
 * Set global extra -> these will be sent with every event
 */
@property (atomic, strong) NSMutableDictionary<NSString *, id> *extraDictionary;

/**
 * Set the fingerprint of an event to determine the grouping
 */
@property (atomic, strong) NSMutableArray<NSString *> *fingerprintArray;

/**
 * SentryLevel of the event
 */
@property (atomic) SentryLevel levelEnum;

- (nullable SentrySpanInternal *)getCastedInternalSpan;

/**
 * used to add values in event context.
 */
@property (atomic, strong)
    NSMutableDictionary<NSString *, NSDictionary<NSString *, id> *> *contextDictionary;

/**
 * Set global tags -> these will be sent with every event
 */
@property (atomic, strong) NSMutableDictionary<NSString *, NSString *> *tagDictionary;

- (nullable SentryEvent *)applyToEvent:(SentryEvent *_Nullable)event
                         maxBreadcrumb:(NSUInteger)maxBreadcrumbs
    NS_SWIFT_NAME(applyTo(event:maxBreadcrumbs:));

- (void)applyToSession:(SentrySession *)session NS_SWIFT_NAME(applyTo(session:));

/**
 * Adds an attachment captured at crash time, such as a screenshot or the view hierarchy, to
 * @c crashReportAttachments so it is sent with the fatal event of that crash.
 */
- (void)addCrashReportAttachmentInPath:(NSString *)filePath;

@end

NS_ASSUME_NONNULL_END
