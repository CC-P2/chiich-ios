// Adapted from: https://github.com/kstenerud/KSCrash
//
//  SentryCrashInstallation.h
//
//  Created by Karl Stenerud on 2013-02-10.
//
//  Copyright (c) 2012 Karl Stenerud. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall remain in place
// in this source code.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#import "SentryCrashReportFilter.h"
#import "SentryCrashReportWriter.h"
#import "SentryDefines.h"

NS_ASSUME_NONNULL_BEGIN

@class SentryCrashBridge;

/**
 * Crash system installation which handles backend-specific details.
 *
 * Only one installation can be installed at a time.
 *
 * This is an abstract class.
 */
@interface SentryCrashInstallation : NSObject

/** Install this installation. Call this instead of -[SentryCrash install] to
 * install with everything needed for your particular backend.
 */
- (void)install:(NSString *)customCacheDirectory;

/**
 * Call this instead of `-[SentryCrash uninstall]`.
 */
- (void)uninstall;

/** Convenience method to call -[SentryCrash sendAllReportsWithCompletion:].
 * This method will set the SentryCrash sink and then send all outstanding
 * reports.
 *
 * Note: Pay special attention to SentryCrash's "deleteBehaviorAfterSendAll"
 * property.
 *
 * @param onCompletion Called when sending is complete (nil = ignore).
 */
- (void)sendAllReportsWithCompletion:(nullable SentryCrashReportFilterCompletion)onCompletion;

/** Bridge for accessing SDK services without dependency container.
 * Must be set by SentryCrashIntegration before calling install. */
@property (nonatomic, strong) SentryCrashBridge *bridge;

/** Sets the bridge. Use from Swift code where the SentryCrashBridge type cannot be
 * resolved directly due to ObjC forward-declaration limits. */
- (void)setBridgeObject:(SENTRY_SWIFT_MIGRATION_ID(SentryCrashBridge))bridge;

@end

NS_ASSUME_NONNULL_END
