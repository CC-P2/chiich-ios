#import "SentryClient.h"

// These are forward declarations, the actual enums are implemented in Swift.
typedef NS_ENUM(NSUInteger, SentryDataCategory);
typedef NS_ENUM(NSUInteger, SentryDiscardReason);

@class SentryAttachment;
@class SentryEnvelope;
@class SentryEnvelopeItem;
@class SentryHint;
@class SentryId;
@class SentryReplayEvent;
@class SentryFileManager;
@class SentryReplayRecording;
@class SentrySession;
@class SentryDefaultThreadInspector;

@protocol SentrySessionDelegate <NSObject>

- (nullable SentrySession *)incrementSessionErrors;

@end

NS_ASSUME_NONNULL_BEGIN

@protocol SentryClientAttachmentProcessor <NSObject>

- (NSArray<SentryAttachment *> *)processAttachments:(NSArray<SentryAttachment *> *)attachments
                                           forEvent:(SentryEvent *)event;

@end

@interface SentryClientInternal ()

@property (nonatomic, strong)
    NSMutableArray<id<SentryClientAttachmentProcessor>> *attachmentProcessors;
@property (nonatomic, strong) SentryDefaultThreadInspector *threadInspector;
@property (nonatomic, strong) SentryFileManager *fileManager;
@property (nonatomic, weak, nullable) id<SentrySessionDelegate> sessionDelegate;

- (SentryId *)captureFatalEvent:(SentryEvent *)event withScope:(SentryScope *)scope;

- (SentryId *)captureFatalEvent:(SentryEvent *)event
                    withSession:(SentrySession *)session
                      withScope:(SentryScope *)scope;

- (void)captureSerializedFeedback:(NSDictionary *)serializedFeedback
                      withEventId:(NSString *)feedbackEventId
                      attachments:(NSArray<SentryAttachment *> *)feedbackAttachments
                            scope:(SentryScope *)scope;

- (void)saveCrashTransaction:(SentryTransaction *)transaction
                   withScope:(SentryScope *)scope
    NS_SWIFT_NAME(saveCrashTransaction(transaction:scope:));

- (SentryId *)captureEvent:(SentryEvent *)event
                  withScope:(SentryScope *)scope
    additionalEnvelopeItems:(NSArray<SentryEnvelopeItem *> *)additionalEnvelopeItems
    NS_SWIFT_NAME(capture(event:scope:additionalEnvelopeItems:));

- (SentryId *)captureEventIncrementingSessionErrorCount:(SentryEvent *)event
                                              withScope:(SentryScope *)scope;

- (SentryId *)captureEventIncrementingSessionErrorCount:(SentryEvent *)event
                                              withScope:(SentryScope *)scope
                                                   hint:(SentryHint *)hint;

- (SentryId *)captureError:(NSError *)error
                 withScope:(SentryScope *)scope
          attachAllThreads:(nullable NSNumber *)attachAllThreads
    NS_SWIFT_NAME(capture(error:scope:attachAllThreads:));

- (SentryId *)captureException:(NSException *)exception
                     withScope:(SentryScope *)scope
              attachAllThreads:(nullable NSNumber *)attachAllThreads
    NS_SWIFT_NAME(capture(exception:scope:attachAllThreads:));

- (SentryId *)captureMessage:(NSString *)message
                   withScope:(SentryScope *)scope
            attachAllThreads:(nullable NSNumber *)attachAllThreads
    NS_SWIFT_NAME(capture(message:scope:attachAllThreads:));

- (SentryId *)captureEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
                      hint:(nullable SentryHint *)hint NS_SWIFT_NAME(capture(event:scope:hint:));

- (SentryId *)captureError:(NSError *)error
                 withScope:(SentryScope *)scope
                      hint:(nullable SentryHint *)hint NS_SWIFT_NAME(capture(error:scope:hint:));

- (SentryId *)captureException:(NSException *)exception
                     withScope:(SentryScope *)scope
                          hint:(nullable SentryHint *)hint
    NS_SWIFT_NAME(capture(exception:scope:hint:));

- (SentryId *)captureMessage:(NSString *)message
                   withScope:(SentryScope *)scope
                        hint:(nullable SentryHint *)hint
    NS_SWIFT_NAME(capture(message:scope:hint:));

- (void)captureReplayEvent:(SentryReplayEvent *)replayEvent
           replayRecording:(SentryReplayRecording *)replayRecording
                     video:(NSURL *)videoURL
                 withScope:(SentryScope *)scope;

- (void)captureSession:(SentrySession *)session NS_SWIFT_NAME(capture(session:));

/**
 * Needed by hybrid SDKs as react-native to synchronously store an envelope to disk.
 */
- (void)storeEnvelope:(SentryEnvelope *)envelope;

- (void)captureEnvelope:(SentryEnvelope *)envelope;

- (void)recordLostEvent:(SentryDataCategory)category reason:(SentryDiscardReason)reason;
- (void)recordLostEvent:(SentryDataCategory)category
                 reason:(SentryDiscardReason)reason
               quantity:(NSUInteger)quantity;

- (void)addAttachmentProcessor:(id<SentryClientAttachmentProcessor>)attachmentProcessor;
- (void)removeAttachmentProcessor:(id<SentryClientAttachmentProcessor>)attachmentProcessor;

- (void)_swiftCaptureLog:(NSObject *)log withScope:(SentryScope *)scope;

/// Exposed so Swift (e.g. metrics) can reuse it to drop data when the client is disabled.
/// Broader than `isEnabled` in `SentryClient.h`: `isEnabled` only reflects `close`,
/// while `isDisabled` also returns YES for `options.enabled == false` or no DSN.
@property (nonatomic, assign, readonly) BOOL isDisabled;

/// Logs a debug message that data is dropped because the client is disabled. Exposed so Swift
/// (e.g. metrics) logs the same message as event/envelope capture when dropping data.
- (void)logDisabledMessage;

/// Exposes the Telemetry Processor so Swift code can forward metrics directly without crossing the
/// ObjC boundary. SentryMetric is a Swift struct and cannot be passed through ObjC methods, so
/// we use a Swift extension on SentryClientInternal.
/// The return type is `id` (not `id<SentryObjCTelemetryProcessor>`) to avoid a
/// circular dependency: the protocol is defined in Swift and cannot be referenced in ObjC headers
/// that Swift imports.
- (SENTRY_SWIFT_MIGRATION_ID(id<SentryObjCTelemetryProcessor>))getTelemetryProcessor;

/// Records a dropped trace metric. Boxed in `SentryMetricObjC` (typed `id`, same header/Swift
/// constraint as `getTelemetryProcessor` above) because `SentryMetric` is a Swift struct.
- (void)recordDroppedTraceMetricInClientReport:(SENTRY_SWIFT_MIGRATION_ID(SentryMetricObjC))metric;

@end

NS_ASSUME_NONNULL_END
