// Adapted from: https://github.com/kstenerud/KSCrash
//
//  SentryCrashMonitor_Signal.h
//
//  Created by Karl Stenerud on 2012-01-28.
//
//  Copyright (c) 2012 Karl Stenerud. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall remain in place
// in this source code.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

/* Catches fatal unix signals.
 */

#ifndef HDR_SentryCrashMonitor_Signal_h
#define HDR_SentryCrashMonitor_Signal_h

#ifdef __cplusplus
extern "C" {
#endif

#include "SentryCrashMonitor.h"

/** Whether to assign the signal handler for SIGTERM or not.
 */
void sentrycrashcm_setEnableSigtermReporting(bool enabled);

/** Tell the signal monitor to ignore the next occurrence of the given signal
 * on the calling thread. Consumed by the next signal delivery, even if it
 * doesn't match. No-op unless SENTRY_CRASH_MANAGED_RUNTIME is set.
 */
void sentrycrashcm_signal_ignore_next(int signum);

/** Access the Monitor API.
 */
SentryCrashMonitorAPI *sentrycrashcm_signal_getAPI(void);

#ifdef __cplusplus
}
#endif

#endif // HDR_SentryCrashMonitor_Signal_h
