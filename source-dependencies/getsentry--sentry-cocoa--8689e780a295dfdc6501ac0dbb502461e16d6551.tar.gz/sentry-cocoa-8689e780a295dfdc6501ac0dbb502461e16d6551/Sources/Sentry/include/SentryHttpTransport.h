#import "SentryDefines.h"
#import "SentryEnvelopeRateLimit.h"
#import "SentrySwift.h"

@class SentryFileManager;
@class SentryDispatchQueueWrapper;
@class SentryNSURLRequestBuilder;
@class SentryDsn;
@class SentryFileManager;
@class SentryReachability;
@protocol SentryCurrentDateProvider;
@protocol SentryRateLimits;
@protocol SentryRequestManager;

NS_ASSUME_NONNULL_BEGIN

@interface SentryHttpTransport : NSObject <SentryTransport, SentryEnvelopeRateLimitDelegate>
SENTRY_NO_INIT

- (id)initWithDsn:(SentryDsn *)dsn
          sendClientReports:(BOOL)sendClientReports
    cachedEnvelopeSendDelay:(NSTimeInterval)cachedEnvelopeSendDelay
               dateProvider:(id<SentryCurrentDateProvider>)dateProvider
                fileManager:(SentryFileManager *)fileManager
             requestManager:(id<SentryRequestManager>)requestManager
             requestBuilder:(SentryNSURLRequestBuilder *)requestBuilder
                 rateLimits:(id<SentryRateLimits>)rateLimits
          envelopeRateLimit:(SentryEnvelopeRateLimit *)envelopeRateLimit
       dispatchQueueWrapper:(SentryDispatchQueueWrapper *)dispatchQueueWrapper
               reachability:(SentryReachability *)reachability;

@end

NS_ASSUME_NONNULL_END
