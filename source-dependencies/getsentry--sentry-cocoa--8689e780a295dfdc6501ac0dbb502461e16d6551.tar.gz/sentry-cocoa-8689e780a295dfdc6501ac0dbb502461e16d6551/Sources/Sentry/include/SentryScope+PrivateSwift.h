#import "SentryScope.h"

NS_ASSUME_NONNULL_BEGIN

static NSString *const SENTRY_CONTEXT_OS_KEY = @"os";
static NSString *const SENTRY_CONTEXT_DEVICE_KEY = @"device";
static NSString *const SENTRY_CONTEXT_APP_KEY = @"app";

// Added to only expose a limited sub-set of internal API needed in the Swift layer.
@interface SentryScope ()

/**
 * Creates a scope that keeps at most @c maxFeatureFlags feature flag evaluations.
 * @discussion Internal because the public designated initializer must stay source and binary
 * stable. The SDK passes @c SentryOptions.maxFeatureFlags here when it creates a scope from
 * options; scopes created without options use the default of 100 defined by
 * @c defaultMaxScopeFeatureFlags in the Swift layer.
 */
- (instancetype)initWithMaxBreadcrumbs:(NSInteger)maxBreadcrumbs
                       maxFeatureFlags:(NSInteger)maxFeatureFlags;

@property (nonatomic, readonly) SentryId *propagationContextTraceId;
@property (nonatomic, readonly) SentryTraceHeader *propagationContextTraceHeader;

- (void)setPropagationContextWithTraceId:(SentryId *)traceId
                                  spanId:(SentrySpanId *)spanId
    NS_SWIFT_NAME(setPropagationContext(traceId:spanId:));

/**
 * Set global user -> this will be sent with every event
 */
@property (atomic, strong) SentryUser *_Nullable userObject;

@property (nonatomic, nullable, copy) NSString *currentScreen;
@property (atomic, strong, readonly) SENTRY_SWIFT_MIGRATION_ID(SentryFeatureFlagBufferWrapper)
    featureFlagBuffer;

- (NSArray<SentryBreadcrumb *> *)breadcrumbs;

- (NSDictionary<NSString *, id> *)extras;

- (NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)context;

- (NSArray<NSString *> *)fingerprints;

- (NSDictionary<NSString *, id> *_Nullable)getContextForKey:(NSString *)key;

/**
 * Adds a scope observer. The observer will be notified of scope changes.
 * The observer should conform to SentryScopeObserver protocol, but the type is id
 * because Swift-defined protocols don't work correctly with Objective-C's id<Protocol> syntax.
 */
- (void)addScopeObserver:(SENTRY_SWIFT_MIGRATION_ID(id<SentryScopeObserver>))observer
    NS_SWIFT_NAME(add(_:));

/**
 * Runs @c block while holding the breadcrumb lock, so @c addBreadcrumb: waits.
 * Used to replay existing crumbs and attach an observer without a concurrent
 * crumb being dropped or inserted ahead of the replay.
 */
- (void)performWithBreadcrumbsLocked:(void(NS_NOESCAPE ^)(void))block
    NS_SWIFT_NAME(performWithBreadcrumbsLocked(_:));

- (void)overlayOnEvent:(SentryEvent *)event maxBreadcrumb:(NSUInteger)maxBreadcrumbs;

- (void)addFeatureFlagWithName:(NSString *)name
                        result:(BOOL)result NS_SWIFT_NAME(addFeatureFlagInternal(name:result:));

- (void)clearFeatureFlags NS_SWIFT_NAME(clearFeatureFlagsInternal());

@end

NS_ASSUME_NONNULL_END
