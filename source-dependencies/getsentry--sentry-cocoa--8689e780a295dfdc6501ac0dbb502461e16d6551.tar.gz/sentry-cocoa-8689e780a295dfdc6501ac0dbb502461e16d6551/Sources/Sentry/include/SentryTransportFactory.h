#import <Foundation/Foundation.h>

@class SentryFileManager;
@class SentryOptions;
@class SentryReachability;
@protocol SentryCurrentDateProvider;
@protocol SentryRateLimits;
@protocol SentryTransport;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(TransportInitializer)
@interface SentryTransportFactory : NSObject

+ (NSArray<id<SentryTransport>> *)initTransports:(SentryOptions *)options
                                    dateProvider:(id<SentryCurrentDateProvider>)dateProvider
                               sentryFileManager:(SentryFileManager *)sentryFileManager
                                      rateLimits:(id<SentryRateLimits>)rateLimits
                                    reachability:(SentryReachability *)reachability;

@end

NS_ASSUME_NONNULL_END
