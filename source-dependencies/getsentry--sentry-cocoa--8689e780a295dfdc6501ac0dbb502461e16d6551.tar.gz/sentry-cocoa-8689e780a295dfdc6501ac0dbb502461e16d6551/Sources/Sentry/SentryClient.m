#import "SentryClient.h"
#import "NSMutableDictionary+Sentry.h"
#import "SentryAttachment.h"
#import "SentryClient+Private.h"
#import "SentryCrashStackEntryMapper.h"
#import "SentryDefaultTelemetryProcessorTransport.h"
#import "SentryDefaultThreadInspector.h"
#import "SentryDeviceContextKeys.h"
#import "SentryEvent+Private.h"
#import "SentryException.h"
#import "SentryInternalDefines.h"
#import "SentryLogC.h"
#import "SentryMechanism.h"
#import "SentryMechanismContext.h"
#import "SentryMessage.h"
#import "SentryMsgPackSerializer.h"
#import "SentryNSError.h"
#import "SentrySDK+Private.h"
#import "SentrySanitizerUtils.h"
#import "SentryScope+Private.h"
#import "SentryScope+PrivateSwift.h"
#import "SentrySerialization.h"
#import "SentryStacktraceBuilder.h"
#import "SentrySwift.h"
#import "SentryTraceContext+Private.h"
#import "SentryTraceContext.h"
#import "SentryTracer.h"
#import "SentryTransaction+Private.h"
#import "SentryTransportFactory.h"
#import "SentryUser.h"

#if SENTRY_HAS_UIKIT
#    import <UIKit/UIKit.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol SentryEventContextEnricher;

@interface SentryClientInternal ()

@property (nonatomic, strong) SentryTransportAdapter *transportAdapter;
@property (nonatomic, strong) SentryDebugImageProvider *debugImageProvider;
@property (nonatomic, strong) id<SentryRandomProtocol> random;
@property (nonatomic, strong) NSLocale *locale;
@property (nonatomic, strong) NSTimeZone *timezone;
@property (nonatomic, strong) id<SentryLogScopeApplier> logScopeApplier;
@property (nonatomic, strong) id<SentryObjCTelemetryProcessor> telemetryProcessor;
@property (nonatomic, strong) id<SentryEventContextEnricher> eventContextEnricher;
@property (nonatomic, strong) SentryDispatchQueueWrapper *dispatchQueueWrapper;
@property (nonatomic, strong) SentryCurrentScopeStorage *currentScopeStorage;

- (void)recordDroppedItemInClientReportWithItemCategory:(SentryDataCategory)itemCategory
                                           byteCategory:(SentryDataCategory)byteCategory
                                         byteCountBlock:(NSUInteger (^)(void))byteCountBlock;

@end

NSString *const DropSessionLogMessage = @"Session has no release name. Won't send it.";

@implementation SentryClientInternal

- (_Nullable instancetype)initWithOptions:(SentryOptions *)options
{
    SentryDependencyContainer *dependencies = SentryDependencyContainer.sharedInstance;

    NSError *error;
    SentryFileManager *fileManager =
        [[SentryFileManager alloc] initWithOptions:options
                                      dateProvider:dependencies.dateProvider
                              dispatchQueueWrapper:dependencies.dispatchQueueWrapper
                                             error:&error];
    if (error != nil) {
        SENTRY_LOG_FATAL(@"Failed to initialize file system: %@", error.localizedDescription);
        return nil;
    }

    NSArray<id<SentryTransport>> *transports =
        [SentryTransportFactory initTransports:options
                                  dateProvider:dependencies.dateProvider
                             sentryFileManager:fileManager
                                    rateLimits:dependencies.rateLimits
                                  reachability:dependencies.reachability];

    SentryTransportAdapter *transportAdapter =
        [[SentryTransportAdapter alloc] initWithTransports:transports options:options];

    SentryDefaultThreadInspector *threadInspector =
        [[SentryDefaultThreadInspector alloc] initWithOptions:options];

    return [self initWithOptions:options
                    dateProvider:dependencies.dateProvider
                transportAdapter:transportAdapter
                     fileManager:fileManager
                 threadInspector:threadInspector
              debugImageProvider:dependencies.debugImageProvider
                          random:dependencies.random
                          locale:[NSLocale autoupdatingCurrentLocale]
                        timezone:[NSCalendar autoupdatingCurrentCalendar].timeZone
            eventContextEnricher:dependencies.eventContextEnricher
                binaryImageCache:dependencies.binaryImageCache
            dispatchQueueWrapper:dependencies.dispatchQueueWrapper
             currentScopeStorage:dependencies.currentScopeStorage];
}

- (instancetype)initWithOptions:(SentryOptions *)options
                   dateProvider:(id<SentryCurrentDateProvider>)dateProvider
               transportAdapter:(SentryTransportAdapter *)transportAdapter
                    fileManager:(SentryFileManager *)fileManager
                threadInspector:(SentryDefaultThreadInspector *)threadInspector
             debugImageProvider:(SentryDebugImageProvider *)debugImageProvider
                         random:(id<SentryRandomProtocol>)random
                         locale:(NSLocale *)locale
                       timezone:(NSTimeZone *)timezone
           eventContextEnricher:(id<SentryEventContextEnricher>)eventContextEnricher
               binaryImageCache:(SentryBinaryImageCache *)binaryImageCache
           dispatchQueueWrapper:(SentryDispatchQueueWrapper *)dispatchQueueWrapper
{
    return [self initWithOptions:options
                    dateProvider:dateProvider
                transportAdapter:transportAdapter
                     fileManager:fileManager
                 threadInspector:threadInspector
              debugImageProvider:debugImageProvider
                          random:random
                          locale:locale
                        timezone:timezone
            eventContextEnricher:eventContextEnricher
                binaryImageCache:binaryImageCache
            dispatchQueueWrapper:dispatchQueueWrapper
             currentScopeStorage:SentryDependencyContainer.sharedInstance.currentScopeStorage];
}

- (instancetype)initWithOptions:(SentryOptions *)options
                   dateProvider:(id<SentryCurrentDateProvider>)dateProvider
               transportAdapter:(SentryTransportAdapter *)transportAdapter
                    fileManager:(SentryFileManager *)fileManager
                threadInspector:(SentryDefaultThreadInspector *)threadInspector
             debugImageProvider:(SentryDebugImageProvider *)debugImageProvider
                         random:(id<SentryRandomProtocol>)random
                         locale:(NSLocale *)locale
                       timezone:(NSTimeZone *)timezone
           eventContextEnricher:(id<SentryEventContextEnricher>)eventContextEnricher
               binaryImageCache:(SentryBinaryImageCache *)binaryImageCache
           dispatchQueueWrapper:(SentryDispatchQueueWrapper *)dispatchQueueWrapper
            currentScopeStorage:(SentryCurrentScopeStorage *)currentScopeStorage
{
    if (self = [super init]) {
        _isEnabled = YES;
        self.options = options;
        self.transportAdapter = transportAdapter;
        self.fileManager = fileManager;
        self.threadInspector = threadInspector;
        self.random = random;
        self.debugImageProvider = debugImageProvider;
        self.locale = locale;
        self.timezone = timezone;
        self.attachmentProcessors = [[NSMutableArray alloc] init];
        self.eventContextEnricher = eventContextEnricher;
        self.dispatchQueueWrapper = dispatchQueueWrapper;
        self.currentScopeStorage = currentScopeStorage;

        self.telemetryProcessor = [SentryTelemetryProcessorFactory
            getProcessorWithTransport:[[SentryDefaultTelemetryProcessorTransport alloc]
                                          initWithTransportAdapter:transportAdapter]
                         dependencies:SentryDependencyContainer.sharedInstance];

#if SDK_V10
        BOOL shouldAddDefaultUserId = options.dataCollectionObjC.userInfo;
#else
        BOOL shouldAddDefaultUserId = options.sendDefaultPii;
#endif // SDK_V10
        self.logScopeApplier =
            [[SentryDefaultLogScopeApplier alloc] initWithEnvironment:options.environment
                                                          releaseName:options.releaseName
                                                   cacheDirectoryPath:options.cacheDirectoryPath
                                               shouldAddDefaultUserId:shouldAddDefaultUserId];

        [binaryImageCache start:options.debug];

        // The SDK stores the installationID in a file. The first call requires file IO. To avoid
        // executing this on the main thread, we cache the installationID async here.
        [SentryInstallation cacheIDAsyncWithCacheDirectoryPath:options.cacheDirectoryPath];

        [fileManager deleteOldEnvelopeItems];
    }
    return self;
}

- (void)setOptionsInternal:(SentryOptions *)optionsInternal
{
    self.options = optionsInternal;
}

- (NSObject *)getOptions
{
    return self.options;
}

- (SentryId *)captureMessage:(NSString *)message
{
    return [self captureMessage:message withScope:[[SentryScope alloc] init]];
}

- (SentryId *)captureMessage:(NSString *)message withScope:(SentryScope *)scope
{
    return [self captureMessage:message withScope:scope hint:nil];
}

- (SentryId *)captureMessage:(NSString *)message
                   withScope:(SentryScope *)scope
            attachAllThreads:(NSNumber *_Nullable)attachAllThreads
{
    SentryEvent *event = [[SentryEvent alloc] initWithLevel:kSentryLevelInfo];
    event.message = [[SentryMessage alloc] initWithFormatted:message];
    event.attachAllThreadsOverride = attachAllThreads;
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event withScope:scope alwaysAttachStacktrace:NO hint:hint];
}

- (SentryId *)captureException:(NSException *)exception
{
    return [self captureException:exception withScope:[[SentryScope alloc] init]];
}

- (SentryId *)captureException:(NSException *)exception withScope:(SentryScope *)scope
{
    return [self captureException:exception withScope:scope hint:nil];
}

- (SentryId *)captureException:(NSException *)exception
                     withScope:(SentryScope *)scope
              attachAllThreads:(NSNumber *_Nullable)attachAllThreads
{
    SentryEvent *event = [self buildExceptionEvent:exception];
    event.attachAllThreadsOverride = attachAllThreads;
    SentryHint *hint = [[SentryHint alloc] initWithException:exception];
    return [self captureEventIncrementingSessionErrorCount:event withScope:scope hint:hint];
}

- (SentryEvent *)buildExceptionEvent:(NSException *)exception
{
    SentryEvent *event = [[SentryEvent alloc] initWithLevel:kSentryLevelError];
    SentryException *sentryException = [[SentryException alloc] initWithValue:exception.reason
                                                                         type:exception.name];

    event.exceptions = @[ sentryException ];

    [self setUserInfo:exception.userInfo withEvent:event];
    return event;
}

- (SentryId *)captureError:(NSError *)error
{
    return [self captureError:error withScope:[[SentryScope alloc] init]];
}

- (SentryId *)captureError:(NSError *)error withScope:(SentryScope *)scope
{
    return [self captureError:error withScope:scope hint:nil];
}

- (SentryId *)captureError:(NSError *)error
                 withScope:(SentryScope *)scope
          attachAllThreads:(NSNumber *_Nullable)attachAllThreads
{
    SentryEvent *event = [self buildErrorEvent:error];
    event.attachAllThreadsOverride = attachAllThreads;
    SentryHint *hint = [[SentryHint alloc] initWithError:error];
    return [self captureEventIncrementingSessionErrorCount:event withScope:scope hint:hint];
}

- (SentryEvent *)buildErrorEvent:(NSError *)error
{
    SentryEvent *event = [[SentryEvent alloc] initWithError:error];

    // flatten any recursive description of underlying errors into a list, to ultimately report them
    // as a list of exceptions with error mechanisms, sorted oldest to newest (so, the leaf node
    // underlying error as oldest, with the root as the newest)
    NSMutableArray<NSError *> *errors = [NSMutableArray<NSError *> arrayWithObject:error];
    NSError *underlyingError;
    if ([error.userInfo[NSUnderlyingErrorKey] isKindOfClass:[NSError class]]) {
        underlyingError = error.userInfo[NSUnderlyingErrorKey];
    } else if (error.userInfo[NSUnderlyingErrorKey] != nil) {
        SENTRY_LOG_WARN(@"Invalid value for NSUnderlyingErrorKey in user info. Data at key: %@. "
                        @"Class type: %@.",
            error.userInfo[NSUnderlyingErrorKey], [error.userInfo[NSUnderlyingErrorKey] class]);
    }

    while (underlyingError != nil) {
        [errors addObject:underlyingError];

        if ([underlyingError.userInfo[NSUnderlyingErrorKey] isKindOfClass:[NSError class]]) {
            underlyingError = underlyingError.userInfo[NSUnderlyingErrorKey];
        } else {
            if (underlyingError.userInfo[NSUnderlyingErrorKey] != nil) {
                SENTRY_LOG_WARN(@"Invalid value for NSUnderlyingErrorKey in user info. Data at "
                                @"key: %@. Class type: %@.",
                    underlyingError.userInfo[NSUnderlyingErrorKey],
                    [underlyingError.userInfo[NSUnderlyingErrorKey] class]);
            }
            underlyingError = nil;
        }
    }

    NSMutableArray<SentryException *> *exceptions = [NSMutableArray<SentryException *> array];
    [errors enumerateObjectsWithOptions:NSEnumerationReverse
                             usingBlock:^(NSError *_Nonnull nextError, NSUInteger __unused idx,
                                 BOOL *_Nonnull __unused stop) {
                                 [exceptions addObject:[self exceptionForError:nextError]];
                             }];

    event.exceptions = exceptions;

    // Once the UI displays the mechanism data we can remove the userInfo from the event.context
    // using only the root error's userInfo.
    [self setUserInfo:sentry_sanitize_dictionary(error.userInfo) withEvent:event];

    return event;
}

- (SentryException *)exceptionForError:(NSError *)error
{
    NSString *exceptionValue;

    // If the error has a debug description, use that.
    NSString *customExceptionValue = [[error userInfo] valueForKey:NSDebugDescriptionErrorKey];

    NSString *swiftErrorDescription = nil;
    // SwiftNativeNSError is the subclass of NSError used to represent bridged native Swift errors,
    // see
    // https://github.com/apple/swift/blob/067e4ec50147728f2cb990dbc7617d66692c1554/stdlib/public/runtime/ErrorObject.mm#L63-L73
    NSString *errorClass = NSStringFromClass(error.class);
    if ([errorClass containsString:@"SwiftNativeNSError"]) {
        swiftErrorDescription = [SwiftDescriptor getSwiftErrorDescription:error];
    }

    if (customExceptionValue != nil) {
        exceptionValue =
            [NSString stringWithFormat:@"%@ (Code: %ld)", customExceptionValue, (long)error.code];
    } else if (swiftErrorDescription != nil) {
        exceptionValue =
            [NSString stringWithFormat:@"%@ (Code: %ld)", swiftErrorDescription, (long)error.code];
    } else {
        exceptionValue = [NSString stringWithFormat:@"Code: %ld", (long)error.code];
    }
    SentryException *exception = [[SentryException alloc] initWithValue:exceptionValue
                                                                   type:error.domain];

    // Sentry uses the error domain and code on the mechanism for grouping
    SentryMechanism *mechanism = [[SentryMechanism alloc] initWithType:@"NSError"];
    SentryMechanismContext *mechanismMeta = [[SentryMechanismContext alloc] init];
    mechanismMeta.error = [[SentryNSError alloc] initWithDomain:error.domain code:error.code];
    mechanism.meta = mechanismMeta;
    // The description of the error can be especially useful for error from swift that
    // use a simple enum.
    mechanism.desc = error.description;

    NSDictionary<NSString *, id> *userInfo = sentry_sanitize_dictionary(error.userInfo);
    mechanism.data = userInfo;
    exception.mechanism = mechanism;

    return exception;
}

// The hint's attachments must be populated before prepareEvent runs the beforeSendWithHint
// callback, so the callback can add and remove attachments. After the callback returns, the
// hint's attachment list is authoritative and is what the SDK sends.
//
// Fatal events are captured on the launch after the crash, so the scope's attachments belong to
// the current app run and not to the crashed one. Only attachments the SDK captured at crash time
// are sent with fatal events; the beforeSendWithHint callback can still add more.
- (void)populateHintAttachments:(SentryHint *)hint
                          scope:(SentryScope *)scope
                   isFatalEvent:(BOOL)isFatalEvent
{
    NSMutableArray<SentryAttachment *> *allAttachments =
        [NSMutableArray arrayWithArray:scope.crashReportAttachments];
    if (!isFatalEvent) {
        [allAttachments addObjectsFromArray:scope.attachments];
        SentryScope *cs = [self.currentScopeStorage scope];
        if (cs != nil) {
            for (SentryAttachment *attachment in cs.attachments) {
                if ([allAttachments indexOfObjectIdenticalTo:attachment] == NSNotFound) {
                    [allAttachments addObject:attachment];
                }
            }
        }
    }
    [allAttachments addObjectsFromArray:hint.attachments];
    hint.attachments = allAttachments;
}

- (SentryId *)captureFatalEvent:(SentryEvent *)event withScope:(SentryScope *)scope
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event
                     withScope:scope
        alwaysAttachStacktrace:NO
                  isFatalEvent:YES
                          hint:hint];
}

- (SentryId *)captureFatalEvent:(SentryEvent *)event
                    withSession:(SentrySession *)session
                      withScope:(SentryScope *)scope
{
    SentryHint *hint = [[SentryHint alloc] init];
    [self populateHintAttachments:hint scope:scope isFatalEvent:YES];
    hint.attachments = [self processAttachmentsForEvent:event attachments:hint.attachments];
    SentryEvent *preparedEvent = [self prepareEvent:event
                                          withScope:scope
                             alwaysAttachStacktrace:NO
                                       isFatalEvent:YES
                                               hint:hint];
    return [self sendEvent:preparedEvent withSession:session withScope:scope hint:hint];
}

- (void)saveCrashTransaction:(SentryTransaction *)transaction withScope:(SentryScope *)scope
{
    // Populate the hint so beforeSendTransaction sees the same attachments as for regular
    // transactions. Attachments are only informational here because storeEvent doesn't send them.
    SentryHint *hint = [[SentryHint alloc] init];
    [self populateHintAttachments:hint scope:scope isFatalEvent:NO];
    SentryEvent *preparedEvent = [self prepareEvent:transaction
                                          withScope:scope
                             alwaysAttachStacktrace:NO
                                       isFatalEvent:NO
                                               hint:hint];

    if (preparedEvent == nil) {
        return;
    }

    SentryTraceContext *traceContext = [self getTraceStateWithEvent:transaction
                                                          withScope:scope
                                                       currentScope:nil];

    [self.transportAdapter storeEvent:preparedEvent traceContext:traceContext];
}

- (SentryId *)captureEvent:(SentryEvent *)event
{
    return [self captureEvent:event withScope:[[SentryScope alloc] init]];
}

- (SentryId *)captureEvent:(SentryEvent *)event withScope:(SentryScope *)scope
{
    return [self captureEvent:event withScope:scope hint:nil];
}

- (SentryId *)captureEvent:(SentryEvent *)event
                  withScope:(SentryScope *)scope
    additionalEnvelopeItems:(NSArray<SentryEnvelopeItem *> *)additionalEnvelopeItems
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:NO
                   isFatalEvent:NO
        additionalEnvelopeItems:additionalEnvelopeItems
                           hint:hint];
}

- (SentryId *)captureEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
                      hint:(SentryHint *_Nullable)hint
{
    SentryHint *resolvedHint = hint ?: [[SentryHint alloc] init];
    return [self sendEvent:event withScope:scope alwaysAttachStacktrace:NO hint:resolvedHint];
}

- (SentryId *)captureError:(NSError *)error
                 withScope:(SentryScope *)scope
                      hint:(SentryHint *_Nullable)hint
{
    SentryHint *resolvedHint = hint ?: [[SentryHint alloc] init];
    SentryEvent *event = [self buildErrorEvent:error];
    if (resolvedHint.originalError == nil) {
        resolvedHint.originalError = error;
    }
    return [self captureEventIncrementingSessionErrorCount:event withScope:scope hint:resolvedHint];
}

- (SentryId *)captureException:(NSException *)exception
                     withScope:(SentryScope *)scope
                          hint:(SentryHint *_Nullable)hint
{
    SentryHint *resolvedHint = hint ?: [[SentryHint alloc] init];
    SentryEvent *event = [self buildExceptionEvent:exception];
    if (resolvedHint.originalException == nil) {
        resolvedHint.originalException = exception;
    }
    return [self captureEventIncrementingSessionErrorCount:event withScope:scope hint:resolvedHint];
}

- (SentryId *)captureMessage:(NSString *)message
                   withScope:(SentryScope *)scope
                        hint:(SentryHint *_Nullable)hint
{
    SentryHint *resolvedHint = hint ?: [[SentryHint alloc] init];
    SentryEvent *event = [[SentryEvent alloc] initWithLevel:kSentryLevelInfo];
    event.message = [[SentryMessage alloc] initWithFormatted:message];
    return [self sendEvent:event withScope:scope alwaysAttachStacktrace:NO hint:resolvedHint];
}

- (SentryId *)captureEventIncrementingSessionErrorCount:(SentryEvent *)event
                                              withScope:(SentryScope *)scope
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self captureEventIncrementingSessionErrorCount:event withScope:scope hint:hint];
}

- (SentryId *)captureEventIncrementingSessionErrorCount:(SentryEvent *)event
                                              withScope:(SentryScope *)scope
                                                   hint:(SentryHint *)hint
{
    [self populateHintAttachments:hint scope:scope isFatalEvent:NO];
    hint.attachments = [self processAttachmentsForEvent:event attachments:hint.attachments];
    SentryEvent *preparedEvent = [self prepareEvent:event
                                          withScope:scope
                             alwaysAttachStacktrace:YES
                                       isFatalEvent:NO
                                               hint:hint];

    if (preparedEvent != nil) {
        SentrySession *session = nil;
        id<SentrySessionDelegate> delegate = self.sessionDelegate;
        if (delegate != nil) {
            session = [delegate incrementSessionErrors];
        }

        return [self sendEvent:preparedEvent withSession:session withScope:scope hint:hint];
    }

    return SentryId.empty;
}

- (SentryId *)sendEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
    alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:alwaysAttachStacktrace
                   isFatalEvent:NO
        additionalEnvelopeItems:@[]
                           hint:hint];
}

- (SentryId *)sendEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
    alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
                      hint:(SentryHint *)hint
{
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:alwaysAttachStacktrace
                   isFatalEvent:NO
        additionalEnvelopeItems:@[]
                           hint:hint];
}

- (nullable SentryTraceContext *)getTraceStateWithEvent:(SentryEvent *)event
                                              withScope:(SentryScope *)scope
                                           currentScope:(nullable SentryScope *)currentScope
{
    id<SentrySpan> currentScopeSpan = currentScope.span;
    id<SentrySpan> span;
    if ([event isKindOfClass:[SentryTransaction class]]) {
        span = [(SentryTransaction *)event trace];
    } else {
        // Even envelopes without transactions can contain the trace state, allowing Sentry to
        // eventually sample attachments belonging to a transaction.
        span = currentScopeSpan ?: scope.span;
    }

    SentryTracer *tracer = [SentryTracer getTracer:span];
    if (tracer != nil) {
        return [[SentryTraceContext alloc] initWithTracer:tracer scope:scope options:_options];
    }

    if (event.error || event.exceptions.count > 0) {
        SentryId *traceId = currentScopeSpan.traceId ?: scope.propagationContext.traceId;
        return [[SentryTraceContext alloc] initWithTraceId:traceId
                                                   options:self.options
                                                  replayId:scope.replayId];
    }

    return nil;
}

- (SentryId *)sendEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
    alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
              isFatalEvent:(BOOL)isFatalEvent
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:alwaysAttachStacktrace
                   isFatalEvent:isFatalEvent
        additionalEnvelopeItems:@[]
                           hint:hint];
}

- (SentryId *)sendEvent:(SentryEvent *)event
                 withScope:(SentryScope *)scope
    alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
              isFatalEvent:(BOOL)isFatalEvent
                      hint:(SentryHint *)hint
{
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:alwaysAttachStacktrace
                   isFatalEvent:isFatalEvent
        additionalEnvelopeItems:@[]
                           hint:hint];
}

- (SentryId *)sendEvent:(SentryEvent *)event
                  withScope:(SentryScope *)scope
     alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
               isFatalEvent:(BOOL)isFatalEvent
    additionalEnvelopeItems:(NSArray<SentryEnvelopeItem *> *)additionalEnvelopeItems
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self sendEvent:event
                      withScope:scope
         alwaysAttachStacktrace:alwaysAttachStacktrace
                   isFatalEvent:isFatalEvent
        additionalEnvelopeItems:additionalEnvelopeItems
                           hint:hint];
}

- (SentryId *)sendEvent:(SentryEvent *)event
                  withScope:(SentryScope *)scope
     alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
               isFatalEvent:(BOOL)isFatalEvent
    additionalEnvelopeItems:(NSArray<SentryEnvelopeItem *> *)additionalEnvelopeItems
                       hint:(SentryHint *)hint
{
    [self populateHintAttachments:hint scope:scope isFatalEvent:isFatalEvent];
    hint.attachments = [self processAttachmentsForEvent:event attachments:hint.attachments];
    SentryEvent *preparedEvent = [self prepareEvent:event
                                          withScope:scope
                             alwaysAttachStacktrace:alwaysAttachStacktrace
                                       isFatalEvent:isFatalEvent
                                               hint:hint];

    if (preparedEvent == nil) {
        return SentryId.empty;
    }

    SentryTraceContext *traceContext =
        [self getTraceStateWithEvent:event
                           withScope:scope
                        currentScope:isFatalEvent ? nil : [self.currentScopeStorage scope]];

    [self.transportAdapter sendEvent:preparedEvent
                        traceContext:traceContext
                         attachments:hint.attachments
             additionalEnvelopeItems:additionalEnvelopeItems];

    return preparedEvent.eventId;
}

- (SentryId *)sendEvent:(SentryEvent *)event
            withSession:(nullable SentrySession *)session
              withScope:(SentryScope *)scope
{
    SentryHint *hint = [[SentryHint alloc] init];
    [self populateHintAttachments:hint scope:scope isFatalEvent:event.isFatalEvent];
    hint.attachments = [self processAttachmentsForEvent:event attachments:hint.attachments];
    return [self sendEvent:event withSession:session withScope:scope hint:hint];
}

- (SentryId *)sendEvent:(SentryEvent *)event
            withSession:(nullable SentrySession *)session
              withScope:(SentryScope *)scope
                   hint:(SentryHint *)hint
{
    if (event == nil) {
        return SentryId.empty;
    }

    NSArray<SentryAttachment *> *attachments = hint.attachments;

    if (event.isFatalEvent && event.context[@"replay"] &&
        [event.context[@"replay"] isKindOfClass:NSDictionary.class]) {
        NSDictionary *replay = event.context[@"replay"];
        scope.replayId = replay[@"replay_id"];
    }

    SentryTraceContext *traceContext =
        [self getTraceStateWithEvent:event
                           withScope:scope
                        currentScope:event.isFatalEvent ? nil : [self.currentScopeStorage scope]];

    if (session == nil) {
        [self.transportAdapter sendEvent:event traceContext:traceContext attachments:attachments];
        return event.eventId;
    }

    SentrySession *nonnullSession = SENTRY_UNWRAP_NULLABLE(SentrySession, session);

    if (nonnullSession.releaseName == nil || [nonnullSession.releaseName length] == 0) {
        SENTRY_LOG_DEBUG(DropSessionLogMessage);

        [self.transportAdapter sendEvent:event traceContext:traceContext attachments:attachments];
        return event.eventId;
    }

    [self.transportAdapter sendEvent:event
                         withSession:nonnullSession
                        traceContext:traceContext
                         attachments:attachments];

    return event.eventId;
}

- (void)captureSession:(SentrySession *)session
{
    if (nil == session.releaseName || [session.releaseName length] == 0) {
        SENTRY_LOG_DEBUG(DropSessionLogMessage);
        return;
    }

    SentryEnvelopeItem *item = [[SentryEnvelopeItem alloc] initWithSession:session];
    SentryEnvelope *envelope = [[SentryEnvelope alloc] initWithHeader:[SentryEnvelopeHeader empty]
                                                           singleItem:item];
    [self captureEnvelope:envelope];
}

- (void)captureReplayEvent:(SentryReplayEvent *)replayEvent
           replayRecording:(SentryReplayRecording *)replayRecording
                     video:(NSURL *)videoURL
                 withScope:(SentryScope *)scope
{
    replayEvent = (SentryReplayEvent *)[self prepareEvent:replayEvent
                                                withScope:scope
                                   alwaysAttachStacktrace:NO];

    if (replayEvent == nil) {
        SENTRY_LOG_DEBUG(@"The replay event was filtered out in prepare event. "
                         @"The replay was discarded.");
        return;
    }

    // Only check the type of the returned event, as the instance could be changed in the event
    // preprocessor and before-send handlers.
    if (![replayEvent isKindOfClass:SentryReplayEvent.class]) {
        SENTRY_LOG_ERROR(@"The event preprocessor didn't update the replay event in place. The "
                         @"replay was discarded.");
        return;
    }

    SentryEnvelopeItem *videoEnvelopeItem =
        [[SentryEnvelopeItem alloc] initWithReplayEvent:replayEvent
                                        replayRecording:replayRecording
                                                  video:videoURL];

    if (videoEnvelopeItem == nil) {
        SENTRY_LOG_ERROR(@"The Session Replay segment will not be sent to Sentry because an "
                         @"Envelope Item could not be created.");
        // Record a counted lost event in case preparing the event (e.g. encoding the event) failed.
        // This is used to determine if replay events are missing due to an error in the SDK.
        [self recordLostEvent:SentryDataCategoryReplay
                       reason:SentryDiscardReasonInsufficientData
                     quantity:1];
        return;
    }

    // Hybrid SDKs may override the sdk info for a replay Event,
    // the same SDK should be used for the envelope header.
    SentryEnvelopeHeader *envelopeHeader =
        [[SentryEnvelopeHeader alloc] initWithId:replayEvent.eventId sdkInfo:replayEvent.sdk];

    SentryEnvelope *envelope = [[SentryEnvelope alloc] initWithHeader:envelopeHeader
                                                                items:@[ videoEnvelopeItem ]];
    [self captureEnvelope:envelope];
}

- (void)captureEnvelope:(SentryEnvelope *)envelope
{
    if ([self isDisabled]) {
        [self logDisabledMessage];
        return;
    }

    [self.transportAdapter sendEnvelope:envelope];
}

- (void)captureFeedback:(SentryFeedback *)feedback withScope:(SentryScope *)scope
{
    SentryScope *cs = [self.currentScopeStorage scope];
    [self captureSerializedFeedback:[feedback serialize]
                        withEventId:feedback.eventId.sentryIdString
                        attachments:[feedback attachmentsForEnvelope]
                              scope:scope
                       currentScope:cs];
}

- (void)captureSerializedFeedback:(NSDictionary *)serializedFeedback
                      withEventId:(NSString *)feedbackEventId
                      attachments:(NSArray<SentryAttachment *> *)feedbackAttachments
                            scope:(SentryScope *)scope
                     currentScope:(nullable SentryScope *)currentScope
{
    if ([self isDisabled]) {
        [self logDisabledMessage];
        return;
    }

    SentryEvent *feedbackEvent = [[SentryEvent alloc] init];
    feedbackEvent.eventId = [[SentryId alloc] initWithUUIDString:feedbackEventId];
    feedbackEvent.type = SentryEnvelopeItemTypes.feedback;

    NSString *replayId = serializedFeedback[@"replay_id"] ?: currentScope.replayId ?: scope.replayId;
    NSUInteger optionalItems = (scope.span == nil ? 0 : 1) + (replayId == nil ? 0 : 1);
    NSMutableDictionary *context = [NSMutableDictionary dictionaryWithCapacity:1 + optionalItems];
    NSMutableDictionary *feedbackContext = [serializedFeedback mutableCopy];
    feedbackContext[@"replay_id"] = replayId;
    context[@"feedback"] = feedbackContext;

    if (replayId != nil) {
        NSMutableDictionary *replayContext = [NSMutableDictionary dictionaryWithCapacity:1];
        replayContext[@"replay_id"] = replayId;
        context[@"replay"] = replayContext;
    }

    feedbackEvent.context = context;

    SentryEvent *preparedEvent = [self prepareEvent:feedbackEvent
                                          withScope:scope
                             alwaysAttachStacktrace:NO
                                       isFatalEvent:NO
                                       currentScope:currentScope];

    if (preparedEvent == nil) {
        return;
    }

    SentryTraceContext *traceContext = [self getTraceStateWithEvent:preparedEvent
                                                          withScope:scope
                                                       currentScope:currentScope];

    NSMutableArray<SentryAttachment *> *allAttachments = [NSMutableArray array];
    [allAttachments addObjectsFromArray:scope.attachments];
    for (SentryAttachment *attachment in currentScope.attachments) {
        if ([allAttachments indexOfObjectIdenticalTo:attachment] == NSNotFound) {
            [allAttachments addObject:attachment];
        }
    }
    NSArray<SentryAttachment *> *attachments = [[self processAttachmentsForEvent:preparedEvent
                                                                     attachments:allAttachments]
        arrayByAddingObjectsFromArray:feedbackAttachments];

    [self.transportAdapter sendEvent:preparedEvent
                        traceContext:traceContext
                         attachments:attachments
             additionalEnvelopeItems:@[]];
}

- (void)captureSerializedFeedback:(NSDictionary *)serializedFeedback
                      withEventId:(NSString *)feedbackEventId
                      attachments:(NSArray<SentryAttachment *> *)feedbackAttachments
                            scope:(SentryScope *)scope
{
    SentryScope *cs = [self.currentScopeStorage scope];
    [self captureSerializedFeedback:serializedFeedback
                        withEventId:feedbackEventId
                        attachments:feedbackAttachments
                              scope:scope
                       currentScope:cs];
}

- (void)storeEnvelope:(SentryEnvelope *)envelope
{
    [self.fileManager storeEnvelope:envelope];
}

- (void)recordLostEvent:(SentryDataCategory)category reason:(SentryDiscardReason)reason
{
    [self.transportAdapter recordLostEvent:category reason:reason];
}

- (void)recordLostEvent:(SentryDataCategory)category
                 reason:(SentryDiscardReason)reason
               quantity:(NSUInteger)quantity
{
    [self.transportAdapter recordLostEvent:category reason:reason quantity:quantity];
}

- (SentryEvent *_Nullable)prepareEvent:(SentryEvent *)event
                             withScope:(SentryScope *)scope
                alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
{
    return [self prepareEvent:event
                     withScope:scope
        alwaysAttachStacktrace:alwaysAttachStacktrace
                  isFatalEvent:NO];
}

- (void)flush:(NSTimeInterval)timeout
{
    NSTimeInterval forwardingTelemetryDataDuration = [self.telemetryProcessor forwardTelemetryData];
    // Calculate remaining timeout for transport flush.
    // We subtract the time already spent capturing logs to respect the overall timeout.
    // If log capture took longer than the timeout, we use 0.0 which will still trigger
    // sending events but won't block waiting for completion.
    NSTimeInterval remainingTimeout = fmax(0.0, timeout - forwardingTelemetryDataDuration);
    [self.transportAdapter flush:remainingTimeout];
}

- (void)close
{
    _isEnabled = NO;
    [self flush:self.options.shutdownTimeInterval];
    SENTRY_LOG_DEBUG(@"Closed the Client.");
}

- (SentryEvent *_Nullable)prepareEvent:(SentryEvent *_Nullable)event
                             withScope:(SentryScope *)scope
                alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
                          isFatalEvent:(BOOL)isFatalEvent
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self prepareEvent:event
                     withScope:scope
        alwaysAttachStacktrace:alwaysAttachStacktrace
                  isFatalEvent:isFatalEvent
                          hint:hint];
}

- (SentryEvent *_Nullable)prepareEvent:(SentryEvent *_Nullable)event
                             withScope:(SentryScope *)scope
                alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
                          isFatalEvent:(BOOL)isFatalEvent
                                  hint:(SentryHint *)hint
{
    SentryScope *cs = [self.currentScopeStorage scope];
    return [self prepareEvent:event
                     withScope:scope
        alwaysAttachStacktrace:alwaysAttachStacktrace
                  isFatalEvent:isFatalEvent
                  currentScope:cs
                          hint:hint];
}

- (SentryEvent *_Nullable)prepareEvent:(SentryEvent *_Nullable)event
                             withScope:(SentryScope *)scope
                alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
                          isFatalEvent:(BOOL)isFatalEvent
                          currentScope:(SentryScope *_Nullable)currentScope
{
    SentryHint *hint = [[SentryHint alloc] init];
    return [self prepareEvent:event
                     withScope:scope
        alwaysAttachStacktrace:alwaysAttachStacktrace
                  isFatalEvent:isFatalEvent
                  currentScope:currentScope
                          hint:hint];
}

- (SentryEvent *_Nullable)prepareEvent:(SentryEvent *_Nullable)event
                             withScope:(SentryScope *)scope
                alwaysAttachStacktrace:(BOOL)alwaysAttachStacktrace
                          isFatalEvent:(BOOL)isFatalEvent
                          currentScope:(SentryScope *_Nullable)currentScope
                                  hint:(SentryHint *)hint
{
    NSParameterAssert(event);
    if (event == nil) {
        return nil;
    }

    if ([self isDisabled]) {
        [self logDisabledMessage];
        return nil;
    }

    BOOL eventIsNotATransaction
        = event.type == nil || ![event.type isEqualToString:SentryEnvelopeItemTypes.transaction];
    BOOL eventIsNotReplay
        = event.type == nil || ![event.type isEqualToString:SentryEnvelopeItemTypes.replayVideo];
    BOOL eventIsNotUserFeedback
        = event.type == nil || ![event.type isEqualToString:SentryEnvelopeItemTypes.feedback];

    // Transactions and replays have their own sampleRate
    if (eventIsNotATransaction && eventIsNotReplay && eventIsNotUserFeedback &&
        [self isSampled:self.options.sampleRate]) {
        SENTRY_LOG_DEBUG(@"Event got sampled, will not send the event");
        [self recordLostEvent:SentryDataCategoryError reason:SentryDiscardReasonSampleRate];
        return nil;
    }

    NSDictionary *infoDict = [[NSBundle mainBundle] infoDictionary];
    if (nil != infoDict && nil == event.dist) {
        event.dist = infoDict[@"CFBundleVersion"];
    }

    // Use the values from SentryOptions as a fallback,
    // in case not yet set directly in the event nor in the scope:
    NSString *releaseName = self.options.releaseName;
    if (nil == event.releaseName && nil != releaseName) {
        // If no release was already set (i.e: crashed on an older version) use
        // current release name
        event.releaseName = releaseName;
    }

    NSString *dist = self.options.dist;
    if (nil != dist) {
        event.dist = dist;
    }

    [self setSdk:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];

    // We don't want to attach debug meta and stacktraces for transactions, replays or user
    // feedback.
    if (eventIsNotATransaction && eventIsNotReplay && eventIsNotUserFeedback) {
        BOOL shouldAttachStacktrace = alwaysAttachStacktrace || self.options.attachStacktrace
            || (nil != event.exceptions && [event.exceptions count] > 0);

#if SENTRY_HAS_METRIC_KIT
        // MetricKit diagnostics describe past events. Current threads and images cannot fill in
        // missing diagnostic data, including when the call stack tree could not be decoded.
        shouldAttachStacktrace = shouldAttachStacktrace && ![event isMetricKitEvent];
#endif

        BOOL threadsNotAttached = !(nil != event.threads && event.threads.count > 0);

        if (!isFatalEvent && shouldAttachStacktrace && threadsNotAttached) {
            BOOL attachAll = event.attachAllThreadsOverride != nil
                ? event.attachAllThreadsOverride.boolValue
                : self.options.attachAllThreads;

            if (attachAll) {
                event.threads = [self.threadInspector getCurrentThreadsWithStackTrace];
            } else {
                event.threads = [self.threadInspector getCurrentThreads];
            }
        }

        BOOL debugMetaNotAttached = !(nil != event.debugMeta && event.debugMeta.count > 0);
        if (!isFatalEvent && shouldAttachStacktrace && debugMetaNotAttached
            && event.threads != nil) {
            event.debugMeta = [self.debugImageProvider
                getDebugImagesFromCacheForThreads:SENTRY_UNWRAP_NULLABLE(
                                                      NSArray<SentryThread *>, event.threads)];
        }
    }

#if SENTRY_HAS_UIKIT
    if (!isFatalEvent && eventIsNotReplay) {
        NSDictionary *currentContext = event.context ?: @{ };
        event.context = [self.eventContextEnricher enrichWithAppState:currentContext];
    }
#endif

    // Crash events are from a previous run. Applying the current scope would potentially apply
    // current data.
    if (!isFatalEvent) {
        // Unwrapping the event because we assume that the event will be returned
        event = SENTRY_UNWRAP_NULLABLE(
            SentryEvent, [scope applyToEvent:event maxBreadcrumb:self.options.maxBreadcrumbs]);
    }

    if (!isFatalEvent && currentScope != nil && event != nil) {
        [currentScope overlayOnEvent:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)
                       maxBreadcrumb:self.options.maxBreadcrumbs];
    }

    if (!eventIsNotReplay) {
        event.breadcrumbs = nil;
    }

    if ([self isWatchdogTermination:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)
                       isFatalEvent:isFatalEvent]) {
        // Remove some mutable properties from the device/app contexts which are no longer
        // applicable
        [self removeExtraDeviceContextFromEvent:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];
    } else if (!isFatalEvent) {
        // Store the current free memory battery level and more mutable properties,
        // at the time of this event, but not for crashes as the current data isn't guaranteed to be
        // the same as when the app crashed.
        [self applyExtraDeviceContextToEvent:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];
        [self applyCultureContextToEvent:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];
#if SENTRY_HAS_UIKIT
        [self applyCurrentViewNamesToEventContext:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)
                                        withScope:scope];
#endif // SENTRY_HAS_UIKIT
    }

    // With scope applied, before running callbacks run:
    if (event.environment == nil) {
        // We default to environment 'production' if nothing was set
        event.environment = self.options.environment;
    }

    // Need to do this after the scope is applied cause this sets the user if there is any
    [self setUserIdIfNoUserSet:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];

    BOOL eventIsATransaction
        = event.type != nil && [event.type isEqualToString:SentryEnvelopeItemTypes.transaction];
    BOOL eventIsATransactionClass
        = eventIsATransaction && [event isKindOfClass:[SentryTransaction class]];

    NSUInteger currentSpanCount;
    if (eventIsATransactionClass) {
        SentryTransaction *transaction = (SentryTransaction *)event;
        currentSpanCount = transaction.spans.count;
    } else {
        currentSpanCount = 0;
    }

    if (event != nil && eventIsATransaction && self.options.beforeSendSpan != nil) {
        SentryTransaction *transaction = (SentryTransaction *)event;
        NSMutableArray<id<SentrySpan>> *processedSpans = [NSMutableArray array];
        for (id<SentrySpan> span in transaction.spans) {
            id<SentrySpan> processedSpan = self.options.beforeSendSpan(span);
            if (processedSpan) {
                [processedSpans addObject:processedSpan];
            }
        }
        transaction.spans = processedSpans;

        if (eventIsATransactionClass) {
            [self recordPartiallyDroppedSpans:transaction
                                   withReason:SentryDiscardReasonBeforeSend
                         withCurrentSpanCount:&currentSpanCount];
        }
    }

#if SDK_V10
    if (eventIsATransactionClass && event != nil) {
        if (self.options.beforeSendTransaction != nil) {
            event = self.options.beforeSendTransaction((SentryTransaction *)event, hint);
        }
        if (event == nil) {
            [self recordLost:NO reason:SentryDiscardReasonBeforeSend];
            // We dropped the whole transaction, the dropped count includes all child spans + 1
            // root span
            [self recordLostSpanWithReason:SentryDiscardReasonBeforeSend
                                  quantity:currentSpanCount + 1];
        } else if ([event isKindOfClass:[SentryTransaction class]]) {
            [self recordPartiallyDroppedSpans:(SentryTransaction *)event
                                   withReason:SentryDiscardReasonBeforeSend
                         withCurrentSpanCount:&currentSpanCount];
        }
    } else if (eventIsNotUserFeedback && !eventIsATransaction && event != nil) {
        if (self.options.beforeSendWithHint != nil) {
            event
                = self.options.beforeSendWithHint(SENTRY_UNWRAP_NULLABLE(SentryEvent, event), hint);
        } else if (self.options.beforeSend != nil) {
            event = self.options.beforeSend(SENTRY_UNWRAP_NULLABLE(SentryEvent, event));
        }
        if (event == nil) {
            [self recordLost:YES reason:SentryDiscardReasonBeforeSend];
        }
    }
#else
    if (eventIsNotUserFeedback && event != nil) {
        if (self.options.beforeSendWithHint != nil) {
            event
                = self.options.beforeSendWithHint(SENTRY_UNWRAP_NULLABLE(SentryEvent, event), hint);
        } else if (self.options.beforeSend != nil) {
            event = self.options.beforeSend(SENTRY_UNWRAP_NULLABLE(SentryEvent, event));
        }
        if (event == nil) {
            [self recordLost:eventIsNotATransaction reason:SentryDiscardReasonBeforeSend];
            if (eventIsATransaction) {
                // We dropped the whole transaction, the dropped count includes all child spans + 1
                // root span
                [self recordLostSpanWithReason:SentryDiscardReasonBeforeSend
                                      quantity:currentSpanCount + 1];
            }
        } else {
            if ([event isKindOfClass:[SentryTransaction class]]) {
                [self recordPartiallyDroppedSpans:(SentryTransaction *)event
                                       withReason:SentryDiscardReasonBeforeSend
                             withCurrentSpanCount:&currentSpanCount];
            }
        }
    }
#endif // SDK_V10

    if (event != nil) {
        // if the event is dropped by beforeSend we should not execute event processors as they
        // might trigger e.g. unnecessary replay capture
        event = [self callEventProcessors:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];
        if (event == nil) {
            [self recordLost:eventIsNotATransaction reason:SentryDiscardReasonEventProcessor];
            if (eventIsATransaction) {
                // We dropped the whole transaction, the dropped count includes all child spans + 1
                // root span
                [self recordLostSpanWithReason:SentryDiscardReasonEventProcessor
                                      quantity:currentSpanCount + 1];
            }
        } else {
            if ([event isKindOfClass:[SentryTransaction class]]) {
                [self recordPartiallyDroppedSpans:(SentryTransaction *)event
                                       withReason:SentryDiscardReasonEventProcessor
                             withCurrentSpanCount:&currentSpanCount];
            }
        }
    }

    if (event != nil && isFatalEvent && !SentrySDKInternal.lastRunStatusCalled) {
        // We only want to call the callbacks once. It can occur that multiple crash events are
        // about to be sent.
        SentrySDKInternal.lastRunStatusCalled = YES;

#if !SDK_V10
#    pragma clang diagnostic push
#    pragma clang diagnostic ignored "-Wdeprecated-declarations"
        if (nil != self.options.onCrashedLastRun) {
            self.options.onCrashedLastRun(SENTRY_UNWRAP_NULLABLE(SentryEvent, event));
        }
#    pragma clang diagnostic pop
#endif

        if (nil != self.options.onLastRunStatusDetermined) {
            self.options.onLastRunStatusDetermined(
                SentryLastRunStatusDidCrash, SENTRY_UNWRAP_NULLABLE(SentryEvent, event));
        }
    }

    return event;
}

- (void)recordPartiallyDroppedSpans:(SentryTransaction *)transaction
                         withReason:(SentryDiscardReason)reason
               withCurrentSpanCount:(NSUInteger *)currentSpanCount
{
    // If some spans got removed we still report them as dropped
    NSUInteger spanCountAfter = transaction.spans.count;
    NSUInteger droppedSpanCount = *currentSpanCount - spanCountAfter;
    if (droppedSpanCount > 0) {
        [self recordLostSpanWithReason:reason quantity:droppedSpanCount];
    }
    *currentSpanCount = spanCountAfter;
}

- (BOOL)isSampled:(NSNumber *_Nullable)sampleRate
{
    if (sampleRate == nil) {
        return NO;
    }

    return [self.random nextNumber] <= sampleRate.doubleValue ? NO : YES;
}

- (BOOL)isDisabled
{
    return !_isEnabled || !self.options.enabled || nil == self.options.parsedDsn;
}

- (void)logDisabledMessage
{
    SENTRY_LOG_DEBUG(@"SDK disabled or no DSN set. Won't do anything.");
}

- (SentryEvent *_Nullable)callEventProcessors:(SentryEvent *)event
{
    SentryGlobalEventProcessor *globalEventProcessor
        = SentryDependencyContainer.sharedInstance.globalEventProcessor;

    SentryEvent *newEvent = [globalEventProcessor reportAll:event];
    if (newEvent == nil) {
        SENTRY_LOG_DEBUG(@"SentryScope callEventProcessors: An event processor decided to "
                         @"remove this event.");
    }
    return newEvent;
}

- (void)setSdk:(SentryEvent *)event
{
    if (event.sdk) {
        return;
    }

    event.sdk = [SentrySdkInfoObjC optionsToDict:self.options];
}

- (void)setUserInfo:(NSDictionary *_Nullable)userInfo withEvent:(SentryEvent *_Nullable)event
{
    if (nil != event && nil != userInfo && userInfo.count > 0) {
        NSMutableDictionary *context;
        if (event.context == nil) {
            context = [[NSMutableDictionary alloc] init];
            event.context = context;
        } else {
            context = [event.context mutableCopy];
        }

        [context setValue:sentry_sanitize_dictionary(userInfo) forKey:@"user info"];
    }
}

- (void)setUserIdIfNoUserSet:(SentryEvent *)event
{
#if SDK_V10
    if (!self.options.dataCollectionObjC.userInfo) {
        return;
    }
#endif // SDK_V10
    // We only want to set the id if the customer didn't set a user so we at least set something to
    // identify the user.
    if (event.user == nil) {
        SentryUser *user = [[SentryUser alloc] init];
        user.userId = [SentryInstallation idWithCacheDirectoryPath:self.options.cacheDirectoryPath];
        event.user = user;
    }
}

- (BOOL)isWatchdogTermination:(SentryEvent *)event isFatalEvent:(BOOL)isFatalEvent
{
    if (!isFatalEvent) {
        return NO;
    }

    if (event.exceptions == nil || event.exceptions.count != 1) {
        return NO;
    }

    SentryException *exception = event.exceptions[0];
    return exception.mechanism != nil &&
        [exception.mechanism.type isEqualToString:SentryWatchdogTerminationConstants.MechanismType];
}

- (void)applyCultureContextToEvent:(SentryEvent *)event
{
    [self modifyContext:event
                    key:@"culture"
                  block:^(NSMutableDictionary *culture) {
                      culture[@"calendar"] = [self.locale
                          localizedStringForCalendarIdentifier:self.locale.calendarIdentifier];
                      culture[@"display_name"] = [self.locale
                          localizedStringForLocaleIdentifier:self.locale.localeIdentifier];
                      culture[@"locale"] = self.locale.localeIdentifier;
                      culture[@"is_24_hour_format"] = @([SentryLocale timeIs24HourFormat]);
                      culture[@"timezone"] = self.timezone.name;
                  }];
}

- (void)applyExtraDeviceContextToEvent:(SentryEvent *)event
{
    NSDictionary *extraContext =
        [SentryDependencyContainer.sharedInstance.extraContextProvider getExtraContext];
    [self modifyContext:event
                    key:SENTRY_CONTEXT_DEVICE_KEY
                  block:^(NSMutableDictionary *device) {
                      if (extraContext[SENTRY_CONTEXT_DEVICE_KEY] != nil &&
                          [extraContext[SENTRY_CONTEXT_DEVICE_KEY]
                              isKindOfClass:NSDictionary.class]) {
                          [device addEntriesFromDictionary:extraContext[SENTRY_CONTEXT_DEVICE_KEY]
                                  ?: @ { }];
                      }
                  }];

    [self modifyContext:event
                    key:SENTRY_CONTEXT_APP_KEY
                  block:^(NSMutableDictionary *app) {
                      if (extraContext[SENTRY_CONTEXT_APP_KEY] != nil &&
                          [extraContext[SENTRY_CONTEXT_APP_KEY] isKindOfClass:NSDictionary.class]) {
                          [app addEntriesFromDictionary:extraContext[SENTRY_CONTEXT_APP_KEY]
                                  ?: @ { }];
                      }
                  }];
}

#if SENTRY_HAS_UIKIT
- (void)applyCurrentViewNamesToEventContext:(SentryEvent *)event withScope:(SentryScope *)scope
{
    [self modifyContext:event
                    key:@"app"
                  block:^(NSMutableDictionary *app) {
                      if ([event isKindOfClass:[SentryTransaction class]]) {
                          SentryTransaction *transaction = (SentryTransaction *)event;
                          if ([transaction.viewNames count] > 0) {
                              app[@"view_names"] = transaction.viewNames;
                          }
                      } else {
                          if (scope.currentScreen != nil) {
                              app[@"view_names"] =
                                  @[ SENTRY_UNWRAP_NULLABLE(NSString, scope.currentScreen) ];
                          } else {
                              app[@"view_names"] = [SentryDependencyContainer.sharedInstance
                                      .application relevantViewControllersNames];
                          }
                      }
                  }];
}
#endif // SENTRY_HAS_UIKIT

- (void)removeExtraDeviceContextFromEvent:(SentryEvent *)event
{
    [self modifyContext:event
                    key:SENTRY_CONTEXT_DEVICE_KEY
                  block:^(NSMutableDictionary *device) {
                      [device removeObjectForKey:SentryDeviceContextFreeMemoryKey];
                      [device removeObjectForKey:@"orientation"];
                      [device removeObjectForKey:@"charging"];
                      [device removeObjectForKey:@"battery_level"];
                      [device removeObjectForKey:@"thermal_state"];
                  }];

    [self modifyContext:event
                    key:@"app"
                  block:^(NSMutableDictionary *app) {
                      [app removeObjectForKey:SentryDeviceContextAppMemoryKey];
                  }];
}

- (void)modifyContext:(SentryEvent *)event
                  key:(NSString *)key
                block:(void (^)(NSMutableDictionary *))block
{
    if (event.context == nil || event.context.count == 0) {
        return;
    }

    NSMutableDictionary *context = [[NSMutableDictionary alloc]
        initWithDictionary:SENTRY_UNWRAP_NULLABLE(NSDictionary, event.context)];
    NSMutableDictionary *dict
        = event.context[key] != nil && [event.context[key] isKindOfClass:[NSDictionary class]]
        ? [[NSMutableDictionary alloc]
              initWithDictionary:SENTRY_UNWRAP_NULLABLE(NSDictionary, context[key])]
        : [NSMutableDictionary dictionary];

    block(dict);
    context[key] = dict;
    event.context = context;
}

- (void)recordLost:(BOOL)eventIsNotATransaction reason:(SentryDiscardReason)reason
{
    if (eventIsNotATransaction) {
        [self recordLostEvent:SentryDataCategoryError reason:reason];
    } else {
        [self recordLostEvent:SentryDataCategoryTransaction reason:reason];
    }
}

- (void)recordLostSpanWithReason:(SentryDiscardReason)reason quantity:(NSUInteger)quantity
{
    [self recordLostEvent:SentryDataCategorySpan reason:reason quantity:quantity];
}

- (void)addAttachmentProcessor:(id<SentryClientAttachmentProcessor>)attachmentProcessor
{
    [self.attachmentProcessors addObject:attachmentProcessor];
}

- (void)removeAttachmentProcessor:(id<SentryClientAttachmentProcessor>)attachmentProcessor
{
    [self.attachmentProcessors removeObject:attachmentProcessor];
}

- (NSArray<SentryAttachment *> *)processAttachmentsForEvent:(SentryEvent *)event
                                                attachments:
                                                    (NSArray<SentryAttachment *> *)attachments
{
    if (self.attachmentProcessors.count == 0) {
        return attachments;
    }

    NSArray<SentryAttachment *> *processedAttachments = attachments;

    for (id<SentryClientAttachmentProcessor> attachmentProcessor in self.attachmentProcessors) {
        // Keep chaining the processed attachments so each processor works on the output of the
        // previous one. This is necessary so each processor can add and remove attachments.
        //
        // Important: This means the order of adding processors matters and relies on the
        // initialization order of the integrations. At this point in time the attachment processors
        // are only adding attachments, therefore we can ignore this restriction for now.
        processedAttachments = [attachmentProcessor processAttachments:processedAttachments
                                                              forEvent:event];
    }

    return processedAttachments;
}

- (void)_swiftCaptureLog:(NSObject *)log withScope:(SentryScope *)scope
{
    SentryScope *cs = [self.currentScopeStorage scope];
    [self _swiftCaptureLog:log withScope:scope currentScope:cs];
}

- (void)_swiftCaptureLog:(NSObject *)log
               withScope:(SentryScope *)scope
            currentScope:(nullable SentryScope *)currentScope
{
    if ([self isDisabled]) {
        [self logDisabledMessage];
        return;
    }

    if (![log isKindOfClass:[SentryLog class]]) {
        return;
    }

    // Custom attribute precedence: caller > current scope > global scope. Trace correlation,
    // user, and the other reserved attributes come from the global scope only.
    SentryLog *enrichedLog = [self.logScopeApplier applyScope:scope
                                                 currentScope:currentScope
                                                        toLog:(SentryLog *)log];
    SentryLog *logToSend = enrichedLog;

    if (self.options.beforeSendLog != nil) {
        logToSend = self.options.beforeSendLog(enrichedLog);
        if (logToSend == nil) {
            SENTRY_LOG_DEBUG(@"Log dropped by beforeSendLog callback.");
            [self recordDroppedLogInClientReport:enrichedLog];
            return;
        }
    }

    [self.telemetryProcessor addLog:logToSend];
}

- (void)recordDroppedLogInClientReport:(SentryLog *)log
{
    [self recordDroppedItemInClientReportWithItemCategory:SentryDataCategoryLogItem
                                             byteCategory:SentryDataCategoryLogByte
                                           byteCountBlock:^NSUInteger {
                                               return [SentryLogClientReport
                                                   serializedByteCountForLog:log];
                                           }];
}

- (void)recordDroppedTraceMetricInClientReport:(SentryMetricObjC *)metric
{
    [self recordDroppedItemInClientReportWithItemCategory:SentryDataCategoryTraceMetric
                                             byteCategory:SentryDataCategoryTraceMetricByte
                                           byteCountBlock:^NSUInteger {
                                               return [metric serializedByteCount];
                                           }];
}

- (void)recordDroppedItemInClientReportWithItemCategory:(SentryDataCategory)itemCategory
                                           byteCategory:(SentryDataCategory)byteCategory
                                         byteCountBlock:(NSUInteger (^)(void))byteCountBlock
{
    // Offload to a background queue: serializing the item to determine its byte size is too
    // expensive to run inline in a beforeSend callback, which runs on the calling thread and must
    // stay fast.
    __weak SentryClientInternal *weakSelf = self;
    [self.dispatchQueueWrapper dispatchAsyncWithBlock:^{
        SentryClientInternal *strongSelf = weakSelf;
        if (strongSelf == nil) {
            return;
        }
        NSUInteger byteCount = byteCountBlock();
        [strongSelf recordLostEvent:itemCategory reason:SentryDiscardReasonBeforeSend];
        [strongSelf recordLostEvent:byteCategory
                             reason:SentryDiscardReasonBeforeSend
                           quantity:byteCount];
    }];
}

- (id)getTelemetryProcessor
{
    return self.telemetryProcessor;
}

@end

NS_ASSUME_NONNULL_END
