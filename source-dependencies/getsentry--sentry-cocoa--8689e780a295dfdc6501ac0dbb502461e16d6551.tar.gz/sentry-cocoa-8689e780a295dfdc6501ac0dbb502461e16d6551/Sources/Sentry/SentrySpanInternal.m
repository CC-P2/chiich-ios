#import "SentryBaggage.h"
#if SDK_V10
#    import "SentryThreadSnapshot.h"
#else
#    import "SentryCrashThread.h"
#endif
#import "SentryDefaultThreadInspector.h"
#import "SentryFrame.h"
#import "SentryInternalDefines.h"
#import "SentryLogC.h"
#import "SentryNoOpSpan.h"
#import "SentrySampleDecision+Private.h"
#import "SentrySanitizerUtils.h"
#import "SentrySpanContext.h"
#import "SentrySpanId.h"
#import "SentrySpanInternal+Private.h"
#import "SentrySwift.h"
#import "SentryTime.h"
#import "SentryTraceContext.h"
#import "SentryTraceHeader.h"
#import "SentryTracer+Private.h"

#if SENTRY_TARGET_PROFILING_SUPPORTED
#    import "SentryContinuousProfiler.h"
#    import "SentryProfilingConditionals.h"
#    import "SentrySDK+Private.h"
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

NS_ASSUME_NONNULL_BEGIN

@interface SentrySpanInternal ()
@property (nonatomic, strong) SentryFeatureFlagBufferWrapper *featureFlagBuffer;
@end

@implementation SentrySpanInternal {
    NSMutableDictionary<NSString *, id> *_data;
    NSMutableDictionary<NSString *, id> *_tags;
    NSObject *_stateLock;
    BOOL _isFinished;
    uint64_t _startSystemTime;
#if SENTRY_HAS_UIKIT
    NSUInteger initTotalFrames;
    NSUInteger initSlowFrames;
    NSUInteger initFrozenFrames;
    SentryFramesTracker *_framesTracker;
#endif // SENTRY_HAS_UIKIT

#if SENTRY_TARGET_PROFILING_SUPPORTED
    BOOL _isContinuousProfiling;
#endif //  SENTRY_TARGET_PROFILING_SUPPORTED
}

- (instancetype)initWithContext:(SentrySpanContext *)context
#if SENTRY_HAS_UIKIT
                  framesTracker:(nullable SentryFramesTracker *)framesTracker;
#endif // SENTRY_HAS_UIKIT
{
    if (self = [super init]) {
        _startSystemTime = SentryDependencyContainer.sharedInstance.dateProvider.systemTime;
        self.startTimestamp = [SentryDependencyContainer.sharedInstance.dateProvider date];
        _data = [[NSMutableDictionary alloc] init];

#if SDK_V10
        uintptr_t currentThread = sentryThreadInspectionCurrentThread();
#else
        SentryCrashThread currentThread = sentrycrashthread_self();
#endif
        _data[SPAN_DATA_THREAD_ID] = @(currentThread);

        if ([NSThread isMainThread]) {
            _data[SPAN_DATA_THREAD_NAME] = @"main";
        } else {
            _data[SPAN_DATA_THREAD_NAME] = [SentryDependencyContainer.sharedInstance.threadInspector
                getThreadName:currentThread];
        }

#if SENTRY_HAS_UIKIT
        _framesTracker = framesTracker;
        if (_framesTracker.isRunning) {
            SentryScreenFrames *currentFrames = _framesTracker.currentFrames;
            initTotalFrames = currentFrames.total;
            initSlowFrames = currentFrames.slow;
            initFrozenFrames = currentFrames.frozen;
        }
#endif // SENTRY_HAS_UIKIT

        _tags = [[NSMutableDictionary alloc] init];
        self.featureFlagBuffer = [SentryFeatureFlagBufferWrapper spanBuffer];
        _stateLock = [[NSObject alloc] init];
        _isFinished = NO;

        _status = kSentrySpanStatusUndefined;
        _parentSpanId = context.parentSpanId;
        _traceId = context.traceId;
        _operation = context.operation;
        _spanDescription = context.spanDescription;
        _spanId = context.spanId;
        _sampled = context.sampled;
        _origin = context.origin;

#if SENTRY_TARGET_PROFILING_SUPPORTED
        _isContinuousProfiling = SentrySDKInternal.options != nil;
        if (_isContinuousProfiling) {
            _profileSessionID = SentryContinuousProfiler.currentProfilerID.sentryIdString;
            if (_profileSessionID == nil) {
                [SentryDependencyContainer.sharedInstance.notificationCenterWrapper
                    addObserver:self
                       selector:@selector(linkProfiler)
                           name:kSentryNotificationContinuousProfileStarted
                         object:nil];
            }
        }
#endif // SENTRY_TARGET_PROFILING_SUPPORTED
    }

    if (context.parentSpanId == nil) {
        SENTRY_LOG_DEBUG(@"Started root span with id %@", context.spanId.sentrySpanIdString);
    } else {
        SENTRY_LOG_DEBUG(@"Started span with id %@; parent id %@",
            context.spanId.sentrySpanIdString, context.parentSpanId.sentrySpanIdString);
    }
    return self;
}

#if SENTRY_TARGET_PROFILING_SUPPORTED
- (void)dealloc
{
    [self stopObservingContinuousProfiling];
}

- (void)linkProfiler
{
    _profileSessionID = SentryContinuousProfiler.currentProfilerID.sentryIdString;
    [self stopObservingContinuousProfiling];
}

- (void)stopObservingContinuousProfiling
{
    if (_isContinuousProfiling) {
        [SentryDependencyContainer.sharedInstance.notificationCenterWrapper
            removeObserver:self
                      name:kSentryNotificationContinuousProfileStarted
                    object:nil];
    }
}
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

- (instancetype)initWithTracer:(SentryTracer *)tracer
                       context:(SentrySpanContext *)context
#if SENTRY_HAS_UIKIT
                 framesTracker:(nullable SentryFramesTracker *)framesTracker
{
    if (self = [self initWithContext:context framesTracker:framesTracker]) {
#else
{
    if (self = [self initWithContext:context]) {
#endif // SENTRY_HAS_UIKIT

        _tracer = tracer;

        if (context.parentSpanId == nil) {
            SENTRY_LOG_DEBUG(@"Starting root span with tracer with profilerReferenceId %@",
                tracer.profilerReferenceID.sentryIdString);
        } else {
            SENTRY_LOG_DEBUG(@"Starting span with tracer with profilerReferenceId %@",
                tracer.profilerReferenceID.sentryIdString);
        }
    }
    return self;
}

- (id<SentrySpan>)startChildWithOperation:(NSString *)operation
{
    return [self startChildWithOperation:operation description:nil];
}

- (id<SentrySpan>)startChildWithOperation:(NSString *)operation
                              description:(nullable NSString *)description
{
    if (self.tracer == nil) {
        SENTRY_LOG_DEBUG(@"No tracer, returning no-op span");
        return [SentryNoOpSpan shared];
    }

    return SENTRY_UNWRAP_NULLABLE_VALUE(id<SentrySpan>,
        [self.tracer startChildWithParentId:self.spanId
                                  operation:operation
                                description:description]);
}

- (void)setDataValue:(nullable id)value forKey:(NSString *)key
{
    @synchronized(_data) {
        [_data setValue:value forKey:key];
    }
}

- (void)removeDataForKey:(NSString *)key
{
    @synchronized(_data) {
        [_data removeObjectForKey:key];
    }
}

- (NSDictionary<NSString *, id> *)data
{
    @synchronized(_data) {
        return [_data copy];
    }
}

- (void)setTagValue:(NSString *)value forKey:(NSString *)key
{
    @synchronized(_tags) {
        [_tags setValue:value forKey:key];
    }
}

- (void)removeTagForKey:(NSString *)key
{
    @synchronized(_tags) {
        [_tags removeObjectForKey:key];
    }
}

- (void)setMeasurement:(NSString *)name value:(NSNumber *)value
{
    [self.tracer setMeasurement:name value:value];
}

- (void)setMeasurement:(NSString *)name value:(NSNumber *)value unit:(SentryMeasurementUnit *)unit
{
    [self.tracer setMeasurement:name value:value unit:unit];
}

- (NSDictionary<NSString *, id> *)tags
{
    @synchronized(_tags) {
        return [_tags copy];
    }
}

- (void)addFeatureFlagWithName:(NSString *)name result:(BOOL)result
{
    @synchronized(_stateLock) {
        if (_isFinished) {
            return;
        }
        [self.featureFlagBuffer addWithName:name result:result];
    }
}

- (BOOL)isFinished
{
    @synchronized(_stateLock) {
        return _isFinished;
    }
}

- (void)finish
{
    SENTRY_LOG_DEBUG(@"Attempting to finish span with id %@", self.spanId.sentrySpanIdString);
    [self finishWithStatus:kSentrySpanStatusOk];
}

- (void)finishWithStatus:(SentrySpanStatus)status
{
#if SENTRY_TARGET_PROFILING_SUPPORTED
    [self stopObservingContinuousProfiling];
#endif // SENTRY_TARGET_PROFILING_SUPPORTED
    self.status = status;
    @synchronized(_stateLock) {
        _isFinished = YES;
    }
    if (self.timestamp == nil) {
        self.timestamp = [SentryDependencyContainer.sharedInstance.dateProvider date];
        SENTRY_LOG_DEBUG(@"Setting span timestamp: %@ at system time %llu", self.timestamp,
            (unsigned long long)SentryDependencyContainer.sharedInstance.dateProvider.systemTime);
    }

#if SENTRY_HAS_UIKIT
    if (_framesTracker.isRunning) {
        CFTimeInterval framesDelay = [_framesTracker
             getFramesDelaySPI:_startSystemTime
            endSystemTimestamp:SentryDependencyContainer.sharedInstance.dateProvider.systemTime]
                                         .delayDuration;

        if (framesDelay >= 0) {
            [self setDataValue:@(framesDelay) forKey:@"frames.delay"];
        }

        SentryScreenFrames *currentFrames = _framesTracker.currentFrames;
        NSInteger totalFrames = currentFrames.total - initTotalFrames;
        NSInteger slowFrames = currentFrames.slow - initSlowFrames;
        NSInteger frozenFrames = currentFrames.frozen - initFrozenFrames;

        if ([SentryFramesTracker shouldAddSlowFrozenFramesDataWithTotalFrames:totalFrames
                                                                   slowFrames:slowFrames
                                                                 frozenFrames:frozenFrames]) {
            [self setDataValue:@(totalFrames) forKey:@"frames.total"];
            [self setDataValue:@(slowFrames) forKey:@"frames.slow"];
            [self setDataValue:@(frozenFrames) forKey:@"frames.frozen"];

            SENTRY_LOG_DEBUG(@"Frames for span \"%@\" Total:%ld Slow:%ld Frozen:%ld",
                self.operation, (long)totalFrames, (long)slowFrames, (long)frozenFrames);
        }
    }

#endif // SENTRY_HAS_UIKIT

    if (self.tracer == nil) {
        SENTRY_LOG_DEBUG(
            @"No tracer associated with span with id %@", self.spanId.sentrySpanIdString);
        return;
    }

    SENTRY_LOG_DEBUG(@"Marking span %@ as finished in tracer %@ (profileReferenceId %@)",
        _spanId.sentrySpanIdString, _tracer.traceId.sentryIdString,
        _tracer.profilerReferenceID.sentryIdString);
    [self.tracer spanFinished:self];
}

- (SentryTraceHeader *)toTraceHeader
{
    return [[SentryTraceHeader alloc] initWithTraceId:self.traceId
                                               spanId:self.spanId
                                              sampled:self.sampled];
}

// Getter for the computed property baggage
- (nullable NSString *)baggageHttpHeader
{
    return [[self.tracer.traceContext toBaggage] toHTTPHeaderWithOriginalBaggage:nil];
}

- (nullable SentryTraceContext *)traceContext
{
    return self.tracer.traceContext;
}

- (NSDictionary *)serialize
{
    NSMutableDictionary *mutableDictionary = @{
        @"type" : SENTRY_TRACE_TYPE,
        @"span_id" : self.spanId.sentrySpanIdString,
        @"trace_id" : self.traceId.sentryIdString,
        @"op" : self.operation,
        @"origin" : self.origin
    }
                                                 .mutableCopy;

    @synchronized(_tags) {
        if (_tags.count > 0) {
            mutableDictionary[@"tags"] = _tags.copy;
        }
    }

    // Since we guard for 'undecided', we'll
    // either send it if it's 'true' or 'false'.
    if (self.sampled != kSentrySampleDecisionUndecided) {
        [mutableDictionary setValue:valueForSentrySampleDecision(self.sampled) forKey:@"sampled"];
    }

    if (self.spanDescription != nil) {
        [mutableDictionary setValue:self.spanDescription forKey:@"description"];
    }

    if (self.parentSpanId != nil) {
        [mutableDictionary setValue:self.parentSpanId.sentrySpanIdString forKey:@"parent_span_id"];
    }

    if (self.status != kSentrySpanStatusUndefined) {
        [mutableDictionary setValue:nameForSentrySpanStatus(self.status)
                             forKey:kSentrySpanStatusSerializationKey];
    }

    [mutableDictionary setValue:@(self.timestamp.timeIntervalSince1970) forKey:@"timestamp"];

    [mutableDictionary setValue:@(self.startTimestamp.timeIntervalSince1970)
                         forKey:@"start_timestamp"];

    @synchronized(_data) {
        NSMutableDictionary *data = _data.mutableCopy;
        [data addEntriesFromDictionary:[self.featureFlagBuffer serializeForSpanData]];

        if (self.frames && self.frames.count > 0) {
            NSMutableArray *frames = [[NSMutableArray alloc] initWithCapacity:self.frames.count];

            for (SentryFrame *frame in self.frames) {
                [frames addObject:[frame serialize]];
            }

            data[@"call_stack"] = frames;
        }

        if (data.count > 0) {
            mutableDictionary[@"data"] = sentry_sanitize_dictionary(data.copy);
        }
    }

    @synchronized(_tags) {
        if (_tags.count > 0) {
            mutableDictionary[@"tags"] = _tags.copy;
        }
    }

#if SENTRY_TARGET_PROFILING_SUPPORTED
    if (_profileSessionID != nil) {
        mutableDictionary[@"profiler_id"] = _profileSessionID;
    }
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

    return mutableDictionary;
}

@end

NS_ASSUME_NONNULL_END
