#import "NSMutableDictionary+Sentry.h"
#import "SentryAttachment+Private.h"
#import "SentryBreadcrumb+Private.h"
#import "SentryBreadcrumb.h"
#import "SentryDefines.h"
#import "SentryEvent+Private.h"
#import "SentryInternalDefines.h"
#import "SentryLevel.h"
#import "SentryLogC.h"
#import "SentryScope+Private.h"
#import "SentryScope+PrivateSwift.h"
#import "SentrySpanInternal.h"
#import "SentrySwift.h"
#import "SentryTracer.h"
#if SDK_V10
#    import "SentryTransaction+Private.h"
#endif // SDK_V10
#import "SentryTransactionContext.h"
#import "SentryUser.h"

NS_ASSUME_NONNULL_BEGIN

static NSString *const kSentryScopeSpanStatusSerializationKey = @"status";

@interface SentryScope ()

@property (atomic) NSUInteger maxBreadcrumbs;
@property (atomic) NSUInteger currentBreadcrumbIndex;

@property (atomic, strong) NSMutableArray<SentryAttachment *> *attachmentArray;

/**
 * Attachments the SDK captured at crash time, such as screenshots and the view hierarchy. These are
 * kept apart from user attachments because fatal events must only carry attachments that belong to
 * the crashed app run.
 */
@property (atomic, strong) NSMutableArray<SentryAttachment *> *crashReportAttachmentArray;

@property (nonatomic, retain) NSMutableArray<id<SentryScopeObserver>> *observers;

@property (atomic, strong) NSMutableArray<SentryBreadcrumb *> *breadcrumbArray;

@property (atomic, strong) NSMutableDictionary<NSString *, id> *attributesDictionary;

@end

@implementation SentryScope {
    NSObject *_spanLock;
    NSObject *_observersLock;
    NSObject *_propagationContextLock;
    SentryFeatureFlagBufferWrapper *_featureFlagBuffer;
}

@synthesize span = _span;
@synthesize propagationContext = _propagationContext;

#pragma mark Initializer

- (instancetype)initWithMaxBreadcrumbs:(NSInteger)maxBreadcrumbs
{
    if (self = [super init]) {
        _maxBreadcrumbs = MAX(0, maxBreadcrumbs);
        _currentBreadcrumbIndex = 0;
        _breadcrumbArray = [[NSMutableArray alloc] initWithCapacity:_maxBreadcrumbs];
        self.tagDictionary = [[NSMutableDictionary alloc] init];
        self.extraDictionary = [[NSMutableDictionary alloc] init];
        self.contextDictionary = [[NSMutableDictionary alloc] init];
        self.attachmentArray = [[NSMutableArray alloc] init];
        self.crashReportAttachmentArray = [[NSMutableArray alloc] init];
        self.fingerprintArray = [[NSMutableArray alloc] init];
        self.attributesDictionary = [[NSMutableDictionary alloc] init];
        _featureFlagBuffer = [SentryFeatureFlagBufferWrapper scopeBuffer];
        _spanLock = [[NSObject alloc] init];
        _observersLock = [[NSObject alloc] init];
        _propagationContextLock = [[NSObject alloc] init];
        self.observers = [[NSMutableArray alloc] init];
        self.propagationContext = [[SentryPropagationContext alloc] init];
    }
    return self;
}

- (instancetype)initWithMaxBreadcrumbs:(NSInteger)maxBreadcrumbs
                       maxFeatureFlags:(NSInteger)maxFeatureFlags
{
    if (self = [self initWithMaxBreadcrumbs:maxBreadcrumbs]) {
        _featureFlagBuffer =
            [SentryFeatureFlagBufferWrapper scopeBufferWithMaxSize:MAX(0, maxFeatureFlags)];
    }
    return self;
}

- (instancetype)init
{
    return [self initWithMaxBreadcrumbs:defaultMaxBreadcrumbs];
}

- (SentryFeatureFlagBufferWrapper *)featureFlagBuffer
{
    return _featureFlagBuffer;
}

- (instancetype)initWithScope:(SentryScope *)scope
{
    if (self = [self initWithMaxBreadcrumbs:scope.maxBreadcrumbs]) {
        [_extraDictionary addEntriesFromDictionary:[scope extras]];
        [_tagDictionary addEntriesFromDictionary:[scope tags]];
        @synchronized(scope->_contextDictionary) {
            [_contextDictionary addEntriesFromDictionary:scope->_contextDictionary.copy];
            _featureFlagBuffer = [scope->_featureFlagBuffer copyBuffer];
        }
        NSArray<SentryBreadcrumb *> *crumbs = [scope breadcrumbs];
        _breadcrumbArray = [[NSMutableArray alloc] initWithCapacity:scope.maxBreadcrumbs];
        _currentBreadcrumbIndex = crumbs.count;
        [_breadcrumbArray addObjectsFromArray:crumbs];
        [_fingerprintArray addObjectsFromArray:[scope fingerprints]];
        [_attachmentArray addObjectsFromArray:[scope attachments]];
        [_crashReportAttachmentArray addObjectsFromArray:[scope crashReportAttachments]];
        [_attributesDictionary addEntriesFromDictionary:[scope attributes]];

        self.propagationContext = scope.propagationContext;
        self.maxBreadcrumbs = scope.maxBreadcrumbs;
        self.userObject = scope.userObject.copy;
        self.distString = scope.distString;
        self.environmentString = scope.environmentString;
        self.levelEnum = scope.levelEnum;
        self.span = scope.span;
        self.replayId = scope.replayId;
    }
    return self;
}

#pragma mark Global properties

- (void)add:(SentryBreadcrumb *)crumb
{
    [self addBreadcrumb:crumb];
}

- (void)addBreadcrumb:(SentryBreadcrumb *)crumb
{
    if (self.maxBreadcrumbs < 1) {
        return;
    }
    SENTRY_LOG_DEBUG(@"Add breadcrumb: %@ - %@", crumb.category, crumb.message);
    @synchronized(_breadcrumbArray) {
        // Use a ring buffer making adding breadcrumbs O(1).
        // In a prior version, we added the new breadcrumb at the end of the array and used
        // removeObjectAtIndex:0 when reaching the max breadcrumb amount. removeObjectAtIndex:0 is
        // O(n) because it needs to reshift the whole array. So when the breadcrumbs array was full
        // every add operation was O(n).

        // Defensive copy: the scope owns an independent snapshot so that (1) callers
        // mutating the breadcrumb after add don't affect stored data, and (2) when
        // the ring buffer evicts an old entry its dealloc cannot race with another
        // thread reading the same object's properties (see #8013).
        SentryBreadcrumb *snapshot = [crumb snapshotCopy];
        _breadcrumbArray[_currentBreadcrumbIndex] = snapshot;

        _currentBreadcrumbIndex = (_currentBreadcrumbIndex + 1) % _maxBreadcrumbs;

        // Serializing is expensive. Only do it once.
        NSDictionary<NSString *, id> *serializedBreadcrumb = [snapshot serialize];
        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer addSerializedBreadcrumb:serializedBreadcrumb];
        }
    }
}

- (void)setSpan:(nullable id<SentrySpan>)span
{
    @synchronized(_spanLock) {
        _span = span;

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setTraceContext:[self buildTraceContext:span]];
        }
    }
}

- (SentryPropagationContext *)propagationContext
{
    @synchronized(_propagationContextLock) {
        return _propagationContext;
    }
}

- (void)setPropagationContext:(SentryPropagationContext *)propagationContext
{
    @synchronized(_propagationContextLock) {
        _propagationContext = propagationContext;

        NSArray<id<SentryScopeObserver>> *observers = [self observerSnapshot];
        if (observers.count > 0) {
            NSDictionary *traceContext = [propagationContext traceContextForEvent];
            for (id<SentryScopeObserver> observer in observers) {
                [observer setTraceContext:traceContext];
            }
        }
    }
}

- (void)setPropagationContextWithTraceId:(SentryId *)traceId spanId:(SentrySpanId *)spanId
{
    self.propagationContext = [[SentryPropagationContext alloc] initWithTraceId:traceId
                                                                         spanId:spanId];
}

- (nullable id<SentrySpan>)span
{
    @synchronized(_spanLock) {
        return _span;
    }
}

- (nullable SentrySpanInternal *)getCastedInternalSpan
{
    id<SentrySpan> span = self.span;

    if (span == nil) {
        return nil;
    }

    if (span && [span isKindOfClass:[SentrySpanInternal class]]) {
        return (SentrySpanInternal *)span;
    }

    SENTRY_LOG_DEBUG(@"The span on the scope is not of type SentrySpan, returning nil.");

    return nil;
}

- (void)clear
{
    // As we need to synchronize the accesses of the arrays and dictionaries and we use the
    // references instead of self we remove all objects instead of creating new instances. Removing
    // all objects is usually O(n). This is acceptable as we don't expect a huge amount of elements
    // in the arrays or dictionaries, that would slow down the performance.
    [self clearBreadcrumbs];
    @synchronized(_tagDictionary) {
        [_tagDictionary removeAllObjects];
    }
    @synchronized(_extraDictionary) {
        [_extraDictionary removeAllObjects];
    }
    @synchronized(_contextDictionary) {
        [_contextDictionary removeAllObjects];
        // Keep the feature flag buffer and serialized flags context in sync.
        [_featureFlagBuffer removeAll];
    }
    @synchronized(_fingerprintArray) {
        [_fingerprintArray removeAllObjects];
    }
    [self clearAttachments];
    @synchronized(_spanLock) {
        _span = nil;
    }
    @synchronized(_attributesDictionary) {
        [_attributesDictionary removeAllObjects];
    }

    self.userObject = nil;
    self.distString = nil;
    self.environmentString = nil;
    self.levelEnum = kSentryLevelNone;

    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        [observer clear];
    }
}

- (void)clearBreadcrumbs
{
    @synchronized(_breadcrumbArray) {
        _currentBreadcrumbIndex = 0;
        [_breadcrumbArray removeAllObjects];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer clearBreadcrumbs];
        }
    }
}

- (NSArray<SentryBreadcrumb *> *)breadcrumbs
{
    NSMutableArray<SentryBreadcrumb *> *crumbs = [[NSMutableArray alloc] init];
    @synchronized(_breadcrumbArray) {
        for (int i = 0; i < _maxBreadcrumbs; i++) {
            // Crumbs use a ring buffer. We need to start at the current crumb to get the
            // crumbs in the correct order.
            NSInteger index = (_currentBreadcrumbIndex + i) % _maxBreadcrumbs;

            if (index < _breadcrumbArray.count) {
                [crumbs addObject:_breadcrumbArray[index]];
            }
        }
    }

    return crumbs;
}

- (void)setContextValue:(NSDictionary<NSString *, id> *)value forKey:(NSString *)key
{
    @synchronized(_contextDictionary) {
        [_contextDictionary setValue:value forKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setContext:_contextDictionary.copy];
        }
    }
}

- (nullable NSDictionary<NSString *, id> *)getContextForKey:(NSString *)key
{
    @synchronized(_contextDictionary) {
        return [_contextDictionary objectForKey:key];
    }
}

- (void)removeContextForKey:(NSString *)key
{
    @synchronized(_contextDictionary) {
        [_contextDictionary removeObjectForKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setContext:_contextDictionary.copy];
        }
    }
}

- (NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)context
{
    @synchronized(_contextDictionary) {
        return _contextDictionary.copy;
    }
}

- (void)setExtraValue:(id _Nullable)value forKey:(NSString *)key
{
    @synchronized(_extraDictionary) {
        [_extraDictionary setValue:value forKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setExtras:_extraDictionary.copy];
        }
    }
}

- (void)removeExtraForKey:(NSString *)key
{
    @synchronized(_extraDictionary) {
        [_extraDictionary removeObjectForKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setExtras:_extraDictionary.copy];
        }
    }
}

- (void)setExtras:(NSDictionary<NSString *, id> *_Nullable)extras
{
    if (extras == nil) {
        return;
    }
    @synchronized(_extraDictionary) {
        [_extraDictionary
            addEntriesFromDictionary:SENTRY_UNWRAP_NULLABLE_DICT(NSString *, id, extras)];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setExtras:_extraDictionary.copy];
        }
    }
}

- (NSDictionary<NSString *, id> *)extras
{
    @synchronized(_extraDictionary) {
        return _extraDictionary.copy;
    }
}

- (void)setTagValue:(NSString *)value forKey:(NSString *)key
{
    @synchronized(_tagDictionary) {
        _tagDictionary[key] = value;

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setTags:_tagDictionary.copy];
        }
    }
}

- (void)removeTagForKey:(NSString *)key
{
    @synchronized(_tagDictionary) {
        [_tagDictionary removeObjectForKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setTags:_tagDictionary.copy];
        }
    }
}

- (void)setTags:(NSDictionary<NSString *, NSString *> *_Nullable)tags
{
    if (tags == nil) {
        return;
    }
    NSDictionary *tagsCopy = [tags copy];
    @synchronized(_tagDictionary) {
        [_tagDictionary addEntriesFromDictionary:tagsCopy];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setTags:_tagDictionary.copy];
        }
    }
}

- (NSDictionary<NSString *, NSString *> *)tags
{
    @synchronized(_tagDictionary) {
        return _tagDictionary.copy;
    }
}

- (void)setUser:(SentryUser *_Nullable)user
{
    @synchronized(self) {
        self.userObject = user;

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setUser:user];
        }
    }
}

- (void)setDist:(NSString *_Nullable)dist
{
    self.distString = dist;

    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        [observer setDist:dist];
    }
}

- (void)setEnvironment:(NSString *_Nullable)environment
{
    self.environmentString = environment;

    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        [observer setEnvironment:environment];
    }
}

- (void)setFingerprint:(NSArray<NSString *> *_Nullable)fingerprint
{
    @synchronized(_fingerprintArray) {
        [_fingerprintArray removeAllObjects];
        if (fingerprint != nil) {
            [_fingerprintArray
                addObjectsFromArray:SENTRY_UNWRAP_NULLABLE(NSArray<NSString *>, fingerprint)];
        }

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setFingerprint:_fingerprintArray.copy];
        }
    }
}

- (NSArray<NSString *> *)fingerprints
{
    @synchronized(_fingerprintArray) {
        return _fingerprintArray.copy;
    }
}

- (void)setCurrentScreen:(NSString *_Nullable)currentScreen
{
    _currentScreen = currentScreen;

    SEL setCurrentScreen = @selector(setCurrentScreen:);
    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        if ([observer respondsToSelector:setCurrentScreen]) {
            [observer setCurrentScreen:currentScreen];
        }
    }
}

- (void)setLevel:(SentryLevel)level
{
    self.levelEnum = level;

    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        [observer setLevel:level];
    }
}

- (void)includeAttachment:(SentryAttachment *)attachment
{
    [self addAttachment:attachment];
}

- (void)addAttachment:(SentryAttachment *)attachment
{
    @synchronized(_attachmentArray) {
        [_attachmentArray addObject:attachment];
    }
}

- (void)addCrashReportAttachmentInPath:(NSString *)filePath
{
    SentryAttachment *attachment;
    if ([filePath.lastPathComponent isEqualToString:@"view-hierarchy.json"]) {
        attachment = [[SentryAttachment alloc] initWithPath:filePath
                                                   filename:@"view-hierarchy.json"
                                                contentType:@"application/json"
                                             attachmentType:kSentryAttachmentTypeViewHierarchy];
    } else {
        attachment = [[SentryAttachment alloc] initWithPath:filePath];
    }
    @synchronized(_crashReportAttachmentArray) {
        [_crashReportAttachmentArray addObject:attachment];
    }
}

- (void)clearAttachments
{
    @synchronized(_attachmentArray) {
        [_attachmentArray removeAllObjects];
    }
}

- (NSArray<SentryAttachment *> *)attachments
{
    @synchronized(_attachmentArray) {
        return _attachmentArray.copy;
    }
}

- (NSArray<SentryAttachment *> *)crashReportAttachments
{
    @synchronized(_crashReportAttachmentArray) {
        return _crashReportAttachmentArray.copy;
    }
}

- (NSDictionary<NSString *, id> *)attributes
{
    @synchronized(_attributesDictionary) {
        return _attributesDictionary.copy;
    }
}

- (void)setAttributeValue:(id)value forKey:(NSString *)key
{
    if (key == nil || key.length == 0) {
        SENTRY_LOG_ERROR(@"Attribute's key cannot be nil nor empty");
        return;
    }

    @synchronized(_attributesDictionary) {
        _attributesDictionary[key] = value;

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setAttributes:_attributesDictionary.copy];
        }
    }
}

- (void)removeAttributeForKey:(NSString *)key
{
    @synchronized(_attributesDictionary) {
        [_attributesDictionary removeObjectForKey:key];

        for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
            [observer setAttributes:_attributesDictionary.copy];
        }
    }
}

- (NSDictionary<NSString *, id> *)serialize
{
    NSMutableDictionary *serializedData = [[NSMutableDictionary alloc] init];
    if (self.tags.count > 0) {
        [serializedData setValue:[self tags] forKey:@"tags"];
    }
    if (self.extras.count > 0) {
        [serializedData setValue:[self extras] forKey:@"extra"];
    }

    NSDictionary *traceContext = nil;
    id<SentrySpan> span = nil;

    if (self.span != nil) {
        @synchronized(_spanLock) {
            span = self.span;
        }
    }
    traceContext = [self buildTraceContext:span];
    serializedData[@"traceContext"] = traceContext;

    NSMutableDictionary *context = [self context].mutableCopy;
    if (context.count > 0) {
        [serializedData setValue:context forKey:@"context"];
    }

    [serializedData setValue:[self.userObject serialize] forKey:@"user"];
    [serializedData setValue:self.distString forKey:@"dist"];
    [serializedData setValue:self.environmentString forKey:@"environment"];
    [serializedData setValue:self.replayId forKey:@"replay_id"];
    if (self.fingerprints.count > 0) {
        [serializedData setValue:[self fingerprints] forKey:@"fingerprint"];
    }

    SentryLevel level = self.levelEnum;
    if (level != kSentryLevelNone) {
        [serializedData setValue:[SentryLevelHelper nameForLevel:level] forKey:@"level"];
    }
    NSArray *crumbs = [self serializeBreadcrumbs];
    if (crumbs.count > 0) {
        [serializedData setValue:crumbs forKey:@"breadcrumbs"];
    }
    if (self.attributes.count > 0) {
        [serializedData setValue:[self attributes] forKey:@"attributes"];
    }
    return serializedData;
}

- (NSArray *)serializeBreadcrumbs
{
    NSMutableArray *serializedCrumbs = [[NSMutableArray alloc] init];

    NSArray<SentryBreadcrumb *> *crumbs = [self breadcrumbs];
    for (SentryBreadcrumb *crumb in crumbs) {
        [serializedCrumbs addObject:[crumb serialize]];
    }

    return serializedCrumbs;
}

- (void)applyToSession:(SentrySession *)session
{
    NSString *environment = self.environmentString;
    if (environment != nil) {
        // TODO: Make sure environment set on options is applied to the
        // scope so it's available now
        session.environment = environment;
    }
}

- (SentryEvent *__nullable)applyToEvent:(SentryEvent *_Nullable)event
                          maxBreadcrumb:(NSUInteger)maxBreadcrumbs
{
    // We changed the parameter to be nullable, so this method can be called with a potential null
    // value
    if (!event) {
        return nil;
    }

    if (event.isFatalEvent) {
        SENTRY_LOG_WARN(@"Won't apply scope to a crash event. This is not allowed as crash "
                        @"events are from a previous run of the app and the current scope might "
                        @"have different data than the scope that was active during the crash.");
        return event;
    }

    if (event.tags == nil) {
        event.tags = [self tags];
    } else {
        NSMutableDictionary *newTags = [[NSMutableDictionary alloc] init];
        [newTags addEntriesFromDictionary:[self tags]];
        [newTags addEntriesFromDictionary:SENTRY_UNWRAP_NULLABLE_DICT(
                                              NSString *, NSString *, event.tags)];
        event.tags = newTags;
    }

    if (event.extra == nil) {
        event.extra = [self extras];
    } else {
        NSMutableDictionary *newExtra = [[NSMutableDictionary alloc] init];
        [newExtra addEntriesFromDictionary:[self extras]];
        [newExtra
            addEntriesFromDictionary:SENTRY_UNWRAP_NULLABLE_DICT(NSString *, id, event.extra)];
        event.extra = newExtra;
    }

    NSArray *fingerprints = [self fingerprints];
    if (fingerprints.count > 0 && event.fingerprint == nil) {
        event.fingerprint = fingerprints;
    }

    if (event.breadcrumbs == nil) {
        NSArray *breadcrumbs = [self breadcrumbs];
        event.breadcrumbs = [breadcrumbs
            subarrayWithRange:NSMakeRange(0, MIN(maxBreadcrumbs, [breadcrumbs count]))];
    }

    SentryUser *user = self.userObject.copy;
    if (user != nil) {
        event.user = user;
    }

    NSString *dist = self.distString;
    if (dist != nil && event.dist == nil) {
        // dist can also be set via options but scope takes precedence.
        event.dist = dist;
    }

    NSString *environment = self.environmentString;
    if (environment != nil && event.environment == nil) {
        // environment can also be set via options but scope takes
        // precedence.
        event.environment = environment;
    }

    SentryLevel level = self.levelEnum;
    if (level != kSentryLevelNone) {
        // We always want to set the level from the scope since this has
        // been set on purpose
        event.level = level;
    }

    NSMutableDictionary *newContext = [self context].mutableCopy;
    BOOL isRegularEvent
        = event.type == nil || [event.type isEqualToString:SentryEnvelopeItemTypes.event];
    if (!isRegularEvent) {
        // Feature flags only apply to regular error/message events, not transactions, replays,
        // feedback, or other event types.
        [newContext removeObjectForKey:@"flags"];
    }
    if (event.context != nil) {
        [SentryDictionary mergeEntriesFromDictionary:SENTRY_UNWRAP_NULLABLE_DICT(
                                                         NSString *, NSDictionary *, event.context)
                                      intoDictionary:newContext];
    }

    event.context = newContext;
    // The span getter acquires _spanLock, so this read needs no outer lock.
    [self applySpan:self.span toEvent:SENTRY_UNWRAP_NULLABLE(SentryEvent, event)];
    return event;
}

- (void)overlayOnEvent:(SentryEvent *)event maxBreadcrumb:(NSUInteger)maxBreadcrumbs
{
    if (!event) {
        return;
    }

    NSDictionary<NSString *, NSString *> *overlayTags = [self tags];
    if (overlayTags.count > 0) {
        NSMutableDictionary *mergedTags =
            [NSMutableDictionary dictionaryWithDictionary:event.tags ?: @{ }];
        [mergedTags addEntriesFromDictionary:overlayTags];
        event.tags = mergedTags;
    }

    NSDictionary<NSString *, id> *overlayExtras = [self extras];
    if (overlayExtras.count > 0) {
        NSMutableDictionary *mergedExtras =
            [NSMutableDictionary dictionaryWithDictionary:event.extra ?: @{ }];
        [mergedExtras addEntriesFromDictionary:overlayExtras];
        event.extra = mergedExtras;
    }

    SentryUser *overlayUser = self.userObject.copy;
    if (overlayUser != nil) {
        event.user = overlayUser;
    }

    NSArray *overlayFingerprint = [self fingerprints];
    if (overlayFingerprint.count > 0) {
        event.fingerprint = [overlayFingerprint copy];
    }

    NSArray<SentryBreadcrumb *> *overlayBreadcrumbs = [self breadcrumbs];
    if (overlayBreadcrumbs.count > 0) {
        NSMutableArray *mergedBreadcrumbs =
            [NSMutableArray arrayWithArray:event.breadcrumbs ?: @[]];
        for (SentryBreadcrumb *crumb in overlayBreadcrumbs) {
            if ([mergedBreadcrumbs indexOfObjectIdenticalTo:crumb] == NSNotFound) {
                [mergedBreadcrumbs addObject:crumb];
            }
        }
        if (mergedBreadcrumbs.count > maxBreadcrumbs) {
            NSRange keepRange
                = NSMakeRange(mergedBreadcrumbs.count - maxBreadcrumbs, maxBreadcrumbs);
            event.breadcrumbs = [mergedBreadcrumbs subarrayWithRange:keepRange];
        } else {
            event.breadcrumbs = mergedBreadcrumbs;
        }
    }

    NSString *overlayDist = self.distString;
    if (overlayDist != nil) {
        event.dist = overlayDist;
    }

    NSString *overlayEnvironment = self.environmentString;
    if (overlayEnvironment != nil) {
        event.environment = overlayEnvironment;
    }

    SentryLevel overlayLevel = self.levelEnum;
    if (overlayLevel != kSentryLevelNone) {
        event.level = overlayLevel;
    }

    NSDictionary<NSString *, NSDictionary<NSString *, id> *> *overlayContext = [self context];
    if (overlayContext.count > 0) {
        NSMutableDictionary *mergedContext =
            [NSMutableDictionary dictionaryWithDictionary:event.context ?: @{ }];
        [SentryDictionary mergeEntriesFromDictionary:overlayContext intoDictionary:mergedContext];

        BOOL isRegularEvent
            = event.type == nil || [event.type isEqualToString:SentryEnvelopeItemTypes.event];
        if (!isRegularEvent) {
            [mergedContext removeObjectForKey:@"flags"];
        }

        event.context = mergedContext;
    }

    id<SentrySpan> span = self.span;
    if (span != nil && !event.isFatalEvent
        && ![event.type isEqualToString:SentryEnvelopeItemTypes.transaction]) {
        [self applySpan:span toEvent:event];
    }
}

- (void)applySpan:(nullable id<SentrySpan>)span toEvent:(SentryEvent *)event
{
    NSMutableDictionary *context =
        [NSMutableDictionary dictionaryWithDictionary:event.context ?: @{ }];
    NSString *previousTraceId = context[@"trace"][@"trace_id"];
#if SDK_V10
    if ([event.type isEqualToString:SentryEnvelopeItemTypes.transaction] &&
        [event isKindOfClass:[SentryTransaction class]]) {
        // Transaction capture is asynchronous, so the scope may no longer hold its tracer.
        // Use the same trace as transaction serialization, including in before-send callbacks.
        context[@"trace"] = [((SentryTransaction *)event).trace serialize];
    } else {
        context[@"trace"] = [self buildTraceContext:span];
    }
#else
    context[@"trace"] = [self buildTraceContext:span];
#endif // SDK_V10
    event.context = context;

    if ([event.type isEqualToString:SentryEnvelopeItemTypes.transaction]) {
        return;
    }

    SentryTracer *tracer = [SentryTracer getTracer:span];
    if (tracer != nil) {
        event.transaction = tracer.transactionContext.name;
    } else if (span != nil && previousTraceId != nil
        && ![previousTraceId isEqual:context[@"trace"][@"trace_id"]]) {
        // A name from another trace must not survive when the new span has no tracer.
        event.transaction = nil;
    }
}

- (void)addScopeObserver:(SENTRY_SWIFT_MIGRATION_ID(id<SentryScopeObserver>))observer
{
    // Validate if the observer conforms because the API doesn't require
    // observers to conform anymore due to the protocol being written in Swift
    // but protocol forwarded in ObjC
    // Additionally, conformsToProtocol:@protocol(SentryScopeObserver) seems to fail
    // because the conformance is declared in a Category, so runtime checks fail.
    // So we use check for all SentryScopeObserver functions AND an assertion to get alerts on tests
    // As a compile check if any of these selectors cease to exist, this should fail to build.
    // Once this class is converted to Swift, we shouldn't need this anymore

    BOOL conformsToScopeObserver = [observer respondsToSelector:@selector(setTraceContext:)] &&
        [observer respondsToSelector:@selector(setUser:)] &&
        [observer respondsToSelector:@selector(setTags:)] &&
        [observer respondsToSelector:@selector(setExtras:)] &&
        [observer respondsToSelector:@selector(setContext:)] &&
        [observer respondsToSelector:@selector(setDist:)] &&
        [observer respondsToSelector:@selector(setEnvironment:)] &&
        [observer respondsToSelector:@selector(setFingerprint:)] &&
        [observer respondsToSelector:@selector(setLevel:)] &&
        [observer respondsToSelector:@selector(setFingerprint:)] &&
        [observer respondsToSelector:@selector(setAttributes:)] &&
        [observer respondsToSelector:@selector(addSerializedBreadcrumb:)] &&
        [observer respondsToSelector:@selector(clearBreadcrumbs)] &&
        [observer respondsToSelector:@selector(clear)];
    SENTRY_ASSERT(conformsToScopeObserver,
        @"Observer must be an instance conforming to SentryScopeObserver protocol")
    if (conformsToScopeObserver) {
        @synchronized(_observersLock) {
            [self.observers addObject:observer];
        }
    }
}

- (void)performWithBreadcrumbsLocked:(void(NS_NOESCAPE ^)(void))block
{
    @synchronized(_breadcrumbArray) {
        block();
    }
}

/**
 * Syncs the feature flag buffer into context and notifies observers.
 * Must be called while synchronized on _contextDictionary.
 */
- (void)updateFeatureFlagsContextLocked
{
    NSDictionary<NSString *, id> *_Nullable featureFlags = [_featureFlagBuffer serializeForContext];
    if (featureFlags.count > 0) {
        _contextDictionary[@"flags"] = featureFlags;
    } else {
        [_contextDictionary removeObjectForKey:@"flags"];
    }

    for (id<SentryScopeObserver> observer in [self observerSnapshot]) {
        [observer setContext:_contextDictionary.copy];
    }
}

- (void)addFeatureFlagWithName:(NSString *)name result:(BOOL)result
{
    SentrySpanInternal *activeSpan = nil;
    // Capture once to avoid forwarding to a different span; don't nest scope locks.
    @synchronized(_spanLock) {
        if ([_span isKindOfClass:SentrySpanInternal.class]) {
            activeSpan = (SentrySpanInternal *)_span;
        }
    }

    @synchronized(_contextDictionary) {
        [_featureFlagBuffer addWithName:name result:result];
        [self updateFeatureFlagsContextLocked];
    }

    [activeSpan addFeatureFlagWithName:name result:result];
}

- (void)clearFeatureFlags
{
    @synchronized(_contextDictionary) {
        [_featureFlagBuffer removeAll];
        [self updateFeatureFlagsContextLocked];
    }
}

- (NSArray<id<SentryScopeObserver>> *)observerSnapshot
{
    @synchronized(_observersLock) {
        return [self.observers copy];
    }
}

- (NSDictionary *)buildTraceContext:(nullable id<SentrySpan>)span
{
    if (span != nil) {
        NSDictionary *dict = [SENTRY_UNWRAP_NULLABLE_VALUE(id<SentrySpan>, span) serialize];
        if (dict[kSentryScopeSpanStatusSerializationKey] != nil) {
            return dict;
        }

        // We set the trace context status to OK by default here if it's not set, because spans on
        // the scope are usually unfinished and don't have a status set. So the default trace
        // context status would be undefined otherwise, which would confuse users. We don't want to
        // set the default status for spans to OK, because when a span finishes, it sets the status
        // to any state other than undefined. Spans first have a default status of OK, but we don't
        // want to change this for the trace context status.
        NSMutableDictionary *mutableDict = [dict mutableCopy];
        mutableDict[kSentryScopeSpanStatusSerializationKey] = kSentrySpanStatusNameOk;
        return mutableDict;

    } else {
        return [self.propagationContext traceContextForEvent];
    }
}

- (SentryId *)propagationContextTraceId
{
    return self.propagationContext.traceId;
}

- (SentryTraceHeader *)propagationContextTraceHeader
{
    return self.propagationContext.traceHeader;
}

@end

NS_ASSUME_NONNULL_END
