#import <Foundation/Foundation.h>

NSString *const SentrySpanDataKeyFileSize = @"file.size";
NSString *const SentrySpanDataKeyFilePath = @"file.path";

NSString *const SentrySpanDataKeyAppVitalsStartType = @"app.vitals.start.type";
NSString *const SentrySpanDataKeyAppVitalsStartValue = @"app.vitals.start.value";
NSString *const SentrySpanDataKeyAppVitalsStartColdValue = @"app.vitals.start.cold.value";
NSString *const SentrySpanDataKeyAppVitalsStartWarmValue = @"app.vitals.start.warm.value";
NSString *const SentrySpanDataKeyAppVitalsStartPrewarmed = @"app.vitals.start.prewarmed";
NSString *const SentrySpanDataKeyAppVitalsStartScreen = @"app.vitals.start.screen";
NSString *const SentrySpanDataKeyAppVitalsStartReason = @"app.vitals.start.reason";
