#import "SentrySDKInternal.h"
#import "SentryAppStartMeasurement.h"
#import "SentryBreadcrumb.h"
#import "SentryClient+Private.h"
#import "SentryCrash.h"
#import "SentryHub+Private.h"
#import "SentryInternalDefines.h"
#import "SentryLogC.h"
#import "SentryProfilingConditionals.h"
#import "SentryReplayApi.h"
#import "SentrySamplingContext.h"
#import "SentryScope+Private.h"
#import "SentryScope.h"
#import "SentrySerialization.h"
#import "SentrySpanInternal.h"
#import "SentrySwift.h"
#import "SentryTransactionContext.h"

@class SentryAppStartMeasurement;

#if SDK_V10
// Keep the dlsym-only Unity C++ ABI compatibility symbols in static links.
extern const void *_Nonnull sentry_cxa_throw_compatibility_linker_anchor(void)
    __attribute__((visibility("hidden")));
#endif

#if TARGET_OS_OSX
#    import "SentryCrashExceptionApplication.h"
#endif // TARGET_OS_MAC

#if SENTRY_TARGET_PROFILING_SUPPORTED
#    import "SentryContinuousProfiler.h"
#    import "SentryProfileConfiguration.h"
#    import "SentryProfiler+Private.h"
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

@interface SentrySDKInternal ()

@property (class) SentryHubInternal *currentHub;

@end

NS_ASSUME_NONNULL_BEGIN
@implementation SentrySDKInternal
static SentryHubInternal *_Nullable currentHub;
static NSObject *currentHubLock;
static BOOL lastRunStatusCalled;
static BOOL fatalDetected;
static SentryAppStartMeasurement *_Nullable sentrySDKappStartMeasurement;
static NSObject *sentrySDKappStartMeasurementLock;
static void (^_Nullable sentryOnAppStartMeasurementAvailable)(SentryAppStartMeasurement *_Nullable);
static BOOL sentryAppStartMeasurementHybridSDKMode;
#if SENTRY_HAS_UIKIT
static BOOL sentryFramesTrackingMeasurementHybridSDKMode;
#endif // SENTRY_HAS_UIKIT
static BOOL _detectedStartUpCrash;

/**
 * @brief We need to keep track of the number of times @c +[startWith...] is called, because our
 * watchdog termination reporting breaks if it's called more than once.
 * @discussion This doesn't just protect from multiple sequential calls to start the SDK, so we
 * can't simply @c dispatch_once the logic inside the start method; there is also a valid workflow
 * where a consumer could start the SDK, then call @c +[close] and then start again, and we want to
 * reenable the integrations.
 */
static NSUInteger startInvocations;
static NSDate *_Nullable startTimestamp = nil;
static BOOL sdkStarted;

+ (void)initialize
{
    if (self == [SentrySDKInternal class]) {
        sentrySDKappStartMeasurementLock = [[NSObject alloc] init];
        currentHubLock = [[NSObject alloc] init];
        startInvocations = 0;
        sdkStarted = NO;
        _detectedStartUpCrash = NO;
    }
}

+ (SentryHubInternal *)currentHub
{
    @synchronized(currentHubLock) {
        if (nil == currentHub) {
            currentHub = [[SentryHubInternal alloc] initWithClient:nil andScope:nil];
        }
        return SENTRY_UNWRAP_NULLABLE(SentryHubInternal, currentHub);
    }
}

+ (nullable SentryOptions *)options
{
    return SentryDependencyContainer.sharedInstance.startOptions;
}

#if SENTRY_TARGET_REPLAY_SUPPORTED
+ (SentryReplayApi *)replay
{
    static SentryReplayApi *replay;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ replay = [[SentryReplayApi alloc] init]; });
    return replay;
}
#endif

/** Internal, only needed for testing. */
+ (void)setCurrentHub:(nullable SentryHubInternal *)hub
{
    @synchronized(currentHubLock) {
        currentHub = hub;
    }
}

+ (void)setStartOptions:(nullable SentryOptions *)options
{
    SentryDependencyContainer.sharedInstance.startOptions = options;
}

+ (nullable id<SentrySpan>)span
{
    // Snapshot under currentHubLock so ARC retains the hub before close() can nil the static
    // and free it; an unsynchronized read races with close() (use-after-free, see #8316).
    SentryHubInternal *localCurrentHub = nil;
    @synchronized(currentHubLock) {
        localCurrentHub = currentHub;
    }
    return localCurrentHub.scope.span;
}

+ (BOOL)isEnabled
{
    // Avoid the SentrySDKInternal.currentHub getter: it lazily creates an empty hub, and this check
    // must be side-effect free. Snapshot under currentHubLock so ARC retains the hub before close()
    // can nil the static and free it; an unsynchronized read races with close() (use-after-free,
    // see #8267).
    // Using a local copy of the hub to minimize the scope of currentHubLock and, more importantly,
    // to avoid calling getClient within the scope of currentHubLock. getClient reads the atomic
    // internal client property, which should minimize the risk of potential future deadlocks.
    SentryHubInternal *localCurrentHub = nil;
    @synchronized(currentHubLock) {
        localCurrentHub = currentHub;
    }

    return localCurrentHub != nil && [localCurrentHub getClient] != nil;
}

+ (BOOL)lastRunStatusCalled
{
    return lastRunStatusCalled;
}

+ (void)setLastRunStatusCalled:(BOOL)value
{
    lastRunStatusCalled = value;
}

+ (BOOL)crashReporterInstalled
{
    return SentryDependencyContainer.sharedInstance.activeCrashReporterState.installed;
}

+ (BOOL)fatalDetected
{
    return fatalDetected;
}

+ (void)setFatalDetected:(BOOL)value
{
    fatalDetected = value;
}

/**
 * Not public, only for internal use.
 */
+ (void)setAppStartMeasurement:(nullable SentryAppStartMeasurement *)value
{
    @synchronized(sentrySDKappStartMeasurementLock) {
        sentrySDKappStartMeasurement = value;
    }

    void (^callback)(SentryAppStartMeasurement *_Nullable) = self.onAppStartMeasurementAvailable;
    if (callback != nil) {
        callback(value);
    }
}

/**
 * Not public, only for internal use.
 */
+ (nullable SentryAppStartMeasurement *)getAppStartMeasurement
{
    @synchronized(sentrySDKappStartMeasurementLock) {
        return sentrySDKappStartMeasurement;
    }
}

+ (void (^_Nullable)(SentryAppStartMeasurement *_Nullable))onAppStartMeasurementAvailable
{
    @synchronized(self) {
        return [sentryOnAppStartMeasurementAvailable copy];
    }
}

+ (void)setOnAppStartMeasurementAvailable:(void (^_Nullable)(
                                              SentryAppStartMeasurement *_Nullable))callback
{
    @synchronized(self) {
        sentryOnAppStartMeasurementAvailable = [callback copy];
    }
}

+ (BOOL)appStartMeasurementHybridSDKMode
{
    @synchronized(self) {
        return sentryAppStartMeasurementHybridSDKMode;
    }
}

+ (void)setAppStartMeasurementHybridSDKMode:(BOOL)value
{
    @synchronized(self) {
        sentryAppStartMeasurementHybridSDKMode = value;
    }
}

#if SENTRY_HAS_UIKIT
+ (BOOL)framesTrackingMeasurementHybridSDKMode
{
    @synchronized(self) {
        return sentryFramesTrackingMeasurementHybridSDKMode;
    }
}

+ (void)setFramesTrackingMeasurementHybridSDKMode:(BOOL)value
{
    @synchronized(self) {
        sentryFramesTrackingMeasurementHybridSDKMode = value;
    }
}
#endif // SENTRY_HAS_UIKIT

/**
 * Not public, only for internal use.
 */
+ (NSUInteger)startInvocations
{
    return startInvocations;
}

/**
 * Only needed for testing.
 */
+ (void)setStartInvocations:(NSUInteger)value
{
    startInvocations = value;
}

/**
 * Not public, only for internal use.
 */
+ (nullable NSDate *)startTimestamp
{
    return startTimestamp;
}

/**
 * Only needed for testing.
 */
+ (void)setStartTimestamp:(NSDate *)value
{
    startTimestamp = value;
}

+ (void)startWithOptions:(SentryOptions *)options
{
#if SDK_V10
    (void)sentry_cxa_throw_compatibility_linker_anchor();
#endif

    BOOL alreadyStarted = NO;
    @synchronized(currentHubLock) {
        alreadyStarted = sdkStarted;
        sdkStarted = YES;
    }
    if (alreadyStarted) {
        SENTRY_LOG_WARN(@"The Sentry SDK has already been started. Calling start again without "
                        @"close() may lead to undefined behavior.");
    }

    [self setStartOptions:options];

    [SentrySDKLogSupport configure:options.debug diagnosticLevel:options.diagnosticLevel];

    // We accept the tradeoff that the SDK might not be fully initialized directly after
    // initializing it on a background thread because scheduling the init synchronously on the main
    // thread could lead to deadlocks.
    SENTRY_LOG_DEBUG(@"Starting SDK...");

#if defined(DEBUG) || defined(SENTRY_TEST) || defined(SENTRY_TEST_CI)
    SENTRY_LOG_DEBUG(@"Configured options: %@", options.debugDescription);
#endif // defined(DEBUG) || defined(SENTRY_TEST) || defined(SENTRY_TEST_CI)

#if TARGET_OS_OSX && !SENTRY_NO_UI_FRAMEWORK
    // Reference to SentryCrashExceptionApplication to prevent compiler from stripping it
    // Only do this if we are not building without UIKit, because otherwise the class should not be
    // available
    [SentryCrashExceptionApplication class];
#endif
    // These classes must be referenced somewhere for their files to not be stripped.
    [PlaceholderSentryApplication class];
    [PlaceholderProcessInfoClass class];

    startInvocations++;
    startTimestamp = [SentryDependencyContainer.sharedInstance.dateProvider date];

    SentryClientInternal *newClient = [[SentryClientInternal alloc] initWithOptions:options];
    [newClient.fileManager moveAppStateToPreviousAppState];
    [newClient.fileManager moveBreadcrumbsToPreviousBreadcrumbs];
    [SentryDependencyContainer.sharedInstance
            .scopePersistentStore moveAllCurrentStateToPreviousState];

    SentryScope *scope = options.initialScope(
        [[SentryScope alloc] initWithMaxBreadcrumbs:options.maxBreadcrumbs
                                    maxFeatureFlags:options.maxFeatureFlags]);

    SENTRY_LOG_DEBUG(@"Dispatching init work required to run on main thread.");
    [SentryDependencyContainer.sharedInstance.dispatchQueueWrapper
        dispatchAsyncOnMainQueueIfNotMainThread:^{
            SENTRY_LOG_DEBUG(@"SDK main thread init started...");

        // The UIDeviceWrapper needs to start before the Hub, because the Hub
        // enriches the scope, which calls the UIDeviceWrapper.
#if SENTRY_HAS_UIKIT
            [SentryDependencyContainer.sharedInstance.uiDeviceWrapper start];
#endif // TARGET_OS_IOS && SENTRY_HAS_UIKIT

            // The Hub needs to be initialized with a client so that closing a session
            // can happen.
            SentryHubInternal *hub = [[SentryHubInternal alloc] initWithClient:newClient
                                                                      andScope:scope];
            [SentrySDKInternal setCurrentHub:hub];

            [SentryDependencyContainer.sharedInstance.binaryImageCache start:options.debug];

            [SentrySDKInternal installIntegrations];

            // The .didCrash case is handled by SentryClient.prepareEvent when
            // a fatal event arrives. Here we report .didNotCrash if no
            // integration set fatalDetected during init.
            if ([SentrySDKInternal crashReporterInstalled] && !fatalDetected) {
                lastRunStatusCalled = YES;
                if (nil != options.onLastRunStatusDetermined) {
                    options.onLastRunStatusDetermined(SentryLastRunStatusDidNotCrash, nil);
                }
            }

#if SENTRY_TARGET_PROFILING_SUPPORTED
            sentry_sdkInitProfilerTasks(options, hub);
#endif // SENTRY_TARGET_PROFILING_SUPPORTED
        }];

    SENTRY_LOG_DEBUG(@"SDK initialized! Version: %@", SentryMeta.versionString);
}

+ (void)captureFatalEvent:(SentryEvent *)event
{
    [SentrySDKInternal.currentHub captureFatalEvent:event];
}

+ (void)captureFatalEvent:(SentryEvent *)event withScope:(SentryScope *)scope
{
    [SentrySDKInternal.currentHub captureFatalEvent:event withScope:scope];
}

#if SENTRY_HAS_UIKIT && !SDK_V10

+ (void)captureFatalAppHangEvent:(SentryEvent *)event
{
    [SentrySDKInternal.currentHub captureFatalAppHangEvent:event];
}

#endif // SENTRY_HAS_UIKIT && !SDK_V10

+ (SentryId *)captureEvent:(SentryEvent *)event
{
    return [SentrySDKInternal captureEvent:event withScope:SentrySDKInternal.currentHub.scope];
}

+ (SentryId *)captureEvent:(SentryEvent *)event withScopeBlock:(void (^)(SentryScope *))block
{
    SentryScope *scope = [[SentryScope alloc] initWithScope:SentrySDKInternal.currentHub.scope];
    block(scope);
    return [SentrySDKInternal captureEvent:event withScope:scope];
}

+ (SentryId *)captureEvent:(SentryEvent *)event withScope:(SentryScope *)scope
{
    return [SentrySDKInternal.currentHub captureEvent:event withScope:scope];
}

+ (id<SentrySpan>)startTransactionWithName:(NSString *)name operation:(NSString *)operation
{
    return [SentrySDKInternal.currentHub startTransactionWithName:name operation:operation];
}

+ (id<SentrySpan>)startTransactionWithName:(NSString *)name
                                 operation:(NSString *)operation
                               bindToScope:(BOOL)bindToScope
{
    return [SentrySDKInternal.currentHub startTransactionWithName:name
                                                        operation:operation
                                                      bindToScope:bindToScope];
}

+ (id<SentrySpan>)startTransactionWithContext:(SentryTransactionContext *)transactionContext
{
    return [SentrySDKInternal.currentHub startTransactionWithContext:transactionContext];
}

+ (id<SentrySpan>)startTransactionWithContext:(SentryTransactionContext *)transactionContext
                                  bindToScope:(BOOL)bindToScope
{
    return [SentrySDKInternal.currentHub startTransactionWithContext:transactionContext
                                                         bindToScope:bindToScope];
}

+ (id<SentrySpan>)startTransactionWithContext:(SentryTransactionContext *)transactionContext
                                  bindToScope:(BOOL)bindToScope
                        customSamplingContext:(NSDictionary<NSString *, id> *)customSamplingContext
{
    return [SentrySDKInternal.currentHub startTransactionWithContext:transactionContext
                                                         bindToScope:bindToScope
                                               customSamplingContext:customSamplingContext];
}

+ (id<SentrySpan>)startTransactionWithContext:(SentryTransactionContext *)transactionContext
                        customSamplingContext:(NSDictionary<NSString *, id> *)customSamplingContext
{
    return [SentrySDKInternal.currentHub startTransactionWithContext:transactionContext
                                               customSamplingContext:customSamplingContext];
}

+ (SentryId *)captureError:(NSError *)error
{
    return [SentrySDKInternal captureError:error withScope:SentrySDKInternal.currentHub.scope];
}

+ (SentryId *)captureError:(NSError *)error withScopeBlock:(void (^)(SentryScope *_Nonnull))block
{
    SentryScope *scope = [[SentryScope alloc] initWithScope:SentrySDKInternal.currentHub.scope];
    block(scope);
    return [SentrySDKInternal captureError:error withScope:scope];
}

+ (SentryId *)captureError:(NSError *)error withScope:(SentryScope *)scope
{
    return [SentrySDKInternal.currentHub captureError:error withScope:scope];
}

+ (SentryId *)captureException:(NSException *)exception
{
    return [SentrySDKInternal captureException:exception
                                     withScope:SentrySDKInternal.currentHub.scope];
}

+ (SentryId *)captureException:(NSException *)exception
                withScopeBlock:(void (^)(SentryScope *))block
{
    SentryScope *scope = [[SentryScope alloc] initWithScope:SentrySDKInternal.currentHub.scope];
    block(scope);
    return [SentrySDKInternal captureException:exception withScope:scope];
}

+ (SentryId *)captureException:(NSException *)exception withScope:(SentryScope *)scope
{
    return [SentrySDKInternal.currentHub captureException:exception withScope:scope];
}

+ (SentryId *)captureMessage:(NSString *)message
{
    return [SentrySDKInternal captureMessage:message withScope:SentrySDKInternal.currentHub.scope];
}

+ (SentryId *)captureMessage:(NSString *)message withScopeBlock:(void (^)(SentryScope *))block
{
    SentryScope *scope = [[SentryScope alloc] initWithScope:SentrySDKInternal.currentHub.scope];
    block(scope);
    return [SentrySDKInternal captureMessage:message withScope:scope];
}

+ (SentryId *)captureMessage:(NSString *)message withScope:(SentryScope *)scope
{
    return [SentrySDKInternal.currentHub captureMessage:message withScope:scope];
}

+ (SentryId *)captureEvent:(SentryEvent *)event withScope:(SentryScope *)scope hint:(id)hint
{
    return [SentrySDKInternal.currentHub captureEvent:event withScope:scope hint:hint];
}

+ (SentryId *)captureError:(NSError *)error withScope:(SentryScope *)scope hint:(id)hint
{
    return [SentrySDKInternal.currentHub captureError:error withScope:scope hint:hint];
}

+ (SentryId *)captureException:(NSException *)exception withScope:(SentryScope *)scope hint:(id)hint
{
    return [SentrySDKInternal.currentHub captureException:exception withScope:scope hint:hint];
}

+ (SentryId *)captureMessage:(NSString *)message withScope:(SentryScope *)scope hint:(id)hint
{
    return [SentrySDKInternal.currentHub captureMessage:message withScope:scope hint:hint];
}

/**
 * Needed by hybrid SDKs as react-native to synchronously capture an envelope.
 */
+ (void)captureEnvelope:(SentryEnvelope *)envelope
{
    [SentrySDKInternal.currentHub captureEnvelope:envelope];
}

/**
 * Needed by hybrid SDKs as react-native to synchronously store an envelope to disk.
 */
+ (void)storeEnvelope:(SentryEnvelope *)envelope
{
    [SentrySDKInternal.currentHub storeEnvelope:envelope];
}

+ (void)captureSerializedFeedback:(NSDictionary *)serializedFeedback
                      withEventId:(NSString *)feedbackEventId
                      attachments:(NSArray<SentryAttachment *> *)feedbackAttachments
{
    [SentrySDKInternal.currentHub captureSerializedFeedback:serializedFeedback
                                                withEventId:feedbackEventId
                                                attachments:feedbackAttachments];
}

#if TARGET_OS_IOS && SENTRY_HAS_UIKIT

+ (SentryFeedbackAPI *)feedback
{
    static SentryFeedbackAPI *feedbackAPI;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ feedbackAPI = [[SentryFeedbackAPI alloc] init]; });
    return feedbackAPI;
}

#endif // TARGET_OS_IOS && SENTRY_HAS_UIKIT

+ (void)addBreadcrumb:(SentryBreadcrumb *)crumb
{
    [self addBreadcrumb:crumb withHint:nil];
}

+ (void)addBreadcrumb:(SentryBreadcrumb *)crumb withHint:(id _Nullable)hint
{
    if (![SentrySDKInternal isEnabled]) {
        // We must log with level fatal because only fatal messages get logged even when the SDK
        // isn't started. We've seen multiple times that users try to add a breadcrumb before
        // starting the SDK, and it confuses them. Ideally, we would do something to store the user
        // and set it once we start the SDK, but this is a breaking change, so we live with the
        // workaround for now.
        SENTRY_LOG_FATAL(
            @"The SDK is disabled, so addBreadcrumb doesn't work. Please ensure to start "
            @"the SDK before adding breadcrumbs.");
    }

    [SentrySDKInternal.currentHub addBreadcrumb:crumb withHint:hint];
}

+ (void)configureScope:(void (^)(SentryScope *scope))callback
{
    [SentrySDKInternal.currentHub configureScope:callback];
}

+ (void)setUser:(SentryUser *_Nullable)user
{
    if (![SentrySDKInternal isEnabled]) {
        // We must log with level fatal because only fatal messages get logged even when the SDK
        // isn't started. We've seen multiple times that users try to set the user before starting
        // the SDK, and it confuses them. Ideally, we would do something to store the user and set
        // it once we start the SDK, but this is a breaking change, so we live with the workaround
        // for now.
        SENTRY_LOG_FATAL(@"The SDK is disabled, so setUser doesn't work. Please ensure to start "
                         @"the SDK before setting the user.");
    }

    [SentrySDKInternal.currentHub setUser:user];
}

+ (BOOL)crashedLastRun
{
    return SentryDependencyContainer.sharedInstance.activeCrashReporterState.crashedLastLaunch;
}

+ (NSInteger)lastRunStatus
{
    if (![SentrySDKInternal crashReporterInstalled]) {
        return SentryLastRunStatusUnknown;
    }

    if (SentryDependencyContainer.sharedInstance.activeCrashReporterState.crashedLastLaunch) {
        return SentryLastRunStatusDidCrash;
    }
    return SentryLastRunStatusDidNotCrash;
}

+ (BOOL)detectedStartUpCrash
{
    return _detectedStartUpCrash;
}

+ (void)setDetectedStartUpCrash:(BOOL)value
{
    _detectedStartUpCrash = value;
}

+ (void)startSession
{
    [SentrySDKInternal.currentHub startSession];
}

+ (void)endSession
{
    [SentrySDKInternal.currentHub endSession];
}

/**
 * Install integrations and keeps ref in @c SentryHub.integrations
 */
+ (void)installIntegrations
{
    if (nil == [SentrySDKInternal.currentHub getClient]) {
        // Gatekeeper
        return;
    }
    SentryOptions *options = [SentrySDKInternal.currentHub getClient].options;

    [SentrySwiftIntegrationInstaller installWith:options];
}

+ (void)reportFullyDisplayed
{
    [SentrySDKInternal.currentHub reportFullyDisplayed];
}

#if !SDK_V10
+ (void)pauseAppHangTracking
{
    SentryHangTrackerIntegrationObjC *anrTrackingIntegration
        = (SentryHangTrackerIntegrationObjC *)[SentrySDKInternal.currentHub
            getInstalledIntegration:[SentryHangTrackerIntegrationObjC class]];

    [anrTrackingIntegration pauseAppHangTracking];
}

+ (void)resumeAppHangTracking
{
    SentryHangTrackerIntegrationObjC *anrTrackingIntegration
        = (SentryHangTrackerIntegrationObjC *)[SentrySDKInternal.currentHub
            getInstalledIntegration:[SentryHangTrackerIntegrationObjC class]];

    [anrTrackingIntegration resumeAppHangTracking];
}
#endif

+ (void)flush:(NSTimeInterval)timeout
{
    [SentrySDKInternal.currentHub flush:timeout];
}

/**
 * Closes the SDK and uninstalls all the integrations.
 */
+ (void)close
{
    SENTRY_LOG_DEBUG(@"Starting to close SDK.");

    [SentryDependencyContainer.sharedInstance.dispatchQueueWrapper dispatchSyncOnMainQueue:^{

#if SENTRY_TARGET_PROFILING_SUPPORTED
        [SentryContinuousProfiler stop];
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

        startTimestamp = nil;

        SentryHubInternal *hub = SentrySDKInternal.currentHub;
        [hub removeAllIntegrations];

        SENTRY_LOG_DEBUG(@"Uninstalled all integrations.");

#if SENTRY_HAS_UIKIT
        // force the AppStateManager to unsubscribe, see
        // https://github.com/getsentry/sentry-cocoa/issues/2455
        [[SentryDependencyContainer sharedInstance].appStateManager stopWithForce:YES];
#endif

        [hub close];
        [hub bindClient:nil];

        [SentrySDKInternal setCurrentHub:nil];

        fatalDetected = NO;
        lastRunStatusCalled = NO;

        [SentryDependencyContainer.sharedInstance.binaryImageCache stop];

#if TARGET_OS_IOS && SENTRY_HAS_UIKIT
        [SentryDependencyContainer.sharedInstance.uiDeviceWrapper stop];
#endif // TARGET_OS_IOS && SENTRY_HAS_UIKIT

        [SentryDependencyContainer reset];

        @synchronized(currentHubLock) {
            sdkStarted = NO;
        }
    }];
    SENTRY_LOG_DEBUG(@"SDK closed!");
}

#ifndef __clang_analyzer__
// Code not to be analyzed
+ (void)crash
{
    // volatile forces an actual null dereference (SIGSEGV) instead of letting
    // the compiler optimize the undefined behavior into a trap (SIGTRAP).
    volatile int *p = 0;
    *p = 0;
}
#endif

#if SENTRY_TARGET_PROFILING_SUPPORTED
+ (void)startProfiler
{
    SentryHubInternal *localCurrentHub = nil;
    @synchronized(currentHubLock) {
        localCurrentHub = currentHub;
    }
    SentryOptions *options = localCurrentHub.client.options;
    if (options == nil) {
        SENTRY_LOG_WARN(@"Cannot start profiling when options are nil.");
        return;
    }

    if (options.profiling != nil) {
        if (options.profiling.lifecycle == SentryProfileLifecycleTrace) {
            SENTRY_LOG_WARN(
                @"The profiling lifecycle is set to trace, so you cannot start profile sessions "
                @"manually. See SentryProfileLifecycle for more information.");
            return;
        }

        SentryProfileConfiguration *profileConfiguration = sentry_getProfileConfiguration();
        if (profileConfiguration.profilerSessionSampleDecision.decision
            != kSentrySampleDecisionYes) {
            SENTRY_LOG_DEBUG(
                @"The profiling session has been sampled out, no profiling will take place.");
            return;
        }
    }

    if ([SentryContinuousProfiler isCurrentlyProfiling]) {
        SENTRY_LOG_WARN(@"There is already a profile session running.");
        return;
    }

    [SentryContinuousProfiler start];
}

+ (void)stopProfiler
{
    // check if we'd be stopping a launch profiler, because then we need to check the hydrated
    // configuration options, not the current ones
    SentryProfileConfiguration *profileConfiguration = sentry_getProfileConfiguration();
    if (profileConfiguration.isProfilingThisLaunch) {
        if (profileConfiguration.profileOptions == nil) {
            SENTRY_LOG_WARN(
                @"The current profiler was started on app launch and was configured as a "
                @"transaction profiler, which cannot be stopped manually. Transaction profiling is "
                @"deprecated and will be removed in a future SDK version.");
            return;
        }

        if (profileConfiguration.profileOptions.lifecycle == SentryProfileLifecycleTrace) {
            SENTRY_LOG_WARN(
                @"The launch profile lifecycle was set to trace, so you cannot stop profile "
                @"sessions manually. See SentryProfileLifecycle for more information.");
            return;
        }

        SENTRY_LOG_DEBUG(@"Stopping launch UI profiler with manual lifecycle.");
        [SentryContinuousProfiler stop];
        return;
    }

    SentryHubInternal *localCurrentHub = nil;
    @synchronized(currentHubLock) {
        localCurrentHub = currentHub;
    }
    SentryOptions *options = localCurrentHub.client.options;
    if (options == nil) {
        SENTRY_LOG_WARN(@"Cannot stop profiling when options are nil.");
        return;
    }
    if (options.profiling != nil && options.profiling.lifecycle == SentryProfileLifecycleTrace) {
        SENTRY_LOG_WARN(
            @"The profiling lifecycle is set to trace, so you cannot stop profile sessions "
            @"manually. See SentryProfileLifecycle for more information.");
        return;
    }

    if (![SentryContinuousProfiler isCurrentlyProfiling]) {
        SENTRY_LOG_WARN(@"No profile session to stop.");
        return;
    }

    [SentryContinuousProfiler stop];
}
#endif // SENTRY_TARGET_PROFILING_SUPPORTED

#if SENTRY_HAS_UIKIT

/** Only needed for testing. We can't use `SENTRY_TEST || SENTRY_TEST_CI` because we call this from
 * the iOS-Swift sample app. */
+ (nullable NSArray<NSString *> *)relevantViewControllersNames
{
    return SentryDependencyContainer.sharedInstance.application.relevantViewControllersNames;
}
#endif // SENTRY_HAS_UIKIT

/** Only needed for testing. We can't use `SENTRY_TEST || SENTRY_TEST_CI` because we call this from
 * the iOS-Swift sample app. */
+ (NSArray<NSString *> *)trimmedInstalledIntegrationNames
{
    return [SentrySDKInternal.currentHub trimmedInstalledIntegrationNames];
}

@end

NS_ASSUME_NONNULL_END
