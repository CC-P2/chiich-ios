// Adapted from: https://github.com/kstenerud/KSCrash
//
//  SentryCrashReportStore.c
//
//  Created by Karl Stenerud on 2012-02-05.
//
//  Copyright (c) 2012 Karl Stenerud. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall remain in place
// in this source code.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#if !SDK_V10

#    include "SentryCrashReportStore.h"
#    include "SentryAsyncSafeLog.h"
#    include "SentryCrashFileUtils.h"

#    include <dirent.h>
#    include <errno.h>
#    include <fcntl.h>
#    include <inttypes.h>
#    include <pthread.h>
#    include <stdio.h>
#    include <stdlib.h>
#    include <string.h>
#    include <time.h>
#    include <unistd.h>

static int g_maxReportCount = 5;
// Have to use max 32-bit atomics because of MIPS.
static _Atomic(uint32_t) g_nextUniqueIDLow;
static int64_t g_nextUniqueIDHigh;
// These values are read while writing crash reports. Keep them in static storage instead of
// heap-allocated strings so crash-time path construction does not depend on heap pointers.
static char g_appName[SentryCrashCRS_MAX_PATH_LENGTH];
static char g_reportsPath[SentryCrashCRS_MAX_PATH_LENGTH];
static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;

static int
compareInt64(const void *a, const void *b)
{
    int64_t diff = *(int64_t *)a - *(int64_t *)b;
    if (diff < 0) {
        return -1;
    } else if (diff > 0) {
        return 1;
    }
    return 0;
}

static inline int64_t
getNextUniqueID(void)
{
    return g_nextUniqueIDHigh + g_nextUniqueIDLow++;
}

static void
getCrashReportPathByID(int64_t id, char *pathBuffer)
{
    snprintf(pathBuffer, SentryCrashCRS_MAX_PATH_LENGTH, "%s/%s-report-%016llx.json", g_reportsPath,
        g_appName, id);
}

static int64_t
getReportIDFromFilename(const char *filename)
{
    // The previous implementation built a "%s-report-%%" PRIx64 ".json" format string and called
    // sscanf, which has two problems flagged by CWE-676: a malformed filename can leave
    // reportID uninitialized (sscanf only writes converted fields), and sscanf accepts arbitrary
    // leading whitespace and silently ignores trailing junk, both of which are easy to misuse.
    // We avoid both by parsing the fixed prefix with strncmp and converting the hex ID with
    // strtoull, which reports exactly how many characters it consumed via endPtr. strlen on
    // g_appName is safe: it is set once during sentrycrashcrs_initialize from a caller-owned
    // C string and is never modified afterwards.
    const size_t appNameLen = strlen(g_appName);
    if (strncmp(filename, g_appName, appNameLen) != 0) {
        return 0;
    }
    const char *rest = filename + appNameLen;
    if (strncmp(rest, "-report-", 8) != 0) {
        return 0;
    }
    const char *hexStart = rest + 8;
    char *endPtr = NULL;
    const uint64_t id = strtoull(hexStart, &endPtr, 16);
    if (endPtr == hexStart) {
        return 0;
    }
    // Expect ".json" suffix
    if (strcmp(endPtr, ".json") != 0) {
        return 0;
    }
    return (int64_t)id;
}

static int64_t
getReportIDFromFilePath(const char *filepath)
{
    // Strip the directory portion and reuse the filename parser. strrchr returns the last '/'
    // or NULL; in the NULL case (a bare filename) we use filepath unchanged.
    const char *lastSlash = strrchr(filepath, '/');
    const char *filename = lastSlash != NULL ? lastSlash + 1 : filepath;
    return getReportIDFromFilename(filename);
}

static int
getReportCount(void)
{
    int count = 0;
    DIR *dir = opendir(g_reportsPath);
    if (dir == NULL) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Could not open directory %s", g_reportsPath);
        goto done;
    }
    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL) {
        if (ent->d_type != DT_DIR && getReportIDFromFilename(ent->d_name) > 0) {
            count++;
        }
    }

done:
    if (dir != NULL) {
        closedir(dir);
    }
    return count;
}

static int
getReportIDs(int64_t *reportIDs, int count)
{
    int index = 0;
    DIR *dir = opendir(g_reportsPath);
    if (dir == NULL) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Could not open directory %s", g_reportsPath);
        goto done;
    }

    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL && index < count) {
        int64_t reportID = getReportIDFromFilename(ent->d_name);
        if (reportID > 0) {
            reportIDs[index++] = reportID;
        }
    }

    qsort(reportIDs, (unsigned)count, sizeof(reportIDs[0]), compareInt64);

done:
    if (dir != NULL) {
        closedir(dir);
    }
    return index;
}

static void
pruneReports(void)
{
    int reportCount = getReportCount();
    if (reportCount > g_maxReportCount) {
        int64_t reportIDs[reportCount];
        reportCount = getReportIDs(reportIDs, reportCount);

        for (int i = 0; i < reportCount - g_maxReportCount; i++) {
            sentrycrashcrs_deleteReportWithID(reportIDs[i]);
        }
    }
}

static int64_t
getBaseIDFromTime(const struct tm *reportTime)
{
    return (int64_t)reportTime->tm_sec + (int64_t)reportTime->tm_min * 61
        + (int64_t)reportTime->tm_hour * 61 * 60 + (int64_t)reportTime->tm_yday * 61 * 60 * 24
        + (int64_t)reportTime->tm_year * 61 * 60 * 24 * 366;
}

static void
initializeIDsFromTime(const struct tm *reportTime)
{
    int64_t baseID = getBaseIDFromTime(reportTime);
    baseID <<= 23;

    g_nextUniqueIDHigh = baseID & ~(int64_t)0xffffffff;
    uint32_t lowerBaseID = (uint32_t)(baseID & 0xffffffff);
    g_nextUniqueIDLow = lowerBaseID;
}

static void
initializeIDs(void)
{
    time_t rawTime;
    time(&rawTime);
    struct tm reportTime;
    gmtime_r(&rawTime, &reportTime);
    initializeIDsFromTime(&reportTime);
}

// Public API

void
sentrycrashcrs_initialize(const char *appName, const char *reportsPath)
{
    pthread_mutex_lock(&g_mutex);
    const size_t appNameLength
        = strlcpy(g_appName, appName != NULL ? appName : "", sizeof(g_appName));
    if (appName == NULL) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Report store initialized with NULL app name");
    } else if (appNameLength >= sizeof(g_appName)) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("App name is too long; truncating from %zu to %zu bytes",
            appNameLength, sizeof(g_appName) - 1);
    }

    const size_t reportsPathLength
        = strlcpy(g_reportsPath, reportsPath != NULL ? reportsPath : "", sizeof(g_reportsPath));
    if (reportsPath == NULL) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Report store initialized with NULL reports path");
    } else if (reportsPathLength >= sizeof(g_reportsPath)) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Reports path is too long; truncating from %zu to %zu bytes",
            reportsPathLength, sizeof(g_reportsPath) - 1);
    }

    sentrycrashfu_makePath(g_reportsPath);
    pruneReports();
    initializeIDs();
    pthread_mutex_unlock(&g_mutex);
}

void
sentrycrashcrs_getNextCrashReportPath(char *crashReportPathBuffer)
{
    getCrashReportPathByID(getNextUniqueID(), crashReportPathBuffer);
}

#    if defined(SENTRY_TEST) || defined(SENTRY_TEST_CI)
void
sentrycrashcrs_initializeIDsWithTimeForTests(const struct tm *reportTime)
{
    pthread_mutex_lock(&g_mutex);
    initializeIDsFromTime(reportTime);
    pthread_mutex_unlock(&g_mutex);
}
#    endif // defined(SENTRY_TEST) || defined(SENTRY_TEST_CI)

int
sentrycrashcrs_getReportCount(void)
{
    pthread_mutex_lock(&g_mutex);
    int count = getReportCount();
    pthread_mutex_unlock(&g_mutex);
    return count;
}

int
sentrycrashcrs_getReportIDs(int64_t *reportIDs, int count)
{
    pthread_mutex_lock(&g_mutex);
    count = getReportIDs(reportIDs, count);
    pthread_mutex_unlock(&g_mutex);
    return count;
}

void
sentrycrashcrs_getCrashReportPathById(int64_t reportId, char *pathBuffer)
{
    getCrashReportPathByID(reportId, pathBuffer);
}

char *
sentrycrashcrs_readReport(int64_t reportID)
{
    pthread_mutex_lock(&g_mutex);
    char path[SentryCrashCRS_MAX_PATH_LENGTH];
    getCrashReportPathByID(reportID, path);
    char *result;
    sentrycrashfu_readEntireFile(path, &result, NULL, 2000000);
    pthread_mutex_unlock(&g_mutex);
    return result;
}

void
sentrycrashcrs_getAttachmentsPath_forReportId(int64_t reportID, char *pathBuffer)
{
    snprintf(pathBuffer, SentryCrashCRS_MAX_PATH_LENGTH, "%s/%s-report-%016llx-attachments",
        g_reportsPath, g_appName, reportID);
}

void
sentrycrashcrs_getAttachmentsPath_forReport(const char *reportPath, char *pathBuffer)
{
    sentrycrashcrs_getAttachmentsPath_forReportId(getReportIDFromFilePath(reportPath), pathBuffer);
}

int64_t
sentrycrashcrs_addUserReport(const char *report, int reportLength)
{
    pthread_mutex_lock(&g_mutex);
    int64_t currentID = getNextUniqueID();
    char crashReportPath[SentryCrashCRS_MAX_PATH_LENGTH];
    getCrashReportPathByID(currentID, crashReportPath);

    int fd = open(crashReportPath, O_WRONLY | O_CREAT, 0644);
    if (fd < 0) {
        SENTRY_ASYNC_SAFE_LOG_ERROR(
            "Could not open file %s: %s", crashReportPath, SENTRY_STRERROR_R(errno));
        goto done;
    }

    int bytesWritten = (int)write(fd, report, (unsigned)reportLength);
    if (bytesWritten < 0) {
        SENTRY_ASYNC_SAFE_LOG_ERROR(
            "Could not write to file %s: %s", crashReportPath, SENTRY_STRERROR_R(errno));
        goto done;
    } else if (bytesWritten < reportLength) {
        SENTRY_ASYNC_SAFE_LOG_ERROR("Expected to write %d bytes to file %s, but only wrote %d",
            reportLength, crashReportPath, bytesWritten);
    }

done:
    if (fd >= 0) {
        close(fd);
    }
    pthread_mutex_unlock(&g_mutex);

    return currentID;
}

void
sentrycrashcrs_deleteAllReports(void)
{
    pthread_mutex_lock(&g_mutex);
    sentrycrashfu_deleteContentsOfPath(g_reportsPath);
    pthread_mutex_unlock(&g_mutex);
}

void
sentrycrashcrs_deleteReportWithID(int64_t reportID)
{
    char path[SentryCrashCRS_MAX_PATH_LENGTH];
    getCrashReportPathByID(reportID, path);
    sentrycrashfu_removeFile(path, true);
}

void
sentrycrashcrs_setMaxReportCount(int maxReportCount)
{
    g_maxReportCount = maxReportCount;
}

#endif // !SDK_V10
