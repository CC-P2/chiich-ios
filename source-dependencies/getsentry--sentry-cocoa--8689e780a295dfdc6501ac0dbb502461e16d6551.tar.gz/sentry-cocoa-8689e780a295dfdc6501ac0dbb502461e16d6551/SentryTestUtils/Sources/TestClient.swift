#if SWIFT_PACKAGE
@_spi(Private) @testable import SentrySwift
#else
@_spi(Private) @testable import Sentry
#endif
import _SentryPrivate
import Foundation
import SentryTestUtilsObjC
import XCTest

/// `open` because subclassed in test targets, e.g. to override `getTelemetryProcessor()`.
open class TestClient: SentryTestClientWrapper {

    public override init?(options: NSObject) {
        guard let options = options as? Options else {
            XCTFail("TestClient.init: Expected Options, got \(type(of: options))")
            return nil
        }

        let fileManager: TestFileManager
        do {
            fileManager = try TestFileManager(
                options: options,
                dateProvider: TestCurrentDateProvider(),
                dispatchQueueWrapper: TestSentryDispatchQueueWrapper()
            )
        } catch {
            XCTFail("TestClient.init: Failed to create TestFileManager: \(error)")
            return nil
        }

        super.init(
            options: options,
            dateProvider: TestCurrentDateProvider(),
            transportAdapter: TestTransportAdapter(transports: [TestTransport()], options: options),
            fileManager: fileManager,
            threadInspector: SentryDefaultThreadInspector(options: options),
            debugImageProvider: SentryDependencyContainer.sharedInstance().debugImageProvider,
            random: SentryDependencyContainer.sharedInstance().random,
            locale: NSLocale.autoupdatingCurrent,
            timezone: NSCalendar.autoupdatingCurrent.timeZone,
            eventContextEnricher: SentryDependencyContainer.sharedInstance().eventContextEnricher,
            binaryImageCache: SentryDependencyContainer.sharedInstance().binaryImageCache,
            dispatchQueueWrapper: TestSentryDispatchQueueWrapper()
        )
    }

    // Without this override we get a fatal error: use of unimplemented initializer
    // see https://stackoverflow.com/questions/28187261/ios-swift-fatal-error-use-of-unimplemented-initializer-init
    public override init(
        options: NSObject,
        dateProvider: Any,
        transportAdapter: Any,
        fileManager: Any,
        threadInspector: Any,
        debugImageProvider: Any,
        random: Any,
        locale: Locale,
        timezone: TimeZone,
        eventContextEnricher: Any,
        binaryImageCache: Any,
        dispatchQueueWrapper: Any
    ) {
        super.init(
            options: options,
            dateProvider: dateProvider,
            transportAdapter: transportAdapter,
            fileManager: fileManager,
            threadInspector: threadInspector,
            debugImageProvider: debugImageProvider,
            random: random,
            locale: locale,
            timezone: timezone,
            eventContextEnricher: eventContextEnricher,
            binaryImageCache: binaryImageCache,
            dispatchQueueWrapper: dispatchQueueWrapper
        )
    }

    @_spi(Private) @nonobjc public convenience init(
        options: NSObject,
        dateProvider: SentryCurrentDateProvider,
        transportAdapter: SentryTransportAdapter,
        fileManager: SentryFileManager,
        threadInspector: SentryDefaultThreadInspector,
        debugImageProvider: SentryDebugImageProvider,
        random: SentryRandomProtocol,
        locale: Locale,
        timezone: TimeZone,
        eventContextEnricher: SentryEventContextEnricher,
        binaryImageCache: SentryBinaryImageCache,
        dispatchQueueWrapper: SentryDispatchQueueWrapper
    ) {
        self.init(
            options: options,
            dateProvider: dateProvider as Any,
            transportAdapter: transportAdapter as Any,
            fileManager: fileManager as Any,
            threadInspector: threadInspector as Any,
            debugImageProvider: debugImageProvider as Any,
            random: random as Any,
            locale: locale,
            timezone: timezone,
            eventContextEnricher: eventContextEnricher as Any,
            binaryImageCache: binaryImageCache as Any,
            dispatchQueueWrapper: dispatchQueueWrapper as Any
        )
    }
    
    @_spi(Private)
    public var captureSessionInvocations = Invocations<SentrySession>()
    @_spi(Private)
    public override func wrapper_capture(session: Any) {
        guard let session = session as? SentrySession else {
            XCTFail("TestClient.wrapper_capture(session:): Expected SentrySession, got \(type(of: session))")
            return
        }
        captureSessionInvocations.record(session)
    }
    
    public var captureEventInvocations = Invocations<Event>()
    public override func capture(event: Event) -> SentryId {
        captureEventInvocations.record(event)
        return event.eventId
    }
    
    @_spi(Private) public var captureEventWithScopeInvocations = Invocations<(event: Event, scope: Scope, additionalEnvelopeItems: [SentryEnvelopeItem])>()
    public override func wrapper_capture(event: Event, scope: Scope, additionalEnvelopeItems: [Any]) -> SentryId {
        guard let additionalEnvelopeItems = additionalEnvelopeItems as? [SentryEnvelopeItem] else {
            XCTFail("TestClient.wrapper_capture: Expected [SentryEnvelopeItem], got \(additionalEnvelopeItems.map { type(of: $0) })")
            return event.eventId
        }
        captureEventWithScopeInvocations.record((event, scope, additionalEnvelopeItems))
        return event.eventId
    }
    
    var captureMessageInvocations = Invocations<String>()
    public override func capture(message: String) -> SentryId {
        self.captureMessageInvocations.record(message)
        return SentryId()
    }
    
    public var captureMessageWithScopeInvocations = Invocations<(message: String, scope: Scope)>()
    public override func capture(message: String, scope: Scope) -> SentryId {
        captureMessageWithScopeInvocations.record((message, scope))
        return SentryId()
    }

    public var captureMessageWithScopeAttachAllThreadsInvocations = Invocations<(message: String, scope: Scope, attachAllThreads: NSNumber?)>()
    public override func capture(message: String, scope: Scope, attachAllThreads: NSNumber?) -> SentryId {
        super.capture(message: message, scope: scope, attachAllThreads: attachAllThreads)
        captureMessageWithScopeAttachAllThreadsInvocations.record((message, scope, attachAllThreads))
        return SentryId()
    }
    
    public var captureErrorInvocations = Invocations<Error>()
    public override func capture(error: Error) -> SentryId {
        super.capture(error: error)

        captureErrorInvocations.record(error)
        return SentryId()
    }
    
    public var captureErrorWithScopeInvocations = Invocations<(error: Error, scope: Scope)>()
    public override func capture(error: Error, scope: Scope) -> SentryId {
        super.capture(error: error, scope: scope)

        captureErrorWithScopeInvocations.record((error, scope))
        return SentryId()
    }

    public var captureErrorWithScopeAttachAllThreadsInvocations = Invocations<(error: Error, scope: Scope, attachAllThreads: NSNumber?)>()
    public override func capture(error: Error, scope: Scope, attachAllThreads: NSNumber?) -> SentryId {
        super.capture(error: error, scope: scope, attachAllThreads: attachAllThreads)
        
        captureErrorWithScopeAttachAllThreadsInvocations.record((error, scope, attachAllThreads))
        return SentryId()
    }
    
    var captureExceptionInvocations = Invocations<NSException>()
    public override func capture(exception: NSException) -> SentryId {
        super.capture(exception: exception)

        captureExceptionInvocations.record(exception)
        return SentryId()
    }
    
    public var captureExceptionWithScopeInvocations = Invocations<(exception: NSException, scope: Scope)>()
    public override func capture(exception: NSException, scope: Scope) -> SentryId {
        super.capture(exception: exception, scope: scope)

        captureExceptionWithScopeInvocations.record((exception, scope))
        return SentryId()
    }

    public var captureExceptionWithScopeAttachAllThreadsInvocations = Invocations<(exception: NSException, scope: Scope, attachAllThreads: NSNumber?)>()
    public override func capture(exception: NSException, scope: Scope, attachAllThreads: NSNumber?) -> SentryId {
        super.capture(exception: exception, scope: scope, attachAllThreads: attachAllThreads)
        captureExceptionWithScopeAttachAllThreadsInvocations.record((exception, scope, attachAllThreads))
        return SentryId()
    }

    @_spi(Private) public var captureEventIncrementingSessionErrorCountInvocations = Invocations<(event: Event, scope: Scope)>()
    @_spi(Private) public override func captureEventIncrementingSessionErrorCount(_ event: Event, with scope: Scope) -> SentryId {
        super.captureEventIncrementingSessionErrorCount(event, with: scope)

        captureEventIncrementingSessionErrorCountInvocations.record((event, scope))
        return SentryId()
    }

    public var captureFatalEventInvocations = Invocations<(event: Event, scope: Scope)>()
    public override func captureFatalEvent(_ event: Event, with scope: Scope) -> SentryId {
        captureFatalEventInvocations.record((event, scope))
        return SentryId()
    }
    
    @_spi(Private)
    public var captureFatalEventWithSessionInvocations = Invocations<(event: Event, session: SentrySession, scope: Scope)>()
    @_spi(Private)
    public override func wrapper_captureFatalEvent(_ event: Event, session: Any, scope: Scope) -> SentryId {
        guard let session = session as? SentrySession else {
            XCTFail("TestClient.wrapper_captureFatalEvent: Expected SentrySession, got \(type(of: session))")
            return event.eventId
        }
        captureFatalEventWithSessionInvocations.record((event, session, scope))
        return SentryId()
    }
    
    public var saveCrashTransactionInvocations = Invocations<(event: Event, scope: Scope)>()
    public override func saveCrashTransaction(transaction: Transaction, scope: Scope) {
        saveCrashTransactionInvocations.record((transaction, scope))
    }
    
    public var captureFeedbackInvocations = Invocations<(SentryFeedback, Scope)>()
    public override func wrapper_capture(feedback: Any, scope: Scope) {
        guard let feedback = feedback as? SentryFeedback else {
            XCTFail("TestClient.wrapper_capture(feedback:scope:): Expected SentryFeedback, got \(type(of: feedback))")
            return
        }
        captureFeedbackInvocations.record((feedback, scope))
    }
    
    public var captureSerializedFeedbackInvocations = Invocations<(String, Scope)>()
    public override func captureSerializedFeedback(_ serializedFeedback: [AnyHashable: Any], withEventId feedbackEventId: String, attachments: [Attachment], scope: Scope) {
        captureSerializedFeedbackInvocations.record((feedbackEventId, scope))
    }
    
    @_spi(Private) public var captureEnvelopeInvocations = Invocations<SentryEnvelope>()
    @_spi(Private) public override func wrapper_capture(envelope: Any) {
        guard let envelope = envelope as? SentryEnvelope else {
            XCTFail("TestClient.wrapper_capture(envelope:): Expected SentryEnvelope, got \(type(of: envelope))")
            return
        }
        captureEnvelopeInvocations.record(envelope)
    }
    
    @_spi(Private) public var storedEnvelopeInvocations = Invocations<SentryEnvelope>()
    @_spi(Private) public override func wrapper_store(envelope: Any) {
        guard let envelope = envelope as? SentryEnvelope else {
            XCTFail("TestClient.wrapper_store: Expected SentryEnvelope, got \(type(of: envelope))")
            return
        }
        storedEnvelopeInvocations.record(envelope)
    }
    
    @_spi(Private) public var recordLostEvents = Invocations<(category: SentryDataCategory, reason: SentryDiscardReason)>()
    public override func wrapper_recordLostEvent(_ category: UInt, reason: UInt) {
        guard let category = SentryDataCategory(rawValue: category),
              let reason = SentryDiscardReason(rawValue: reason) else {
            XCTFail("TestClient.wrapper_recordLostEvent: Invalid category \(category) or reason \(reason)")
            return
        }
        recordLostEvents.record((category, reason))
    }

    @_spi(Private) public var recordLostEventsWithQauntity = Invocations<(category: SentryDataCategory, reason: SentryDiscardReason, quantity: UInt)>()
    public override func wrapper_recordLostEvent(_ category: UInt, reason: UInt, quantity: UInt) {
        guard let category = SentryDataCategory(rawValue: category),
              let reason = SentryDiscardReason(rawValue: reason) else {
            XCTFail("TestClient.wrapper_recordLostEvent(_:reason:quantity:): Invalid category \(category) or reason \(reason)")
            return
        }
        recordLostEventsWithQauntity.record((category, reason, quantity))
    }
    
    public var flushInvocations = Invocations<TimeInterval>()
    public override func flush(timeout: TimeInterval) {
        flushInvocations.record(timeout)
    }
    
    public var captureLogInvocations = Invocations<(log: SentryLog, scope: Scope)>()
    public override func _swiftCaptureLog(_ log: NSObject, with scope: Scope) {
        if let castLog = log as? SentryLog {
            captureLogInvocations.record((castLog, scope))
        }
    }
}
