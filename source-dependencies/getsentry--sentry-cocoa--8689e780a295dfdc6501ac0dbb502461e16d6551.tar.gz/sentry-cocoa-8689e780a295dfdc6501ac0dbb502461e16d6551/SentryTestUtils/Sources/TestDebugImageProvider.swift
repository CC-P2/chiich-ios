#if SWIFT_PACKAGE
@_spi(Private) @testable import SentrySwift
#else
@_spi(Private) @testable import Sentry
#endif
import _SentryPrivate
import Foundation

@_spi(Private) public class TestDebugImageProvider: SentryDebugImageProvider {
    public var debugImages: [DebugMeta]?
    
    public var getDebugImagesFromCacheForFramesInvocations = Invocations<Void>()
    public override func getDebugImagesFromCacheForFrames(frames: [Frame]) -> [DebugMeta] {
        getDebugImagesFromCacheForFramesInvocations.record(Void())
        
        return debugImages ?? super.getDebugImagesFromCacheForFrames(frames: frames)
    }
    
    public var getDebugImagesFromCacheForThreadsInvocations = Invocations<Void>()
    public override func getDebugImagesFromCacheForThreads(threads: [SentryThread]) -> [DebugMeta] {
        getDebugImagesFromCacheForThreadsInvocations.record(Void())
        return debugImages ?? super.getDebugImagesFromCacheForThreads(threads: threads)
    }
    
    public var getDebugImagesFromCacheInvocations = Invocations<Void>()
    public override func getDebugImagesFromCache() -> [DebugMeta] {
        getDebugImagesFromCacheInvocations.record(Void())
        return debugImages ?? super.getDebugImagesFromCache()
    }
}
