import UIKit

public struct CropViewConfig {
    public var cropAuxiliaryIndicatorConfig = CropAuxiliaryIndicatorConfig()
    
    public var cropShapeType: CropShapeType = .rect
    
    public var cropBorderWidth: CGFloat = 0 {
        didSet {
            assert(cropBorderWidth > 0)
        }
    }
    
    public var cropBorderColor: UIColor = .clear
    
    /**
     When backgroundColor is set, cropMaskVisualEffectType is automatically set to custom type
     */
    public var backgroundColor: UIColor? {
        didSet {
            cropMaskVisualEffectType = .custom(color: backgroundColor!)
        }
    }
    
    public var cropMaskVisualEffectType: CropMaskVisualEffectType = .blurDark
    
    public var presetTransformationType: PresetTransformationType = .none
    
    public var minimumZoomScale: CGFloat = 1 {
        didSet {
            assert(minimumZoomScale >= 1)
        }
    }
    
    public var maximumZoomScale: CGFloat = 15
    
    public var showAttachedRotationControlView = true
    
    public var padding: CGFloat = 14 {
        didSet {
            assert(padding >= 3, "padding is need to be at least 3 in order to show the whole crop box handles")
        }
    }
    
    public var cropActivityIndicator: ActivityIndicatorProtocol?
    
    public var cropActivityIndicatorSize = CGSize(width: 100, height: 100)
    
    public var rotationControlViewHeight: CGFloat = 60
    
    public var rotateCropBoxFor90DegreeRotation = true
    
    public var minimumCropBoxSize: CGFloat = 42 {
        didSet {
            assert(minimumCropBoxSize >= 4)
        }
    }
    
    public enum BuiltInRotationControlViewType {
        case rotationDial(config: RotationDialConfig = .init())
        case slideDial(config: SlideDialConfig = .init())
    }
    
    public var builtInRotationControlViewType: BuiltInRotationControlViewType = .rotationDial()
    
    public var keyboardZoomScaleFactor: CGFloat = 1.1
    
    /// When true, enables perspective correction with straighten / horizontal skew / vertical skew
    /// adjustments similar to Apple Photos app.
    public var enablePerspectiveCorrection: Bool = false
    
    /// Maximum pixel count (width × height) for input images before enabling large image mode.
    /// When set to a value > 0 and the input image exceeds this limit, Mantis will:
    /// - Use a downsampled version for display (to prevent UIImageView black screen)
    /// - Use a memory-efficient CIImage pipeline for cropping (to avoid CGContext memory issues)
    /// - Preserve full original resolution in the crop output
    /// Set to 0 to disable (default). Recommended value when enabled: 4096 * 4096.
    public var maxImagePixelCount: Int = 0

    var appearanceMode: AppearanceMode = .forceDark

    public init() {}
}
