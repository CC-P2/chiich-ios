/*
 * Copyright 2024 New Vector Ltd.
 * Copyright 2024 The Matrix.org Foundation C.I.C.
 *
 * SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
 * Please see LICENSE in the repository root for full details.
 */

package io.element.android.wysiwyg.utils

import org.jsoup.nodes.Document

/**
 * HTML converter that is not depend on Android, for unit tests.
 */
class BasicHtmlConverter: HtmlConverter {
    override fun fromHtmlToSpans(html: String): CharSequence = html.replace("<[^>]*>".toRegex(), "")
    override fun fromDocumentToSpans(dom: Document): CharSequence {
        return fromHtmlToSpans(dom.html())
    }
}