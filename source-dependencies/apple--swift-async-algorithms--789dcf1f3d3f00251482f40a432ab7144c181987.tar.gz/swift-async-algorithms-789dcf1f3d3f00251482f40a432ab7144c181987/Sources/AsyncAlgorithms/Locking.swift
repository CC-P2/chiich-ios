//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Async Algorithms open source project
//
// Copyright (c) 2022 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
//===----------------------------------------------------------------------===//

#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#elseif canImport(Musl)
import Musl
#elseif canImport(WinSDK)
import WinSDK
#elseif canImport(Bionic)
import Bionic
#elseif canImport(wasi_pthread)
import wasi_pthread
#elseif canImport(WASILibc)
// Here, we can not import wasi_pthread, but we can import WASILibc. So
// this is a variation of WASILibc without pthread support. As such, the
// platform does not have locks or mechanisms to become multi-threaded,
// so no locks are needed.
#else
#error("Unsupported platform")
#endif

internal struct Lock {
  #if canImport(Darwin)
  typealias Primitive = os_unfair_lock
  #elseif canImport(Glibc) || canImport(Musl) || canImport(Bionic) || canImport(wasi_pthread)
  #if os(FreeBSD) || os(OpenBSD)
  typealias Primitive = pthread_mutex_t?
  #else
  typealias Primitive = pthread_mutex_t
  #endif
  #elseif canImport(WASILibc)
  // This WASILibc variation is single threaded, provides no locks
  #elseif canImport(WinSDK)
  typealias Primitive = SRWLOCK
  #else
  #error("Unsupported platform")
  #endif

  typealias PlatformLock = UnsafeMutablePointer<Primitive>
  let platformLock: PlatformLock

  private init(_ platformLock: PlatformLock) {
    self.platformLock = platformLock
  }

  fileprivate static func initialize(_ platformLock: PlatformLock) {
    #if canImport(Darwin)
    platformLock.initialize(to: os_unfair_lock())
    #elseif canImport(Glibc) || canImport(Musl) || canImport(Bionic) || canImport(wasi_pthread)
    let result = pthread_mutex_init(platformLock, nil)
    precondition(result == 0, "pthread_mutex_init failed")
    #elseif canImport(WASILibc)
    // Here, we can not import wasi_pthread, but we can import WASILibc. So
    // this is a variation of WASILibc without pthread support. As such, the
    // platform does not have locks or mechanisms to become multi-threaded,
    // so no locks are needed.
    #elseif canImport(WinSDK)
    InitializeSRWLock(platformLock)
    #else
    #error("Unsupported platform")
    #endif
  }

  fileprivate static func deinitialize(_ platformLock: PlatformLock) {
    #if canImport(Glibc) || canImport(Musl) || canImport(Bionic) || canImport(wasi_pthread)
    let result = pthread_mutex_destroy(platformLock)
    precondition(result == 0, "pthread_mutex_destroy failed")
    #endif
    platformLock.deinitialize(count: 1)
  }

  fileprivate static func lock(_ platformLock: PlatformLock) {
    #if canImport(Darwin)
    os_unfair_lock_lock(platformLock)
    #elseif canImport(Glibc) || canImport(Musl) || canImport(Bionic) || canImport(wasi_pthread)
    pthread_mutex_lock(platformLock)
    #elseif canImport(WASILibc)
    // Here, we can not import wasi_pthread, but we can import WASILibc. So
    // this is a variation of WASILibc without pthread support. As such, the
    // platform does not have locks or mechanisms to become multi-threaded,
    // so no locks are needed.
    return
    #elseif canImport(WinSDK)
    AcquireSRWLockExclusive(platformLock)
    #else
    #error("Unsupported platform")
    #endif
  }

  fileprivate static func unlock(_ platformLock: PlatformLock) {
    #if canImport(Darwin)
    os_unfair_lock_unlock(platformLock)
    #elseif canImport(Glibc) || canImport(Musl) || canImport(Bionic) || canImport(wasi_pthread)
    let result = pthread_mutex_unlock(platformLock)
    precondition(result == 0, "pthread_mutex_unlock failed")
    #elseif canImport(WASILibc)
    // Here, we can not import wasi_pthread, but we can import WASILibc. So
    // this is a variation of WASILibc without pthread support. As such, the
    // platform does not have locks or mechanisms to become multi-threaded,
    // so no locks are needed.
    return
    #elseif canImport(WinSDK)
    ReleaseSRWLockExclusive(platformLock)
    #else
    #error("Unsupported platform")
    #endif
  }

  static func allocate() -> Lock {
    let platformLock = PlatformLock.allocate(capacity: 1)
    initialize(platformLock)
    return Lock(platformLock)
  }

  func deinitialize() {
    Lock.deinitialize(platformLock)
    platformLock.deallocate()
  }

  func lock() {
    Lock.lock(platformLock)
  }

  func unlock() {
    Lock.unlock(platformLock)
  }

  /// Acquire the lock for the duration of the given block.
  ///
  /// This convenience method should be preferred to `lock` and `unlock` in
  /// most situations, as it ensures that the lock will be released regardless
  /// of how `body` exits.
  ///
  /// - Parameter body: The block to execute while holding the lock.
  /// - Returns: The value returned by the block.
  func withLock<T>(_ body: () throws -> T) rethrows -> T {
    self.lock()
    defer {
      self.unlock()
    }
    return try body()
  }

  // specialise Void return (for performance)
  func withLockVoid(_ body: () throws -> Void) rethrows {
    try self.withLock(body)
  }
}

struct ManagedCriticalState<State> {
  private final class LockedBuffer: ManagedBuffer<State, Lock.Primitive> {
    deinit {
      withUnsafeMutablePointerToElements { Lock.deinitialize($0) }
    }
  }

  private let buffer: ManagedBuffer<State, Lock.Primitive>

  init(_ initial: State) {
    buffer = LockedBuffer.create(minimumCapacity: 1) { buffer in
      buffer.withUnsafeMutablePointerToElements { Lock.initialize($0) }
      return initial
    }
  }

  func withCriticalRegion<R>(_ critical: (inout State) throws -> R) rethrows -> R {
    try buffer.withUnsafeMutablePointers { header, lock in
      Lock.lock(lock)
      defer { Lock.unlock(lock) }
      return try critical(&header.pointee)
    }
  }

  func withLock<R>(_ critical: (inout State) throws -> R) rethrows -> R {
    return try withCriticalRegion(critical)
  }
}

extension ManagedCriticalState: @unchecked Sendable where State: Sendable {}
