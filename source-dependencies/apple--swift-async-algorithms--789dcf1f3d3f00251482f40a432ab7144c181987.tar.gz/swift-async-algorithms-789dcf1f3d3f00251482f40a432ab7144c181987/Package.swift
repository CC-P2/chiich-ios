// swift-tools-version: 6.2

import PackageDescription
import CompilerPluginSupport

let AsyncAlgorithms_v1_0 = "AvailabilityMacro=AsyncAlgorithms 1.0:macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0"
#if compiler(>=6.0) && swift(>=6.0)  // 5.10 doesnt support visionOS availability
let AsyncAlgorithms_v1_1 =
  "AvailabilityMacro=AsyncAlgorithms 1.1:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, visionOS 2.0"
let AsyncAlgorithms_v1_2 =
  "AvailabilityMacro=AsyncAlgorithms 1.2:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, visionOS 2.0"
let AsyncAlgorithms_v1_3 =
  "AvailabilityMacro=AsyncAlgorithms 1.3:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, visionOS 2.0"
#else
let AsyncAlgorithms_v1_1 = "AvailabilityMacro=AsyncAlgorithms 1.1:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0"
let AsyncAlgorithms_v1_2 = "AvailabilityMacro=AsyncAlgorithms 1.2:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0"
let AsyncAlgorithms_v1_3 = "AvailabilityMacro=AsyncAlgorithms 1.2:macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0"
#endif

let availabilityMacros: [SwiftSetting] = [
  .enableExperimentalFeature(
    AsyncAlgorithms_v1_0
  ),
  .enableExperimentalFeature(
    AsyncAlgorithms_v1_1
  ),
  .enableExperimentalFeature(
    AsyncAlgorithms_v1_2
  ),
  .enableExperimentalFeature(
    AsyncAlgorithms_v1_3
  ),
]

let package = Package(
  name: "swift-async-algorithms",
  products: [
    .library(name: "AsyncAlgorithms", targets: ["AsyncAlgorithms"]),
    .library(name: "AsyncStreaming", targets: ["AsyncStreaming"]),
  ],
  traits: [
    .default(
      enabledTraits: [
        //        "UnstableAsyncStreaming"
      ]
    ),
    .trait(
      name: "UnstableAsyncStreaming",
      description: """
        Enables source unstable async streaming components in the _AsyncStreaming
        module. Do not rely on this module in API stable packages.
        """
    ),
  ],
  targets: [
    .target(
      name: "AsyncAlgorithms",
      dependencies: [
        .product(name: "OrderedCollections", package: "swift-collections"),
        .product(name: "DequeModule", package: "swift-collections"),
      ],
      swiftSettings: availabilityMacros + [
        .enableExperimentalFeature("StrictConcurrency=complete")
      ]
    ),
    .target(
      name: "AsyncStreaming",
      dependencies: [
        .product(name: "BasicContainers", package: "swift-collections"),
        .product(name: "ContainersPreview", package: "swift-collections"),
        .product(name: "DequeModule", package: "swift-collections"),
      ],
      exclude: ["NNNN-async-streaming.md"],
      swiftSettings: [
        .enableExperimentalFeature("SuppressedAssociatedTypesWithDefaults"),
        .enableExperimentalFeature("LifetimeDependence"),
        .enableExperimentalFeature("Lifetimes"),
        .enableUpcomingFeature("LifetimeDependence"),
        .enableUpcomingFeature("NonisolatedNonsendingByDefault"),
        .enableUpcomingFeature("InferIsolatedConformances"),
        .enableUpcomingFeature("ExistentialAny"),
        .enableUpcomingFeature("MemberImportVisibility"),
        .enableUpcomingFeature("InternalImportsByDefault"),
      ]
    ),
    .target(
      name: "AsyncSequenceValidation",
      dependencies: ["_CAsyncSequenceValidationSupport", "AsyncAlgorithms"],
      swiftSettings: availabilityMacros + [
        .enableExperimentalFeature("StrictConcurrency=complete")
      ]
    ),
    .systemLibrary(name: "_CAsyncSequenceValidationSupport"),
    .target(
      name: "AsyncAlgorithms_XCTest",
      dependencies: ["AsyncAlgorithms", "AsyncSequenceValidation"],
      swiftSettings: availabilityMacros + [
        .enableExperimentalFeature("StrictConcurrency=complete")
      ]
    ),
    .testTarget(
      name: "AsyncAlgorithmsTests",
      dependencies: [
        .target(name: "AsyncAlgorithms"),
        .target(
          name: "AsyncSequenceValidation",
          condition: .when(platforms: [
            .macOS,
            .iOS,
            .tvOS,
            .watchOS,
            .visionOS,
            .macCatalyst,
            .android,
            .linux,
            .custom("freebsd"),
            .openbsd,
            .wasi,
          ])
        ),
        .target(
          name: "AsyncAlgorithms_XCTest",
          condition: .when(platforms: [
            .macOS,
            .iOS,
            .tvOS,
            .watchOS,
            .visionOS,
            .macCatalyst,
            .android,
            .linux,
            .custom("freebsd"),
            .openbsd,
            .wasi,
          ])
        ),
      ],
      swiftSettings: availabilityMacros + [
        .enableExperimentalFeature("StrictConcurrency=complete")
      ]
    ),
    .testTarget(
      name: "AsyncStreamingTests",
      dependencies: [
        "AsyncStreaming",
        .product(name: "BasicContainers", package: "swift-collections"),
        .product(name: "ContainersPreview", package: "swift-collections"),
        .product(name: "SpanPreview", package: "swift-collections"),
      ],
      swiftSettings: [
        .enableExperimentalFeature("SuppressedAssociatedTypesWithDefaults"),
        .enableExperimentalFeature("LifetimeDependence"),
        .enableExperimentalFeature("Lifetimes"),
        .enableUpcomingFeature("LifetimeDependence"),
        .enableUpcomingFeature("NonisolatedNonsendingByDefault"),
        .enableUpcomingFeature("InferIsolatedConformances"),
        .enableUpcomingFeature("ExistentialAny"),
        .enableUpcomingFeature("MemberImportVisibility"),
        .enableUpcomingFeature("InternalImportsByDefault"),
      ]
    ),
  ]
)

if Context.environment["SWIFTCI_USE_LOCAL_DEPS"] == nil {
  package.dependencies += [
    .package(
      url: "https://github.com/apple/swift-collections.git",
      from: "1.7.0",
      traits: [.trait(name: "UnstableContainersPreview", condition: .when(traits: ["UnstableAsyncStreaming"]))]
    )
  ]
} else {
  package.dependencies += [
    .package(path: "../swift-collections")
  ]
}
