//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation
import MatrixRtc
import Observation

/// Our participation in a room's call: membership in, media attached separately.
///
/// You are in the call as soon as ``MatrixRTCRoom/joinCall(kind:)`` returned; media is attached with
/// ``connectMedia()``. Teardown order matters: disconnect media → leave → shut the room down.
@MainActor
@Observable
public final class MatrixRTCCall {
    public let roomID: String
    public let slotID: String
    /// Minted by the core at join time; what every event, roster entry and key report is keyed by.
    public let localMemberID: String
    
    /// Who is in the call, from the core's membership projection, ourselves included.
    public private(set) var members: [MatrixRTCMembership] = []
    public var memberCount: Int {
        members.count
    }
    
    /// Where the call is, as the core sees it. In a DM it is also how the call ends without us: the
    /// core leaves by itself on a decline, a ring nobody answered or the other side hanging up.
    public private(set) var status: MatrixRTCCallStatus
    /// Every change of ``status``, starting after the value it had at the join.
    public let statusUpdates: AsyncStream<MatrixRTCCallStatus>
    @ObservationIgnored private let statusContinuation: AsyncStream<MatrixRTCCallStatus>.Continuation
    
    public private(set) var mediaSession: MatrixRTCMediaSession?
    
    /// The protocol rather than the class so a test can stand in for the membership; only
    /// ``connectMedia()`` needs the core's own call, and says so.
    @ObservationIgnored private let rtcCall: any RtcCallProtocol
    @ObservationIgnored private var hasLeft = false
    @ObservationIgnored private var membershipReader: Task<Void, Never>?
    @ObservationIgnored private var statusReader: Task<Void, Never>?
    
    /// The call's engine and sounds, from the join: the ringback plays before there is media.
    @ObservationIgnored let audio: CallAudio
    @ObservationIgnored private let clock: any Clock<Duration>
    /// Time on ``clock`` since the join.
    @ObservationIgnored private let elapsed: () -> Duration
    /// When the end sound finishes, on ``elapsed``; the audio is released no earlier (030 R25).
    @ObservationIgnored private var endSoundEnds: Duration?
    
    init(rtcCall: any RtcCallProtocol, audio: CallAudio = CallAudio(), clock: any Clock<Duration> = ContinuousClock()) {
        self.rtcCall = rtcCall
        self.audio = audio
        self.clock = clock
        elapsed = stopwatch(clock)
        roomID = rtcCall.roomId()
        slotID = rtcCall.slotId()
        localMemberID = rtcCall.memberId()
        status = MatrixRTCCallStatus(rtcCall.status())
        (statusUpdates, statusContinuation) = AsyncStream.makeStream(bufferingPolicy: .unbounded)
        playSounds(for: status)
    }
    
    /// Reads the roster until the room is shut down. Each `next()` waits for a change, the first
    /// answering the current roster; nil means the room has gone, and only then does reading stop.
    func start() {
        let rtcCall = rtcCall
        membershipReader = Task { [weak self] in
            let subscription = await rtcCall.subscribeMembershipSnapshots()
            while let snapshot = await subscription.next() {
                guard !Task.isCancelled else { return }
                self?.updateMembers(snapshot.map(MatrixRTCMembership.init))
            }
        }
        // The subscription answers the current status first, which `init` already read.
        statusReader = Task { [weak self] in
            let subscription = rtcCall.subscribeStatus()
            while let status = await subscription.next() {
                guard !Task.isCancelled else { return }
                self?.updateStatus(MatrixRTCCallStatus(status))
            }
            self?.statusContinuation.finish()
        }
    }
    
    func stop() {
        membershipReader?.cancel()
        membershipReader = nil
        statusReader?.cancel()
        statusReader = nil
        statusContinuation.finish()
    }
    
    /// Attaches media. The core takes the transport from the join and the account from the backend,
    /// so there is nothing to pass.
    public func connectMedia() async throws -> MatrixRTCMediaSession {
        if let mediaSession {
            return mediaSession
        }
        guard let rtcCall = rtcCall as? RtcCall else {
            throw MatrixRTCError.media("\(roomID)/\(slotID) is not a core call and has no media")
        }
        let ffiSession: MediaSession
        do {
            ffiSession = try await connectMediaSession(call: rtcCall, config: MediaSessionConfig())
        } catch {
            MatrixRTCLog.warning("Failed to connect media for \(roomID)/\(slotID): \(error)")
            throw MatrixRTCError.media("\(error)")
        }
        
        let mediaSession = MatrixRTCMediaSession(localMemberID: localMemberID, mediaSession: ffiSession, audio: audio)
        self.mediaSession = mediaSession
        await mediaSession.start()
        MatrixRTCLog.info("Media connected for \(roomID)/\(slotID) as \(localMemberID)")
        return mediaSession
    }
    
    /// Idempotent: hanging up and tearing the screen down both leave, and the core refuses a second
    /// attempt.
    public func leave(reason: MatrixRTCLeaveReason? = nil) async {
        guard !hasLeft else {
            MatrixRTCLog.debug("Already left \(roomID)/\(slotID)")
            return
        }
        hasLeft = true
        
        await mediaSession?.disconnect()
        mediaSession = nil
        do {
            let leaveReason = reason.map { FfiLeaveReason(code: $0.code, reason: $0.reason) }
            try await rtcCall.leave(params: FfiLeaveSessionParams(leaveReason: leaveReason))
            MatrixRTCLog.info("Left \(roomID)/\(slotID)")
        } catch {
            MatrixRTCLog.warning("Failed to leave \(roomID)/\(slotID): \(error)")
        }
    }
    
    // MARK: - Audio
    
    /// Once the system has activated the audio session (CallKit's `didActivate`, or directly where
    /// nothing else owns it). Returns before the engine is running: starting it reconfigures the
    /// graph, which must not happen synchronously on this thread.
    public func startAudio() {
        audio.start()
    }
    
    /// CallKit's `didDeactivate`.
    public func stopAudio() {
        audio.stop()
    }
    
    /// After the call has ended: lets a decline's or a timeout's sound play to its end, then shuts the
    /// call's audio down (030 R25). Nothing to wait for after a hang-up, which has no sound.
    public func releaseAudio() async {
        if let endSoundEnds {
            let remaining = endSoundEnds - elapsed()
            if remaining > .zero {
                try? await clock.sleep(for: remaining)
            }
        }
        audio.shutdown()
        MatrixRTCLog.info("Audio released for \(roomID)/\(slotID)")
    }
    
    private func playSounds(for status: MatrixRTCCallStatus) {
        audio.setRingback(RingingSoundPolicy.playsRingback(status))
        if let sound = RingingSoundPolicy.endSound(status) {
            audio.play(sound)
            endSoundEnds = audio.duration(of: sound).map { elapsed() + $0 }
        }
    }
    
    // MARK: - Raised hand
    
    /// Returns once the homeserver has the annotation, and the core has recorded our hand as up. The
    /// tiles carry it a moment later, through the same raised-hand set as everyone else's, which is
    /// what the control shows: never this call's success, which is not yet what others see.
    ///
    /// A no-op while the hand is up. The core keeps it on our membership across sticky refreshes,
    /// so nothing here re-raises it.
    public func raiseHand() async throws {
        do {
            try await rtcCall.raiseHand()
            MatrixRTCLog.info("Hand raised in \(roomID)/\(slotID)")
        } catch {
            MatrixRTCLog.warning("Failed to raise hand in \(roomID)/\(slotID): \(error)")
            throw MatrixRTCError.ffi("\(error)")
        }
    }
    
    /// Redacts the annotation. A no-op while the hand is down.
    public func lowerHand() async throws {
        do {
            try await rtcCall.lowerHand()
            MatrixRTCLog.info("Hand lowered in \(roomID)/\(slotID)")
        } catch {
            MatrixRTCLog.warning("Failed to lower hand in \(roomID)/\(slotID): \(error)")
            throw MatrixRTCError.ffi("\(error)")
        }
    }
    
    private func updateStatus(_ status: MatrixRTCCallStatus) {
        guard status != self.status else { return }
        MatrixRTCLog.info("\(roomID)/\(slotID) is \(status)")
        self.status = status
        playSounds(for: status)
        statusContinuation.yield(status)
    }
    
    private func updateMembers(_ members: [MatrixRTCMembership]) {
        if members.map(\.memberID) != self.members.map(\.memberID) {
            MatrixRTCLog.info("\(members.count) member(s) in \(roomID)/\(slotID): \(members.map(\.memberID))")
        }
        self.members = members
    }
}
