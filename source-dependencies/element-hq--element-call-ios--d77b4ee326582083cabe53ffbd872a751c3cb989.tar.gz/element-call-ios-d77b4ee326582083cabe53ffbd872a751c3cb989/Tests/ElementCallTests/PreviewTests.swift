//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Combine
import ElementCallHost
@testable import ElementCallUI

// The library does not expose `verifySnapshot`, `SimplySnapshotting`, `Diffing` or `snapshotView`
// publicly, and the harness below needs all four to apply per-preview precision. Adapted from
// Compound's harness, which does the same.
@testable import SnapshotTesting
import SwiftUI
import Testing

struct PreviewTests {
    private struct SnapshotDevice {
        let name: String
        let device: String
        let isLandscape: Bool
    }
    
    private let deviceConfig: ViewImageConfig = .iPhoneX
    private let simulatorDevice: String? = SnapshotEnvironment.simulatorModelIdentifier
    private let requiredOSVersion = SnapshotEnvironment.requiredOSVersion
    /// The name is what lands in the file name; the device selects a size and safe area.
    private let snapshotDevices: [SnapshotDevice] = SnapshotEnvironment.renderDevices.map {
        .init(name: $0.name, device: $0.device, isLandscape: $0.isLandscape)
    }
    
    private var recordMode: SnapshotTestingConfiguration.Record = .missing
    
    /// Recording is asked for with a file, not an environment variable.
    ///
    /// The harness used to read `RECORD_FAILURES` from its environment, and `record-snapshots.yml`
    /// duly set it on the xcodebuild command line, where it reached nothing: not as a build setting,
    /// not behind the `TEST_RUNNER_` prefix, not from the calling shell. It arrives when it is set in
    /// a scheme, which is why it works from inside Xcode, and does nothing at all from a terminal.
    /// So the job re-recorded new images only and reported "No snapshot changes detected" for every
    /// changed one it was asked to record.
    ///
    /// A file beside this one always arrives, because `#filePath` is the checkout the tests were
    /// built from. `RECORD_FAILURES` still works for anyone running from Xcode.
    static let recordMarkerURL = URL(fileURLWithPath: #filePath)
        .deletingLastPathComponent()
        .appendingPathComponent(".record-snapshots")
    
    init() {
        if ProcessInfo().environment["RECORD_FAILURES"].map(Bool.init) == true
            || FileManager.default.fileExists(atPath: Self.recordMarkerURL.path) {
            recordMode = .failed
        }
        
        checkEnvironments()
        UIView.setAnimationsEnabled(false)
    }
    
    /// Check environments to avoid problems with snapshots on different devices or OS.
    private func checkEnvironments() {
        if let simulatorDevice {
            let deviceModel = ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"]
            guard deviceModel?.contains(simulatorDevice) ?? false else {
                fatalError("\(deviceModel ?? "Unknown") is the wrong simulator. Create and use \(SnapshotEnvironment.simulatorName) for these tests.")
            }
        }
        
        let osVersion = ProcessInfo().operatingSystemVersion
        guard osVersion.majorVersion == requiredOSVersion.major, osVersion.minorVersion == requiredOSVersion.minor else {
            fatalError("Switch to iOS \(requiredOSVersion) for these tests.")
        }
        guard !snapshotDevices.isEmpty else {
            fatalError("Specify at least one snapshot device to test on.")
        }
        
        // The locale lands in every snapshot file name, so an unpinned one makes the images
        // machine-specific and 42 of them fail at once without saying why. element-x-ios pins this in
        // a test plan; a package has no test plan, so it comes from the command line.
        let language = Locale.current.language.languageCode?.identifier
        let region = Locale.current.language.region?.identifier
        guard language == SnapshotEnvironment.requiredLanguage, region == SnapshotEnvironment.requiredRegion else {
            fatalError("""
            Snapshots are recorded in \(SnapshotEnvironment.requiredLanguage)-\(SnapshotEnvironment.requiredRegion), \
            but this run is \(language ?? "??")-\(region ?? "??"). Add the following to the xcodebuild command:
              -testLanguage \(SnapshotEnvironment.requiredLanguage) -testRegion \(SnapshotEnvironment.requiredRegion)
            """)
        }
    }
    
    // MARK: - Snapshots
    
    func assertSnapshots(matching preview: _Preview, testName: String = #function, step: Int) async throws {
        let preferences = SnapshotPreferences()
        
        let preferenceReadingView = preview.content
            .onPreferenceChange(SnapshotPrecisionPreferenceKey.self) { preferences.precision = $0 }
            .onPreferenceChange(SnapshotPerceptualPrecisionPreferenceKey.self) { preferences.perceptualPrecision = $0 }
        
        // Render an image of the view in order to trigger the preference updates to occur.
        let imageRenderer = ImageRenderer(content: preferenceReadingView)
        _ = imageRenderer.uiImage
        
        let sanitizedSuiteName = String(testName.dropLast(2))
        
        for snapshotDevice in snapshotDevices {
            guard var device = PreviewDevice(rawValue: snapshotDevice.device).snapshotDevice(isLandscape: snapshotDevice.isLandscape) else {
                fatalError("Unknown device name: \(snapshotDevice.device)")
            }
            // Ignore specific device safe area (using the workaround value to fix rendering issues).
            device.safeArea = .one
            // Ignore specific device display scale
            let traits = UITraitCollection(displayScale: 2.0)
            
            var testName = ""
            if let displayName = preview.displayName {
                testName = "\(displayName)-\(snapshotDevice.name)-\(localeCode)"
            } else {
                testName = "\(snapshotDevice.name)-\(localeCode)-\(step)"
            }
            
            let isScreen = switch preview.layout {
            case .device: true
            default: false
            }
            if let failure = assertSnapshots(matching: preview.content,
                                             name: testName,
                                             isScreen: isScreen,
                                             device: device,
                                             testName: sanitizedSuiteName,
                                             traits: traits,
                                             preferences: preferences) {
                Issue.record(Comment(rawValue: failure))
            }
        }
    }
    
    private var localeCode: String {
        if UserDefaults.standard.bool(forKey: "NSDoubleLocalizedStrings") {
            return "pseudo"
        }
        return languageCode + "-" + regionCode
    }
    
    private var languageCode: String {
        Locale.current.language.languageCode?.identifier ?? ""
    }
    
    private var regionCode: String {
        Locale.current.language.region?.identifier ?? ""
    }
    
    private func assertSnapshots(matching view: AnyView,
                                 name: String?,
                                 isScreen: Bool,
                                 device: ViewImageConfig,
                                 testName: String = #function,
                                 traits: UITraitCollection = .init(),
                                 preferences: SnapshotPreferences) -> String? {
        // The flat fallback rather than glass, and still sound waves rather than a frame of ripples:
        // see `elementCallGlassEnabled` and `elementCallSoundWavesRipple`.
        let view = AnyView(view
            .environment(\.elementCallGlassEnabled, false)
            .environment(\.elementCallSoundWavesRipple, false))
        let matchingView = isScreen ? AnyView(view) : AnyView(view
            .frame(width: device.size?.width)
            .fixedSize(horizontal: false, vertical: true))
        
        return withSnapshotTesting(record: recordMode) {
            verifySnapshot(of: matchingView,
                           as: .prefireImage(preferences: preferences,
                                             layout: isScreen ? .device(config: device) : .sizeThatFits,
                                             traits: traits),
                           named: name,
                           testName: testName)
        }
    }
}

private class SnapshotPreferences: @unchecked Sendable {
    var precision: Float = 1
    var perceptualPrecision: Float = 1
    var fulfillmentPublisher: AnyPublisher<Bool, Never>?
}

// MARK: - SnapshotTesting + Extensions

private extension PreviewDevice {
    /// The orientation is passed rather than baked in because every one of these has a landscape
    /// counterpart in the library; the harness simply never asked for one, so nothing was rendered
    /// on its side and the layout that only breaks on its side went unnoticed.
    func snapshotDevice(isLandscape: Bool = false) -> ViewImageConfig? {
        let orientation: ViewImageConfig.Orientation = isLandscape ? .landscape : .portrait
        switch rawValue {
        case "iPhone 17", "iPhone 16", "iPhone 15", "iPhone 14", "iPhone 13", "iPhone 12", "iPhone 11", "iPhone 10":
            return .iPhoneX(orientation)
        case "iPhone 6", "iPhone 6s", "iPhone 7", "iPhone 8":
            return .iPhone8(orientation)
        case "iPhone 6 Plus", "iPhone 6s Plus", "iPhone 8 Plus":
            return .iPhone8Plus(orientation)
        case "iPhone SE (1st generation)", "iPhone SE (2nd generation)":
            return .iPhoneSe(orientation)
        case "iPad":
            return .iPad10_2(orientation)
        case "iPad Mini":
            return .iPadMini(orientation)
        case "iPad Pro 11":
            return .iPadPro11(orientation)
        case "iPad Pro 12.9":
            return .iPadPro12_9(orientation)
        default: return nil
        }
    }
}

private extension Snapshotting where Value: SwiftUI.View, Format == UIImage {
    @MainActor
    static func prefireImage(drawHierarchyInKeyWindow: Bool = false,
                             preferences: SnapshotPreferences,
                             layout: SwiftUISnapshotLayout = .sizeThatFits,
                             traits: UITraitCollection = .init()) -> Snapshotting {
        let config: ViewImageConfig
        
        switch layout {
        #if os(iOS) || os(tvOS)
        case let .device(config: deviceConfig):
            config = deviceConfig
        #endif
        case .sizeThatFits:
            // Make sure to use the workaround safe area insets.
            config = .init(safeArea: .one, size: nil, traits: traits)
        case let .fixed(width: width, height: height):
            let size = CGSize(width: width, height: height)
            // Make sure to use the workaround safe area insets.
            config = .init(safeArea: .one, size: size, traits: traits)
        }
        
        return SimplySnapshotting<UIImage>(pathExtension: "png", diffing: .prefireImage(preferences: preferences, scale: traits.displayScale))
            .asyncPullback { @MainActor view in
                var config = config
                
                let controller: UIViewController
                
                if config.size != nil {
                    controller = UIHostingController(rootView: view)
                } else {
                    let hostingController = UIHostingController(rootView: view)
                    
                    let maxSize = CGSize.zero
                    config.size = hostingController.sizeThatFits(in: maxSize)
                    
                    controller = hostingController
                }
                
                return snapshotView(config: config,
                                    drawHierarchyInKeyWindow: drawHierarchyInKeyWindow,
                                    traits: traits,
                                    view: controller.view,
                                    viewController: controller)
            }
    }
}

private extension Diffing where Value == UIImage {
    static func prefireImage(preferences: SnapshotPreferences, scale: CGFloat?) -> Diffing {
        lazy var originalDiffing = Diffing.image(precision: preferences.precision, perceptualPrecision: preferences.perceptualPrecision, scale: scale)
        return Diffing(toData: { originalDiffing.toData($0) },
                       fromData: { originalDiffing.fromData($0) },
                       diff: { originalDiffing.diff($0, $1) })
    }
}

private extension UIEdgeInsets {
    /// A custom inset that prevents the snapshotting library from rendering the
    /// origin at (10000, 10000) which breaks some of our views such as MessageText.
    static var one: UIEdgeInsets {
        UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    }
}
