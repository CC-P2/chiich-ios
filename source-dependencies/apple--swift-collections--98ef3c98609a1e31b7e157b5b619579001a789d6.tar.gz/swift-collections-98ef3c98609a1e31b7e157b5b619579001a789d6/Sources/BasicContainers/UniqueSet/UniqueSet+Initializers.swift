//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if compiler(>=6.4) && UnstableHashedContainers

@available(SwiftStdlib 5.0, *)
extension UniqueSet where Element: ~Copyable {
  @inlinable
  public init() {
    self.init(_storage: .init())
  }
  
  @inlinable
  public init(minimumCapacity: Int) {
    precondition(minimumCapacity >= 0, "Capacity must be nonnegative")
    let table = _HTable(minimumCapacity: minimumCapacity)
    self.init(_storage: RigidSet(_table: table))
  }
  
  @inlinable
  public init(consuming set: consuming RigidSet<Element>) {
    self.init(_storage: set)
  }
}

@available(SwiftStdlib 5.0, *)
extension UniqueSet where Element: ~Copyable {
  @_alwaysEmitIntoClient
  public init<E: Error>(
    minimumCapacity: Int,
    initializingWith initializer: (inout OutputSpan<Element>) throws(E) -> Void
  ) throws(E) {
    self.init(minimumCapacity: minimumCapacity)
    try self.insert(
      addingCount: minimumCapacity,
      initializingWith: initializer)
  }
}

@available(SwiftStdlib 5.0, *)
extension UniqueSet where Element: Copyable {
  @available(SwiftStdlib 6.4, *)
  @_alwaysEmitIntoClient
  public init<S: Iterable & ~Copyable & ~Escapable>(
    copying items: borrowing S
  ) throws(S.Failure)
  where S.Element == Element {
    self.init()
    try self.insert(copying: items)
  }

  @_alwaysEmitIntoClient
  public init(copying items: some Sequence<Element>) {
    self.init()
    self.insert(copying: items)
  }
  
  @available(SwiftStdlib 6.4, *)
  @_alwaysEmitIntoClient
  public init<S: Iterable & Sequence<Element>>(
    copying items: borrowing S
  ) throws(S.Failure)
  where S.Element == Element {
    self.init()
    try self._insert(copying: items)
  }
}

#endif
