//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import InternalCollectionsUtilities
#endif

#if compiler(>=6.4) && UnstableHashedContainers

@available(SwiftStdlib 5.0, *)
extension RigidSet where Element: ~Copyable {
  @inlinable
  public func isTriviallyIdentical(to other: borrowing Self) -> Bool {
    self._members == other._members
    && self._table.isTriviallyIdentical(to: other._table)
  }
}

@available(SwiftStdlib 6.4, *)
extension RigidSet: Equatable where Element: ~Copyable {}

@available(SwiftStdlib 5.0, *)
extension RigidSet where Element: ~Copyable {
  @inlinable
  public static func ==(left: borrowing Self, right: borrowing Self) -> Bool {
    if left.isTriviallyIdentical(to: right) { return true }
    
    guard left.count == right.count else { return false }

    var lit = left.makeBorrowingIterator()
    while true {
      let l = lit.nextSpan(maxCount: .max)
      if l.isEmpty { break }
      var i = 0
      while i < l.count {
        guard right.contains(l[i]) else { return false }
        i &+= 1
      }
    }
    return true
  }
}
#endif
