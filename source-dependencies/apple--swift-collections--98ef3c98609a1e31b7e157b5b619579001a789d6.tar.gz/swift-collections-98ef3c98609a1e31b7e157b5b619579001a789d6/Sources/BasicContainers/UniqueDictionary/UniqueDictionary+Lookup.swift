//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if compiler(>=6.4) && UnstableHashedContainers

@available(SwiftStdlib 5.0, *)
extension UniqueDictionary where Key: ~Copyable, Value: ~Copyable {
  /// Checks if the given key is present in the `UniqueDictionary`.
  ///
  /// - Parameter key: The key to find in the dictionary.
  @inlinable
  public func containsKey(_ key: borrowing Key) -> Bool {
    _storage.containsKey(key)
  }

  /// Checks if the given key is present in the `RigidDictionary`, and returns
  /// a reference to the value associated with it.
  ///
  /// - Parameter key: The key to find in the dictionary.
  /// - Returns: A reference to the value associated with the given `key`, or
  ///            nil if the `key` is not found.
  @available(SwiftStdlib 6.4, *)
  @inlinable
  @_lifetime(borrow self)
  public func value(
    forKey key: borrowing Key
  ) -> Ref<Value>? {
    // FIXME: Why is this override necessary? Is it sound? It was triggered by RigidDictionary becoming `@_addressableForDependencies`.
    _overrideLifetime(_storage.value(forKey: key), borrowing: self)
  }

  /// Checks if the given key is present in the `RigidDictionary`, and returns
  /// a mutable reference to the value associated with it.
  ///
  /// - Parameter key: The key to find in the dictionary.
  /// - Returns: A mutable reference to the value associated with the given
  ///            `key`, or nil if the `key` is not found.
  @available(SwiftStdlib 6.4, *)
  @inlinable
  @_lifetime(&self)
  public mutating func mutableValue(
    forKey key: borrowing Key
  ) -> MutableRef<Value>? {
    _storage.mutableValue(forKey: key)
  }

  /// A stand-in for a `struct Ref`-returning lookup operation.
  /// This is quite clumsy to use, but this is the best we can do without a way
  /// to express optional borrows.
  @_alwaysEmitIntoClient
  @_transparent
  public func withValue<E: Error, R: ~Copyable>(
    forKey key: borrowing Key,
    _ body: (borrowing Value) throws(E) -> R?
  ) throws(E) -> R? {
    try _storage.withValue(forKey: key, body)
  }
}

#endif
