//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if compiler(>=6.4) && UnstableHashedContainers

@available(SwiftStdlib 5.0, *)
extension UniqueDictionary where Key: ~Copyable, Value: ~Copyable {
  @_alwaysEmitIntoClient
  public var keys: RigidSet<Key> {
    borrow {
      _storage.keys
    }
  }

  // FIXME: Remove
  @available(*, deprecated, renamed: "keys")
  @_alwaysEmitIntoClient
  public func withKeys<E: Error, R: ~Copyable>(
  _ body: (borrowing RigidSet<Key>) throws(E) -> R
  ) throws(E) -> R {
    try _storage.withKeys(body)
  }
}

#endif
