//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2024 - 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import InternalCollectionsUtilities
#endif

#if UnstableContainersPreview

#if false // FIXME
@available(SwiftStdlib 5.0, *)
extension RigidArray where Element: ~Copyable {
  @inlinable
  public mutating func reallocate<E: Error, R: ~Copyable>(
    capacity: Int,
    with body: (
      inout InputSpan<Element>,
      inout OutputSpan<Element>
    ) throws(E) -> R
  ) throws(E) -> R {
    var source = InputSpan(buffer: _storage, initializedCount: _count)
    let newStorage: UnsafeMutableBufferPointer<Element> = .allocate(
      capacity: capacity)
    var target = OutputSpan(buffer: newStorage, initializedCount: 0)
    defer {
      _ = consume source
      _storage.deallocate()
      _count = target.finalize(for: newStorage)
      _storage = newStorage
      source = .init()
      target = .init()
    }
    return try body(&source, &target)
  }
}
#endif

#if false // FIXME
@available(SwiftStdlib 5.0, *)
extension RigidArray where Element: ~Copyable {
  /// Removes all the elements that satisfy the given predicate.
  ///
  /// Use this method to remove every element in a container that meets
  /// particular criteria. The order of the remaining elements is preserved.
  ///
  /// - Parameter shouldBeRemoved: A closure that takes an element of the
  ///   sequence as its argument and returns a Boolean value indicating
  ///   whether the element should be removed from the array.
  ///
  /// - Complexity: O(`count`)
  @_alwaysEmitIntoClient
  public mutating func removeAll<E: Error>(
    where shouldBeRemoved: (borrowing Element) throws(E) -> Bool
  ) throws(E) {
    // FIXME: Remove this in favor of a standard algorithm.
    let suffixStart = try _halfStablePartition(isSuffixElement: shouldBeRemoved)
    removeSubrange(suffixStart...)
  }
}
#endif

#endif
