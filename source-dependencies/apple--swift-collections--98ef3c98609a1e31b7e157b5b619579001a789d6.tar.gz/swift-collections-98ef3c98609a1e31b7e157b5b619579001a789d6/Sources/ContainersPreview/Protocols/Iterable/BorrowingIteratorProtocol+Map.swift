//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if compiler(>=6.4) && UnstableContainersPreview

@available(SwiftStdlib 6.4, *)
extension BorrowingIteratorProtocol
where
  Self: ~Copyable & ~Escapable,
  Element: ~Copyable
{
  @inlinable
  @_lifetime(copy self)
  public consuming func map<T: ~Copyable>(
    _ transform: @escaping (borrowing Element) -> T
  ) -> BorrowingMapProducer<Self, T> {
    // FIXME: `map` should allow `transform` to throw, and not just `Self.Failure`. See `_map2` and `_map3` below.
    BorrowingMapProducer(
      _base: self,
      transform: { v throws(Failure) in
        // FIXME: Conversion from non-throwing to throwing closure should be implicit
        transform(v)
      })
  }

  @inlinable
  @_lifetime(copy self)
  public consuming func _map2<T: ~Copyable>( // FIXME: We can't overload on the type of error thrown.
    _ transform: @escaping (borrowing Element) throws(Failure) -> T
  ) -> BorrowingMapProducer<Self, T> {
    BorrowingMapProducer(_base: self, transform: transform)
  }

  @inlinable
  @_lifetime(copy self)
  public consuming func _map3<T: ~Copyable, E: Error>( // FIXME: We can't overload on the type of error thrown.
    _ transform: @escaping (borrowing Element) throws(E) -> T
  ) -> BorrowingMapProducer<ErrorMappedIterator<Self, E>, T>
  where Failure == Never {
    BorrowingMapProducer(_base: self.mapError(), transform: transform)
  }
}

@available(SwiftStdlib 6.4, *)
public struct BorrowingMapProducer<
  Base: BorrowingIteratorProtocol & ~Copyable & ~Escapable,
  Element: ~Copyable,
>: ~Copyable, ~Escapable {
  @_alwaysEmitIntoClient
  public let _transform: (borrowing Base.Element) throws(Failure) -> Element

  @_alwaysEmitIntoClient
  public var _it: Base

  @inlinable
  @_lifetime(copy _base)
  internal init(
    _base: consuming Base,
    transform: @escaping (borrowing Base.Element) throws(Failure) -> Element
  ) {
    self._transform = transform
    self._it = _base
  }
}

// FIXME: Sendable

@available(SwiftStdlib 6.4, *)
extension BorrowingMapProducer: Producer
where
  Base: ~Copyable & ~Escapable,
  Element: ~Copyable
{
  public typealias Failure = Base.Failure

  @inlinable
  public var underestimatedCount: Int {
    0 // FIXME
  }

  @inlinable
  @_lifetime(self: copy self)
  public mutating func next() throws(Failure) -> Element? {
    let span = try _it.nextSpan(maxCount: 1)
    guard !span.isEmpty else { return nil }
    return try _transform(span[unchecked: 0])
  }

  @inlinable
  @discardableResult
  @_lifetime(target: copy target)
  @_lifetime(self: copy self)
  public mutating func generate(
    into target: inout OutputSpan<Element>
  ) throws(Failure) -> Int {
    var c = 0
    while !target.isFull {
      let span = try _it.nextSpan(maxCount: target.freeCapacity)
      guard !span.isEmpty else { break }
      c += span.count
      var i = 0
      while i < span.count {
        target.append(try _transform(span[unchecked: i]))
        i &+= 1
      }
    }
    return c
  }

  @inlinable
  @_lifetime(self: copy self)
  public mutating func skip(by n: inout Int) throws(Failure) {
    precondition(n > 0, "Can't skip a negative number of elements")
    if Failure.self == Never.self {
      n -= try! _it.skip(by: n)
      return
    }
#if false
    // FIXME: Iterator's ill-conceived skip(by:) fails to report the position that triggers errors
    try _it.skip(by: &n)
#else
    // We have no choice other than skipping items one by one, or allowing
    // the base to materialize every element. The latter performs better in
    // the common case of containers, so let's do that.
    while n > 0 {
      let span = try _it.nextSpan(maxCount: n)
      n -= span.count
    }
#endif
  }
}

#endif
