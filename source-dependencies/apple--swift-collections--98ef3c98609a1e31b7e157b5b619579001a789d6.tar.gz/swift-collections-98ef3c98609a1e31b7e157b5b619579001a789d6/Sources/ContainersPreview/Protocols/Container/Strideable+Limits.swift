//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2024 - 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import InternalCollectionsUtilities
#endif

#if UnstableContainersPreview
extension Strideable {
  @inlinable
  public mutating func advance(
    by distance: inout Stride, limitedBy limit: Self
  ) {
    _advance(by: &distance, limitedBy: limit)
  }
}
#endif
