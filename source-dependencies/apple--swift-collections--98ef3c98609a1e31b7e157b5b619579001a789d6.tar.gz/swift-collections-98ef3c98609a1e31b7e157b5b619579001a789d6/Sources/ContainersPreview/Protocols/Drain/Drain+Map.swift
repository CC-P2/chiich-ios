//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import SpanPreview
#endif

#if compiler(>=6.4) && UnstableContainersPreview

@available(SwiftStdlib 5.0, *)
extension Drain where Self: ~Copyable & ~Escapable, Element: ~Copyable {
  @inlinable
  @_lifetime(copy self)
  public consuming func map<E: Error, T: ~Copyable>(
    _ transform: @escaping (borrowing Element) throws(E) -> T
  ) throws(E) -> DrainMapProducer<Self, T, E> {
    DrainMapProducer(_base: self, transform: transform)
  }
}

@available(SwiftStdlib 5.0, *)
public struct DrainMapProducer<
  Base: Drain & ~Copyable & ~Escapable,
  Element: ~Copyable,
  Failure: Error
>: ~Copyable, ~Escapable {
  @_alwaysEmitIntoClient
  public let _transform: (consuming Base.Element) throws(Failure) -> Element

  @_alwaysEmitIntoClient
  public var _base: Base

  @inlinable
  @_lifetime(copy _base)
  internal init(
    _base: consuming Base,
    transform: @escaping (consuming Base.Element) throws(Failure) -> Element
  ) {
    self._base = _base
    self._transform = transform
  }
}

@available(SwiftStdlib 5.0, *)
extension DrainMapProducer: Producer
where
  Base: ~Copyable & ~Escapable,
  Element: ~Copyable
{
  @inlinable
  public var underestimatedCount: Int {
    _base.underestimatedCount
  }

  @inlinable
  public mutating func next() throws(Failure) -> Element? {
    guard let next = _base.next() else { return nil }
    return try _transform(next)
  }

  @inlinable
  @discardableResult
  @_lifetime(target: copy target)
  @_lifetime(self: copy self)
  public mutating func generate(
    into target: inout OutputSpan<Element>
  ) throws(Failure) -> Int {
    var c = 0
    while !target.isFull {
      var source = _base.drainNext(maxCount: target.freeCapacity)
      if source.isEmpty { break }
      c += source.count
      while !source.isEmpty {
        try target.append(_transform(source.removeFirst()))
      }
    }
    return c
  }

  @inlinable
  @_lifetime(self: copy self)
  public mutating func skip(by n: inout Int) throws(Failure) {
    _base.skip(by: &n)
  }
}

#endif
