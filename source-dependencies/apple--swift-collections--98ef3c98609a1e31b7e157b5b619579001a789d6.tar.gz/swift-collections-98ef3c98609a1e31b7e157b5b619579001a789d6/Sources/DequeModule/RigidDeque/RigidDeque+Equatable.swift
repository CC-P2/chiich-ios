//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import InternalCollectionsUtilities
#endif

@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: ~Copyable {
  public func isTriviallyIdentical(to other: borrowing Self) -> Bool {
    self._handle.isIdentical(to: other._handle)
  }
}

#if compiler(>=6.4)
@available(SwiftStdlib 6.4, *)
extension RigidDeque: Equatable where Element: Equatable & ~Copyable {}

@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: Equatable & ~Copyable {
  @inlinable
  public static func ==(
    left: borrowing Self,
    right: borrowing Self
  ) -> Bool {
    guard left.count == right.count else { return false }
    guard !left.isTriviallyIdentical(to: right) else { return true }

    if #available(anyAppleOS 27, *) {
      return left._elementsEqual(right)
    }
    for i in 0 ..< left.count {
      guard left[i] == right[i] else { return false }
    }
    return true
  }
}
#else
@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: Equatable {
  @inlinable
  public static func ==(
    left: borrowing Self,
    right: borrowing Self
  ) -> Bool {
    guard left.count == right.count else { return false }
    guard !left.isTriviallyIdentical(to: right) else { return true }

    for i in 0 ..< left.count {
      guard left[i] == right[i] else { return false }
    }
    return true
  }
}
#endif
