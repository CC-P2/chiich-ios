//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2025 - 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

#if !COLLECTIONS_SINGLE_MODULE
import InternalCollectionsUtilities
import SpanPreview
#endif

@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: ~Copyable {
  /// Adds an element to the end of the deque.
  ///
  /// If the deque does not have sufficient capacity to hold any more elements,
  /// then this triggers a runtime error.
  ///
  /// - Parameter item: The element to append to the deque.
  ///
  /// - Complexity: O(1)
  @_alwaysEmitIntoClient
  @inline(__always)
  public mutating func append(_ item: consuming Element) {
    precondition(!isFull, "RigidDeque capacity overflow")
    _handle.uncheckedAppend(item)
  }

  /// Adds an element to the end of the deque, if possible.
  ///
  /// If the deque does not have sufficient capacity to hold any more elements,
  /// then this returns the given item without appending it; otherwise it
  /// returns nil.
  ///
  /// - Parameter item: The element to append to the deque.
  /// - Returns: `item` if the deque is full; otherwise nil.
  ///
  /// - Complexity: O(1)
  @_alwaysEmitIntoClient
  @inline(__always)
  public mutating func pushLast(_ item: consuming Element) -> Element? {
    // FIXME: Remove this in favor of a standard algorithm.
    if isFull { return item }
    append(item)
    return nil
  }
}

@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: ~Copyable {
  /// Efficiently append a given number of items to the back of this deque by
  /// populating a series of storage regions through repeated calls of the
  /// specified callback function.
  ///
  /// If the capacity of the deque isn't sufficient to accommodate the specified
  /// number of new elements, then this method triggers a runtime error.
  ///
  ///     var buffer = RigidDeque<Int>(capacity: 20)
  ///     buffer.append(999)
  ///     var i = 0
  ///     buffer.append(addingCount: 6) { target in
  ///       while !target.isFull {
  ///         target.append(i)
  ///         i += 1
  ///       }
  ///     }
  ///     // `buffer` now contains [999, 0, 1, 2, 3, 4, 5]
  ///
  /// The newly appended items are not guaranteed to form a single contiguous
  /// storage region. Therefore, the supplied callback may be invoked multiple
  /// times to initialize each successive chunk of storage. However, invocations
  /// cease when the callback fails to fully populate its output span or if
  /// it throws an error. In such cases, the deque keeps all items that were
  /// successfully initialized before the callback terminated the append.
  ///
  ///     var buffer = RigidDeque<Int>(capacity: 20)
  ///     buffer.append(999)
  ///     var i = 0
  ///     buffer.append(addingCount: 6) { target in
  ///       while !target.isFull, i <= 3 {
  ///         target.append(i)
  ///         i += 1
  ///       }
  ///     }
  ///     // `buffer` now contains [999, 0, 1, 2, 3]
  ///
  /// - Parameters:
  ///    - newItemCount: The maximum number of items to append to the deque.
  ///    - body: A callback that gets called at most twice to directly
  ///       populate newly reserved storage within the deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`newItemCount`) in addition to the complexity of the callback
  ///    invocations.
  @_alwaysEmitIntoClient
  @inline(__always)
  @discardableResult
  public mutating func append<E: Error>(
    addingCount newItemCount: Int,
    initializingWith body: (inout OutputSpan<Element>) throws(E) -> Void
  ) throws(E) -> Range<Int> {
    precondition(newItemCount >= 0, "Cannot append a negative number of items")
    guard newItemCount > 0 else {
      return Range(uncheckedBounds: (count, count))
    }
    precondition(freeCapacity >= newItemCount, "RigidDeque capacity overflow")
    return try _handle.uncheckedAppend(addingCount: newItemCount, initializingWith: body)
  }
}

@available(SwiftStdlib 5.0, *)
extension RigidDeque where Element: ~Copyable {
  /// Moves the elements of a buffer to the end of this deque, leaving the
  /// buffer uninitialized.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// buffer, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: A fully initialized buffer whose contents to move into
  ///        the deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(
    moving items: UnsafeMutableBufferPointer<Element>
  ) -> Range<Int> {
    precondition(items.count <= freeCapacity, "RigidDeque capacity overflow")
    return _handle.uncheckedAppend(moving: items)
  }

#if UnstableContainersPreview
  /// Moves the elements of an input span by appending them to the end of
  /// this deque, leaving the span empty.
  ///
  /// If the deque does not have sufficient capacity to hold all items in its
  /// storage, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: An input span whose contents need to be appended to this deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(
    moving items: inout InputSpan<Element>
  ) -> Range<Int> {
    items.withUnsafeMutableBufferPointer { buffer, count in
      let source = buffer._extracting(last: count)
      count = 0
      return unsafe self.append(moving: source)
    }
  }
#endif

  /// Moves the elements of an output span by appending them to the end of
  /// this deque, leaving the span empty.
  ///
  /// If the deque does not have sufficient capacity to hold all items in its
  /// storage, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: An output span whose contents need to be appended to this deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(
    moving items: inout OutputSpan<Element>
  ) -> Range<Int> {
    items.withUnsafeMutableBufferPointer { buffer, count in
      let source = buffer._extracting(first: count)
      count = 0
      return unsafe self.append(moving: source)
    }
  }
}

@available(SwiftStdlib 5.0, *)
extension RigidDeque /*where Element: Copyable*/ {
  /// Copies the elements of a buffer and append them to the end of this
  /// deque.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// buffer, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: A fully initialized buffer whose contents to copy into
  ///       the deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(
    copying items: UnsafeBufferPointer<Element>
  ) -> Range<Int> {
    precondition(
      items.count <= freeCapacity,
      "RigidDeque capacity overflow")
    return _handle.uncheckedAppend(copying: items)
  }

  /// Copies the elements of a buffer and append them to the end of this
  /// deque.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// buffer, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: A fully initialized buffer whose contents to copy into
  ///        the deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(
    copying items: UnsafeMutableBufferPointer<Element>
  ) -> Range<Int> {
    unsafe self.append(copying: UnsafeBufferPointer(items))
  }

  /// Copies the elements of a span and append them to the end of this deque.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// span, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: A span whose contents to copy into the deque.
  /// - Returns: A valid index range addressing the newly inserted items.
  /// - Complexity: O(`items.count`)
  @_alwaysEmitIntoClient
  @discardableResult
  public mutating func append(copying items: Span<Element>) -> Range<Int> {
    items.withUnsafeBufferPointer { source in
      unsafe self.append(copying: source)
    }
  }

#if compiler(>=6.4)
  @available(SwiftStdlib 6.4, *)
  @_alwaysEmitIntoClient
  internal mutating func _append<
    S: Iterable & ~Copyable & ~Escapable
  >(copying items: borrowing S) throws(S.Failure)
  where S.Element == Element {
    var it = items.makeBorrowingIterator()
    while true {
      let span = try it.nextSpan()
      if span.isEmpty { break }
      self.append(copying: span)
    }
  }

  /// Copies the elements of a borrowing sequence and append them to the end of
  /// this deque.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// sequence, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - newElements: The new elements to copy into the deque.
  ///
  /// - Complexity: O(*m*), where *m* is the length of `newElements`.
  @available(SwiftStdlib 6.4, *)
  @_alwaysEmitIntoClient
  public mutating func append<S: Iterable & ~Copyable & ~Escapable>(
    copying newElements: borrowing S
  ) throws(S.Failure)
  where S.Element == Element {
    try self._append(copying: newElements)
  }
#endif

  /// Append the elements of a sequence to the end of this deque by copying
  /// them.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// sequence, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - newElements: The new elements to copy into the deque.
  ///
  /// - Complexity: O(*m*), where *m* is the length of `newElements`.
  @_alwaysEmitIntoClient
  public mutating func append(copying newElements: some Sequence<Element>) {
    let done: Void? = newElements.withContiguousStorageIfAvailable { buffer in
      unsafe self.append(copying: buffer)
      return
    }
    if done != nil { return }

    var it = _handle.uncheckedAppend(copyingPrefixOf: newElements)
    precondition(it.next() == nil, "RigidDeque capacity overflow")
  }

#if compiler(>=6.4)
  /// Copies the elements of a borrowing sequence to the end of this deque.
  ///
  /// If the deque does not have sufficient capacity to hold all items in the
  /// sequence, then this triggers a runtime error.
  ///
  /// - Parameters:
  ///    - items: The new elements to copy into the deque.
  ///
  /// - Complexity: O(*m*), where *m* is the length of `items`.  @available(SwiftStdlib 5.0, *)
  @available(SwiftStdlib 6.4, *)
  @_alwaysEmitIntoClient
  public mutating func append<
    S: Iterable & Sequence<Element>
  >(
    copying items: S
  ) throws(S.Failure)
  where S.Element == Element {
    try self._append(copying: items)
  }
#endif
}
