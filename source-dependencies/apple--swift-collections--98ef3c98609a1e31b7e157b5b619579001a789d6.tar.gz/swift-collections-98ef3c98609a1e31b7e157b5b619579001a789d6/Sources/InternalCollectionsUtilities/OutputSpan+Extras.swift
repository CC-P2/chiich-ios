//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Collections open source project
//
// Copyright (c) 2024 - 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
// SPDX-License-Identifier: Apache-2.0 WITH Swift-exception
//
//===----------------------------------------------------------------------===//

@available(SwiftStdlib 5.0, *)
@_alwaysEmitIntoClient
package func withTemporaryOutputSpan<Element: ~Copyable, E: Error, R: ~Copyable>(
  of type: Element.Type,
  capacity: Int,
  _ body: (inout OutputSpan<Element>) throws(E) -> R
) throws(E) -> R {
  try _withUnsafeTemporaryAllocation(
    of: Element.self, capacity: capacity
  ) { buffer throws(E) in
    var span = OutputSpan(buffer: buffer, initializedCount: 0)
    return try body(&span)
  }
}

@available(SwiftStdlib 5.0, *)
extension OutputSpan where Element: ~Copyable {
  /// Removes and returns the last element of this output span, if it exists.
  ///
  /// - Returns: The last element of the original span if it wasn't empty;
  ///    otherwise, `nil`.
  ///
  /// - Complexity: O(1)
  @inlinable
  package mutating func _popLast() -> Element? {
    // FIXME: This needs to be in the stdlib.
    withUnsafeMutableBufferPointer { buffer, count in
      guard count > 0 else { return nil }
      count &-= 1
      return buffer.moveElement(from: count)
    }
  }
}

@available(SwiftStdlib 5.0, *)
extension OutputSpan where Element: ~Copyable {
  @inlinable
  @inline(__always)
  @_lifetime(self: copy self)
  package mutating func _append(
    moving source: UnsafeMutableBufferPointer<Element>
  ) {
    // FIXME: This needs to be in the stdlib.
    guard source.count > 0 else { return }
    self.withUnsafeMutableBufferPointer { dst, dstCount in
      let dstEnd = dstCount + source.count
      precondition(dstEnd <= dst.count, "OutputSpan capacity overflow")
      dst
        ._extracting(uncheckedFrom: dstCount, to: dstEnd)
        .moveInitializeAll(fromContentsOf: source)
      dstCount &+= source.count
    }
  }

  @_lifetime(source: copy source)
  @inlinable
  @inline(__always)
  @_lifetime(self: copy self)
  package mutating func _append(moving source: inout OutputSpan<Element>) {
    // FIXME: This needs to be in the stdlib.
    source.withUnsafeMutableBufferPointer { src, srcCount in
      let items = src._extracting(uncheckedFrom: 0, to: srcCount)
      self._append(moving: items)
      srcCount = 0
    }
  }
}

@available(SwiftStdlib 5.0, *)
extension OutputSpan /*where Element: Copyable*/ {
  @inlinable
  @_lifetime(self: copy self)
  package mutating func _append(copying source: UnsafeBufferPointer<Element>) {
    // FIXME: This needs to be in the stdlib.
    self.withUnsafeMutableBufferPointer { dst, dstCount in
      let dstEnd = dstCount + source.count
      precondition(dstEnd <= dst.count, "OutputSpan capacity overflow")
      dst
        ._extracting(uncheckedFrom: dstCount, to: dstEnd)
        .initializeAll(fromContentsOf: source)
      dstCount &+= source.count
    }
  }

  @inlinable
  @_lifetime(self: copy self)
  package mutating func _append(copying source: Span<Element>) {
    // FIXME: This needs to be in the stdlib.
    source.withUnsafeBufferPointer { buffer in
      self._append(copying: buffer)
    }
  }
}

@available(SwiftStdlib 5.0, *)
extension OutputSpan where Element: ~Copyable {
  @inlinable
  @_lifetime(self: copy self)
  package mutating func _remove(
    from index: Int,
    where shouldBeRemoved: (borrowing Element) -> Bool
  ) {
    // FIXME: This needs to be in the stdlib.
    precondition(index >= 0 && index <= count, "Index out of bounds")
    self.withUnsafeMutableBufferPointer { buffer, count in
      var i = index
      var j = i
      // Invariant: i ..< j is uninitialized
      while j < count {
        if shouldBeRemoved(buffer[j]) {
          buffer.deinitializeElement(at: j)
          j &+= 1
        } else {
          if i != j {
            buffer.initializeElement(at: i, to: buffer.moveElement(from: j))
          }
          i &+= 1
          j &+= 1
        }
      }
      count = i
    }
  }
}

@available(SwiftStdlib 5.0, *)
extension OutputSpan where Element: ~Copyable {
  @_alwaysEmitIntoClient
  @discardableResult
  @_lifetime(self: copy self)
  package mutating func _append<E: Error, R: ~Copyable>(
    addingCount newItemCount: Int,
    initializingWith initializer: (inout OutputSpan<Element>) throws(E) -> R
  ) throws(E) -> R {
    // FIXME: This needs to be in the stdlib.
    // Note: This is the wrong shape for append, as it doesn't generalize
    // to piecewise contiguous containers and doesn't return indices.
    // However, it feels like we need to _also_ provide a simple append
    // implementation for flat containers, as the ability return things out of
    // the closure is quite important for usability. We can't name them both
    // `append(addingCount:initializingWith:)` though!
    precondition(newItemCount >= 0, "Cannot add a negative number of items")
    return try withUnsafeMutableBufferPointer { buf, c throws(E) in
      precondition(newItemCount <= buf.count - c, "OutputSpan capacity overflow")
      let dst = buf._extracting(unchecked: Range(
        uncheckedBounds: (c, c &+ newItemCount)))
      var span = OutputSpan(buffer: dst, initializedCount: 0)
      defer {
        c &+= span.finalize(for: dst)
        span = OutputSpan()
      }
      return try initializer(&span)
    }
  }
}
