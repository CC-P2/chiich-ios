# Changelog

All notable changes to this project will be documented in this file.

<!-- changelog start -->

## [0.19.1](https://github.com/matrix-org/matrix-rust-sdk/tree/0.19.1) - 2026-09-18

No significant changes.

## [0.19.0](https://github.com/matrix-org/matrix-rust-sdk/tree/0.19.0) - 2026-09-16

### Added

- `linked_chunk::UpdatesSubscriber` is now available to everyone, not only for
  internal testing purposes.

  ```rust
  let linked_chunk = LinkedChunk::new_with_update_history();
  let mut updates_subscriber = linked_chunk.updates().unwrap().subscribe();

  // `UpdatesSubscriber` implements `Stream`.
  // Let's wait on a next value to come…
  use futures_util::stream::StreamExt;

  while let Some(next_update) = updates_subscriber.next().await {
      // Do something!
  }
  ``` ([#6752](https://github.com/matrix-org/matrix-rust-sdk/pull/6752))
- Propagate the tracing `Span` into tasks spawned via `TaskMonitor`.
  ([#6833](https://github.com/matrix-org/matrix-rust-sdk/pull/6833))

### Changed

- The `TimelineEvent::event_id` now returns an `Option<&EventId>` instead of an
  `Option<OwnedEventId>`. This is possible because the event ID is now eagerly
  parsed when constructing this type and kept in memory for performance
  concerns.

  This cached event ID is not serialized: it is backward compatible regarding
  the storage, while it is not regarding the `event_id()` method signature.

  If one needs an `OwnedEventId` from an `&EventId`, let's just use
  `EventId::to_owned`.
  ([#6626](https://github.com/matrix-org/matrix-rust-sdk/pull/6626))
- `LinkedChunk` creates its first chunk lazily. If one expects an
  `Update::NewItemsChunk` to be sent immediately after the `LinkedChunk` is
  created (with `new_with_update_history`), now they need to wait until a method
  on `LinkedChunk` is called. Consequently, another change is
  `LinkedChunk::clear` that no longer recreates an empty chunk immediately too.
  ([#6752](https://github.com/matrix-org/matrix-rust-sdk/pull/6752))

### Fixed

- Fix a bug where cloning a `CrossProcessLockGuard` does not increase the
  `num_holders`, protecting against an _impossible to release_ lock, or a
  _prematurely released_ lock. Why? Because when the second to last holder drops
  the lock, it makes the `num_holders` to overflow and to wrap around. It would
  never make it to release because the number of holders became `u32::MAX`.
  Alternatively, the counter could reach zero prematurely, and then the lock was
  prematurely released while holders exist.

  Another bug existed where the `num_holders` was off by 1 with
  `CrossProcessLockConfig::SingleProcess`, and is now fixed.
  ([#6629](https://github.com/matrix-org/matrix-rust-sdk/pull/6629))
- Dropping `CrossProcessLock` no longer releases the lock if a
  `CrossProcessGuard` is still alive.

  An important problem has been found with the `CrossProcessLock`. We noticed
  that when a `CrossProcessLock` is dropped, all `CrossProcessLockGuard`s report
  0 holder, and thus, the lock is released, but it's wrong. As long as guards
  are alive, the lock **MUST NOT** be released. Dropping all the guards releases
  the lock, but dropping the `CrossProcessLock` —which is not the lock in
  itself— must not drop the acquired lock. There is no public changes, but the
  incorrect behaviour is now fixed.
  ([#6674](https://github.com/matrix-org/matrix-rust-sdk/pull/6674))
- `RingBuffer` now preserves its logical capacity when serializing and
  deserializing. Older serialized sequence-form buffers remain readable and use
  a legacy fallback capacity.
  ([#6815](https://github.com/matrix-org/matrix-rust-sdk/pull/6815))
- Update `RelationalLinkedChunk` to ensure it adheres to the following three
  properties.

  1. An `Event` should not exist within a `LinkedChunk` more than once - i.e.,
     it should occupy only a single `Position`.
  2. Each `Position` within a `LinkedChunk` should only be occupied by a single
     `Event`.
  3. When changes are made to the content of an `Event` in one `LinkedChunk`,
     these changes should be reflected in all `LinkedChunk`s which contain an
     instance of that `Event`.
     ([#6872](https://github.com/matrix-org/matrix-rust-sdk/pull/6872))
- The `TimelineEvent::bundled_latest_thread_event` _field_ is replaced by the
  `TimelineEvent::bundled_latest_thread_event()` _method_.

  1. The `TimelineEvent` type is 8 bytes smaller,
  2. The `bundled_latest_thread_event` field was only set when a constructor was
     used, it was unset when the value was deserialised, which was error-prone,
  3. The field value was boxed, which forced to clone it in some cases. Now, the
     returned value is owned.
     ([#7033](https://github.com/matrix-org/matrix-rust-sdk/pull/7033))

## [0.18.0](https://github.com/matrix-org/matrix-rust-sdk/tree/0.18.0) - 2026-06-02

No significant changes.

## [0.17.0] - 2026-05-08

### Features

- [**breaking**] Change to the stable identifiers for `m.history_not_shared`.
  We still support reading the unstable identifier.
  ([#6467](https://github.com/matrix-org/matrix-rust-sdk/pull/6467))
- Add a method to check the validity of edits.
  ([#6454](https://github.com/matrix-org/matrix-rust-sdk/pull/6454))
- A background task monitor has been added, that can spawn background tasks and
  monitor their execution on a separate channel. Such tasks can run forever, or
  they can run for one-shot jobs.
  ([#6075](https://github.com/matrix-org/matrix-rust-sdk/pull/6075) &&
  [#6421](https://github.com/matrix-org/matrix-rust-sdk/pull/6421))
- Add `AcquireCrossProcessLockResult` and `AcquireCrossProcessLockFn`
  for convenience in generalizing cross-process lock acquisition.
  ([#6326](https://github.com/matrix-org/matrix-rust-sdk/pull/6326))
- Add support in the `MemoryStore`'s implementation of `EventCacheStore` for
  having duplicate events in a room, where each duplicate is in a different
  `LinkedChunk`. This is useful, e.g., when an event is in a room and a
  thread in that room.
- [**breaking**] In order to support having duplicate events in the same room
  (in different `LinkedChunk`'s) a few functions were changed in
  `RelationalLinkedChunk`. The items in the `Iterator` returned by
  `RelationalLinkedChunk::items` now also include the `LinkedChunkId` in which
  the `Item` was found. Additionally, `RelationalLinkedChunk::save_item` now
  requires the `Item` to be `Clone` as it may be stored in multiple
  `LinkedChunk`s.
  (#[6200](https://github.com/matrix-org/matrix-rust-sdk/pull/6200))
- [**breaking**] Added `CrossProcessLockConfig`, which can be used to configure
  the behavior of the cross-process lock. `CrossProcessLock` now takes a
  `CrossProcessLockConfig` as an argument to its constructor instead of a
  `lock_holder` value.
  ([#6160](https://github.com/matrix-org/matrix-rust-sdk/pull/6160))
- [**breaking**] `ShieldStateCode` no longer includes
  `SentInClear`. `VerificationState::to_shield_state_{lax,strict}` never
  returned that code, and so having it in the enum was somewhat misleading.
  ([#5959](https://github.com/matrix-org/matrix-rust-sdk/pull/5959))
- Add field `forwarder` of type `ForwarderInfo` to `EncryptionInfo`, which
  exposes information about the forwarder of the keys with which an event was
  encrypted if they were shared as part of an
  [MSC4268](https://github.com/matrix-org/matrix-spec-proposals/pull/4268) room
  key bundle.
  ([#5945](https://github.com/matrix-org/matrix-rust-sdk/pull/5945)).

### Bug fixes

- Fix an off-by-one check for `Error:InvalidItemIndex` in
  `LinkedChunk::remove_item_at`.
  ([#6057](https://github.com/matrix-org/matrix-rust-sdk/pull/6057))
- Fix `TimelineEvent::from_bundled_latest_event` sometimes removing the
  `session_id` of UTDs. This broken event could later be saved to the event
  cache and become an unresolvable UTD.
  ([#5970](https://github.com/matrix-org/matrix-rust-sdk/pull/5970)).

### Refactor

- [**breaking**] Remove `ttl_cache::TtlCache` because it is now unused.
  ([#6484](https://github.com/matrix-org/matrix-rust-sdk/pull/6484))

## [0.16.1] - 2026-05-08

### Features

- Add a method to check the validity of edits.
  ([#6454](https://github.com/matrix-org/matrix-rust-sdk/pull/6454))

## [0.16.0] - 2025-12-04

### Features

- [**breaking**] Cross-process lock can be dirty. The
  `CrossProcess::try_lock_once` now returns a new type `CrossProcessResult`,
  which is an enum with `Clean`, `Dirty` or `Unobtained` variants. When the lock
  is dirty it means it's been acquired once, then acquired another time from
  another holder, so the current holder may want to refresh its internal state.
  ([#5672](https://github.com/matrix-org/matrix-rust-sdk/pull/5672)).

## [0.14.0] - 2025-09-04

### Features

- Tracing subscribers created via
  [`matrix_sdk_common::js_tracing::MakeJsLogWriter`] or
  [`make_tracing_subscriber`] will now drop log events at the `TRACE` level.
  Previously `TRACE` logs were treated the same as `DEBUG` logs.
  ([#5590](https://github.com/matrix-org/matrix-rust-sdk/pull/5590)).

- [**breaking**] Use `Raw<AnyTimelineEvent>` in place of
  `Raw<AnyMessageLikeEvent>` in `DecryptedRoomEvent::event`.
  ([#5512](https://github.com/matrix-org/matrix-rust-sdk/pull/5512)). Affects
  the following functions:
  - `OlmMachine::decrypt_room_event` - existing matches on the result's event
    field should be updated to
    `AnyTimelineEvent::MessageLike(AnyMessageLikeEvent::...)`

## [0.13.0] - 2025-07-10

### Features

- Expose the `ROOM_VERSION_RULES_FALLBACK` that should be used when the rules of
  a room are unknown.
  ([#5337](https://github.com/matrix-org/matrix-rust-sdk/pull/5337))
- Expose the `ROOM_VERSION_FALLBACK` that should be used when the version of a
  room is unknown.
  ([#5306](https://github.com/matrix-org/matrix-rust-sdk/pull/5306))

### Refactor

- [**breaking**] `extract_bundled_thread_summary()` returns a
  `Raw<AnySyncMessageLikeEvent>` for the latest event instead of a
  `Raw<AnyMessageLikeEvent>`.
  ([#5337](https://github.com/matrix-org/matrix-rust-sdk/pull/5337))

## [0.12.0] - 2025-06-10

No notable changes in this release.

## [0.11.0] - 2025-04-11

### Features

- Add a simple TTL cache implementation. The `TtlCache` struct can be used as a
  key/value map that expires items after 15 minutes.
  ([#4663](https://github.com/matrix-org/matrix-rust-sdk/pull/4663))

## [0.10.0] - 2025-02-04

- [**breaking**]: `SyncTimelineEvent` and `TimelineEvent` have been
  fused into a single type `TimelineEvent`, and its field `push_actions`
  has been made `Option`al (it is set to `None` when we couldn't
  compute the push actions, because we lacked some information).
  ([#4568](https://github.com/matrix-org/matrix-rust-sdk/pull/4568))

## [0.9.0] - 2024-12-18

### Bug fixes

- Change the behavior of `LinkedChunk::new_with_update_history()` to emit an
  `Update::NewItemsChunk` when a new, initial empty, chunk is created.
  ([#4327](https://github.com/matrix-org/matrix-rust-sdk/pull/4321))

- [**breaking**] Make `Room::history_visibility()` return an Option, and
  introduce `Room::history_visibility_or_default()` to return a better
  sensible default, according to the spec.
  ([#4325](https://github.com/matrix-org/matrix-rust-sdk/pull/4325))

- Clear the internal state of the `AsVector` struct if an `Update::Clear`
  state has been received.
  ([#4321](https://github.com/matrix-org/matrix-rust-sdk/pull/4321))

### Documentation

- Document that a decrypted raw event always has a room id.
  ([#728e1fd](https://github.com/matrix-org/matrix-rust-sdk/commit/728e1fda2ae9f1bfa87df162aa553040be705223))

## [0.8.0] - 2024-11-19

### Refactor

- Move `linked_chunk` from `matrix-sdk` to `matrix-sdk-common`.
