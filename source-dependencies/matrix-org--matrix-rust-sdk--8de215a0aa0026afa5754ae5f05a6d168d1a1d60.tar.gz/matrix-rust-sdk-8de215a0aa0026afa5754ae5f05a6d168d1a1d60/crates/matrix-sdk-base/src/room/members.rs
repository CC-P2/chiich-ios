// Copyright 2020 The Matrix.org Foundation C.I.C.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::{
    collections::{BTreeSet, HashMap},
    mem, slice,
    sync::Arc,
};

use bitflags::bitflags;
use futures_util::future;
#[cfg(feature = "unstable-msc4426")]
use ruma::profile::{Call, CallProfileField, Status, StatusProfileField, UserProfile};
use ruma::{
    Int, MxcUri, OwnedUserId, UserId,
    events::{
        MessageLikeEventType, StateEventType,
        ignored_user_list::IgnoredUserListEventContent,
        room::{
            member::{MembershipState, RoomMemberEventContent},
            power_levels::{PowerLevelAction, RoomPowerLevels, UserPowerLevel},
        },
    },
};
use tracing::debug;

use super::Room;
use crate::{
    MinimalRoomMemberEvent, StateStore, StoreError,
    deserialized_responses::{DisplayName, MemberEvent},
    store::{Result as StoreResult, StateStoreExt, ambiguity_map::is_display_name_ambiguous},
};

impl Room {
    /// Check if the room has its members fully synced.
    ///
    /// Members might be missing if lazy member loading was enabled for the
    /// sync.
    ///
    /// Returns true if no members are missing, false otherwise.
    pub fn are_members_synced(&self) -> bool {
        self.info.read().members_synced
    }

    /// Mark this Room as holding all member information.
    ///
    /// Useful in tests if we want to persuade the Room not to sync when asked
    /// about its members.
    #[cfg(feature = "testing")]
    pub fn mark_members_synced(&self) {
        self.info.update(|info| {
            info.members_synced = true;
        });
    }

    /// Mark this Room as still missing member information.
    pub fn mark_members_missing(&self) {
        self.info.update_if(|info| {
            // notify observable subscribers only if the previous value was
            // false
            mem::replace(&mut info.members_synced, false)
        })
    }

    /// Get the `RoomMember`s of this room that are known to the store, with the
    /// given memberships.
    pub async fn members(&self, memberships: RoomMemberships) -> StoreResult<Vec<RoomMember>> {
        let user_ids = self.store.get_user_ids(self.room_id(), memberships).await?;

        if user_ids.is_empty() {
            return Ok(Vec::new());
        }

        // These store reads are independent of each other, so run them
        // together rather than one after the other.
        let member_events = async {
            self.store
                .get_state_events_for_keys_static::<RoomMemberEventContent, _, _>(
                    self.room_id(),
                    &user_ids,
                )
                .await?
                .into_iter()
                .map(|raw_event| raw_event.deserialize())
                .collect::<Result<Vec<_>, _>>()
                .map_err(StoreError::from)
        };

        let profiles = self.store.get_profiles(self.room_id(), &user_ids);

        #[cfg(feature = "unstable-msc4426")]
        let (member_events, mut profiles, mut global_profiles) =
            future::try_join3(member_events, profiles, self.store.get_global_profiles(&user_ids))
                .await?;

        #[cfg(not(feature = "unstable-msc4426"))]
        let (member_events, mut profiles) = future::try_join(member_events, profiles).await?;

        let display_names = member_events.iter().map(|e| e.display_name()).collect::<Vec<_>>();
        let room_info = self.member_room_info(&display_names).await?;

        let mut members = Vec::with_capacity(member_events.len());

        for (event, display_name) in member_events.into_iter().zip(&display_names) {
            let profile = profiles.remove(event.user_id());
            #[cfg(feature = "unstable-msc4426")]
            let global_profile = global_profiles.remove(event.user_id());
            members.push(RoomMember::from_parts(
                event,
                profile,
                #[cfg(feature = "unstable-msc4426")]
                global_profile,
                display_name,
                &room_info,
            ))
        }

        Ok(members)
    }

    /// Get the user IDs of the members with the given memberships, without the
    /// service members, see [`Self::service_members`].
    pub async fn human_member_ids(
        &self,
        memberships: RoomMemberships,
    ) -> StoreResult<Vec<OwnedUserId>> {
        let user_ids = self.store.get_user_ids(self.room_id(), memberships).await?;

        let Some(service_members) = self.service_members() else {
            return Ok(user_ids);
        };

        Ok(user_ids.into_iter().filter(|user_id| !service_members.contains(user_id)).collect())
    }

    /// Returns the number of members who have joined or been invited to the
    /// room.
    pub fn active_members_count(&self) -> u64 {
        self.info.read().active_members_count()
    }

    /// Returns the number of members who have been invited to the room.
    pub fn invited_members_count(&self) -> u64 {
        self.info.read().invited_members_count()
    }

    /// Returns the number of members who have joined the room.
    pub fn joined_members_count(&self) -> u64 {
        self.info.read().joined_members_count()
    }

    /// Get the `RoomMember` with the given `user_id`.
    ///
    /// Returns `None` if the member was never part of this room, otherwise
    /// return a `RoomMember` that can be in a joined, RoomState::Invited, left,
    /// banned state.
    ///
    /// Async because it can read from storage.
    pub async fn get_member(&self, user_id: &UserId) -> StoreResult<Option<RoomMember>> {
        let event = async {
            let Some(raw_event) = self.store.get_member_event(self.room_id(), user_id).await?
            else {
                debug!(%user_id, "Member event not found in state store");
                return Ok(None);
            };

            Ok(Some(raw_event.deserialize()?))
        };

        let profile = self.store.get_profile(self.room_id(), user_id);

        #[cfg(feature = "unstable-msc4426")]
        let (Some(event), profile, global_profile) = future::try_join3(event, profile, async {
            self.store.get_global_profile(user_id).await
        })
        .await?
        else {
            return Ok(None);
        };
        #[cfg(not(feature = "unstable-msc4426"))]
        let (Some(event), profile) = future::try_join(event, profile).await? else {
            return Ok(None);
        };

        let display_name = event.display_name();
        let room_info = self.member_room_info(slice::from_ref(&display_name)).await?;

        Ok(Some(RoomMember::from_parts(
            event,
            profile,
            #[cfg(feature = "unstable-msc4426")]
            global_profile,
            &display_name,
            &room_info,
        )))
    }

    /// The current `MemberRoomInfo` for this room.
    ///
    /// Async because it can read from storage.
    async fn member_room_info<'a>(
        &self,
        display_names: &'a [DisplayName],
    ) -> StoreResult<MemberRoomInfo<'a>> {
        let max_power_level = self.max_power_level();
        let power_levels = async { Ok(self.power_levels_or_default().await) };

        let users_display_names =
            self.store.get_users_with_display_names(self.room_id(), display_names);

        let ignored_users = async {
            Ok(self
                .store
                .get_account_data_event_static::<IgnoredUserListEventContent>()
                .await?
                .map(|c| c.deserialize())
                .transpose()?
                .map(|e| e.content.ignored_users.into_keys().collect()))
        };

        let (power_levels, users_display_names, ignored_users) =
            future::try_join3(power_levels, users_display_names, ignored_users).await?;

        Ok(MemberRoomInfo {
            power_levels: power_levels.into(),
            max_power_level,
            users_display_names,
            ignored_users,
            service_members: self.service_members(),
        })
    }
}

/// A member of a room.
#[derive(Clone, Debug)]
pub struct RoomMember {
    pub(crate) event: Arc<MemberEvent>,
    // The latest member event sent by the member themselves. Stored in addition
    // to the latest member event overall to get displayname and avatar from,
    // which should be ignored on events sent by others.
    pub(crate) profile: Arc<Option<MinimalRoomMemberEvent>>,
    // The user's status, taken from their global profile.
    #[cfg(feature = "unstable-msc4426")]
    pub(crate) status: Option<StatusProfileField>,
    // The user's call indicator, taken from their global profile.
    #[cfg(feature = "unstable-msc4426")]
    pub(crate) call: Option<CallProfileField>,
    pub(crate) power_levels: Arc<RoomPowerLevels>,
    pub(crate) max_power_level: i64,
    pub(crate) display_name_ambiguous: bool,
    pub(crate) is_ignored: bool,
    pub(crate) is_service_member: bool,
}

impl RoomMember {
    /// Build a member from its parts.
    ///
    /// `display_name` must be the value returned by
    /// [`MemberEvent::display_name`] for this `event`.
    pub(crate) fn from_parts(
        event: MemberEvent,
        profile: Option<MinimalRoomMemberEvent>,
        #[cfg(feature = "unstable-msc4426")] global_profile: Option<UserProfile>,
        display_name: &DisplayName,
        room_info: &MemberRoomInfo<'_>,
    ) -> Self {
        let MemberRoomInfo {
            power_levels,
            max_power_level,
            users_display_names,
            ignored_users,
            service_members,
        } = room_info;

        let user_id = event.user_id().to_owned();
        let display_name_ambiguous = users_display_names
            .get(display_name)
            .is_some_and(|s| is_display_name_ambiguous(display_name, s));
        let is_ignored = ignored_users.as_ref().is_some_and(|s| s.contains(event.user_id()));
        let is_service_member = service_members.as_ref().is_some_and(|s| s.contains(&user_id));

        // Extract global profile fields, swallowing any deserialization errors.
        #[cfg(feature = "unstable-msc4426")]
        let status = global_profile.as_ref().and_then(|p| p.get_static::<Status>().ok().flatten());
        #[cfg(feature = "unstable-msc4426")]
        let call = global_profile.as_ref().and_then(|p| p.get_static::<Call>().ok().flatten());

        Self {
            event: event.into(),
            profile: profile.into(),
            #[cfg(feature = "unstable-msc4426")]
            status,
            #[cfg(feature = "unstable-msc4426")]
            call,
            power_levels: power_levels.clone(),
            max_power_level: *max_power_level,
            display_name_ambiguous,
            is_ignored,
            is_service_member,
        }
    }

    /// Get the unique user id of this member.
    pub fn user_id(&self) -> &UserId {
        self.event.user_id()
    }

    /// Get the original member event
    pub fn event(&self) -> &Arc<MemberEvent> {
        &self.event
    }

    /// Get the display name of the member if there is one.
    pub fn display_name(&self) -> Option<&str> {
        if let Some(p) = self.profile.as_ref() {
            p.content.displayname.as_deref()
        } else {
            self.event.displayname_value()
        }
    }

    /// Get the name of the member.
    ///
    /// This returns either the display name or the local part of the user id if
    /// the member didn't set a display name.
    pub fn name(&self) -> &str {
        if let Some(d) = self.display_name() { d } else { self.user_id().localpart() }
    }

    /// Get the avatar url of the member, if there is one.
    pub fn avatar_url(&self) -> Option<&MxcUri> {
        if let Some(p) = self.profile.as_ref() {
            p.content.avatar_url.as_deref()
        } else {
            self.event.avatar_url()
        }
    }

    /// Get the user's status, if any.
    ///
    /// This is the user-set status (emoji + text) taken from the user's global
    /// profile.
    ///
    /// Global profiles are only populated when syncing via sliding sync with
    /// the profiles extension enabled; this is always `None` under sync v2.
    #[cfg(feature = "unstable-msc4426")]
    pub fn status(&self) -> Option<&StatusProfileField> {
        self.status.as_ref()
    }

    /// Get the user's call indicator, if any.
    ///
    /// This indicates the user is currently in a call (and optionally how long
    /// they've been in it). It is taken from the user's global profile.
    ///
    /// Global profiles are only populated when syncing via sliding sync with
    /// the profiles extension enabled; this is always `None` under sync v2.
    #[cfg(feature = "unstable-msc4426")]
    pub fn call(&self) -> Option<&CallProfileField> {
        self.call.as_ref()
    }

    /// Get the normalized power level of this member.
    ///
    /// The normalized power level depends on the maximum power level that can
    /// be found in a certain room, positive values that are not `Infinite` are
    /// always in the range of 0-100.
    pub fn normalized_power_level(&self) -> UserPowerLevel {
        let UserPowerLevel::Int(power_level) = self.power_level() else {
            return UserPowerLevel::Infinite;
        };

        let normalized_power_level = if self.max_power_level > 0 {
            normalize_power_level(power_level, self.max_power_level)
        } else {
            power_level
        };

        UserPowerLevel::Int(normalized_power_level)
    }

    /// Get the power level of this member.
    pub fn power_level(&self) -> UserPowerLevel {
        self.power_levels.for_user(self.user_id())
    }

    /// Whether this user can ban other users based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::Ban)`.
    pub fn can_ban(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_ban(self.user_id()))
    }

    /// Whether this user can invite other users based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::Invite)`.
    pub fn can_invite(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_invite(self.user_id()))
    }

    /// Whether this user can kick other users based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::Kick)`.
    pub fn can_kick(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_kick(self.user_id()))
    }

    /// Whether this user can redact their own events based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::RedactOwn)`.
    pub fn can_redact_own(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_redact_own_event(self.user_id()))
    }

    /// Whether this user can redact events of other users based on the power
    /// levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::RedactOther)`.
    pub fn can_redact_other(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_redact_event_of_other(self.user_id()))
    }

    /// Whether this user can send message events based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::SendMessage(msg_type))`.
    pub fn can_send_message(&self, msg_type: MessageLikeEventType) -> bool {
        self.can_do_impl(|pls| pls.user_can_send_message(self.user_id(), msg_type))
    }

    /// Whether this user can send state events based on the power levels.
    ///
    /// Same as `member.can_do(PowerLevelAction::SendState(state_type))`.
    pub fn can_send_state(&self, state_type: StateEventType) -> bool {
        self.can_do_impl(|pls| pls.user_can_send_state(self.user_id(), state_type))
    }

    /// Whether this user can pin or unpin events based on the power levels.
    pub fn can_pin_or_unpin_event(&self) -> bool {
        self.can_send_state(StateEventType::RoomPinnedEvents)
    }

    /// Whether this user can notify everybody in the room by writing `@room` in
    /// a message.
    ///
    /// Same as
    /// `member. can_do(PowerLevelAction::TriggerNotification(NotificationPowerLevelType::Room))`.
    pub fn can_trigger_room_notification(&self) -> bool {
        self.can_do_impl(|pls| pls.user_can_trigger_room_notification(self.user_id()))
    }

    /// Whether this user can do the given action based on the power levels.
    pub fn can_do(&self, action: PowerLevelAction) -> bool {
        self.can_do_impl(|pls| pls.user_can_do(self.user_id(), action))
    }

    fn can_do_impl(&self, f: impl FnOnce(&RoomPowerLevels) -> bool) -> bool {
        f(&self.power_levels)
    }

    /// Is the name that the member uses ambiguous in the room.
    ///
    /// A name is considered to be ambiguous if at least one other member shares
    /// the same name.
    pub fn name_ambiguous(&self) -> bool {
        self.display_name_ambiguous
    }

    /// Get the membership state of this member.
    pub fn membership(&self) -> &MembershipState {
        self.event.membership()
    }

    /// Is the room member ignored by the current account user
    pub fn is_ignored(&self) -> bool {
        self.is_ignored
    }

    /// Is the room member a service member.
    pub fn is_service_member(&self) -> bool {
        self.is_service_member
    }
}

// Information about the room a member is in.
pub(crate) struct MemberRoomInfo<'a> {
    pub(crate) power_levels: Arc<RoomPowerLevels>,
    pub(crate) max_power_level: i64,
    pub(crate) users_display_names: HashMap<&'a DisplayName, BTreeSet<OwnedUserId>>,
    pub(crate) ignored_users: Option<BTreeSet<OwnedUserId>>,
    pub(crate) service_members: Option<BTreeSet<OwnedUserId>>,
}

/// The kind of room member updates that just happened.
#[derive(Debug, Clone)]
pub enum RoomMembersUpdate {
    /// The whole list room members was reloaded.
    FullReload,
    /// A few members were updated, their user ids are included.
    Partial(BTreeSet<OwnedUserId>),
}

bitflags! {
    /// Room membership filter as a bitset.
    ///
    /// Note that [`RoomMemberships::empty()`] doesn't filter the results and
    /// [`RoomMemberships::all()`] filters out unknown memberships.
    #[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
    pub struct RoomMemberships: u16 {
        /// The member joined the room.
        const JOIN    = 0b00000001;
        /// The member was invited to the room.
        const INVITE  = 0b00000010;
        /// The member requested to join the room.
        const KNOCK   = 0b00000100;
        /// The member left the room.
        const LEAVE   = 0b00001000;
        /// The member was banned.
        const BAN     = 0b00010000;

        /// The member is active in the room (i.e. joined or invited).
        const ACTIVE = Self::JOIN.bits() | Self::INVITE.bits();
    }
}

impl RoomMemberships {
    /// Whether the given membership matches this `RoomMemberships`.
    pub fn matches(&self, membership: &MembershipState) -> bool {
        if self.is_empty() {
            return true;
        }

        let membership = match membership {
            MembershipState::Ban => Self::BAN,
            MembershipState::Invite => Self::INVITE,
            MembershipState::Join => Self::JOIN,
            MembershipState::Knock => Self::KNOCK,
            MembershipState::Leave => Self::LEAVE,
            _ => return false,
        };

        self.contains(membership)
    }

    /// Get this `RoomMemberships` as a list of matching [`MembershipState`]s.
    pub fn as_vec(&self) -> Vec<MembershipState> {
        let mut memberships = Vec::new();

        if self.contains(Self::JOIN) {
            memberships.push(MembershipState::Join);
        }
        if self.contains(Self::INVITE) {
            memberships.push(MembershipState::Invite);
        }
        if self.contains(Self::KNOCK) {
            memberships.push(MembershipState::Knock);
        }
        if self.contains(Self::LEAVE) {
            memberships.push(MembershipState::Leave);
        }
        if self.contains(Self::BAN) {
            memberships.push(MembershipState::Ban);
        }

        memberships
    }
}

/// Scale the given `power_level` to a range between 0-100.
pub fn normalize_power_level(power_level: Int, max_power_level: i64) -> Int {
    let mut power_level = i64::from(power_level);
    power_level = (power_level * 100) / max_power_level;

    Int::try_from(power_level.clamp(0, 100))
        .expect("We clamped the normalized power level so they must fit into the Int")
}

#[cfg(test)]
mod tests {
    #[cfg(feature = "unstable-msc4426")]
    use matrix_sdk_common::ROOM_VERSION_RULES_FALLBACK;
    #[cfg(feature = "unstable-msc4426")]
    use matrix_sdk_test::event_factory::EventFactory;
    use proptest::prelude::*;
    #[cfg(feature = "unstable-msc4426")]
    use ruma::{
        SecondsSinceUnixEpoch, events::room::power_levels::RoomPowerLevelsSource,
        profile::ProfileFieldValue, user_id,
    };

    use super::*;

    prop_compose! {
        fn arb_int()(id in any::<i64>()) -> Int {
            id.try_into().unwrap_or_default()
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(10_000))]
        #[test]
        fn test_power_level_normalization_with_min_max_level(power_level in arb_int()) {
            let normalized = normalize_power_level(power_level, 1);
            let normalized = i64::from(normalized);

            assert!(normalized >= 0);
            assert!(normalized <= 100);
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(10_000))]
        #[test]
        fn test_power_level_normalization(power_level in arb_int(), max_level in 1i64..) {
            let normalized = normalize_power_level(power_level, max_level);
            let normalized = i64::from(normalized);

            assert!(normalized >= 0);
            assert!(normalized <= 100);
        }
    }

    #[test]
    fn test_power_level_normalization_limits() {
        let level = Int::MIN;
        let normalized = normalize_power_level(level, 1);
        let normalized = i64::from(normalized);
        assert!(normalized >= 0);
        assert!(normalized <= 100);

        let level = Int::MAX;
        let normalized = normalize_power_level(level, 1);
        let normalized = i64::from(normalized);
        assert!(normalized >= 0);
        assert!(normalized <= 100);
    }

    #[cfg(feature = "unstable-msc4426")]
    #[test]
    fn test_global_profile_fields() {
        let user_id = user_id!("@alice:example.org");
        let event = MemberEvent::Sync(EventFactory::new().sender(user_id).member(user_id).into());
        let room_info = MemberRoomInfo {
            power_levels: Arc::new(RoomPowerLevels::new(
                RoomPowerLevelsSource::None,
                &ROOM_VERSION_RULES_FALLBACK.authorization,
                std::iter::empty::<OwnedUserId>(),
            )),
            max_power_level: 100,
            users_display_names: HashMap::new(),
            ignored_users: None,
            service_members: None,
        };

        // Without a global profile, neither field is set.
        let member =
            RoomMember::from_parts(event.clone(), None, None, &event.display_name(), &room_info);
        assert!(member.status().is_none());
        assert!(member.call().is_none());

        // A global profile carrying both m.status and m.call is extracted into
        // both fields.
        let mut call = CallProfileField::new();
        call.call_joined_ts = Some(SecondsSinceUnixEpoch(1_700_000_000u32.into()));
        let global_profile = UserProfile::from_iter([
            ProfileFieldValue::Status(StatusProfileField::new(
                "Working".to_owned(),
                "💻".to_owned(),
            )),
            ProfileFieldValue::Call(call),
        ]);

        let display_name = event.display_name();
        let member =
            RoomMember::from_parts(event, None, Some(global_profile), &display_name, &room_info);

        let status = member.status().expect("status is set");
        assert_eq!(status.text, "Working");
        assert_eq!(status.emoji, "💻");
        assert_eq!(
            member.call().expect("call is set").call_joined_ts,
            Some(SecondsSinceUnixEpoch(1_700_000_000u32.into()))
        );
    }
}
