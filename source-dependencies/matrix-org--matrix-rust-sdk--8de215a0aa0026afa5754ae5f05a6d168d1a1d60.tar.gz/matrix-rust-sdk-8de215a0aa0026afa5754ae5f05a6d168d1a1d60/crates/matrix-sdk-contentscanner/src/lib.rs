// Copyright 2026 The Matrix.org Foundation C.I.C.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#![recursion_limit = "256"]

#[cfg(feature = "e2e-encryption")]
use std::io::Read;
use std::{
    fmt::{Debug, Formatter},
    sync::Arc,
};

use api::{
    download::{
        encrypted::DownloadAndScanEncryptedMediaRequest, unencrypted::DownloadAndScanMediaRequest,
    },
    public_server_key::PublicServerKeyRequest,
};
use matrix_sdk::{
    BoxFuture, Client, Error, IdParseError,
    config::RequestConfig,
    encryption::vodozemac::pk_encryption::Message,
    locks::Mutex,
    media::{MediaFetcher, MediaRequestParameters},
    ruma::events::room::MediaSource,
};
#[cfg(feature = "e2e-encryption")]
use matrix_sdk_crypto::AttachmentDecryptor;
use matrix_sdk_crypto::olm::Curve25519PublicKey;
use ruma::{
    events::room::EncryptedFile,
    serde::{Base64, base64::Standard},
};
use serde::{Deserialize, Serialize};
use tracing::trace;

#[cfg(feature = "uniffi")]
uniffi::setup_scaffolding!();

pub use crate::api::scan::MediaScanResponse;
use crate::api::{
    DownloadAndScanMediaResponse,
    scan::{encrypted::EncryptedMediaScanRequest, unencrypted::MediaScanRequest},
};

mod api;

/// A helper component to download and scan media from a content scanner server.
#[derive(Debug)]
pub struct ContentScanner {
    scanner_url: String,
    public_server_key: Arc<Mutex<Option<String>>>,
}

impl ContentScanner {
    /// Instantiate a new [`ContentScanner`] using the `scanner_url`.
    pub fn new(scanner_url: impl Into<String>) -> Self {
        Self { scanner_url: scanner_url.into(), public_server_key: Arc::new(Mutex::new(None)) }
    }

    pub(crate) async fn fetch_public_server_key(&self, client: &Client) -> Result<String, Error> {
        let response = client.send(PublicServerKeyRequest::new(self.scanner_url.clone())).await?;
        Ok(response.public_key)
    }

    async fn get_or_fetch_public_server_key(&self, client: &Client) -> Option<Curve25519PublicKey> {
        let public_server_key =
            if let Some(public_server_key) = (*self.public_server_key.lock()).clone() {
                trace!("Using cached public server key");
                Some(public_server_key)
            } else {
                trace!("Using cached public server key");
                let ret = self.fetch_public_server_key(client).await.ok();

                if let Some(public_server_key) = &ret {
                    trace!("Saved new public server key");
                    let mut guard = self.public_server_key.lock();
                    let _ = guard.insert(public_server_key.clone());
                }

                ret
            };

        public_server_key.and_then(|key| Curve25519PublicKey::from_base64(&key).ok())
    }

    pub(crate) async fn get_media(
        &self,
        client: &Client,
        media_source: &MediaSource,
        config: Option<RequestConfig>,
    ) -> Result<DownloadAndScanMediaResponse, Error> {
        match &media_source {
            MediaSource::Encrypted(encrypted) => {
                // Get the public server key if we don't have it yet.
                let public_server_key = self.get_or_fetch_public_server_key(client).await;

                Ok(client
                    .send(DownloadAndScanEncryptedMediaRequest::new(
                        self.scanner_url.clone(),
                        public_server_key,
                        *encrypted.clone(),
                    ))
                    .with_request_config(config)
                    .await?)
            }
            MediaSource::Plain(mxc) => {
                let (server_name, media_id) =
                    mxc.parts().map_err(|e| Error::Identifier(IdParseError::InvalidMxcUri(e)))?;
                Ok(client
                    .send(DownloadAndScanMediaRequest::new(
                        &self.scanner_url,
                        server_name.as_str(),
                        media_id,
                    ))
                    .await?)
            }
        }
    }

    /// Scan a media source, returning a [`MediaScanResponse`] with the scan
    /// result, or an error if something failed when trying to scan the media.
    pub async fn scan(
        &self,
        client: &Client,
        media_source: &MediaSource,
    ) -> Result<MediaScanResponse, Error> {
        match &media_source {
            MediaSource::Encrypted(encrypted) => {
                // Get the public server key if we don't have it yet.
                let public_server_key = self.get_or_fetch_public_server_key(client).await;

                Ok(client
                    .send(EncryptedMediaScanRequest::new(
                        self.scanner_url.clone(),
                        public_server_key,
                        *encrypted.clone(),
                    ))
                    .await?)
            }
            MediaSource::Plain(mxc) => {
                let (server_name, media_id) =
                    mxc.parts().map_err(|e| Error::Identifier(IdParseError::InvalidMxcUri(e)))?;
                Ok(client
                    .send(MediaScanRequest::new(
                        self.scanner_url.clone(),
                        server_name.to_string(),
                        media_id.to_owned(),
                    ))
                    .await?)
            }
        }
    }
}

#[derive(Debug, Clone, Serialize)]
struct EncryptedBody {
    ciphertext: String,
    mac: String,
    ephemeral: String,
}

impl From<Message> for EncryptedBody {
    fn from(value: Message) -> Self {
        Self {
            ciphertext: Base64::<Standard>::new(value.ciphertext).to_string(),
            mac: Base64::<Standard>::new(value.mac).to_string(),
            ephemeral: value.ephemeral_key.to_base64(),
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub(crate) struct EncryptedFileRequest {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub file: Option<EncryptedFile>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub encrypted_body: Option<EncryptedBody>,
}

impl EncryptedFileRequest {
    pub(crate) fn from_file_info(file_info: EncryptedFile) -> Self {
        Self { file: Some(file_info), encrypted_body: None }
    }

    pub(crate) fn from_encrypted_body(encrypted_body: EncryptedBody) -> Self {
        Self { file: None, encrypted_body: Some(encrypted_body) }
    }
}

/// A media fetcher that uses the content scanner to download and scan media.
pub struct ContentScannerMediaFetcher {
    pub content_scanner: Arc<ContentScanner>,
}

impl ContentScannerMediaFetcher {
    /// Instantiate a new [`MediaFetcher`] using the provided `scanner_url`.
    pub fn new(scanner_url: impl Into<String>) -> Self {
        Self { content_scanner: Arc::new(ContentScanner::new(scanner_url.into())) }
    }

    pub fn with_content_scanner(content_scanner: Arc<ContentScanner>) -> Self {
        Self { content_scanner }
    }

    async fn fetch_media_inner(
        &self,
        client: &Client,
        request: &MediaRequestParameters,
        request_config: Option<RequestConfig>,
    ) -> matrix_sdk::Result<Vec<u8>, Error> {
        let content =
            self.content_scanner.get_media(client, &request.source, request_config).await?.content;
        #[cfg(feature = "e2e-encryption")]
        let content = {
            match &request.source {
                MediaSource::Encrypted(file) => {
                    let content_len = content.len();
                    let mut cursor = std::io::Cursor::new(content);
                    let mut reader =
                        AttachmentDecryptor::new(&mut cursor, file.as_ref().clone().into())?;

                    // Encrypted size should be the same as the decrypted size,
                    // rounded up to a cipher block.
                    let mut decrypted = Vec::with_capacity(content_len);

                    reader.read_to_end(&mut decrypted)?;

                    decrypted
                }
                MediaSource::Plain(_) => content,
            }
        };
        Ok(content)
    }
}

impl MediaFetcher for ContentScannerMediaFetcher {
    fn fetch_media_content<'a>(
        &'a self,
        client: &'a Client,
        request: &'a MediaRequestParameters,
    ) -> BoxFuture<'a, matrix_sdk::Result<Vec<u8>, Error>> {
        Box::pin(self.fetch_media_inner(client, request, None))
    }

    fn fetch_media_content_with_config<'a>(
        &'a self,
        client: &'a Client,
        request: &'a MediaRequestParameters,
        request_config: RequestConfig,
    ) -> BoxFuture<'a, matrix_sdk::Result<Vec<u8>, Error>> {
        Box::pin(self.fetch_media_inner(client, request, Some(request_config)))
    }
}

impl Debug for ContentScannerMediaFetcher {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        f.write_str("ContentScannerMediaFetcher")
    }
}

/// A content scanner error.
#[derive(Debug, Deserialize)]
pub struct ContentScannerError {
    pub info: String,
    pub reason: ErrorReason,
}

/// The reason for the content scanner error.
#[allow(non_camel_case_types)]
#[cfg_attr(feature = "uniffi", derive(uniffi::Enum))]
#[derive(Clone, Debug, Deserialize)]
pub enum ErrorReason {
    /// The JSON file is malformed.
    MCS_MALFORMED_JSON,
    /// The media could not be decrypted.
    MCS_MEDIA_FAILED_TO_DECRYPT,
    /// No access token was provided.
    M_MISSING_TOKEN,
    /// The access token provided is invalid.
    M_UNKNOWN_TOKEN,
    /// The media was not found.
    M_NOT_FOUND,
    /// The media has some potentially dangerous content.
    MCS_MEDIA_NOT_CLEAN,
    /// The media has been blocked by the server because of its mime type.
    MCS_MIME_TYPE_FORBIDDEN,
    /// The used public key is wrong.
    MCS_BAD_DECRYPTION,
    /// An unknown error occurred.
    M_UNKNOWN,
    /// The server failed to request media from the media repo.
    MCS_MEDIA_REQUEST_FAILED,
}

#[cfg(test)]
mod tests {
    #[cfg(feature = "e2e-encryption")]
    use std::sync::Arc;
    use std::{assert_matches, ops::Not};

    #[cfg(feature = "e2e-encryption")]
    use matrix_sdk::media::{MediaFormat, MediaRequestParameters};
    use matrix_sdk::{HttpError, RumaApiError, test_utils::mocks::MatrixMockServer};
    use matrix_sdk_test::async_test;
    use ruma::{
        api::{
            MatrixVersion,
            error::{ErrorBody, FromHttpResponseError},
        },
        events::room::{
            EncryptedFile, EncryptedFileHash, EncryptedFileHashes, EncryptedFileInfo, MediaSource,
            V2EncryptedFileInfo,
        },
        exports::{http::StatusCode, serde_json::json},
        owned_mxc_uri,
        serde::Base64,
    };
    use serde::Deserialize;
    use strass::assert_let;
    use wiremock::{
        Mock, MockServer, ResponseTemplate,
        matchers::{header_exists, method, path, path_regex},
    };

    #[cfg(feature = "e2e-encryption")]
    use crate::ContentScannerMediaFetcher;
    use crate::{ContentScanner, ContentScannerError, ErrorReason};

    #[async_test]
    async fn test_fetch_public_key() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/_matrix/media_proxy/unstable/public_key"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "public_key": "1234567890"
            })))
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        content_scanner.fetch_public_server_key(&client).await.expect("Load public key");
    }

    #[async_test]
    async fn test_get_media() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path_regex(r"/_matrix/media_proxy/unstable/download/.+/.+"))
            .and(header_exists("Authorization"))
            .respond_with(
                ResponseTemplate::new(200).set_body_bytes(vec![1, 2, 3, 4, 5, 6, 7, 8, 9]),
            )
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let media_source =
            MediaSource::Plain(owned_mxc_uri!("mxc://matrix.org/RhfpOXOzAwzkuqcmbgMwQUrJ"));
        content_scanner.get_media(&client, &media_source, None).await.expect("Get media");
    }

    #[async_test]
    async fn test_get_media_unsupported() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path_regex(r"/_matrix/media_proxy/unstable/download/.+/.+"))
            .and(header_exists("Authorization"))
            .respond_with(ResponseTemplate::new(403).set_body_json(json!({
                "reason": "MCS_MIME_TYPE_FORBIDDEN",
                "info": "File type: application/octet-stream not allowed",
            })))
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let media_source =
            MediaSource::Plain(owned_mxc_uri!("mxc://matrix.org/ckTaStcNnFXLzKApkBmgRDoC"));
        let err = content_scanner
            .get_media(&client, &media_source, None)
            .await
            .expect_err("Get media error");
        let client_error = err.as_client_api_error().expect("Get client error");
        assert_eq!(client_error.status_code, StatusCode::FORBIDDEN);
        assert_eq!(
            client_error.to_string(),
            "[403] {\"info\":\"File type: application/octet-stream not allowed\",\"reason\":\"MCS_MIME_TYPE_FORBIDDEN\"}"
        );
    }

    #[async_test]
    async fn test_get_encrypted_media() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("POST"))
            .and(path("/_matrix/media_proxy/unstable/download_encrypted"))
            .and(header_exists("Authorization"))
            .respond_with(
                ResponseTemplate::new(200).set_body_bytes(vec![1, 2, 3, 4, 5, 6, 7, 8, 9]),
            )
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let file_info = EncryptedFileInfo::V2(V2EncryptedFileInfo::new(
            Base64::parse("9lpOscZyMOZRCF3v867nPPo3WPNMZt9JXMsuYiWRszc".as_bytes()).expect("k"),
            Base64::parse("czvdfKSjfLEAAAAAAAAAAA".as_bytes()).expect("iv"),
        ));
        let mut hashes = EncryptedFileHashes::new();
        hashes.insert(EncryptedFileHash::Sha256(
            Base64::parse("SBbJ3hINT2LgwXK8ev82enjnhubUy5UuKGDF3SezAhs".as_bytes()).expect("hash"),
        ));
        let media_source = MediaSource::Encrypted(Box::new(EncryptedFile::new(
            owned_mxc_uri!(
                "mxc://element.io/b50f38aa8ae820c75992370e4e944a045481e3932057062074730676224"
            ),
            file_info,
            hashes,
        )));
        content_scanner.get_media(&client, &media_source, None).await.expect("Get media");
    }

    #[async_test]
    async fn test_get_encrypted_media_unsupported() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;

        Mock::given(method("POST"))
            .and(path("/_matrix/media_proxy/unstable/download_encrypted"))
            .and(header_exists("Authorization"))
            .respond_with(ResponseTemplate::new(403).set_body_json(json!({
                "reason": "MCS_MIME_TYPE_FORBIDDEN",
                "info": "File type: application/octet-stream not allowed",
            })))
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let file_info = EncryptedFileInfo::V2(V2EncryptedFileInfo::new(
            Base64::parse("tdHdCI5mc-g29IYfhYx2wkA5o-bILP9-nXY6Np1uSnM".as_bytes()).expect("k"),
            Base64::parse("IBFdH65KqhoAAAAAAAAAAA".as_bytes()).expect("iv"),
        ));
        let mut hashes = EncryptedFileHashes::new();
        hashes.insert(EncryptedFileHash::Sha256(
            Base64::parse("HSkkamvMSvF3Q30HInorh0ccPrxjgu+wp1vyUOmov/8".as_bytes()).expect("hash"),
        ));
        let media_source = MediaSource::Encrypted(Box::new(EncryptedFile::new(
            owned_mxc_uri!("mxc://matrix.org/WlfuejQQdpvWiWVpAGwfIKJL"),
            file_info,
            hashes,
        )));
        let err = content_scanner
            .get_media(&client, &media_source, None)
            .await
            .expect_err("Invalid type error");
        let client_error = err.as_client_api_error().expect("Invalid error");
        assert_eq!(client_error.status_code, StatusCode::FORBIDDEN);
        assert_eq!(
            client_error.to_string(),
            "[403] {\"info\":\"File type: application/octet-stream not allowed\",\"reason\":\"MCS_MIME_TYPE_FORBIDDEN\"}"
        );
    }

    #[async_test]
    async fn test_scan_media() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path_regex(r"/_matrix/media_proxy/unstable/scan/.+/.+"))
            .and(header_exists("Authorization"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "clean": true,
                "info": "All clear!"
            })))
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let media_source =
            MediaSource::Plain(owned_mxc_uri!("mxc://matrix.org/RhfpOXOzAwzkuqcmbgMwQUrJ"));
        let response = content_scanner.scan(&client, &media_source).await.expect("Get media");
        assert!(response.clean);
    }

    #[async_test]
    async fn test_scan_encrypted_media() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("POST"))
            .and(path("/_matrix/media_proxy/unstable/scan_encrypted"))
            .and(header_exists("Authorization"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "clean": true,
                "info": "All clear!"
            })))
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let file_info = EncryptedFileInfo::V2(V2EncryptedFileInfo::new(
            Base64::parse("9lpOscZyMOZRCF3v867nPPo3WPNMZt9JXMsuYiWRszc".as_bytes()).expect("k"),
            Base64::parse("czvdfKSjfLEAAAAAAAAAAA".as_bytes()).expect("iv"),
        ));
        let mut hashes = EncryptedFileHashes::new();
        hashes.insert(EncryptedFileHash::Sha256(
            Base64::parse("SBbJ3hINT2LgwXK8ev82enjnhubUy5UuKGDF3SezAhs".as_bytes()).expect("hash"),
        ));
        let media_source = MediaSource::Encrypted(Box::new(EncryptedFile::new(
            owned_mxc_uri!(
                "mxc://element.io/b50f38aa8ae820c75992370e4e944a045481e3932057062074730676224"
            ),
            file_info,
            hashes,
        )));
        let response = content_scanner.scan(&client, &media_source).await.expect("Get media");
        assert!(response.clean);
    }

    #[async_test]
    async fn test_scan_media_unsupported() {
        let server = MatrixMockServer::new().await;
        let client =
            server.client_builder().server_versions(vec![MatrixVersion::V1_11]).build().await;

        let content_scanner_server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path_regex(r"/_matrix/media_proxy/unstable/scan/.+/.+"))
            .and(header_exists("Authorization"))
            .respond_with(
                // This always returns a 200 status code for scan results, even for failures
                ResponseTemplate::new(200).set_body_json(json!({
                    "clean": false,
                    "info": "***VIRUS DETECTED***"
                })),
            )
            .mount(&content_scanner_server)
            .await;

        let content_scanner = ContentScanner::new(content_scanner_server.uri());
        let media_source =
            MediaSource::Plain(owned_mxc_uri!("mxc://matrix.org/RhfpOXOzAwzkuqcmbgMwQUrJ"));
        let response = content_scanner.scan(&client, &media_source).await.expect("Get media");
        assert!(response.clean.not());
    }

    #[test]
    fn test_error_mapping() {
        let error = HttpError::Api(Box::new(FromHttpResponseError::Server(
            RumaApiError::MatrixError(ruma::api::error::Error::new(
                StatusCode::FORBIDDEN,
                ErrorBody::Json(json!({
                    "info": "***VIRUS DETECTED***",
                    "reason": "MCS_MEDIA_NOT_CLEAN"
                })),
            )),
        )));
        let api_error = error.as_client_api_error().expect("error as api error");
        assert_eq!(
            api_error.to_string(),
            "[403] {\"info\":\"***VIRUS DETECTED***\",\"reason\":\"MCS_MEDIA_NOT_CLEAN\"}"
        );
        assert_let!(ErrorBody::Json(json_body) = &api_error.body);
        let content_scanner_error =
            ContentScannerError::deserialize(json_body).expect("deserialize");
        assert_eq!(content_scanner_error.info, "***VIRUS DETECTED***");
        assert_matches!(content_scanner_error.reason, ErrorReason::MCS_MEDIA_NOT_CLEAN);
    }

    #[cfg(feature = "e2e-encryption")]
    #[async_test]
    async fn test_content_scanner_media_fetcher_decrypts_media() {
        let server = MatrixMockServer::new().await;

        let media_fetcher = Arc::new(ContentScannerMediaFetcher::new(server.uri()));

        let client = server
            .client_builder()
            .on_builder(|builder| builder.media_fetcher(media_fetcher.clone()))
            .server_versions(vec![MatrixVersion::V1_11])
            .build()
            .await;

        // The original (unencrypted) media content
        let original = vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
        // The encrypted media content to return
        let encrypted: Vec<u8> = vec![0xEA, 0x10, 0x2D, 0x01, 0x53, 0xB7, 0x87, 0xF0, 0x75, 0xED];

        // Set up the mock server as the content scanner one, with the expected
        // endpoint
        Mock::given(method("POST"))
            .and(path("/_matrix/media_proxy/unstable/download_encrypted"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(encrypted.clone()))
            .expect(1)
            .mount(server.server())
            .await;

        let mut hashes = EncryptedFileHashes::new();
        // The SHA256 hash of the unencrypted bytes
        hashes.insert(EncryptedFileHash::Sha256(
            Base64::parse("HT/BV9JX7tQgtvLt9NQs914ytE8kp4V6cBGN6SAU/do".as_bytes())
                .expect("Hash deserialization"),
        ));

        let request = MediaRequestParameters {
            source: MediaSource::Encrypted(Box::new(EncryptedFile::new(
                owned_mxc_uri!("mxc://example.com/1234"),
                EncryptedFileInfo::V2(V2EncryptedFileInfo::new(
                    Base64::parse("QRsQvqumCgRLrZEMTZIc-DU-08Lak2c1dBQC6u5x7rE".as_bytes())
                        .expect("k"),
                    Base64::parse("uMwbioRbD6EAAAAAAAAAAA".as_bytes()).expect("iv"),
                )),
                hashes,
            ))),
            format: MediaFormat::File,
        };

        // If there was a decryption error, we'd be able to check the decryption
        // took place
        let result = client
            .media()
            .get_media_content(&request, false)
            .await
            .expect("Get media content from mock server");

        // Check the original media content matches the decrypted downloaded one
        assert_eq!(original, result);
    }
}
