DROP TABLE "secrets"
