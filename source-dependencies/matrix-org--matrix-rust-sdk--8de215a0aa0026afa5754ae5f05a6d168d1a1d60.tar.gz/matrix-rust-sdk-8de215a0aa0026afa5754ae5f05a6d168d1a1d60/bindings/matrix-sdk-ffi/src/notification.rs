// Copyright 2025 The Matrix.org Foundation C.I.C.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for that specific language governing permissions and
// limitations under the License.

use std::{collections::HashMap, sync::Arc, time::Duration};

use matrix_sdk_ui::notification_client::{
    NotificationClient as SdkNotificationClient,
    NotificationClientTimeouts as SdkNotificationClientTimeouts,
    NotificationEvent as SdkNotificationEvent, NotificationItem as SdkNotificationItem,
    NotificationStatus as SdkNotificationStatus, RawNotificationEvent as SdkRawNotificationEvent,
};
use ruma::{EventId, OwnedEventId, OwnedRoomId, RoomId};

use crate::{
    client::{Client, JoinRule},
    error::ClientError,
    event::TimelineEvent,
    room::Room,
};

#[derive(uniffi::Enum)]
pub enum NotificationEvent {
    Timeline { event: Arc<TimelineEvent> },
    Invite { sender: String },
}

#[derive(uniffi::Record)]
pub struct NotificationSenderInfo {
    pub display_name: Option<String>,
    pub avatar_url: Option<String>,
    pub is_name_ambiguous: bool,
}

#[derive(uniffi::Record)]
pub struct NotificationRoomInfo {
    pub display_name: String,
    pub avatar_url: Option<String>,
    pub canonical_alias: Option<String>,
    pub topic: Option<String>,
    pub join_rule: Option<JoinRule>,
    pub joined_members_count: u64,
    pub active_service_members_count: u64,
    pub service_members: Vec<String>,
    pub is_encrypted: Option<bool>,
    pub is_direct: bool,
    pub is_space: bool,
    pub is_dm: bool,
}

#[derive(uniffi::Record)]
pub struct NotificationItem {
    pub event: NotificationEvent,

    /// The raw JSON of the underlying event.
    pub raw_event: String,

    pub sender_info: NotificationSenderInfo,
    pub room_info: NotificationRoomInfo,

    /// Is the notification supposed to be at the "noisy" level? Can be `None`
    /// if we couldn't determine this, because we lacked information to create a
    /// push context.
    pub is_noisy: Option<bool>,
    pub has_mention: Option<bool>,
    pub thread_id: Option<String>,

    /// The push actions for this notification (notify, sound, highlight, etc.).
    pub actions: Option<Vec<crate::notification_settings::Action>>,
}

impl NotificationItem {
    fn from_inner(item: SdkNotificationItem) -> Self {
        let event = match item.event {
            SdkNotificationEvent::Timeline(event) => {
                NotificationEvent::Timeline { event: Arc::new(TimelineEvent(event)) }
            }
            SdkNotificationEvent::Invite(event) => {
                NotificationEvent::Invite { sender: event.sender.to_string() }
            }
        };

        let raw_event = match &item.raw_event {
            SdkRawNotificationEvent::Timeline(raw) => raw.json().get().to_owned(),
            SdkRawNotificationEvent::Invite(raw) => raw.json().get().to_owned(),
        };

        Self {
            event,
            raw_event,
            sender_info: NotificationSenderInfo {
                display_name: item.sender_display_name,
                avatar_url: item.sender_avatar_url,
                is_name_ambiguous: item.is_sender_name_ambiguous,
            },
            room_info: NotificationRoomInfo {
                display_name: item.room_computed_display_name,
                avatar_url: item.room_avatar_url,
                canonical_alias: item.room_canonical_alias,
                topic: item.room_topic,
                join_rule: item.room_join_rule.map(TryInto::try_into).transpose().ok().flatten(),
                joined_members_count: item.joined_members_count,
                service_members: item.service_members,
                active_service_members_count: item.active_service_members_count,
                is_encrypted: item.is_room_encrypted,
                is_direct: item.is_direct_message_room,
                is_space: item.is_space,
                is_dm: item.room_is_dm,
            },
            is_noisy: item.is_noisy,
            has_mention: item.has_mention,
            thread_id: item.thread_id.map(|t| t.to_string()),
            actions: item
                .actions
                .map(|a| a.into_iter().filter_map(|action| action.try_into().ok()).collect()),
        }
    }
}

#[allow(clippy::large_enum_variant)]
#[derive(uniffi::Enum)]
pub enum NotificationStatus {
    /// The event has been found and was not filtered out.
    Event { item: NotificationItem },
    /// The event couldn't be found in the network queries used to find it.
    EventNotFound,
    /// The event has been filtered out, either because of the user's push
    /// rules, or because the user which triggered it is ignored by the current
    /// user.
    EventFilteredOut,
    /// The event has been redacted.
    EventRedacted,
}

impl From<SdkNotificationStatus> for NotificationStatus {
    fn from(item: SdkNotificationStatus) -> Self {
        match item {
            SdkNotificationStatus::Event(item) => {
                NotificationStatus::Event { item: NotificationItem::from_inner(*item) }
            }
            SdkNotificationStatus::EventNotFound => NotificationStatus::EventNotFound,
            SdkNotificationStatus::EventFilteredOut => NotificationStatus::EventFilteredOut,
            SdkNotificationStatus::EventRedacted => NotificationStatus::EventRedacted,
        }
    }
}

#[allow(clippy::large_enum_variant)]
#[derive(uniffi::Enum)]
pub enum BatchNotificationResult {
    /// We have more detailed information about the notification.
    Ok { status: NotificationStatus },
    /// An error occurred while trying to fetch the notification.
    Error {
        /// The error message observed while handling a specific notification.
        message: String,
    },
}

/// Timeouts applied by a `NotificationClient` while fetching the content of
/// notifications.
#[derive(Clone, uniffi::Record)]
pub struct NotificationClientTimeouts {
    /// Long-poll timeout of the sliding sync request retrieving the notified
    /// events, i.e. how long the homeserver waits for the events to be
    /// available before answering.
    pub sync_poll_timeout: Duration,

    /// Extra time allowed for the network round trip of the sliding sync
    /// request retrieving the notified events, on top of `sync_poll_timeout`.
    pub sync_network_timeout: Duration,

    /// Maximum time spent waiting for a missing room key, when an event in a
    /// notification can't be decrypted.
    ///
    /// This bounds both the encryption sync the notification client runs
    /// itself, after a minimum number of iterations, and the wait for the app's
    /// own encryption sync to receive the key when that sync is already running
    /// in the same process. In both cases the wait ends as soon as the event
    /// can be decrypted, and the event is returned undecrypted once the
    /// deadline has passed.
    pub decryption_deadline: Duration,

    /// Long-poll timeout of each request of the encryption sync run to obtain a
    /// missing room key, i.e. how long the homeserver waits for a to-device
    /// message to arrive before answering.
    ///
    /// Together with `decryption_deadline`, this determines how many iterations
    /// are run when the homeserver has nothing to return.
    pub encryption_sync_poll_timeout: Duration,

    /// Extra time allowed for the network round trip of each request of the
    /// encryption sync, on top of `encryption_sync_poll_timeout`. This is an
    /// upper bound on how long a request may take.
    pub encryption_sync_network_timeout: Duration,
}

impl From<SdkNotificationClientTimeouts> for NotificationClientTimeouts {
    fn from(value: SdkNotificationClientTimeouts) -> Self {
        Self {
            sync_poll_timeout: value.sync_poll_timeout,
            sync_network_timeout: value.sync_network_timeout,
            decryption_deadline: value.decryption_deadline,
            encryption_sync_poll_timeout: value.encryption_sync_poll_timeout,
            encryption_sync_network_timeout: value.encryption_sync_network_timeout,
        }
    }
}

impl From<NotificationClientTimeouts> for SdkNotificationClientTimeouts {
    fn from(value: NotificationClientTimeouts) -> Self {
        Self {
            sync_poll_timeout: value.sync_poll_timeout,
            sync_network_timeout: value.sync_network_timeout,
            decryption_deadline: value.decryption_deadline,
            encryption_sync_poll_timeout: value.encryption_sync_poll_timeout,
            encryption_sync_network_timeout: value.encryption_sync_network_timeout,
        }
    }
}

#[derive(uniffi::Object)]
pub struct NotificationClient {
    pub(crate) inner: SdkNotificationClient,

    /// A reference to the FFI client.
    ///
    /// Note: we do this to make it so that the FFI `NotificationClient` keeps
    /// the FFI `Client` and thus the SDK `Client` alive. Otherwise, we would
    /// need to repeat the hack done in the FFI `Client::drop` method.
    pub(crate) client: Arc<Client>,
}

#[matrix_sdk_ffi_macros::export]
impl NotificationClient {
    /// Fetches a room by its ID using the in-memory state store backed client.
    ///
    /// Useful to retrieve room information after running the limited
    /// notification client sliding sync loop.
    pub fn get_room(&self, room_id: String) -> Result<Option<Arc<Room>>, ClientError> {
        let room_id = RoomId::parse(room_id)?;
        let sdk_room = self.inner.get_room(&room_id);
        let room = sdk_room
            .map(|room| Arc::new(Room::new(room, self.client.utd_hook_manager.get().cloned())));
        Ok(room)
    }

    /// Returns the timeouts applied while fetching notifications.
    pub fn timeouts(&self) -> NotificationClientTimeouts {
        (*self.inner.timeouts()).into()
    }

    /// Fetches the content of a notification.
    ///
    /// This will first try to get the notification using a short-lived sliding
    /// sync, and if the sliding-sync can't find the event, then it'll use a
    /// `/context` query to find the event with associated member information.
    ///
    /// An error result means that we couldn't resolve the notification; in that
    /// case, a dummy notification may be displayed instead.
    pub async fn get_notification(
        &self,
        room_id: String,
        event_id: String,
    ) -> Result<NotificationStatus, ClientError> {
        let room_id = RoomId::parse(room_id)?;
        let event_id = EventId::parse(event_id)?;

        let item =
            self.inner.get_notification(&room_id, &event_id).await.map_err(ClientError::from)?;

        Ok(item.into())
    }

    /// Get several notification items in a single batch.
    ///
    /// Returns an error if the flow failed when preparing to fetch the
    /// notifications, and a [`HashMap`] containing either a
    /// [`BatchNotificationResult`], that indicates if the notification was
    /// successfully fetched (in which case, it's a [`NotificationStatus`]), or
    /// an error message if it couldn't be fetched.
    pub async fn get_notifications(
        &self,
        requests: Vec<NotificationItemsRequest>,
    ) -> Result<HashMap<String, BatchNotificationResult>, ClientError> {
        let requests =
            requests.into_iter().map(TryInto::try_into).collect::<Result<Vec<_>, _>>()?;

        let items = self.inner.get_notifications(&requests).await?;

        let mut batch_result = HashMap::new();
        for (key, value) in items.into_iter() {
            let result = match value {
                Ok(status) => BatchNotificationResult::Ok { status: status.into() },
                Err(error) => BatchNotificationResult::Error { message: error.to_string() },
            };
            batch_result.insert(key.to_string(), result);
        }

        Ok(batch_result)
    }
}

/// A request for notification items grouped by their room.
#[derive(uniffi::Record)]
pub struct NotificationItemsRequest {
    room_id: String,
    event_ids: Vec<String>,
}

impl NotificationItemsRequest {
    /// The parsed [`OwnedRoomId`] to use with the SDK crates.
    pub fn room_id(&self) -> Result<OwnedRoomId, ClientError> {
        RoomId::parse(&self.room_id).map_err(ClientError::from)
    }

    /// The parsed [`OwnedEventId`] list to use with the SDK crates.
    pub fn event_ids(&self) -> Result<Vec<OwnedEventId>, ClientError> {
        self.event_ids
            .iter()
            .map(|id| EventId::parse(id).map_err(ClientError::from))
            .collect::<Result<Vec<_>, _>>()
    }
}

impl TryFrom<NotificationItemsRequest>
    for matrix_sdk_ui::notification_client::NotificationItemsRequest
{
    type Error = ClientError;
    fn try_from(value: NotificationItemsRequest) -> Result<Self, Self::Error> {
        Ok(Self { room_id: value.room_id()?, event_ids: value.event_ids()? })
    }
}
