//
//  CoberturaCoverageConverter.swift
//  xcresult2text
//
//  Created by Eliot Lash on 12.07.22.
//
/**
 MIT License

 Copyright (c) 2020 Thibault Wittemberg

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */

import Foundation

enum JSONParseError: Error {
    case convertError(code: Int, message: String)
}

public class CoberturaCoverageConverter: CoverageConverter, XmlSerializable {
    public var xmlString: String {
        do {
            return try xmlString(quiet: true)
        } catch {
            return "Error creating coverage xml: \(error.localizedDescription)"
        }
    }

    override public func xmlString(quiet: Bool) throws -> String {
        let dtd = readDTD()
        dtd.name = "coverage"
        // dtd.systemID = "http://cobertura.sourceforge.net/xml/coverage-04.dtd"
        dtd.systemID =
            "https://github.com/cobertura/cobertura/blob/master/cobertura/src/site/htdocs/xml/coverage-04.dtd"

        let rootElement = makeRootElement()

        let doc = XMLDocument(rootElement: rootElement)
        doc.version = "1.0"
        doc.dtd = dtd
        doc.documentContentKind = XMLDocument.ContentKind.xml

        let sourceElement = XMLElement(name: "sources")
        rootElement.addChild(sourceElement)
        sourceElement.addChild(XMLElement(name: "source", stringValue: projectRoot.isEmpty ? "." : projectRoot))

        let packagesElement = XMLElement(name: "packages")
        rootElement.addChild(packagesElement)

        // Get the xccov results as a JSON.
        let coverageJson = try getCoverageDataAsJSON()

        var fileInfo = [FileInfo]()
        for (fileName, value) in coverageJson.files {
            guard isTargetIncluded(forFile: fileName) else {
                continue
            }
            guard !isPathExcluded(fileName) else {
                continue
            }
            let relativePath = fileName.relativePath(relativeTo: projectRoot)
            if strictPathnames,
               relativePath == nil {
                continue
            }
            var fileLines = [LineInfo]() // This will store information about each line.

            for lineData in value {
                let lineNum = lineData.line
                guard let covered = lineData.executionCount else {
                    continue
                }
                let line = LineInfo(lineNumber: String(lineNum), coverage: covered)
                fileLines.append(line)
            }

            let fileInfoInst = FileInfo(path: relativePath ?? fileName, lines: fileLines)
            fileInfo.append(fileInfoInst)
        }
        // Sort files to avoid duplicated packages
        fileInfo.sort { $0.path > $1.path }

        var currentPackage = ""
        var currentPackageElement: XMLElement!
        var isNewPackage = false

        var currentClassesElement = XMLElement()

        for file in fileInfo {
            let pathComponents = file.path.split(separator: "/")
            let packageName = createValidPackageName(from: pathComponents)

            isNewPackage = currentPackage != packageName

            if isNewPackage {
                currentPackageElement = XMLElement(name: "package")
                currentClassesElement = XMLElement()
                packagesElement.addChild(currentPackageElement)
            }

            currentPackage = packageName
            if isNewPackage {
                let packageLineCoverage = calculatePackageLineCoverage(for: packageName, in: fileInfo)
                currentPackageElement.addAttribute(XMLNode.nodeAttribute(withName: "name", stringValue: packageName))
                currentPackageElement.addAttribute(XMLNode.nodeAttribute(withName: "line-rate", stringValue: "\(packageLineCoverage)"))
                currentPackageElement.addAttribute(XMLNode.nodeAttribute(withName: "branch-rate", stringValue: "1.0"))
                currentPackageElement.addAttribute(XMLNode.nodeAttribute(withName: "complexity", stringValue: "0.0"))
                currentClassesElement = XMLElement(name: "classes")
                currentPackageElement.addChild(currentClassesElement)
            }

            let classElement = XMLElement(name: "class")
            let className = createValidClassName(from: file.path, packageName: packageName)
            classElement.addAttribute(XMLNode.nodeAttribute(withName: "name", stringValue: className))
            classElement.addAttribute(XMLNode.nodeAttribute(withName: "filename", stringValue: file.path))

            let fileLineCoverage = Float(file.lines.count(where: { $0.coverage > 0 })) / Float(file.lines.count)
            classElement.addAttribute(XMLNode.nodeAttribute(withName: "line-rate", stringValue: "\(fileLineCoverage)"))
            classElement.addAttribute(XMLNode.nodeAttribute(withName: "branch-rate", stringValue: "1.0"))
            classElement.addAttribute(XMLNode.nodeAttribute(withName: "complexity", stringValue: "0.0"))
            currentClassesElement.addChild(classElement)

            // Add empty methods element as required by DTD
            let methodsElement = XMLElement(name: "methods")
            classElement.addChild(methodsElement)

            let linesElement = XMLElement(name: "lines")
            classElement.addChild(linesElement)

            for line in file.lines {
                let lineElement = XMLElement(name: "line")
                lineElement.addAttribute(XMLNode.nodeAttribute(withName: "number", stringValue: "\(line.lineNumber)"))
                lineElement.addAttribute(XMLNode.nodeAttribute(withName: "branch", stringValue: "false"))
                lineElement.addAttribute(XMLNode.nodeAttribute(withName: "hits", stringValue: "\(line.coverage)"))
                linesElement.addChild(lineElement)
            }
        }

        return doc.xmlString(options: [.nodePrettyPrint, .nodeCompactEmptyElement])
    }

    private func readDTD() -> XMLDTD {
        do {
            return try XMLDTD(data: Data(dtd04.utf8))
        } catch {
            fatalError("DTD could not be constructed. Error: \(error.localizedDescription)")
        }
    }

    private func makeRootElement() -> XMLElement {
        // Cobertura requires these attributes; branch/complexity values are placeholders for now.
        let timeStamp = startTime ?? Date().timeIntervalSince1970
        let rootElement = XMLElement(name: "coverage")
        rootElement.addAttribute(
            XMLNode.nodeAttribute(withName: "line-rate", stringValue: "\(lineCoverage)")
        )
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "branch-rate", stringValue: "1.0"))
        rootElement.addAttribute(
            XMLNode.nodeAttribute(withName: "lines-covered", stringValue: "\(coveredLines)")
        )
        rootElement.addAttribute(
            XMLNode.nodeAttribute(withName: "lines-valid", stringValue: "\(executableLines)")
        )
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "timestamp", stringValue: "\(timeStamp)"))
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "version", stringValue: "diff_coverage 0.1"))
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "complexity", stringValue: "0.0"))
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "branches-valid", stringValue: "1.0"))
        rootElement.addAttribute(XMLNode.nodeAttribute(withName: "branches-covered", stringValue: "1.0"))

        return rootElement
    }

    // Keep DTD inline to avoid runtime fetches and bundle/file lookup issues.
    // Helper methods for creating valid Cobertura XML structure
    private func createValidPackageName(from pathComponents: [Substring]) -> String {
        // Use original simple logic: join all path components except the filename with dots
        return pathComponents[0 ..< pathComponents.count - 1].joined(separator: ".")
    }

    private func createValidClassName(from filePath: String, packageName: String) -> String {
        let baseName = (filePath as NSString).deletingPathExtension
        return "\(packageName).\(baseName)"
    }

    private func calculatePackageLineCoverage(for packageName: String, in fileInfoArray: [FileInfo]) -> Float {
        let packageFiles = fileInfoArray.filter { file in
            let pathComponents = file.path.split(separator: "/")
            let filePackageName = createValidPackageName(from: pathComponents)
            return filePackageName == packageName
        }

        guard !packageFiles.isEmpty else { return 0.0 }

        let totalLines = packageFiles.reduce(0) { $0 + $1.lines.count }
        let coveredLines = packageFiles.reduce(0) { total, file in
            total + file.lines.count(where: { $0.coverage > 0 })
        }

        return totalLines > 0 ? Float(coveredLines) / Float(totalLines) : 0.0
    }

    private var dtd04 = """
    <!-- Portions (C) International Organization for Standardization 1986:
         Permission to copy in any form is granted for use with
         conforming SGML systems and applications as defined in
         ISO 8879, provided this notice is included in all copies.
    -->

      <!ELEMENT coverage (sources?,packages)>
      <!ATTLIST coverage line-rate        CDATA #REQUIRED>
      <!ATTLIST coverage branch-rate      CDATA #REQUIRED>
      <!ATTLIST coverage lines-covered    CDATA #REQUIRED>
      <!ATTLIST coverage lines-valid      CDATA #REQUIRED>
      <!ATTLIST coverage branches-covered CDATA #REQUIRED>
      <!ATTLIST coverage branches-valid   CDATA #REQUIRED>
      <!ATTLIST coverage complexity       CDATA #REQUIRED>
      <!ATTLIST coverage version          CDATA #REQUIRED>
      <!ATTLIST coverage timestamp        CDATA #REQUIRED>

      <!ELEMENT sources (source*)>

      <!ELEMENT source (#PCDATA)>

      <!ELEMENT packages (package*)>

      <!ELEMENT package (classes)>
      <!ATTLIST package name        CDATA #REQUIRED>
      <!ATTLIST package line-rate   CDATA #REQUIRED>
      <!ATTLIST package branch-rate CDATA #REQUIRED>
      <!ATTLIST package complexity  CDATA #REQUIRED>

      <!ELEMENT classes (class*)>

      <!ELEMENT class (methods,lines)>
      <!ATTLIST class name        CDATA #REQUIRED>
      <!ATTLIST class filename    CDATA #REQUIRED>
      <!ATTLIST class line-rate   CDATA #REQUIRED>
      <!ATTLIST class branch-rate CDATA #REQUIRED>
      <!ATTLIST class complexity  CDATA #REQUIRED>

      <!ELEMENT methods (method*)>

      <!ELEMENT method (lines)>
      <!ATTLIST method name        CDATA #REQUIRED>
      <!ATTLIST method signature   CDATA #REQUIRED>
      <!ATTLIST method line-rate   CDATA #REQUIRED>
      <!ATTLIST method branch-rate CDATA #REQUIRED>
      <!ATTLIST method complexity  CDATA #REQUIRED>

      <!ELEMENT lines (line*)>

      <!ELEMENT line (conditions*)>
      <!ATTLIST line number CDATA #REQUIRED>
      <!ATTLIST line hits   CDATA #REQUIRED>
      <!ATTLIST line branch CDATA "false">
      <!ATTLIST line condition-coverage CDATA "100%">

      <!ELEMENT conditions (condition*)>

      <!ELEMENT condition EMPTY>
      <!ATTLIST condition number CDATA #REQUIRED>
      <!ATTLIST condition type CDATA #REQUIRED>
      <!ATTLIST condition coverage CDATA #REQUIRED>
    """
}

private struct LineInfo {
    let lineNumber: String
    let coverage: UInt64
}

private struct FileInfo {
    let path: String
    var lines: [LineInfo]
}

private extension XMLNode {
    static func nodeAttribute(withName name: String, stringValue value: String) -> XMLNode {
        guard let attribute = XMLNode.attribute(withName: name, stringValue: value) as? XMLNode else {
            return XMLNode()
        }

        return attribute
    }
}
