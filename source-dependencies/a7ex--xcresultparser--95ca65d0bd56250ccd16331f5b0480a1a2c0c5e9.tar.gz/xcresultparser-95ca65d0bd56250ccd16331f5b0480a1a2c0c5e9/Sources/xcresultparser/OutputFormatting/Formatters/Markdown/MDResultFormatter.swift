//
//  MDResultFormatter.swift
//
//  Created by Alex da Franca on 31.05.22.
//

import Foundation

public struct MDResultFormatter: XCResultFormatting {
    public var testFailIcon: String {
        return forGithub ? "🔴 " : "🔴&nbsp;&nbsp;"
    }
    public var testPassIcon: String {
        return forGithub ? "🟢 " : "🟢&nbsp;&nbsp;"
    }
    public var testSkipIcon: String {
        return forGithub ? "⚪️ " : "⚪️&nbsp;&nbsp;"
    }
    public var testExpectedFailureIcon: String {
        return forGithub ? "🟡 " : "🟡&nbsp;&nbsp;"
    }
    public var testFlakyIcon: String {
        return forGithub ? "🟠 " : "🟠&nbsp;&nbsp;"
    }

    private let forGithub: Bool

    public init(forGithub: Bool = false) {
        self.forGithub = forGithub
    }

    public func documentPrefix(title: String) -> String {
        return ""
    }

    public var documentSuffix: String {
        return ""
    }

    public var accordionOpenTag: String {
        return ""
    }

    public var accordionCloseTag: String {
        return ""
    }

    public var tableOpenTag: String {
        return ""
    }

    public var tableCloseTag: String {
        return ""
    }

    public var divider: String {
        return "\n---------------------\n"
    }

    public func resultSummaryLine(_ item: String, failed: Bool) -> String {
        return "* " + item.escapingQuotes
    }

    public func resultSummaryLineWarning(_ item: String, hasWarnings: Bool) -> String {
        return "* " + item.escapingQuotes
    }

    public func testConfiguration(_ item: String) -> String {
        return "" // "## " + item.escapingQuotes
    }

    public func testTarget(_ item: String, failed: Bool) -> String {
        return "### " + item.escapingQuotes
    }

    public func testClass(_ item: String, failed: Bool) -> String {
        return "### " + item.escapingQuotes
    }

    public func singleTestItem(_ item: String, failed: Bool) -> String {
        let color = failed ? "red" : "green"
        if forGithub {
            return "$\\textcolor{\(color)}{\\text{\(item.escapingQuotes)}}$"
        } else {
            return "* <span style=\\\"color:\(color)\\\">" + item.escapingQuotes + "</span>"
        }
    }

    public func failedTestItem(_ item: String, message: String) -> String {
        if forGithub {
            return "* $\\textcolor{red}{\\text{\(item.escapingQuotes)}}$\n" +
            "  * $\\textcolor{gray}{\\text{\(message.escapingQuotes)"
        } else {
            return "* <span style=\\\"color:red\\\">" + item.escapingQuotes + "</span><br />" + "\n" +
            "  * <span style=\\\"color:gray\\\">" + message.escapingQuotes + "</span>"
        }
    }

    public func codeCoverageTargetSummary(_ item: String) -> String {
        return item.escapingQuotes
    }

    public func codeCoverageFileSummary(_ item: String) -> String {
        return "## " + item.escapingQuotes
    }

    public func codeCoverageFunctionSummary(_ items: [String]) -> String {
        return "### " + items.joined(separator: " ").escapingQuotes
    }
}

private extension String {
    var escapingQuotes: String {
        return replacingOccurrences(of: "\"", with: "\\\"")
    }
}
