//
//  Issue.swift
//
//  Created by Alex da Franca on 22.05.24.
//

import Foundation

struct Issue: Codable {
    /// Required. A description of the code quality violation.
    let description: String
    /// Required. A unique name representing the static analysis check that emitted this issue.
    let checkName: String
    /// Optional. A unique, deterministic identifier for the specific issue being reported to allow a user
    /// to exclude it from future analyses. For example, an MD5 hash.
    let fingerprint: String
    /// Optional. A Severity string (info, minor, major, critical, or blocker) describing the potential
    /// impact of the issue found..
    let severity: IssueSeverity
    let engineName: String
    /// Required. A Location object representing the place in the source code where the issue was discovered.
    let location: IssueLocation
    /// Required. Must always be "issue".
    let type: IssueType
    /// Required. At least one category indicating the nature of the issue being reported.
    let categories: [IssueCategory]
    /// Optional. A markdown snippet describing the issue, including deeper explanations and links to other resources.
    let content: IssueContent

    enum CodingKeys: String, CodingKey {
        case description, fingerprint, severity, location, type, categories, content
        case checkName = "check_name"
        case engineName = "engine_name"
    }
}

extension Issue {
    init?(
        issueSummary: XCIssue,
        severity: IssueSeverity,
        checkName: String,
        projectRoot: String = "",
        excludedPaths: Set<String> = []
    ) {
        let issueLocationInfo = IssueLocationInfo(with: issueSummary.sourceURL)
        if let filePath = issueLocationInfo?.filePath,
           excludedPaths.isPathExcluded(filePath) {
            return nil
        }
        description = "\(issueSummary.issueType) • \(issueSummary.message)"
        self.checkName = checkName
        self.severity = severity
        engineName = "Xcode Result Bundle Tool"
        location = IssueLocation(issueLocationInfo: issueLocationInfo, projectRoot: projectRoot)
        fingerprint = "\(issueSummary.issueType)-\(issueSummary.message)-\(location.fingerprint)".sha256()
        type = .issue
        categories = []
        content = IssueContent(body: "\(issueSummary.issueType) • \(issueSummary.message)")
    }
}

private extension Set<String> {
    func isPathExcluded(_ path: String) -> Bool {
        for excludedPath in self where path.contains(excludedPath) {
            return true
        }
        return false
    }
}

enum IssueType: String, Codable {
    case issue
}
