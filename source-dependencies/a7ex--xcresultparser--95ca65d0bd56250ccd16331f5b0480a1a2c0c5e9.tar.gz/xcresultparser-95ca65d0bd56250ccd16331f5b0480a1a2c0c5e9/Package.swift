// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "Xcresultparser",
    platforms: [
        .macOS(.v12),
    ],
    products: [
        .executable(
            name: "xcresultparser",
            targets: ["CommandlineTool"]
        ),
        .library(
            name: "XcresultparserLib",
            targets: ["XcresultparserLib"]
        )
    ],
    dependencies: [
        .package(
            url: "https://github.com/apple/swift-argument-parser.git",
            from: "1.8.0"
        )
    ],
    targets: [
        .executableTarget(
            name: "CommandlineTool",
            dependencies: ["XcresultparserLib"],
            path: "CommandlineTool"
        ),
        .target(
            name: "XcresultparserLib",
            dependencies: [
                .product(
                    name: "ArgumentParser",
                    package: "swift-argument-parser"
                ),
            ],
            path: "Sources"
//            plugins: [.plugin(name: "SwiftLintBuildToolPlugin", package: "SwiftLint")]
        ),
        .testTarget(
            name: "XcresultparserTests",
            dependencies: ["XcresultparserLib"],
            resources: [
                .copy("TestAssets/test.xcresult"),
                .copy("TestAssets/test_merged.xcresult"),
                .copy("TestAssets/test_repeated.xcresult"),
                .copy("TestAssets/junit.xml"),
                .copy("TestAssets/junit_merged.xml"),
                .copy("TestAssets/junit_repeated.xml"),
                .copy("TestAssets/sonarTestExecution.xml"),
                .copy("TestAssets/cobertura.xml"),
                .copy("TestAssets/coberturaExcludingDirectory.xml"),
                .copy("TestAssets/warnings.json"),
                .copy("TestAssets/resultWithCompileError.xcresult"),
                .copy("TestAssets/sonarTestExecutionWithProjectRootAbsolute.xml"),
                .copy("TestAssets/sonarTestExecutionWithProjectRootRelative.xml"),
                .copy("TestAssets/parametrized.xcresult"),
                .copy("TestAssets/session_level_failure.xcresult"),
                .copy("TestAssets/junit_session_level_failure.xml"),
                .copy("TestAssets/Test-FlakyFixture.xcresult")
            ]
        )
    ]
)
