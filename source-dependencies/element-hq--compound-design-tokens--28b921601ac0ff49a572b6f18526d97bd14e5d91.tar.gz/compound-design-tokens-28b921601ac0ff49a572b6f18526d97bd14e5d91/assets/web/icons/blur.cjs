var _reactJsxRuntime = require("react/jsx-runtime");
var React = require("react");
function BlurIcon(props, ref) {
  return /*#__PURE__*/_reactJsxRuntime.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    viewBox: "0 0 24 24",
    ref: ref,
    ...props,
    children: /*#__PURE__*/_reactJsxRuntime.jsx("path", {
      d: "M19.793 3.207a1 1 0 0 1 1.414 1.414L4.621 21.207a1 1 0 0 1-1.414-1.414zm0 5a1 1 0 0 1 1.414 1.414L9.621 21.207a1 1 0 0 1-1.414-1.414zm0 5a1 1 0 0 1 1.414 1.414l-6.586 6.586a1 1 0 0 1-1.414-1.414zm0 5a1 1 0 0 1 1.414 1.414l-1.586 1.586a1 1 0 0 1-1.414-1.415zm-4.5-15.5a1 1 0 0 1 1.414 1.414L4.121 16.707a1 1 0 0 1-1.414-1.414zm-5 0a1 1 0 0 1 1.414 1.414l-7.586 7.586a1 1 0 0 1-1.414-1.415zm-5.5.5a1 1 0 0 1 1.414 1.414L4.621 6.207a1 1 0 0 1-1.414-1.415z"
    })
  });
}
;
BlurIcon.displayName = "BlurIcon";
module.exports = React.forwardRef(BlurIcon);