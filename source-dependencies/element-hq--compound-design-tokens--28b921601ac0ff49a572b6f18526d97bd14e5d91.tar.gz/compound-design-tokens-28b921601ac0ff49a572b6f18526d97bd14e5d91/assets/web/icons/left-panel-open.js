import { forwardRef } from "react";
import { jsx as _jsx } from "react/jsx-runtime";
function LeftPanelOpenIcon(props, ref) {
  return /*#__PURE__*/_jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    viewBox: "0 0 24 24",
    ref: ref,
    ...props,
    children: /*#__PURE__*/_jsx("path", {
      d: "M12.5 9.2v5.6q0 .35.3.475t.55-.125l2.45-2.45q.3-.3.3-.7t-.3-.7l-2.45-2.45q-.25-.25-.55-.125t-.3.475M5 19q-.824 0-1.412-.587A1.93 1.93 0 0 1 3 17V7q0-.824.587-1.412A1.93 1.93 0 0 1 5 5h14q.824 0 1.413.588Q21 6.175 21 7v10q0 .824-.587 1.413A1.93 1.93 0 0 1 19 19zm3-2V7H5v10zm2 0h9V7h-9z"
    })
  });
}
;
LeftPanelOpenIcon.displayName = "LeftPanelOpenIcon";
export default forwardRef(LeftPanelOpenIcon);