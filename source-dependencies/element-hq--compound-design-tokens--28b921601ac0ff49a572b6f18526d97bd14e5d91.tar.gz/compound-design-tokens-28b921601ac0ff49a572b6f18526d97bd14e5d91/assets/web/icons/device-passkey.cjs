var _reactJsxRuntime = require("react/jsx-runtime");
var React = require("react");
function DevicePasskeyIcon(props, ref) {
  return /*#__PURE__*/_reactJsxRuntime.jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    viewBox: "0 0 24 24",
    ref: ref,
    ...props,
    children: [/*#__PURE__*/_reactJsxRuntime.jsx("path", {
      fillRule: "evenodd",
      d: "M19.5 9.385q1.458 0 2.48 1.021Q23 11.426 23 12.885q0 1.122-.642 2.027a3.4 3.4 0 0 1-1.691 1.269v.204l.758.759q.088.087.124.189a.7.7 0 0 1 .036.219q0 .116-.036.218a.5.5 0 0 1-.124.19l-.758.759.802 1.02a.6.6 0 0 1 .11.197.5.5 0 0 1 .02.226.57.57 0 0 1-.204.38l-1.501 1.313a.62.62 0 0 1-.409.145.5.5 0 0 1-.212-.044.6.6 0 0 1-.167-.116l-.598-.599a.58.58 0 0 1-.175-.423v-4.637a3.54 3.54 0 0 1-1.875-1.553A3.36 3.36 0 0 1 16 12.885q0-1.458 1.02-2.479 1.022-1.02 2.48-1.021m0 2.334q-.481 0-.824.343a1.12 1.12 0 0 0-.343.823q0 .48.343.824.342.343.824.343t.824-.343q.343-.342.343-.824 0-.48-.343-.823a1.12 1.12 0 0 0-.824-.343",
      clipRule: "evenodd"
    }), /*#__PURE__*/_reactJsxRuntime.jsx("path", {
      d: "M11 13.125q1.532 0 3.025.298a5.25 5.25 0 0 0 1.054 2.737q.542.714 1.254 1.217v3.441q0 .092.007.182H3.125q-.478 0-.802-.323A1.1 1.1 0 0 1 2 19.875V17.85q0-.957.492-1.758A3.3 3.3 0 0 1 3.8 14.869a16.7 16.7 0 0 1 3.544-1.309A15.5 15.5 0 0 1 11 13.125M11 3q1.857 0 3.178 1.322Q15.5 5.644 15.5 7.5t-1.322 3.178T11 12t-3.178-1.322T6.5 7.5t1.322-3.178T11 3"
    })]
  });
}
;
DevicePasskeyIcon.displayName = "DevicePasskeyIcon";
module.exports = React.forwardRef(DevicePasskeyIcon);