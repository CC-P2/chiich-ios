import { forwardRef } from "react";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
function GuestSolidIcon(props, ref) {
  return /*#__PURE__*/_jsxs("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    viewBox: "0 0 24 24",
    ref: ref,
    ...props,
    children: [/*#__PURE__*/_jsx("path", {
      d: "M8.148 4.304a1.04 1.04 0 0 1 1.47 0l1.343 1.344-5.5 5.5a1.04 1.04 0 0 0 0 1.47l5.5 5.5-1.344 1.343a1.04 1.04 0 0 1-1.47 0l-6.843-6.843a1.04 1.04 0 0 1 0-1.47z"
    }), /*#__PURE__*/_jsx("path", {
      d: "M14.383 4.304a1.04 1.04 0 0 1 1.469 0l6.844 6.844a1.04 1.04 0 0 1 0 1.47l-6.844 6.843a1.04 1.04 0 0 1-1.469 0L7.54 12.618a1.04 1.04 0 0 1 0-1.47z"
    })]
  });
}
;
GuestSolidIcon.displayName = "GuestSolidIcon";
export default forwardRef(GuestSolidIcon);